namespace Revit26_Plugin.AutoSlopeByPoint.Models
{
    public class AutoSlopeMetrics
    {
        public int Processed;
        public int Skipped;
        public double HighestElevation;
        public double LongestPath;
    }
}
