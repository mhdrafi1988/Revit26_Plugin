using Autodesk.Revit.DB;

namespace Revit26_Plugin.SmartViewToSheetPlacer.V201.Models
{
    /// <summary>
    /// Represents a titleblock family/type available for new sheets, along with
    /// its real usable placement area (family symbol bounding box, minus the
    /// user-specified margin on all sides). UsableWidthMm/UsableHeightMm are
    /// computed once when the titleblock is selected in Stage 1 and reused
    /// as-is by the packing algorithm in Stage 2.
    /// </summary>
    public class TitleblockOption
    {
        /// <summary>FamilySymbol ElementId for this titleblock type.</summary>
        public ElementId FamilySymbolId { get; }

        /// <summary>Display name, e.g. "A1 Metric - WAMI Standard".</summary>
        public string Name { get; }

        /// <summary>Full sheet width in mm, read from the FamilySymbol's bounding box.</summary>
        public double SheetWidthMm { get; }

        /// <summary>Full sheet height in mm, read from the FamilySymbol's bounding box.</summary>
        public double SheetHeightMm { get; }

        /// <summary>Usable width in mm (SheetWidthMm minus margin on both sides).</summary>
        public double UsableWidthMm { get; private set; }

        /// <summary>Usable height in mm (SheetHeightMm minus margin on both sides).</summary>
        public double UsableHeightMm { get; private set; }

        public TitleblockOption(
            ElementId familySymbolId,
            string name,
            double sheetWidthMm,
            double sheetHeightMm)
        {
            FamilySymbolId = familySymbolId;
            Name = name;
            SheetWidthMm = sheetWidthMm;
            SheetHeightMm = sheetHeightMm;
        }

        /// <summary>
        /// Recomputes UsableWidthMm/UsableHeightMm from the current SheetWidthMm/
        /// SheetHeightMm using the given margin (mm), applied on all four sides.
        /// Call this whenever the user changes the Margin field in Stage 1.
        /// </summary>
        public void ApplyMargin(double marginMm)
        {
            UsableWidthMm = System.Math.Max(0, SheetWidthMm - (marginMm * 2));
            UsableHeightMm = System.Math.Max(0, SheetHeightMm - (marginMm * 2));
        }

        public override string ToString() => Name;
    }
}
