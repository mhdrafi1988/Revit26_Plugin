namespace Revit26_Plugin.SmartViewToSheetPlacer.V201.Models
{
    /// <summary>
    /// Persisted per-tool settings, stored at
    /// %AppData%\Revit26_Plugin\SmartViewToSheetPlacer\settings.json
    /// via System.Text.Json. Loaded on window open, saved on window close.
    /// Only last-used Titleblock name and Margin are remembered for V201.
    /// </summary>
    public class SmartViewToSheetPlacerSettings
    {
        /// <summary>Name of the last-used titleblock type (matched by name on reload; falls back to first available if not found).</summary>
        public string? LastTitleblockName { get; set; }

        /// <summary>Last-used margin value in mm. Defaults to 10 if not yet saved.</summary>
        public double LastMarginMm { get; set; } = 10.0;
    }
}
