using System.Windows;
using System.Windows.Controls;

namespace Revit26_Plugin.SmartViewToSheetPlacer.V201.Views
{
    /// <summary>
    /// Reusable collapsible stage card: numbered circle, title, subtitle,
    /// status badge (Current/Complete/Pending), chevron, and collapsible
    /// content area. Used 4x in SmartViewToSheetPlacerWindow (one per stage).
    /// Expand/collapse state is bound TwoWay from the parent so any stage
    /// can be freely toggled independent of the others (per confirmed
    /// behavior — no forced sequential locking, no auto-collapse of others).
    /// </summary>
    public partial class StageCardControl : UserControl
    {
        public StageCardControl()
        {
            InitializeComponent();
        }

        public static readonly DependencyProperty StageNumberProperty =
            DependencyProperty.Register(nameof(StageNumber), typeof(string), typeof(StageCardControl), new PropertyMetadata("1"));
        public string StageNumber
        {
            get => (string)GetValue(StageNumberProperty);
            set => SetValue(StageNumberProperty, value);
        }

        public static readonly DependencyProperty StageTitleProperty =
            DependencyProperty.Register(nameof(StageTitle), typeof(string), typeof(StageCardControl), new PropertyMetadata(string.Empty));
        public string StageTitle
        {
            get => (string)GetValue(StageTitleProperty);
            set => SetValue(StageTitleProperty, value);
        }

        public static readonly DependencyProperty StageSubtitleProperty =
            DependencyProperty.Register(nameof(StageSubtitle), typeof(string), typeof(StageCardControl), new PropertyMetadata(string.Empty));
        public string StageSubtitle
        {
            get => (string)GetValue(StageSubtitleProperty);
            set => SetValue(StageSubtitleProperty, value);
        }

        public static readonly DependencyProperty StatusLabelProperty =
            DependencyProperty.Register(nameof(StatusLabel), typeof(string), typeof(StageCardControl), new PropertyMetadata("Not Started"));
        public string StatusLabel
        {
            get => (string)GetValue(StatusLabelProperty);
            set => SetValue(StatusLabelProperty, value);
        }

        public static readonly DependencyProperty IsExpandedProperty =
            DependencyProperty.Register(nameof(IsExpanded), typeof(bool), typeof(StageCardControl), new PropertyMetadata(false));
        public bool IsExpanded
        {
            get => (bool)GetValue(IsExpandedProperty);
            set => SetValue(IsExpandedProperty, value);
        }

        public static readonly DependencyProperty IsCompleteProperty =
            DependencyProperty.Register(nameof(IsComplete), typeof(bool), typeof(StageCardControl), new PropertyMetadata(false));
        public bool IsComplete
        {
            get => (bool)GetValue(IsCompleteProperty);
            set => SetValue(IsCompleteProperty, value);
        }

        public static readonly DependencyProperty StageContentProperty =
            DependencyProperty.Register(nameof(StageContent), typeof(object), typeof(StageCardControl), new PropertyMetadata(null));
        public object StageContent
        {
            get => GetValue(StageContentProperty);
            set => SetValue(StageContentProperty, value);
        }
    }
}
