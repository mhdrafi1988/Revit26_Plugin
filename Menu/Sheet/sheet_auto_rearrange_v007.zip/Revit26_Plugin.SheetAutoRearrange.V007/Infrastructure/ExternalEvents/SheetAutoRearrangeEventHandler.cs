using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.SheetAutoRearrange.V007.Core.Engine;
using Revit26_Plugin.SheetAutoRearrange.V007.Core.Models;
using Revit26_Plugin.SheetAutoRearrange.V007.Core.Services;
using Revit26_Plugin.Shared.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Revit26_Plugin.SheetAutoRearrange.V007.Infrastructure.ExternalEvents
{
    public enum SheetAutoRearrangeAction
    {
        LoadViewsOnSheet,
        RunRearrange,
        RedetectRegion
    }

    /// <summary>
    /// Single IExternalEventHandler for Sheet Auto Rearrange.
    ///
    /// V007 CHANGE: adds TallSettings / WideSettings pass-through fields,
    /// forwarded to RearrangeEngine.Run for RunRearrange. No change to the
    /// Load / RedetectRegion paths — tall/wide detection only affects
    /// packing, not region resolution.
    /// </summary>
    public class SheetAutoRearrangeEventHandler : IExternalEventHandler
    {
        public SheetAutoRearrangeAction Action { get; set; }

        public ViewSheet? TargetSheet { get; set; }
        public List<ViewOnSheetItem>? LoadedItems { get; private set; }

        public PlaceableRegion? Region { get; private set; }
        public bool MultipleTitleBlocksFound { get; private set; }
        public bool NoTitleBlockFound { get; private set; }

        public (double minXMm, double minYMm, double maxXMm, double maxYMm)? ManualRegionOverride { get; set; }

        public List<ViewOnSheetItem>? ItemsToProcess { get; set; }
        public RearrangeAlgorithm Algorithm { get; set; }
        public OverflowHandlingMode OverflowHandlingMode { get; set; }
        public GapSettings? GapSettings { get; set; }
        public double RowToleranceMm { get; set; }
        public RowAlignment RowAlignment { get; set; }
        public BlockAlignmentH BlockAlignmentH { get; set; }
        public BlockAlignmentV BlockAlignmentV { get; set; }

        /// <summary>V007 NEW — required for RunRearrange when Algorithm == SheetOrder.</summary>
        public TallWideDetectionSettings? TallSettings { get; set; }

        /// <summary>V007 NEW — required for RunRearrange when Algorithm == SheetOrder.</summary>
        public TallWideDetectionSettings? WideSettings { get; set; }

        public ObservableCollection<LogEntry>? Log { get; set; }
        public RunResult? LastRunResult { get; private set; }

        public event Action? Completed;

        private readonly ViewportCollectorService _collector = new();
        private readonly TitleBlockDetectionService _detectionService = new();
        private readonly RearrangeEngine _engine = new();

        public void Execute(UIApplication app)
        {
            var doc = app.ActiveUIDocument.Document;

            try
            {
                switch (Action)
                {
                    case SheetAutoRearrangeAction.LoadViewsOnSheet:
                        ExecuteLoad(doc);
                        break;

                    case SheetAutoRearrangeAction.RedetectRegion:
                        ExecuteDetectRegion(doc);
                        break;

                    case SheetAutoRearrangeAction.RunRearrange:
                        ExecuteRun(doc);
                        break;
                }
            }
            finally
            {
                Completed?.Invoke();
            }
        }

        private void ExecuteLoad(Document doc)
        {
            if (TargetSheet == null)
            {
                LoadedItems = new List<ViewOnSheetItem>();
                Region = null;
                return;
            }

            LoadedItems = _collector.CollectViewsOnSheet(doc, TargetSheet);
            ExecuteDetectRegion(doc);
        }

        private void ExecuteDetectRegion(Document doc)
        {
            if (TargetSheet == null)
            {
                Region = null;
                return;
            }

            if (ManualRegionOverride.HasValue)
            {
                var m = ManualRegionOverride.Value;
                Region = _detectionService.BuildManualRegion(m.minXMm, m.minYMm, m.maxXMm, m.maxYMm);
                MultipleTitleBlocksFound = false;
                NoTitleBlockFound = false;
                return;
            }

            var detection = _detectionService.Detect(doc, TargetSheet);
            MultipleTitleBlocksFound = detection.MultipleTitleBlocksFound;
            NoTitleBlockFound = detection.NoTitleBlockFound;
            Region = detection.Region;
        }

        private void ExecuteRun(Document doc)
        {
            if (TargetSheet == null || ItemsToProcess == null || GapSettings == null || Log == null
                || TallSettings == null || WideSettings == null)
            {
                LastRunResult = new RunResult { Success = false, ErrorMessage = "Missing required Run parameters." };
                return;
            }

            ExecuteDetectRegion(doc);

            if (MultipleTitleBlocksFound)
            {
                LastRunResult = new RunResult
                {
                    Success = false,
                    ErrorMessage = "Sheet has multiple title blocks — Run skipped, no changes made."
                };
                return;
            }

            LastRunResult = _engine.Run(
                doc,
                TargetSheet,
                ItemsToProcess,
                Algorithm,
                OverflowHandlingMode,
                GapSettings,
                RowToleranceMm,
                RowAlignment,
                BlockAlignmentH,
                BlockAlignmentV,
                TallSettings,
                WideSettings,
                Region,
                Log);
        }

        public string GetName() => "Sheet Auto Rearrange Event Handler";
    }
}
