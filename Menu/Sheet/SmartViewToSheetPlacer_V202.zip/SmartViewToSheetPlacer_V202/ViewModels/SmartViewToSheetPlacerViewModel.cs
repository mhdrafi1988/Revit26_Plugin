using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Data;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.SmartViewToSheetPlacer.V202.Handlers;
using Revit26_Plugin.SmartViewToSheetPlacer.V202.Models;
using System.ComponentModel;

namespace Revit26_Plugin.SmartViewToSheetPlacer.V202.ViewModels
{
    /// <summary>
    /// Single shared ViewModel driving all 4 accordion stages in one window.
    /// Holds state directly as properties (no PlacementSession object needed,
    /// since this is one Window / one ViewModel rather than chained Windows).
    /// </summary>
    public partial class SmartViewToSheetPlacerViewModel : ObservableObject
    {
        private const string ToolName = "SmartViewToSheetPlacer";

        private readonly Document _doc;
        private readonly ExternalEvent _event;
        private readonly SmartViewToSheetPlacerHandler _handler;
        private readonly Dispatcher _dispatcher;
        private SmartViewToSheetPlacerSettings _settings = new();

        public ObservableCollection<ViewInfo> AllViews { get; } = new();
        public ICollectionView ViewsView { get; }
        public ObservableCollection<ViewTypeFilterOption> ViewTypeFilters { get; } = new();
        public ObservableCollection<TitleblockOption> Titleblocks { get; } = new();
        public ObservableCollection<SheetGroup> SuggestedSheets { get; } = new();
        public ObservableCollection<ViewPlacement> AllPlacements { get; } = new();
        public ObservableCollection<LogEntry> Logs { get; } = new();

        // ---- Stage 1 state ----
        [ObservableProperty] private string _viewNameFilter = string.Empty;
        [ObservableProperty] private TitleblockOption? _selectedTitleblock;
        [ObservableProperty] private double _marginMm = 10.0;
        [ObservableProperty] private int _selectedViewCount;
        [ObservableProperty] private int _totalViewCount;
        [ObservableProperty] private bool _stage1Complete;
        public string Stage1StatusLabel => Stage1Complete ? "Complete" : "In Progress";

        // ---- Stage 1: View Name always-visible filter, View Type popover filter (V204) ----
        [ObservableProperty] private bool _isViewTypeFilterOpen;

        /// <summary>True when the View Name filter box has an active (non-empty) value.</summary>
        public bool IsViewNameFilterActive => !string.IsNullOrWhiteSpace(ViewNameFilter);

        /// <summary>True when at least one View Type is excluded from the filter.</summary>
        public bool IsViewTypeFilterActive => ViewTypeFilters.Any(f => !f.IsChecked);

        // ---- Stage 2 state ----
        [ObservableProperty] private int _suggestedSheetCount;
        [ObservableProperty] private bool _stage2Complete;
        public string Stage2StatusLabel => Stage2Complete ? "Complete" : (Stage1Complete ? "In Progress" : "Not Started");

        // ---- Stage 3 state ----
        [ObservableProperty] private bool _stage3Complete;
        public string Stage3StatusLabel => Stage3Complete ? "Complete" : (Stage2Complete ? "In Progress" : "Not Started");

        // ---- Stage 4 state ----
        [ObservableProperty] private int _placedSheetCount;
        [ObservableProperty] private int _placedViewCount;
        [ObservableProperty] private int _failedCount;
        public string Stage4StatusLabel => Stage3Complete ? "In Progress" : "Not Started";

        // ---- Accordion expand/collapse (all freely toggle-able) ----
        [ObservableProperty] private bool _stage1Expanded = true;
        [ObservableProperty] private bool _stage2Expanded;
        [ObservableProperty] private bool _stage3Expanded;
        [ObservableProperty] private bool _stage4Expanded;

        // ---- Busy state ----
        [ObservableProperty] private bool _isBusy;
        [ObservableProperty] private string _busyMessage = string.Empty;

        public SmartViewToSheetPlacerViewModel(UIDocument uiDoc)
        {
            _doc = uiDoc.Document;
            _dispatcher = Dispatcher.CurrentDispatcher;

            _handler = new SmartViewToSheetPlacerHandler(uiDoc);
            _handler.RequestCompleted += OnHandlerRequestCompleted;
            _event = ExternalEvent.Create(_handler);

            ViewsView = CollectionViewSource.GetDefaultView(AllViews);
            ViewsView.Filter = FilterViews;

            LoadSettings();
            RunLoadViews();
        }

        // ─────────────────────────────────────────────────────────────
        // Stage 1: Select Views
        // ─────────────────────────────────────────────────────────────
        private void RunLoadViews()
        {
            IsBusy = true;
            BusyMessage = "Loading project views...";
            Logs.Add(new LogEntry(LogLevel.Info, "Requesting view + titleblock load from Revit."));

            _handler.Request = SmartViewToSheetPlacerRequest.LoadViews;
            _event.Raise();
        }

        [RelayCommand]
        private void RefreshViews() => RunLoadViews();

        [RelayCommand]
        private void SelectAllViews()
        {
            foreach (ViewInfo v in ViewsView)
                v.IsSelected = true;
            RecomputeSelectedCount();
        }

        [RelayCommand]
        private void ClearSelection()
        {
            foreach (ViewInfo v in ViewsView)
                v.IsSelected = false;
            RecomputeSelectedCount();
        }

        public void RecomputeSelectedCount()
        {
            SelectedViewCount = AllViews.Count(v => v.IsSelected);
        }

        /// <summary>Bound to the "All" link inside the View Type header popover.</summary>
        [RelayCommand]
        private void CheckAllViewTypes()
        {
            foreach (var f in ViewTypeFilters)
                f.IsChecked = true;
        }

        /// <summary>Bound to the "None" link inside the View Type header popover.</summary>
        [RelayCommand]
        private void UncheckAllViewTypes()
        {
            foreach (var f in ViewTypeFilters)
                f.IsChecked = false;
        }

        partial void OnStage1CompleteChanged(bool value)
        {
            OnPropertyChanged(nameof(Stage1StatusLabel));
            OnPropertyChanged(nameof(Stage2StatusLabel));
        }

        partial void OnStage2CompleteChanged(bool value)
        {
            OnPropertyChanged(nameof(Stage2StatusLabel));
            OnPropertyChanged(nameof(Stage3StatusLabel));
        }

        partial void OnStage3CompleteChanged(bool value)
        {
            OnPropertyChanged(nameof(Stage3StatusLabel));
            OnPropertyChanged(nameof(Stage4StatusLabel));
        }

        partial void OnViewNameFilterChanged(string value)
        {
            ViewsView.Refresh();
            OnPropertyChanged(nameof(IsViewNameFilterActive));
        }

        private bool FilterViews(object obj)
        {
            if (obj is not ViewInfo v) return false;

            if (!string.IsNullOrWhiteSpace(ViewNameFilter) &&
                v.Name.IndexOf(ViewNameFilter, StringComparison.OrdinalIgnoreCase) < 0)
                return false;

            var typeFilter = ViewTypeFilters.FirstOrDefault(f => f.RevitViewType == v.RevitViewType);
            if (typeFilter != null && !typeFilter.IsChecked)
                return false;

            return true;
        }

        [RelayCommand(CanExecute = nameof(CanGoToStage2))]
        private void NextToStage2()
        {
            RecomputeSelectedCount();
            if (SelectedViewCount == 0)
            {
                Logs.Add(new LogEntry(LogLevel.Warning, "No views selected — cannot proceed to Suggested Placement."));
                return;
            }
            if (SelectedTitleblock == null)
            {
                Logs.Add(new LogEntry(LogLevel.Warning, "No titleblock selected — cannot proceed."));
                return;
            }

            SelectedTitleblock.ApplyMargin(MarginMm);
            SaveSettings();

            RunPacking();

            Stage1Complete = true;
            Stage1Expanded = false;
            Stage2Expanded = true;
        }

        private bool CanGoToStage2() => !IsBusy;

        // ─────────────────────────────────────────────────────────────
        // Stage 2: Suggested Placement (pure calculation, no handler)
        // ─────────────────────────────────────────────────────────────
        private void RunPacking()
        {
            SuggestedSheets.Clear();
            var selected = AllViews.Where(v => v.IsSelected).ToList();

            var packed = GreedyRowPackingService.Pack(selected, SelectedTitleblock!);
            foreach (var sheet in packed)
                SuggestedSheets.Add(sheet);

            AllPlacements.Clear();
            foreach (var sheet in SuggestedSheets)
                foreach (var placement in sheet.Placements)
                {
                    AllPlacements.Add(placement);
                    placement.PropertyChanged += OnPlacementPropertyChanged;
                }

            // Each placement's dropdown may only offer sheets sharing its own
            // ViewType (non-mixed rule) — wire this up now that all sheets exist.
            foreach (var placement in AllPlacements)
            {
                var sameTypeSheets = SuggestedSheets.Where(s => s.RevitViewType == placement.View.RevitViewType);
                placement.AvailableSheets.Clear();
                foreach (var s in sameTypeSheets)
                    placement.AvailableSheets.Add(s);
            }

            SuggestedSheetCount = SuggestedSheets.Count;
            Logs.Add(new LogEntry(LogLevel.Info,
                $"Packing complete: {selected.Count} view(s) across {SuggestedSheetCount} suggested sheet(s)."));

            PlaceViewsCommand.NotifyCanExecuteChanged();
        }

        /// <summary>
        /// Fires whenever any placement's AssignedSheet changes — including
        /// via the Stage 2 DataGrid's "Suggested Sheet #" dropdown binding.
        /// Moves the placement between SheetGroup.Placements collections and
        /// re-validates fit (GeneratedName on both sheets updates
        /// automatically via SheetGroup's own CollectionChanged wiring).
        /// </summary>
        private void OnPlacementPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(ViewPlacement.AssignedSheet)) return;
            if (sender is not ViewPlacement placement) return;
            if (SelectedTitleblock == null) return;

            foreach (var sheet in SuggestedSheets.Where(s => s != placement.AssignedSheet))
                sheet.Placements.Remove(placement);

            if (!placement.AssignedSheet.Placements.Contains(placement))
                placement.AssignedSheet.Placements.Add(placement);

            GreedyRowPackingService.RevalidateFit(placement.AssignedSheet, SelectedTitleblock);
        }

        /// <summary>
        /// Fires whenever a View Type filter checkbox is toggled in the column-header
        /// popover. Re-applies the ViewsView filter predicate and updates the header
        /// icon's "active" styling. Bug fix (V202): previously IsChecked toggles had
        /// no effect on the grid because nothing called ViewsView.Refresh().
        /// </summary>
        private void OnViewTypeFilterOptionPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName != nameof(ViewTypeFilterOption.IsChecked)) return;
            ViewsView.Refresh();
            OnPropertyChanged(nameof(IsViewTypeFilterActive));
        }

        [RelayCommand]
        private void BackToStage1()
        {
            Stage2Expanded = false;
            Stage1Expanded = true;
        }

        [RelayCommand]
        private void NextToStage3()
        {
            Stage2Complete = true;
            Stage2Expanded = false;
            Stage3Expanded = true;
        }

        // ─────────────────────────────────────────────────────────────
        // Stage 3: Confirm & Place
        // ─────────────────────────────────────────────────────────────
        [RelayCommand]
        private void BackToStage2()
        {
            Stage3Expanded = false;
            Stage2Expanded = true;
        }

        [RelayCommand(CanExecute = nameof(CanPlaceViews))]
        private void PlaceViews()
        {
            if (SelectedTitleblock == null) return;

            IsBusy = true;
            BusyMessage = "Creating sheets and placing views...";

            _handler.TitleblockFamilySymbolId = SelectedTitleblock.FamilySymbolId;
            _handler.MarginMm = MarginMm;
            _handler.SheetsToPlace = SuggestedSheets.ToList();
            _handler.Request = SmartViewToSheetPlacerRequest.PlaceViews;
            _event.Raise();
        }

        private bool CanPlaceViews() => !IsBusy && SuggestedSheets.Count > 0;

        [RelayCommand]
        private void ExportLogs()
        {
            try
            {
                var dialog = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*",
                    FileName = $"{ToolName}_Logs_{DateTime.Now:yyyy-MM-dd_HH-mm}.txt",
                    InitialDirectory = _lastExportFolder ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                };

                if (dialog.ShowDialog() == true)
                {
                    var text = string.Join(Environment.NewLine, Logs.Select(l => l.ToString()));
                    File.WriteAllText(dialog.FileName, text);
                    _lastExportFolder = Path.GetDirectoryName(dialog.FileName);
                    Logs.Add(new LogEntry(LogLevel.Success, $"Logs exported to: {dialog.FileName}"));
                }
            }
            catch (Exception ex)
            {
                Logs.Add(new LogEntry(LogLevel.Error, $"Failed to export logs: {ex.Message}"));
            }
        }

        private string? _lastExportFolder;

        // ─────────────────────────────────────────────────────────────
        // Stage 4: Placement Complete
        // ─────────────────────────────────────────────────────────────
        [RelayCommand]
        private void SelectAllSheetsToOpen()
        {
            foreach (var s in SuggestedSheets)
                s.OpenAfterPlacement = true;
        }

        [RelayCommand]
        private void ClearSheetsToOpen()
        {
            foreach (var s in SuggestedSheets)
                s.OpenAfterPlacement = false;
        }

        [RelayCommand]
        private void OpenSelectedAndClose()
        {
            var idsToOpen = SuggestedSheets
                .Where(s => s.OpenAfterPlacement && s.CreatedSheetId != null)
                .Select(s => s.CreatedSheetId!)
                .ToList();

            if (idsToOpen.Count == 0)
            {
                CloseRequested?.Invoke();
                return;
            }

            IsBusy = true;
            BusyMessage = "Opening selected sheets...";
            _handler.SheetIdsToOpen = idsToOpen;
            _handler.Request = SmartViewToSheetPlacerRequest.OpenSheets;
            _event.Raise();
        }

        [RelayCommand]
        private void Close() => CloseRequested?.Invoke();

        /// <summary>Raised when the ViewModel wants the owning Window to close.</summary>
        public event Action? CloseRequested;

        // ─────────────────────────────────────────────────────────────
        // Handler completion callback (always marshal back via Dispatcher,
        // since ExternalEvent callbacks may not be on the WPF UI thread
        // depending on Revit's internal scheduling).
        // ─────────────────────────────────────────────────────────────
        private void OnHandlerRequestCompleted()
        {
            _dispatcher.Invoke(() =>
            {
                IsBusy = false;
                BusyMessage = string.Empty;

                foreach (var log in _handler.Logs)
                    Logs.Add(log);
                _handler.Logs.Clear();

                switch (_handler.Request)
                {
                    case SmartViewToSheetPlacerRequest.LoadViews:
                        HandleLoadViewsCompleted();
                        break;
                    case SmartViewToSheetPlacerRequest.PlaceViews:
                        HandlePlaceViewsCompleted();
                        break;
                    case SmartViewToSheetPlacerRequest.OpenSheets:
                        CloseRequested?.Invoke();
                        break;
                }

                NextToStage2Command.NotifyCanExecuteChanged();
                PlaceViewsCommand.NotifyCanExecuteChanged();
            });
        }

        private void HandleLoadViewsCompleted()
        {
            AllViews.Clear();
            foreach (var v in _handler.LoadedViews)
                AllViews.Add(v);
            TotalViewCount = AllViews.Count;

            // Preserve each type's checked state across a Refresh (match by RevitViewType)
            // so re-loading views doesn't silently clear a filter the user had set.
            var previousCheckedState = ViewTypeFilters.ToDictionary(f => f.RevitViewType, f => f.IsChecked);

            // Unsubscribe from any options left over from a prior load (e.g. Refresh),
            // mirroring the AllPlacements subscribe/unsubscribe pattern used below.
            foreach (var existing in ViewTypeFilters)
                existing.PropertyChanged -= OnViewTypeFilterOptionPropertyChanged;

            ViewTypeFilters.Clear();
            foreach (var vt in AllViews.Select(v => v.RevitViewType).Distinct())
            {
                var option = new ViewTypeFilterOption(vt, FriendlyLabel(vt));
                if (previousCheckedState.TryGetValue(vt, out var wasChecked))
                    option.IsChecked = wasChecked;
                option.PropertyChanged += OnViewTypeFilterOptionPropertyChanged;
                ViewTypeFilters.Add(option);
            }
            OnPropertyChanged(nameof(IsViewTypeFilterActive));

            Titleblocks.Clear();
            foreach (var tb in _handler.LoadedTitleblocks)
                Titleblocks.Add(tb);

            // Restore last-used titleblock by name, falling back to first available.
            SelectedTitleblock = Titleblocks.FirstOrDefault(t => t.Name == _settings.LastTitleblockName)
                                 ?? Titleblocks.FirstOrDefault();

            RecomputeSelectedCount();
        }

        private void HandlePlaceViewsCompleted()
        {
            if (!_handler.LastRunSucceeded)
            {
                Logs.Add(new LogEntry(LogLevel.Error, "Placement did not complete successfully. See log above."));
                return;
            }

            PlacedSheetCount = SuggestedSheets.Count(s => s.CreatedSheetId != null);
            PlacedViewCount = _handler.PlacedCount;
            FailedCount = _handler.FailedCount;

            Stage3Complete = true;
            Stage3Expanded = false;
            Stage4Expanded = true;

            AutoSaveLogs();
        }

        /// <summary>
        /// Auto-saves logs on completion (in addition to the manual Export
        /// Logs button), per convention. Prompts for a folder on first save
        /// this session, then reuses the last-used folder silently.
        /// </summary>
        private void AutoSaveLogs()
        {
            try
            {
                string folder = _lastExportFolder ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (_lastExportFolder == null)
                {
                    var selected = Handlers.DialogService.SelectFolder(folder);
                    if (!string.IsNullOrEmpty(selected))
                        folder = selected;
                    _lastExportFolder = folder;
                }

                string fileName = $"{ToolName}_Logs_{DateTime.Now:yyyy-MM-dd_HH-mm}.txt";
                string fullPath = Path.Combine(folder, fileName);
                var text = string.Join(Environment.NewLine, Logs.Select(l => l.ToString()));
                File.WriteAllText(fullPath, text);
                Logs.Add(new LogEntry(LogLevel.Info, $"Logs auto-saved to: {fullPath}"));
            }
            catch (Exception ex)
            {
                Logs.Add(new LogEntry(LogLevel.Warning, $"Auto-save of logs failed: {ex.Message}"));
            }
        }

        private static string FriendlyLabel(ViewType t) => t switch
        {
            ViewType.FloorPlan => "Floor Plan",
            ViewType.CeilingPlan => "Ceiling Plan",
            ViewType.Elevation => "Elevation",
            ViewType.Section => "Section",
            ViewType.ThreeD => "3D View",
            ViewType.DraftingView => "Drafting",
            ViewType.AreaPlan => "Area Plan",
            ViewType.EngineeringPlan => "Structural Plan",
            ViewType.Detail => "Detail",
            ViewType.Legend => "Legend",
            _ => t.ToString()
        };

        // ─────────────────────────────────────────────────────────────
        // Settings persistence (per convention:
        // %AppData%\Revit26_Plugin\SmartViewToSheetPlacer\settings.json)
        // ─────────────────────────────────────────────────────────────
        private static string SettingsPath =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Revit26_Plugin", ToolName, "settings.json");

        private void LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsPath))
                {
                    var json = File.ReadAllText(SettingsPath);
                    _settings = JsonSerializer.Deserialize<SmartViewToSheetPlacerSettings>(json) ?? new();
                    MarginMm = _settings.LastMarginMm;
                }
            }
            catch
            {
                _settings = new SmartViewToSheetPlacerSettings();
            }
        }

        private void SaveSettings()
        {
            try
            {
                _settings.LastTitleblockName = SelectedTitleblock?.Name;
                _settings.LastMarginMm = MarginMm;

                var dir = Path.GetDirectoryName(SettingsPath)!;
                Directory.CreateDirectory(dir);
                var json = JsonSerializer.Serialize(_settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsPath, json);
            }
            catch (Exception ex)
            {
                Logs.Add(new LogEntry(LogLevel.Warning, $"Could not save settings: {ex.Message}"));
            }
        }
    }
}
