using System.Windows;

namespace Revit26_Plugin.SmartViewToSheetPlacer.V202.Views
{
    /// <summary>
    /// Code-behind is intentionally minimal — all behavior is driven by
    /// SmartViewToSheetPlacerViewModel via data binding and commands (MVVM).
    /// The window closes only when the ViewModel raises CloseRequested
    /// (wired in SmartViewToSheetPlacerCommand), never automatically.
    /// </summary>
    public partial class SmartViewToSheetPlacerWindow : Window
    {
        public SmartViewToSheetPlacerWindow()
        {
            InitializeComponent();
        }

        private void StageCardControl_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
