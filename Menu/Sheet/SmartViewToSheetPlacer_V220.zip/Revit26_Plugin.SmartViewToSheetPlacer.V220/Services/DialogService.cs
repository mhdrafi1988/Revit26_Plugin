using System;
using System.IO;
using System.Windows;

namespace Revit26_Plugin.SmartViewToSheetPlacer.V220.Services
{
    /// <summary>
    /// Pure-WPF dialog helper — no System.Windows.Forms dependency. WPF has
    /// no built-in folder-picker, so SelectFolder shows a small popup Window
    /// with a text box + Browse button; Browse uses Microsoft.Win32's
    /// OpenFileDialog with ValidateNames=false/CheckFileExists=true as a
    /// folder-picking trick (user picks any file, we take its directory).
    /// Duplicated per-tool from AutoSlopeByPoint.V025's DialogService per
    /// project convention (kept local rather than promoted to Shared).
    /// V213: moved from Handlers/ to Services/ — this is a UI utility, not
    /// a Revit-API handler.
    /// </summary>
    public static class DialogService
    {
        public static string? SelectFolder(string initialPath = "")
        {
            try
            {
                var dialog = new Window
                {
                    Title = "Select Folder for Log Exports",
                    Width = 420,
                    Height = 150,
                    WindowStartupLocation = WindowStartupLocation.CenterScreen
                };

                var stackPanel = new System.Windows.Controls.StackPanel { Margin = new Thickness(20) };
                var textBox = new System.Windows.Controls.TextBox
                {
                    Text = initialPath,
                    Margin = new Thickness(0, 0, 0, 10)
                };
                var buttonPanel = new System.Windows.Controls.DockPanel();
                var browseButton = new System.Windows.Controls.Button { Content = "Browse", Width = 75, Margin = new Thickness(0, 0, 10, 0) };
                var okButton = new System.Windows.Controls.Button { Content = "OK", Width = 75, Margin = new Thickness(0, 0, 10, 0) };
                var cancelButton = new System.Windows.Controls.Button { Content = "Cancel", Width = 75 };

                string? result = null;
                bool dialogResult = false;

                browseButton.Click += (s, e) =>
                {
                    var openDialog = new Microsoft.Win32.OpenFileDialog
                    {
                        Filter = "All files (*.*)|*.*",
                        InitialDirectory = textBox.Text,
                        Title = "Select a folder (choose any file in the folder)",
                        CheckFileExists = true,
                        ValidateNames = false
                    };
                    if (openDialog.ShowDialog() == true)
                        textBox.Text = Path.GetDirectoryName(openDialog.FileName);
                };
                okButton.Click += (s, e) => { result = textBox.Text; dialogResult = true; dialog.Close(); };
                cancelButton.Click += (s, e) => { dialogResult = false; dialog.Close(); };

                buttonPanel.Children.Add(browseButton);
                buttonPanel.Children.Add(okButton);
                buttonPanel.Children.Add(cancelButton);

                stackPanel.Children.Add(new System.Windows.Controls.TextBlock { Text = "Enter or select folder path:", Margin = new Thickness(0, 0, 0, 5) });
                stackPanel.Children.Add(textBox);
                stackPanel.Children.Add(buttonPanel);
                dialog.Content = stackPanel;

                dialog.ShowDialog();
                return dialogResult ? result : null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error selecting folder: {ex.Message}\n\nUsing default folder.",
                    "Folder Selection Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return initialPath;
            }
        }
    }
}
