﻿using System.Windows;
using Revit26_Plugin.CreaserAdv.V071.ViewModels;

namespace Revit26_Plugin.CreaserAdv.V071.Views
{
    public partial class CreaserAdvWindow : Window
    {
        public CreaserAdvWindow(CreaserAdvViewModel viewModel)
        {
            this.InitializeComponent();
            DataContext = viewModel;
        }
    }
}
