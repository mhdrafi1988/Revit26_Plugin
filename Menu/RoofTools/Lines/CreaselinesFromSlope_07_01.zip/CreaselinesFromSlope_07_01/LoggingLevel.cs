﻿using System;

namespace Revit26_Plugin.CreaserAdv.V071.Services
{
    /// <summary>
    /// Log severity levels.
    /// </summary>
    public enum LoggingLevel
    {
        Info,
        Warning,
        Error
    }
}
