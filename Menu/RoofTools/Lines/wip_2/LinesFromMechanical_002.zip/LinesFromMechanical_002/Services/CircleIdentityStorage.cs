using Autodesk.Revit.DB;
using Autodesk.Revit.DB.ExtensibleStorage;
using System;
using System.Linq;

namespace Revit26_Plugin.LinesFromMechanical.V002.Services;

public static class CircleIdentityStorage
{
    private static readonly Guid SchemaGuid =
        new("70F4544F-7C59-4D76-A31A-F5D5B2C70001");

    private const string SchemaName = "LinkedMechanicalEquipmentCircleIdentity";
    private const string SourceKeyField = "SourceKey";

    private static Schema? _cachedSchema = null;

    /// <summary>
    /// Call this once before any transaction is opened to ensure the schema
    /// is built and cached outside of any active transaction context.
    /// </summary>
    public static void Initialize()
    {
        // Force schema creation now, outside of any transaction.
        // SchemaBuilder.Finish() must never be called inside an open transaction.
        GetOrCreateSchema();
    }

    public static Schema GetOrCreateSchema()
    {
        if (_cachedSchema != null)
            return _cachedSchema;

        Schema? schema = Schema.Lookup(SchemaGuid);
        if (schema != null)
        {
            _cachedSchema = schema;
            return schema;
        }

        var builder = new SchemaBuilder(SchemaGuid);
        builder.SetSchemaName(SchemaName);
        builder.SetReadAccessLevel(AccessLevel.Public);
        builder.SetWriteAccessLevel(AccessLevel.Public);
        builder.AddSimpleField(SourceKeyField, typeof(string));

        schema = builder.Finish();
        _cachedSchema = schema;
        return schema;
    }

    public static string BuildSourceKey(RevitLinkInstance linkInstance, Element linkedElement)
    {
        return $"{linkInstance.UniqueId}|{linkedElement.UniqueId}";
    }

    public static bool DetailCurveExistsForSource(Document doc, View view, string sourceKey)
    {
        // Schema must already be cached by Initialize() before we reach here.
        // GetOrCreateSchema() is safe to call here because the schema is already
        // built � it will only do a cache lookup, not call SchemaBuilder.Finish().
        Schema schema = GetOrCreateSchema();

        return new FilteredElementCollector(doc, view.Id)
            .OfClass(typeof(CurveElement))
            .WhereElementIsNotElementType()
            .Cast<CurveElement>()
            .Any(curveElement =>
            {
                Entity entity = curveElement.GetEntity(schema);
                return entity.IsValid()
                       && entity.Get<string>(SourceKeyField) == sourceKey;
            });
    }

    public static void AttachSourceKey(Element element, string sourceKey)
    {
        Schema schema = GetOrCreateSchema();

        var entity = new Entity(schema);
        entity.Set(SourceKeyField, sourceKey);

        element.SetEntity(entity);
    }
}