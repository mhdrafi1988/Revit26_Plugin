using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.LinesFromMechanical.V002.Services;
using Revit26_Plugin.LinesFromMechanical.V002.ViewModels;
using Revit26_Plugin.LinesFromMechanical.V002.Views;
using System;
using System.Windows;

namespace Revit26_Plugin.LinesFromMechanical.V002.Commands;

[Transaction(TransactionMode.Manual)]
public sealed class CreateLinkedMechanicalCirclesCommand : IExternalCommand
{
    public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
    {
        UIDocument uiDoc = commandData.Application.ActiveUIDocument;
        Document doc = uiDoc.Document;
        View activeView = doc.ActiveView;

        if (activeView is not ViewPlan viewPlan)
        {
            message = "Active view must be a host plan view.";
            return Result.Failed;
        }

        if (activeView.IsTemplate)
        {
            message = "Active view cannot be a view template.";
            return Result.Failed;
        }

        try
        {
            // Initialize schema BEFORE any transaction is opened.
            // No longer needs a Document parameter � schema creation
            // requires no transaction and no document context.
            CircleIdentityStorage.Initialize();

            var viewModel = new MainWindowViewModel(uiDoc, doc, viewPlan);
            var window = new MainWindow
            {
                DataContext = viewModel
            };

            bool? result = window.ShowDialog();

            return result == true ? Result.Succeeded : Result.Cancelled;
        }
        catch (Exception ex)
        {
            message = ex.Message;
            return Result.Failed;
        }
    }
}