using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.LinesFromMechanical.V002.Models;
using Revit26_Plugin.LinesFromMechanical.V002.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using RevitColor = Autodesk.Revit.DB.Color;
using WpfColor = System.Windows.Media.Color;

namespace Revit26_Plugin.LinesFromMechanical.V002.ViewModels;

public class MainWindowViewModel : INotifyPropertyChanged, IDisposable
{
    private readonly UIDocument _uiDoc;
    private readonly Document _doc;
    private readonly ViewPlan _activePlanView;
    private readonly LinkedMechanicalCircleService _service;
    private readonly List<Element> _currentlyHighlightedElements;

    private bool _isProcessing;
    private string _activeViewName;
    private bool _isValidView;
    private string _viewWarning;
    private ObservableCollection<LinkInfo> _availableLinks;
    private LinkInfo _selectedLink;
    private ObservableCollection<string> _availableFamilies;
    private string _selectedFamily;
    private int _previewCount;
    private double _radiusMm;
    private WpfColor _selectedColor;
    private ObservableCollection<string> _logMessages;
    private bool _canProcess;

    public MainWindowViewModel(UIDocument uiDoc, Document doc, ViewPlan activePlanView)
    {
        _uiDoc = uiDoc;
        _doc = doc;
        _activePlanView = activePlanView;
        _service = new LinkedMechanicalCircleService();
        _service.OnLogMessage += AddLogMessage;
        _currentlyHighlightedElements = new List<Element>();

        AvailableLinks = new ObservableCollection<LinkInfo>();
        AvailableFamilies = new ObservableCollection<string>();
        LogMessages = new ObservableCollection<string>();

        RadiusMm = 400.0;
        SelectedColor = Colors.Red;

        HighlightCommand = new RelayCommand(_ => ExecuteHighlight(), _ => CanExecuteHighlight());
        ProcessCommand = new RelayCommand(_ => ExecuteProcess(), _ => CanExecuteProcess());
        CancelCommand = new RelayCommand(_ => ExecuteCancel());
        CopyLogCommand = new RelayCommand(_ => ExecuteCopyLog(), _ => LogMessages.Count > 0);

        InitializeViewValidation();
        LoadVisibleLinks();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    // Properties
    public string ActiveViewName
    {
        get => _activeViewName;
        set { _activeViewName = value; OnPropertyChanged(); }
    }

    public bool IsValidView
    {
        get => _isValidView;
        set { _isValidView = value; OnPropertyChanged(); OnPropertyChanged(nameof(ShowViewWarning)); }
    }

    public string ViewWarning
    {
        get => _viewWarning;
        set { _viewWarning = value; OnPropertyChanged(); OnPropertyChanged(nameof(ShowViewWarning)); }
    }

    public bool ShowViewWarning => !IsValidView && !string.IsNullOrEmpty(ViewWarning);

    public bool IsProcessing
    {
        get => _isProcessing;
        set { _isProcessing = value; OnPropertyChanged(); OnPropertyChanged(nameof(IsNotProcessing)); UpdateCanProcess(); }
    }

    public bool IsNotProcessing => !IsProcessing;

    public ObservableCollection<LinkInfo> AvailableLinks
    {
        get => _availableLinks;
        set { _availableLinks = value; OnPropertyChanged(); }
    }

    public LinkInfo SelectedLink
    {
        get => _selectedLink;
        set
        {
            _selectedLink = value;
            OnPropertyChanged();
            LoadFamiliesForSelectedLink();
            UpdatePreviewCount();
            UpdateCanProcess();
        }
    }

    public ObservableCollection<string> AvailableFamilies
    {
        get => _availableFamilies;
        set { _availableFamilies = value; OnPropertyChanged(); }
    }

    public string SelectedFamily
    {
        get => _selectedFamily;
        set
        {
            _selectedFamily = value;
            OnPropertyChanged();
            UpdatePreviewCount();
            UpdateCanProcess();
        }
    }

    public int PreviewCount
    {
        get => _previewCount;
        set { _previewCount = value; OnPropertyChanged(); OnPropertyChanged(nameof(ShowPreviewCount)); }
    }

    public bool ShowPreviewCount => PreviewCount > 0;

    public double RadiusMm
    {
        get => _radiusMm;
        set
        {
            if (value > 0)
            {
                _radiusMm = value;
                OnPropertyChanged();
                UpdateCanProcess();
            }
        }
    }

    public WpfColor SelectedColor
    {
        get => _selectedColor;
        set { _selectedColor = value; OnPropertyChanged(); }
    }

    public ObservableCollection<string> LogMessages
    {
        get => _logMessages;
        set { _logMessages = value; OnPropertyChanged(); }
    }

    public bool CanProcess
    {
        get => _canProcess;
        set { _canProcess = value; OnPropertyChanged(); }
    }

    // Commands
    public ICommand HighlightCommand { get; }
    public ICommand ProcessCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand CopyLogCommand { get; }

    private void InitializeViewValidation()
    {
        ActiveViewName = _activePlanView.Name;
        IsValidView = true;
        ViewWarning = string.Empty;
    }

    private void LoadVisibleLinks()
    {
        AvailableLinks.Clear();

        var collector = new FilteredElementCollector(_doc, _activePlanView.Id);
        var linkInstances = collector.OfClass(typeof(RevitLinkInstance))
            .WhereElementIsNotElementType()
            .Cast<RevitLinkInstance>()
            .ToList();

        foreach (var link in linkInstances)
        {
            var linkDoc = link.GetLinkDocument();
            if (linkDoc != null)
            {
                AvailableLinks.Add(new LinkInfo
                {
                    Id = link.Id,
                    Name = link.Name,
                    Instance = link
                });
            }
        }

        if (AvailableLinks.Count == 0 && IsValidView)
        {
            AddLogMessage("Warning: No visible loaded links found in active view.");
        }

        UpdateCanProcess();
    }

    private void LoadFamiliesForSelectedLink()
    {
        AvailableFamilies.Clear();
        SelectedFamily = null;

        if (SelectedLink?.Instance == null)
            return;

        var linkDoc = SelectedLink.Instance.GetLinkDocument();
        if (linkDoc == null)
            return;

        var familyNames = new HashSet<string>();

        var collector = new FilteredElementCollector(linkDoc)
            .OfCategory(BuiltInCategory.OST_MechanicalEquipment)
            .WhereElementIsNotElementType()
            .Cast<FamilyInstance>();

        foreach (var instance in collector)
        {
            var familyName = instance.Symbol?.Family?.Name;
            if (!string.IsNullOrEmpty(familyName))
                familyNames.Add(familyName);
        }

        foreach (var name in familyNames.OrderBy(n => n))
        {
            AvailableFamilies.Add(name);
        }
    }

    private void UpdatePreviewCount()
    {
        if (SelectedLink?.Instance == null || string.IsNullOrEmpty(SelectedFamily))
        {
            PreviewCount = 0;
            return;
        }

        PreviewCount = _service.GetPreviewCount(_doc, _activePlanView, SelectedLink.Instance, SelectedFamily);
    }

    private void ExecuteHighlight()
    {
        ClearHighlight();

        if (SelectedLink?.Instance == null || string.IsNullOrEmpty(SelectedFamily))
            return;

        var elements = _service.GetPreviewElements(_doc, _activePlanView, SelectedLink.Instance, SelectedFamily);
        _currentlyHighlightedElements.AddRange(elements);

        if (elements.Any())
        {
            _uiDoc.Selection.SetElementIds(elements.Select(e => e.Id).ToList());
            AddLogMessage($"Highlighted {elements.Count} elements in the active view.");
        }
        else
        {
            AddLogMessage("No elements found to highlight.");
        }
    }

    private void ClearHighlight()
    {
        _uiDoc.Selection.SetElementIds(new List<ElementId>());
        _currentlyHighlightedElements.Clear();
    }

    private bool CanExecuteHighlight()
    {
        return !IsProcessing && SelectedLink != null && !string.IsNullOrEmpty(SelectedFamily) && PreviewCount > 0;
    }

    private void ExecuteProcess()
    {
        if (SelectedLink?.Instance == null || string.IsNullOrEmpty(SelectedFamily))
            return;

        IsProcessing = true;
        ClearLog();

        AddLogMessage("=== Operation Started ===");
        AddLogMessage($"Selected Link: {SelectedLink.Name}");
        AddLogMessage($"Selected Family: {SelectedFamily}");
        AddLogMessage($"Radius: {RadiusMm} mm");
        AddLogMessage($"Color: R={SelectedColor.R}, G={SelectedColor.G}, B={SelectedColor.B}");

        var revitColor = new RevitColor(
            SelectedColor.R,
            SelectedColor.G,
            SelectedColor.B);

        try
        {
            var summary = _service.CreateCircles(
                _doc,
                _activePlanView,
                SelectedLink.Instance,
                SelectedFamily,
                RadiusMm,
                revitColor);

            AddLogMessage("");
            AddLogMessage("=== Operation Complete ===");
            AddLogMessage(summary.ToDisplayText());
        }
        catch (Exception ex)
        {
            AddLogMessage($"ERROR: {ex.Message}");
        }
        finally
        {
            IsProcessing = false;
            ClearHighlight();
        }
    }

    private bool CanExecuteProcess()
    {
        return IsValidView && !IsProcessing && SelectedLink != null && !string.IsNullOrEmpty(SelectedFamily) && PreviewCount > 0 && RadiusMm > 0;
    }

    private void UpdateCanProcess()
    {
        CanProcess = IsValidView && !IsProcessing && SelectedLink != null && !string.IsNullOrEmpty(SelectedFamily) && PreviewCount > 0 && RadiusMm > 0;
    }

    private void ExecuteCancel()
    {
        ClearHighlight();
        Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w.DataContext == this)?.Close();
    }

    private void ExecuteCopyLog()
    {
        var logText = string.Join(Environment.NewLine, LogMessages);
        System.Windows.Clipboard.SetText(logText);
        AddLogMessage("Log copied to clipboard.");
    }

    private void AddLogMessage(string message)
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            LogMessages.Add(message);
        });
    }

    private void ClearLog()
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            LogMessages.Clear();
        });
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public void Dispose()
    {
        _service.OnLogMessage -= AddLogMessage;
        ClearHighlight();
    }
}

public class LinkInfo
{
    public ElementId Id { get; set; }
    public string Name { get; set; }
    public RevitLinkInstance Instance { get; set; }

    public override string ToString() => Name;
}