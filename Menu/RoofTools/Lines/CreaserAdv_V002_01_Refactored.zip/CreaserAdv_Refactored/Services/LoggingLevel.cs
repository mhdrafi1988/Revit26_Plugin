// ==================================
// File: LoggingLevel.cs
// Namespace: Revit26_Plugin.CreaserAdv_V002_01
// ==================================

namespace Revit26_Plugin.CreaserAdv_V002_01.Services
{
    /// <summary>Log severity levels.</summary>
    public enum LoggingLevel
    {
        Info,
        Warning,
        Error
    }
}
