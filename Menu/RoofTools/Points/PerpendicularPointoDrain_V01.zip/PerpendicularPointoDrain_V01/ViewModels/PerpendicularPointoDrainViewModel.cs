using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.PDCV3.Models;
using Revit26_Plugin.PDCV3.Services;
using Revit26_Plugin.PerpendicularPointoDrain.V01.Models;
using Revit26_Plugin.PerpendicularPointoDrain.V01.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Revit26_Plugin.PerpendicularPointoDrain.V01.ViewModels
{
    public class PerpendicularPointoDrainViewModel : ObservableObject
    {
        private readonly Document    _doc;
        private readonly UIDocument  _uidoc;
        private readonly RoofBase    _roof;

        // Loop extraction is reused directly from PDCV3 — same assembly, no duplication needed.
        private readonly RoofGeometryService       _geometryService   = new RoofGeometryService();
        private readonly DrainGroupingService      _groupingService   = new DrainGroupingService();
        private readonly DrainPickService          _pickService       = new DrainPickService();
        private readonly BoundaryProjectionService _projectionService = new BoundaryProjectionService();

        private List<DrainGroupModel>    _drainGroups    = new List<DrainGroupModel>();
        private List<LoopBoundaryModel>  _loopBoundaries = new List<LoopBoundaryModel>();

        // ── Drain method ─────────────────────────────────────────────────────────
        public List<string> DrainMethods { get; } = new List<string>
        {
            "Pick points on screen",
            "Select drain family instances",
            "Reuse AutoSlope detection logic"
        };

        private string _selectedDrainMethod;
        public string SelectedDrainMethod
        {
            get => _selectedDrainMethod;
            set => SetProperty(ref _selectedDrainMethod, value);
        }

        private string _drainSummary = "No drains detected yet.";
        public string DrainSummary
        {
            get => _drainSummary;
            set => SetProperty(ref _drainSummary, value);
        }

        // ── Tolerance ─────────────────────────────────────────────────────────────
        private double _toleranceMm = 500;
        public double ToleranceMm
        {
            get => _toleranceMm;
            set => SetProperty(ref _toleranceMm, value);
        }

        // ── Direction toggles (Project North = +Y) ───────────────────────────────
        private bool _isNorthEnabled = true;
        public bool IsNorthEnabled { get => _isNorthEnabled; set => SetProperty(ref _isNorthEnabled, value); }

        private bool _isNortheastEnabled = true;
        public bool IsNortheastEnabled { get => _isNortheastEnabled; set => SetProperty(ref _isNortheastEnabled, value); }

        private bool _isEastEnabled = true;
        public bool IsEastEnabled { get => _isEastEnabled; set => SetProperty(ref _isEastEnabled, value); }

        private bool _isSoutheastEnabled = true;
        public bool IsSoutheastEnabled { get => _isSoutheastEnabled; set => SetProperty(ref _isSoutheastEnabled, value); }

        private bool _isSouthEnabled = true;
        public bool IsSouthEnabled { get => _isSouthEnabled; set => SetProperty(ref _isSouthEnabled, value); }

        private bool _isSouthwestEnabled = true;
        public bool IsSouthwestEnabled { get => _isSouthwestEnabled; set => SetProperty(ref _isSouthwestEnabled, value); }

        private bool _isWestEnabled = true;
        public bool IsWestEnabled { get => _isWestEnabled; set => SetProperty(ref _isWestEnabled, value); }

        private bool _isNorthwestEnabled = true;
        public bool IsNorthwestEnabled { get => _isNorthwestEnabled; set => SetProperty(ref _isNorthwestEnabled, value); }

        // ── Loop / vertex options ─────────────────────────────────────────────────
        private bool _includeInteriorLoops = true;
        public bool IncludeInteriorLoops { get => _includeInteriorLoops; set => SetProperty(ref _includeInteriorLoops, value); }

        private bool _snapToVertex = true;
        public bool SnapToVertex { get => _snapToVertex; set => SetProperty(ref _snapToVertex, value); }

        // ── Results / log ─────────────────────────────────────────────────────────
        public ObservableCollection<ProjectionResultModel> Results { get; } = new ObservableCollection<ProjectionResultModel>();

        private string _logText = string.Empty;
        public string LogText
        {
            get => _logText;
            set => SetProperty(ref _logText, value);
        }

        // ── Commands ──────────────────────────────────────────────────────────────
        public IRelayCommand DetectDrainsCommand { get; }
        public IRelayCommand AnalyzeCommand       { get; }
        public IRelayCommand ApplyCommand          { get; }

        // ─────────────────────────────────────────────────────────────────────────
        public PerpendicularPointoDrainViewModel(Document doc, UIDocument uidoc, RoofBase roof)
        {
            _doc   = doc;
            _uidoc = uidoc;
            _roof  = roof;

            SelectedDrainMethod = DrainMethods[0];

            DetectDrainsCommand = new RelayCommand(DetectDrains);
            AnalyzeCommand       = new RelayCommand(Analyze);
            ApplyCommand          = new RelayCommand(Apply);
        }

        // ── Detect ────────────────────────────────────────────────────────────────
        private void DetectDrains()
        {
            List<XYZ> pts;

            switch (SelectedDrainMethod)
            {
                case "Select drain family instances":
                    pts = _pickService.PickFamilyInstances(_uidoc, _doc);
                    break;
                case "Reuse AutoSlope detection logic":
                    pts = _pickService.AutoDetectNearRoof(_doc, _roof);
                    break;
                default:
                    pts = _pickService.PickOnScreen(_uidoc);
                    break;
            }

            if (!pts.Any())
            {
                AppendLog("⚠️ No drain points captured.");
                return;
            }

            double toleranceFeet = UnitUtils.ConvertToInternalUnits(ToleranceMm, UnitTypeId.Millimeters);
            _drainGroups = _groupingService.GroupDrains(pts, toleranceFeet);
            DrainSummary = $"{pts.Count} drain(s) → {_drainGroups.Count} group(s)";

            AppendLog($"✅ Captured {pts.Count} drain point(s), grouped into {_drainGroups.Count} centroid group(s) at {ToleranceMm}mm tolerance.");
        }

        // ── Analyze (dry run) ─────────────────────────────────────────────────────
        private void Analyze()
        {
            Results.Clear();

            if (!_drainGroups.Any())
            {
                AppendLog("⚠️ Analyze skipped — detect drains first.");
                return;
            }

            List<RoofLoopModel> rawLoops;
            try
            {
                rawLoops = _geometryService.ExtractLoops(_roof);
            }
            catch (Exception ex)
            {
                AppendLog($"❌ Geometry extraction failed: {ex.Message}");
                return;
            }

            _loopBoundaries = new List<LoopBoundaryModel>();
            int innerIdx = 0;
            foreach (var l in rawLoops)
            {
                if (l.LoopType == "Outer")
                {
                    _loopBoundaries.Add(new LoopBoundaryModel { Label = "Outer", Curves = l.Geometry.ToList() });
                }
                else if (IncludeInteriorLoops)
                {
                    innerIdx++;
                    _loopBoundaries.Add(new LoopBoundaryModel { Label = $"Inner #{innerIdx}", Curves = l.Geometry.ToList() });
                }
            }

            if (!_loopBoundaries.Any())
            {
                AppendLog("⚠️ No boundary loops found on the selected roof.");
                return;
            }

            var enabledDirections = GetEnabledDirections();
            if (!enabledDirections.Any())
            {
                AppendLog("⚠️ No directions enabled — nothing to search.");
                return;
            }

            foreach (var group in _drainGroups)
            {
                var candidates = _projectionService.ComputeCandidates(group, _loopBoundaries, enabledDirections);
                foreach (var c in candidates) Results.Add(c);
            }

            int fallbackCount = Results.Count(r => r.IsFallback);
            AppendLog($"✅ Analysis complete — {Results.Count} candidate point(s) across {_drainGroups.Count} group(s) and {_loopBoundaries.Count} loop(s). {fallbackCount} used the nearest-edge fallback.");
        }

        // ── Apply (commit) ────────────────────────────────────────────────────────
        private void Apply()
        {
            if (!Results.Any())
            {
                AppendLog("⚠️ Apply skipped — run Analyze first.");
                return;
            }

            AppendLog("── Applying points... ──");

            using (Transaction tx = new Transaction(_doc, "Add Perpendicular Drain Points"))
            {
                tx.Start();

                SlabShapeEditor editor = _roof.GetSlabShapeEditor();
                if (!editor.IsEnabled)
                    editor.Enable();

                double snapToleranceFeet = UnitUtils.ConvertToInternalUnits(ToleranceMm, UnitTypeId.Millimeters);
                _projectionService.ApplyPoints(editor, Results, SnapToVertex, snapToleranceFeet);

                tx.Commit();
            }

            int added   = Results.Count(r => r.Status.StartsWith("Added"));
            int skipped = Results.Count(r => r.Status.StartsWith("Skipped"));
            AppendLog($"── Done. {added} point(s) added, {skipped} skipped. ──");
        }

        // ── Helpers ───────────────────────────────────────────────────────────────
        private List<string> GetEnabledDirections()
        {
            var dirs = new List<string>();
            if (IsNorthEnabled)     dirs.Add("N");
            if (IsNortheastEnabled) dirs.Add("NE");
            if (IsEastEnabled)      dirs.Add("E");
            if (IsSoutheastEnabled) dirs.Add("SE");
            if (IsSouthEnabled)     dirs.Add("S");
            if (IsSouthwestEnabled) dirs.Add("SW");
            if (IsWestEnabled)      dirs.Add("W");
            if (IsNorthwestEnabled) dirs.Add("NW");
            return dirs;
        }

        private void AppendLog(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            LogText += $"[{timestamp}] {message}{Environment.NewLine}";
        }
    }
}
