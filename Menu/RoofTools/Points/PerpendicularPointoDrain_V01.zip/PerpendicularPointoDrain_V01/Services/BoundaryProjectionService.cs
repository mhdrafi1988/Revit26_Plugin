using Autodesk.Revit.DB;
using Revit26_Plugin.PerpendicularPointoDrain.V01.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.PerpendicularPointoDrain.V01.Services
{
    /// <summary>
    /// For each drain-group centroid, searches every boundary loop (outer + interior, per
    /// caller's selection) in up to 8 compass directions (Project North = +Y) and computes the
    /// perpendicular projection of the centroid onto the nearest valid boundary segment in each
    /// direction. If a direction has no exact-sector hit, falls back to the nearest valid edge
    /// on that loop regardless of direction (per the agreed design). A "valid" hit requires the
    /// true perpendicular foot to land strictly within the finite segment — not clamped to an
    /// endpoint — matching the validation rule from the spec.
    ///
    /// Split into ComputeCandidates (dry run, no model changes) and ApplyPoints (commits via
    /// SlabShapeEditor inside a caller-managed transaction), mirroring the Analyze/Apply split
    /// already used in RoofLoopAnalyzer.
    /// </summary>
    public class BoundaryProjectionService
    {
        private static readonly string[] DirectionOrder = { "E", "NE", "N", "NW", "W", "SW", "S", "SE" };

        // ─────────────────────────────────────────────────────────────────────────
        // ANALYZE (dry run)
        // ─────────────────────────────────────────────────────────────────────────
        public List<ProjectionResultModel> ComputeCandidates(
            DrainGroupModel group,
            List<LoopBoundaryModel> loops,
            List<string> enabledDirections)
        {
            var results    = new List<ProjectionResultModel>();
            var enabledSet = new HashSet<string>(enabledDirections);

            foreach (var loop in loops)
            {
                var candidates = new List<(XYZ foot, double dist, double angleDeg)>();

                foreach (var curve in loop.Curves)
                {
                    if (TryGetPerpendicularFoot(curve, group.Centroid, out XYZ foot, out double dist))
                    {
                        double angleDeg = NormalizeDegrees(
                            Math.Atan2(foot.Y - group.Centroid.Y, foot.X - group.Centroid.X) * 180.0 / Math.PI);
                        candidates.Add((foot, dist, angleDeg));
                    }
                }

                if (!candidates.Any())
                {
                    results.Add(new ProjectionResultModel
                    {
                        GroupLabel = group.Label,
                        Direction  = "-",
                        LoopLabel  = loop.Label,
                        Status     = "Warning - no valid perpendicular foot on this loop"
                    });
                    continue;
                }

                var bySector = candidates
                    .GroupBy(c => NearestSectorIndex(c.angleDeg))
                    .ToDictionary(g => g.Key, g => g.OrderBy(c => c.dist).First());

                var globalNearest = candidates.OrderBy(c => c.dist).First();

                for (int i = 0; i < DirectionOrder.Length; i++)
                {
                    string dirName = DirectionOrder[i];
                    if (!enabledSet.Contains(dirName)) continue;

                    bool hasSectorHit = bySector.TryGetValue(i, out var hit);
                    var chosen = hasSectorHit ? hit : globalNearest;

                    results.Add(new ProjectionResultModel
                    {
                        GroupLabel = group.Label,
                        Direction  = dirName,
                        LoopLabel  = loop.Label,
                        DistanceMm = Math.Round(UnitUtils.ConvertFromInternalUnits(chosen.dist, UnitTypeId.Millimeters), 1),
                        Point      = chosen.foot,
                        IsFallback = !hasSectorHit,
                        Status     = "Pending"
                    });
                }
            }

            return results;
        }

        // ─────────────────────────────────────────────────────────────────────────
        // APPLY (commit) — caller starts/commits the transaction
        // ─────────────────────────────────────────────────────────────────────────
        public void ApplyPoints(SlabShapeEditor editor, IEnumerable<ProjectionResultModel> results,
                                 bool snapToExistingVertex, double snapToleranceFeet)
        {
            foreach (var r in results)
            {
                if (r.Point == null) continue; // warning rows — nothing to apply

                if (snapToExistingVertex && HasNearbyVertex(editor, r.Point, snapToleranceFeet))
                {
                    r.Status = "Skipped (existing vertex)";
                    continue;
                }

                try
                {
                    editor.AddPoint(r.Point);
                    r.Status = r.IsFallback ? "Added (fallback)" : "Added";
                }
                catch (Autodesk.Revit.Exceptions.ArgumentException)
                {
                    r.Status = "Skipped (duplicate)";
                }
            }
        }

        private bool HasNearbyVertex(SlabShapeEditor editor, XYZ pt, double toleranceFeet)
        {
            foreach (SlabShapeVertex v in editor.SlabShapeVertices)
            {
                double dx = v.Position.X - pt.X;
                double dy = v.Position.Y - pt.Y;
                if (Math.Sqrt(dx * dx + dy * dy) <= toleranceFeet)
                    return true;
            }
            return false;
        }

        // ─────────────────────────────────────────────────────────────────────────
        // Perpendicular foot — valid only if it lands strictly within the segment
        // ─────────────────────────────────────────────────────────────────────────
        private bool TryGetPerpendicularFoot(Curve curve, XYZ point, out XYZ foot, out double dist)
        {
            foot = null;
            dist = 0;

            if (curve is Line line) return TryLineFoot(line, point, out foot, out dist);
            if (curve is Arc arc)   return TryArcFoot(arc, point, out foot, out dist);

            return false;
        }

        private bool TryLineFoot(Line line, XYZ point, out XYZ foot, out double dist)
        {
            foot = null;
            dist = 0;

            XYZ a  = line.GetEndPoint(0);
            XYZ b  = line.GetEndPoint(1);
            XYZ ab = b - a;
            double lenSq = ab.X * ab.X + ab.Y * ab.Y;
            if (lenSq < 1e-9) return false;

            double t = ((point.X - a.X) * ab.X + (point.Y - a.Y) * ab.Y) / lenSq;
            if (t <= 1e-4 || t >= 1 - 1e-4) return false; // foot falls outside the segment

            foot = new XYZ(a.X + ab.X * t, a.Y + ab.Y * t, a.Z);
            dist = Math.Sqrt(Math.Pow(point.X - foot.X, 2) + Math.Pow(point.Y - foot.Y, 2));
            return true;
        }

        private bool TryArcFoot(Arc arc, XYZ point, out XYZ foot, out double dist)
        {
            foot = null;
            dist = 0;

            XYZ center = arc.Center;
            double angle = Math.Atan2(point.Y - center.Y, point.X - center.X);

            // Resolve true sweep direction via midpoint — mirrors LoopDivisionService.AddMixedCurvedPoints
            XYZ startVec = (arc.GetEndPoint(0) - center).Normalize();
            XYZ endVec   = (arc.GetEndPoint(1) - center).Normalize();
            double startAngle = Math.Atan2(startVec.Y, startVec.X);
            double endAngle   = Math.Atan2(endVec.Y, endVec.X);
            double sweep      = endAngle - startAngle;

            XYZ midPt  = arc.Evaluate(0.5, true);
            XYZ midVec = (midPt - center).Normalize();
            double midAngleGeom = Math.Atan2(midVec.Y, midVec.X);
            double midAngleCalc = startAngle + sweep / 2.0;
            if (Math.Abs(NormalizeSigned(midAngleGeom - midAngleCalc)) > 0.1)
                sweep = sweep > 0 ? sweep - 2 * Math.PI : sweep + 2 * Math.PI;

            double rel = angle - startAngle;
            bool within;
            if (sweep >= 0)
            {
                while (rel < 0) rel += 2 * Math.PI;
                while (rel > 2 * Math.PI) rel -= 2 * Math.PI;
                within = rel > 1e-3 && rel < sweep - 1e-3;
            }
            else
            {
                while (rel > 0) rel -= 2 * Math.PI;
                while (rel < -2 * Math.PI) rel += 2 * Math.PI;
                within = rel < -1e-3 && rel > sweep + 1e-3;
            }

            if (!within) return false;

            foot = new XYZ(center.X + arc.Radius * Math.Cos(angle),
                            center.Y + arc.Radius * Math.Sin(angle),
                            arc.GetEndPoint(0).Z);
            dist = Math.Sqrt(Math.Pow(point.X - foot.X, 2) + Math.Pow(point.Y - foot.Y, 2));
            return true;
        }

        private int NearestSectorIndex(double angleDeg)
        {
            int idx = (int)Math.Round(angleDeg / 45.0) % 8;
            if (idx < 0) idx += 8;
            return idx;
        }

        private double NormalizeDegrees(double deg)
        {
            deg %= 360;
            if (deg < 0) deg += 360;
            return deg;
        }

        private double NormalizeSigned(double angle)
        {
            while (angle > Math.PI) angle -= 2 * Math.PI;
            while (angle < -Math.PI) angle += 2 * Math.PI;
            return angle;
        }
    }
}
