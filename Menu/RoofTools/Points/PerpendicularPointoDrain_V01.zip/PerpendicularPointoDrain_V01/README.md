# Perpendicular Point to Drain (V01)

Namespace: `Revit26_Plugin.PerpendicularPointoDrain.V01`

## What it does

1. Pick a roof, enable its `SlabShapeEditor` (no flattening — existing shape points are left alone).
2. Identify drains via one of three runtime-selectable methods: pick points on screen, select
   existing drain family instances, or auto-detect near the roof (best-effort placeholder, see below).
3. Group nearby drains by tolerance distance (Union-Find, same shape as AutoSlopeByPoint's ridge
   clustering) into centroid groups.
4. For each centroid, for each boundary loop (outer + every interior loop, since every loop is
   processed every time per the agreed design), search all 8 compass directions (Project North =
   internal +Y). For each direction, the nearest boundary segment whose true perpendicular foot
   falls strictly within that segment is used. If no segment matches a direction's 45° sector
   exactly, the nearest valid segment anywhere on that loop is used instead (fallback).
5. Analyze computes all candidates as a dry run (no model changes). Apply commits them via
   `editor.AddPoint` inside a single transaction, catching duplicate-point exceptions the same
   way `LoopDivisionService.TryAddPoint` already does in RoofLoopAnalyzer.

## Things to verify / wire up before building

- **SharedStyles key names**: the XAML merges `SharedStyles.xaml` via the pack URI but doesn't
  reference specific style keys (`StandardDataGrid`, `DarkGhostButton`, etc.) since the exact key
  names weren't available when this was written. Apply `Style="{StaticResource ...}"` to the
  `DataGrid` / buttons if you want the established look.
- **`AutoDetectNearRoof`** in `DrainPickService.cs` is a placeholder: it filters `FamilyInstance`
  elements within the roof's bounding box whose family or type name contains "drain". If your
  actual AutoSlopeByPoint detection logic uses different category/parameter rules, swap this
  method's body for the real thing.
- **`RoofGeometryService`** is referenced directly from `Revit26_Plugin.PDCV3.Services` (same
  assembly) rather than duplicated — add a project reference / using if your build setup needs it
  made explicit.
- **Ribbon / `.addin` registration**: this only adds the command class — wire
  `PerpendicularPointoDrainCommand` into your ribbon panel setup the same way the other PDCV3
  tools are registered.

## Folder structure

```
Commands/PerpendicularPointoDrainCommand.cs
Models/DrainGroupModel.cs
Models/LoopBoundaryModel.cs
Models/ProjectionResultModel.cs
Services/DrainGroupingService.cs
Services/DrainPickService.cs
Services/BoundaryProjectionService.cs
ViewModels/PerpendicularPointoDrainViewModel.cs
Views/PerpendicularPointoDrainWindow.xaml
Views/PerpendicularPointoDrainWindow.xaml.cs
```
