using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.RoofEdgeVertexReducer.V002.Commands;
using Revit26_Plugin.RoofEdgeVertexReducer.V002.Services;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.RoofEdgeVertexReducer.V002.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private RoofEdgeVertexReducerEventHandler _handler;
        private Autodesk.Revit.UI.ExternalEvent _externalEvent;

        /// <summary>Set by MainWindow — hides the window right before a Revit pick operation.</summary>
        public Action HideOwner { get; set; }

        /// <summary>Set by MainWindow — restores/activates the window once a pick completes
        /// (success, cancel, or error all route back through this).</summary>
        public Action ShowOwner { get; set; }

        [ObservableProperty] private string roofLabel = "Roof: (none selected)";
        [ObservableProperty] private double toleranceMm = 5.0;
        [ObservableProperty] private bool outerEnabled = true;
        [ObservableProperty] private bool innerEnabled = true;
        [ObservableProperty] private bool canPreview;
        [ObservableProperty] private bool canApply;
        [ObservableProperty] private bool hasPreviewResult;
        [ObservableProperty] private int totalPoints;
        [ObservableProperty] private int skippedPoints;
        [ObservableProperty] private int removedPoints;
        [ObservableProperty] private int remainingPoints;
        [ObservableProperty] private string summaryText = "No preview run yet";

        public ObservableCollection<LogEntry> Logs { get; } = new();

        public void Initialize(RoofEdgeVertexReducerEventHandler handler, Autodesk.Revit.UI.ExternalEvent externalEvent)
        {
            _handler = handler;
            _externalEvent = externalEvent;
        }

        [RelayCommand]
        private void SelectRoof()
        {
            // Hide first — Revit's PickObject needs the model unobstructed, and the
            // window would otherwise be left stranded behind the main Revit window.
            HideOwner?.Invoke();
            _handler.PendingRequest = ReducerRequest.SelectRoof;
            _externalEvent.Raise();
        }

        [RelayCommand]
        private void Preview()
        {
            CanPreview = false;
            _handler.PendingRequest = ReducerRequest.Preview;
            _externalEvent.Raise();
        }

        [RelayCommand]
        private void Apply()
        {
            CanApply = false;
            _handler.PendingRequest = ReducerRequest.Apply;
            _externalEvent.Raise();
        }

        [RelayCommand]
        private void CopyAllLogs()
        {
            if (Logs.Count == 0) return;
            Clipboard.SetText(string.Join(Environment.NewLine, Logs.Select(l => l.ToString())));
        }

        [RelayCommand]
        private void ClearLogs() => Logs.Clear();

        public void CopySelectedLogs(IList selected)
        {
            if (selected == null || selected.Count == 0) return;
            var lines = selected.Cast<LogEntry>().Select(l => l.ToString());
            Clipboard.SetText(string.Join(Environment.NewLine, lines));
        }

        /// <summary>Called from the event handler after a roof pick completes.</summary>
        public void SetSelectedRoof(string label)
        {
            RoofLabel = label;
            HasPreviewResult = false;
            CanPreview = true;
            CanApply = false;
            SummaryText = "No preview run yet";
        }

        /// <summary>Called from the event handler after Preview (ClassifyAndReduce) completes. Enables Apply.</summary>
        public void SetPreviewSummary(int total, int skipped, int removed, int remaining)
        {
            TotalPoints = total;
            SkippedPoints = skipped;
            RemovedPoints = removed;
            RemainingPoints = remaining;
            HasPreviewResult = true;
            CanApply = true;
            SummaryText = $"{remaining} kept \u00b7 {removed} pending removal \u00b7 {skipped} skipped";
        }

        /// <summary>Called from the event handler after Apply completes. Does not re-enable
        /// Apply — a fresh Preview is required before applying again.</summary>
        public void SetAppliedSummary(int total, int skipped, int removed, int remaining)
        {
            TotalPoints = total;
            SkippedPoints = skipped;
            RemovedPoints = removed;
            RemainingPoints = remaining;
            HasPreviewResult = true;
            SummaryText = $"{remaining} kept \u00b7 {removed} removed \u00b7 {skipped} skipped";
        }

        public void AddLog(LogLevel level, string message) => Logs.Add(new LogEntry(level, message));

        public void SetSummary(string text) => SummaryText = text;
    }
}
