using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Revit26_Plugin.RoofEdgeVertexReducer.V002.Models;
using Revit26_Plugin.RoofEdgeVertexReducer.V002.Services;
using Revit26_Plugin.RoofEdgeVertexReducer.V002.ViewModels;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.RoofEdgeVertexReducer.V002.Commands
{
    public enum ReducerRequest
    {
        None,
        SelectRoof,
        Preview,
        Apply
    }

    /// <summary>
    /// Every Revit API call for this tool goes through here — never called directly
    /// from the WPF UI thread. Raise() on the ExternalEvent queues Execute() to run
    /// on Revit's own thread.
    /// </summary>
    public class RoofEdgeVertexReducerEventHandler : IExternalEventHandler
    {
        private readonly MainViewModel _vm;

        public ReducerRequest PendingRequest { get; set; } = ReducerRequest.None;

        private Element _roof;
        private List<VertexDecision> _lastDecisions;

        public RoofEdgeVertexReducerEventHandler(MainViewModel vm)
        {
            _vm = vm;
        }

        public void Execute(UIApplication app)
        {
            bool wasSelectRoof = PendingRequest == ReducerRequest.SelectRoof;

            try
            {
                switch (PendingRequest)
                {
                    case ReducerRequest.SelectRoof:
                        HandleSelectRoof(app.ActiveUIDocument);
                        break;
                    case ReducerRequest.Preview:
                        HandlePreview(app.ActiveUIDocument.Document);
                        break;
                    case ReducerRequest.Apply:
                        HandleApply(app.ActiveUIDocument.Document);
                        break;
                }
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                // user cancelled the pick — no log needed
            }
            catch (Exception ex)
            {
                _vm.AddLog(LogLevel.Error, $"Unexpected error: {ex.Message}");
            }
            finally
            {
                PendingRequest = ReducerRequest.None;

                // Bug fix (V002): the window is hidden before a roof pick (see
                // MainViewModel.SelectRoof) so Revit's selection UI isn't obstructed.
                // Restore it here unconditionally — success, cancel, and error all
                // flow through this finally block, so the window always comes back.
                if (wasSelectRoof)
                    _vm.ShowOwner?.Invoke();
            }
        }

        private void HandleSelectRoof(UIDocument uidoc)
        {
            var reference = uidoc.Selection.PickObject(
                ObjectType.Element,
                new RoofSelectionFilter(),
                "Select a roof with shape editing enabled");

            _roof = uidoc.Document.GetElement(reference);
            _lastDecisions = null;

            string name = _roof?.Name ?? "Unknown";
            _vm.SetSelectedRoof($"Roof: {name} (id {_roof.Id.Value})");
            _vm.AddLog(LogLevel.Info, $"Roof selected: {name} (id {_roof.Id.Value})");
        }

        private void HandlePreview(Document doc)
        {
            if (_roof == null)
            {
                _vm.AddLog(LogLevel.Warning, "No roof selected.");
                return;
            }

            var footprint = _roof as FootPrintRoof;
            var editor = footprint?.SlabShapeEditor;
            if (editor == null || !editor.IsEnabled)
            {
                _vm.AddLog(LogLevel.Error, "Selected roof does not have shape editing enabled.");
                return;
            }

            if (!_vm.OuterEnabled && !_vm.InnerEnabled)
            {
                _vm.AddLog(LogLevel.Warning, "Both outer and inner boundary lines are unchecked \u2014 nothing to process.");
                return;
            }

            var segments = EdgeVertexReducerService.BuildSegments(_roof, out var skippedSegments);
            foreach (var s in skippedSegments)
                _vm.AddLog(LogLevel.Warning, s);

            double toleranceFeet = EdgeVertexReducerService.MmToFeet(_vm.ToleranceMm);
            _lastDecisions = EdgeVertexReducerService.ClassifyAndReduce(
                editor, segments, toleranceFeet, _vm.OuterEnabled, _vm.InnerEnabled);

            int total = _lastDecisions.Count;
            int removed = _lastDecisions.Count(d => d.WillRemove);
            int skipped = _lastDecisions.Count(d =>
                d.Action == VertexAction.KeepUnmatched || d.Action == VertexAction.KeepBoundaryDisabled);
            int remaining = total - removed;

            _vm.SetPreviewSummary(total, skipped, removed, remaining);
            _vm.AddLog(LogLevel.Success, $"Preview complete: {segments.Count} straight segments scanned, {removed} point(s) marked for removal");
        }

        private void HandleApply(Document doc)
        {
            if (_roof == null || _lastDecisions == null)
            {
                _vm.AddLog(LogLevel.Warning, "Run Preview before Apply.");
                return;
            }

            var footprint = _roof as FootPrintRoof;
            var editor = footprint?.SlabShapeEditor;
            if (editor == null)
            {
                _vm.AddLog(LogLevel.Error, "Shape editor unavailable.");
                return;
            }

            var tg = new TransactionGroup(doc, "Roof edge vertex reducer");
            tg.Start();

            var t = new Transaction(doc, "Remove interior shape points");
            var startStatus = t.Start();
            if (startStatus != TransactionStatus.Started)
            {
                _vm.AddLog(LogLevel.Error, "Could not start transaction.");
                tg.RollBack();
                return;
            }

            int total = _lastDecisions.Count;
            int skipped = _lastDecisions.Count(d =>
                d.Action == VertexAction.KeepUnmatched || d.Action == VertexAction.KeepBoundaryDisabled);

            int removed = EdgeVertexReducerService.ApplyRemovals(
                editor, _lastDecisions, msg => _vm.AddLog(LogLevel.Warning, msg));

            var commitStatus = t.Commit();
            if (commitStatus != TransactionStatus.Committed)
            {
                _vm.AddLog(LogLevel.Error, $"Transaction failed to commit: {commitStatus}");
                tg.RollBack();
                return;
            }

            tg.Assimilate();

            int remaining = total - removed;
            _vm.AddLog(LogLevel.Success, $"Changes applied \u2014 {removed} point(s) removed");
            _vm.SetAppliedSummary(total, skipped, removed, remaining);
            _lastDecisions = null;
        }

        public string GetName() => "Roof Edge Vertex Reducer Event Handler";
    }
}
