using System.Windows;
using Revit26_Plugin.RoofEdgeVertexReducer.V002.ViewModels;

namespace Revit26_Plugin.RoofEdgeVertexReducer.V002.Views
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _viewModel;

        public MainWindow(MainViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            DataContext = _viewModel;

            // Bug fix (V002): hide during the Revit pick, restore afterward — see
            // RoofEdgeVertexReducerEventHandler.Execute's finally block.
            _viewModel.HideOwner = () => Hide();
            _viewModel.ShowOwner = () =>
            {
                Show();
                Activate();
            };
        }

        private void CopySelectedLogs_Click(object sender, RoutedEventArgs e)
        {
            _viewModel.CopySelectedLogs(LogList.SelectedItems);
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
