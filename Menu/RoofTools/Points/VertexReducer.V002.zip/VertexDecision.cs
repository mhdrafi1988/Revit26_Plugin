using Autodesk.Revit.DB;

namespace Revit26_Plugin.RoofEdgeVertexReducer.V002.Models
{
    public enum VertexAction
    {
        KeepStart,
        KeepEnd,

        /// <summary>One of up to 2 interior points per segment with the highest Z,
        /// each individually above both the segment's start and end Z.</summary>
        KeepTopZ,

        Remove,

        /// <summary>Not within tolerance of any straight segment — always left untouched.</summary>
        KeepUnmatched,

        /// <summary>On a boundary loop (outer/inner) whose checkbox is unchecked — left untouched.</summary>
        KeepBoundaryDisabled
    }

    /// <summary>
    /// Result of classifying one SlabShapeVertex against the roof's straight edges
    /// and applying the keep/remove rule.
    /// </summary>
    public class VertexDecision
    {
        public SlabShapeVertex Vertex { get; set; }
        public XYZ Position { get; set; }

        /// <summary>Elevation in Revit internal units (feet).</summary>
        public double ZFeet { get; set; }

        public string SegmentLabel { get; set; }
        public VertexAction Action { get; set; }
        public string Reason { get; set; }

        public bool WillRemove => Action == VertexAction.Remove;
    }
}
