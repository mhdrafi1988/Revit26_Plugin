﻿// File: AutoSlopeDrainEngine.cs
// Location: Core/Engine/
// Base: ported from AutoSlopeByDrain V004 — orchestration only.
//
// UPDATED (V005, second round), per Rafi's confirmed decisions on 2026-07-22:
//   - REMOVED drain re-detection + MatchSelectedDrains (position-signature
//     matching) entirely. The Engine no longer re-reads the roof's Sketch
//     profile at Run time — it reuses the exact DrainItem objects (with
//     their LoopCurves) the user selected in the grid, carried directly via
//     payload.SelectedDrains. Rafi confirmed trading away the "roof changed
//     since grid was populated" Warning as an acceptable cost of this.
//   - ADDED: shape-edit vertex matching (X,Y -> Z) now happens HERE, per
//     selected DrainItem, against a freshly re-read SlabShapeVertex list —
//     this part must still be fresh, since shape-edit vertices genuinely can
//     move between detection time and Run time. Uses
//     DrainDetectionService.FindShapeVerticesAtLoopPoints (now public).
//     Only runs for items the user selected — unselected openings never get
//     DrainVertices populated at all, matching Rafi's confirmed decision
//     that unchecked openings are treated as ordinary roof (sloped toward
//     the nearest selected drain like any other vertex, not excluded from
//     the pathfinding graph).
//
// NEW (V005, first round), per Rafi's confirmed decisions on 2026-07-21:
//   - InsertCurveIntersectionPoints and VerifyElevationsAfterCommit toggles
//     passed through to RoofSlopeProcessorService.
//   - Excel export (ExcelExportHelper/ExcelExportService) replaces CSV
//     export entirely — single workbook, single export call (no duplicate
//     detailed/summary pair; see ExportConfig.cs for why).
//   - TotalDetectedCount / SelectedCount / ArcsCalculated / Version /
//     UnreachableVertexCount populated on the result.
//   - Parameter writer now receives an explicit version string instead of
//     a hardcoded one (see AutoSlopeDrainParameterWriter fix notes).

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.MultiRoofSlopeByDrain.V010.Core.Models;
using Revit26_Plugin.MultiRoofSlopeByDrain.V010.Core.Parameters;
using Revit26_Plugin.MultiRoofSlopeByDrain.V010.Core.Services;
using Revit26_Plugin.MultiRoofSlopeByDrain.V010.Infrastructure.Helpers;
using Revit26_Plugin.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.MultiRoofSlopeByDrain.V010.Core.Engine
{
    public static class AutoSlopeDrainEngine
    {
        private const string ToolVersion = "009";

        public static AutoSlopeDrainResult Execute(UIApplication app, AutoSlopeDrainPayload payload)
        {
            var log = payload.Log ?? (_ => { });
            var doc = app.ActiveUIDocument.Document;
            var startTime = DateTime.Now;
            log(new LogEntry(LogLevel.Info, $"Run started at {startTime:HH:mm:ss}"));

            try
            {
                payload.CancelToken.ThrowIfCancellationRequested();

                var roof = doc.GetElement(payload.RoofId) as RoofBase;
                if (roof == null)
                {
                    return Fail("Selected roof could not be found (it may have been deleted).", log, startTime);
                }

                if (!(roof is FootPrintRoof))
                {
                    // Should not be reachable — RoofFilter restricts PickObject to
                    // FootPrintRoof only. Guarded here anyway so a mismatch fails
                    // clearly instead of silently reaching DrainDetectionService and
                    // producing a confusing "0 drains detected" result.
                    return Fail("Selected roof is not a FootPrintRoof. Sketch-based opening detection requires a sketch-based roof.", log, startTime);
                }

                // ── Re-analyze geometry with FRESH handles ─────────────────────
                log(new LogEntry(LogLevel.Info, "Re-reading roof geometry with fresh handles..."));
                payload.Progress?.Invoke(new RunProgressInfo("Reading roof geometry"));
                var roofData = new RoofData { Roof = roof };
                var topFace = GetTopFace(roof);
                if (topFace == null)
                {
                    return Fail("Could not find top face of the roof.", log, startTime);
                }
                roofData.TopFace = topFace;

                var editor = roof.GetSlabShapeEditor();
                foreach (SlabShapeVertex v in editor.SlabShapeVertices)
                    roofData.Vertices.Add(v);

                log(new LogEntry(LogLevel.Info, $"Found {roofData.Vertices.Count} shape editing vertices."));

                // ── Reuse selected DrainItems directly (no re-detection) ───────
                // Per Rafi's confirmed decision: the loop geometry captured during
                // the ORIGINAL detection pass (in the Command) is reused as-is here,
                // not re-extracted from the Sketch. detectedDrains is no longer
                // fetched fresh; TotalDetectedCount comes from what the payload
                // recorded at grid-population time.
                var selectedDrains = payload.SelectedDrains ?? new List<DrainItem>();

                if (selectedDrains.Count == 0)
                {
                    // Defensive backstop only — the UI disables Run when 0 drains are
                    // checked, so this path should be unreachable in normal use.
                    return Fail("No drains selected for slope application.", log, startTime);
                }

                payload.Progress?.Invoke(new RunProgressInfo("Matching drain vertices"));

                // ── Match shape-edit vertices for SELECTED drains only ──────────
                // Deferred from detection time (per Rafi's confirmed decision) to
                // here, and only for the drains the user actually selected —
                // unselected openings never get DrainVertices populated at all, so
                // their shape-edit vertices are treated as ordinary roof points by
                // RoofSlopeProcessorService (sloped toward the nearest selected
                // drain, same as any other vertex — confirmed behavior). This part
                // MUST use a freshly re-read SlabShapeVertex list: shape-edit
                // vertices can genuinely move between detection time and Run time,
                // unlike the loop geometry itself.
                var detectionService = new DrainDetectionService();
                foreach (var drain in selectedDrains)
                {
                    var loopPoints = new List<XYZ>();
                    if (drain.LoopCurves != null)
                        foreach (var curve in drain.LoopCurves)
                            loopPoints.Add(curve.GetEndPoint(0));

                    drain.DrainVertices = detectionService.FindShapeVerticesAtLoopPoints(
                        loopPoints, roofData.Vertices, log);
                }

                int totalMatchedVertices = selectedDrains.Sum(d => d.DrainVertices?.Count ?? 0);
                log(new LogEntry(LogLevel.Info,
                    $"Matched {totalMatchedVertices} shape-edit vertex/vertices across {selectedDrains.Count} selected drain(s)."));

                log(new LogEntry(LogLevel.Info, $"Applying {payload.SlopePercent}% slope to {selectedDrains.Count} drain(s)..."));

                // ── Core slope path/elevation algorithm ────────────────────────
                var slopeService = new RoofSlopeProcessorService();
                View activeView = app.ActiveUIDocument?.ActiveView;
                var results = slopeService.ProcessRoofSlopes(
                    roofData,
                    selectedDrains,
                    payload.SlopePercent,
                    msg => log(new LogEntry(LogLevel.Info, msg)),
                    payload.ConnectionThresholdMeters,
                    payload.PathSampleCount,
                    payload.InsertCurveIntersectionPoints,
                    payload.VerifyElevationsAfterCommit,
                    payload.ThresholdMeters,
                    activeView,
                    payload.DrainMarkerGroup,
                    payload.HighestPointMarkerGroup,
                    payload.AllowedOffsetMarkerGroup,
                    payload.AllowedOffsetThresholdMm,
                    payload.Progress,
                    payload.CancelToken);

                var endTime = DateTime.Now;
                int durationSec = (int)(endTime - startTime).TotalSeconds;
                var vertexData = slopeService.GetLastExportData() ?? new List<DrainVertexData>();

                int processedCount = vertexData.Count(v => v.WasProcessed);
                int skippedCount = vertexData.Count(v => !v.WasProcessed);

                var metrics = new DrainExportMetrics
                {
                    ProcessedVertices = processedCount,
                    SkippedVertices = skippedCount,
                    DrainCount = selectedDrains.Count,
                    HighestElevationMm = results.maxOffset,
                    LongestPathM = results.longestPath,
                    SlopePercent = payload.SlopePercent,
                    RunDurationSec = durationSec,
                    RunDate = DateTime.Now.ToString("dd-MM-yy HH:mm"),
                    StartTime = startTime.ToString("HH:mm:ss"),
                    EndTime = endTime.ToString("HH:mm:ss"),
                    RoofId = roof.Id.Value.ToString(),
                    RoofName = roof.Name,
                    TotalDetectedCount = payload.TotalDetectedCount,
                    SelectedCount = selectedDrains.Count,
                    ArcsCalculated = slopeService.LastArcsCalculated,
                    Version = ToolVersion,
                    UnreachableVertexCount = slopeService.LastUnreachableCount,
                    OverThresholdVertexCount = slopeService.LastOverThresholdCount
                };

                // ── Write tracking parameters ───────────────────────────────────
                payload.Progress?.Invoke(new RunProgressInfo("Writing tracking parameters"));
                var paramWriter = new AutoSlopeDrainParameterWriter();
                paramWriter.WriteAll(doc, roof, metrics, payload.SlopePercent, payload.ConnectionThresholdMeters,
                    ToolVersion, msg => log(new LogEntry(LogLevel.Info, msg)));

                // ── Excel export (single workbook: Vertex Data + Run Summary) ──
                string exportedPath = null;

                if (payload.ExportConfig != null && payload.ExportConfig.ExportToExcel)
                {
                    payload.Progress?.Invoke(new RunProgressInfo("Exporting Excel workbook"));
                    System.IO.Directory.CreateDirectory(payload.ExportConfig.ExportPath);

                    exportedPath = ExcelExportService.ExportWorkbook(
                        payload, vertexData, roof, payload.SlopePercent, metrics, log);

                    if (!string.IsNullOrEmpty(exportedPath))
                    {
                        log(new LogEntry(LogLevel.Success, $"✅ Excel exported to: {exportedPath}"));
                    }
                }

                log(new LogEntry(LogLevel.Success,
                    $"SUCCESS: {results.modifiedCount} vertices modified | Max offset {results.maxOffset:F1} mm | Longest path {results.longestPath:F2} m"));
                log(new LogEntry(LogLevel.Info,
                    $"Circles Placed            : {slopeService.LastDrainCirclesPlaced} drain, {slopeService.LastHighestCirclesPlaced} highest, {slopeService.LastOffsetCirclesPlaced} allowed-offset"));
                log(new LogEntry(LogLevel.Info,
                    $"Run finished at {endTime:HH:mm:ss} | Started {startTime:HH:mm:ss} | Duration: {durationSec}s"));

                return new AutoSlopeDrainResult
                {
                    Success = true,
                    VerticesModified = results.modifiedCount,
                    VerticesProcessed = processedCount,
                    VerticesSkipped = skippedCount,
                    DrainCount = selectedDrains.Count,
                    HighestElevation_mm = results.maxOffset,
                    LongestPath_m = results.longestPath,
                    RunDuration_sec = durationSec,
                    RunDate = metrics.RunDate,
                    StartTime = metrics.StartTime,
                    EndTime = metrics.EndTime,
                    Status = AppConstants.Status_OK,
                    Version = ToolVersion,
                    TotalDetectedCount = payload.TotalDetectedCount,
                    SelectedCount = selectedDrains.Count,
                    ArcsCalculated = slopeService.LastArcsCalculated,
                    UnreachableVertexCount = slopeService.LastUnreachableCount,
                    OverThresholdVertexCount = slopeService.LastOverThresholdCount,
                    ExportedFilePath = exportedPath,
                    DrainCirclesPlaced = slopeService.LastDrainCirclesPlaced,
                    HighestCirclesPlaced = slopeService.LastHighestCirclesPlaced,
                    OffsetCirclesPlaced = slopeService.LastOffsetCirclesPlaced
                };
            }
            catch (OperationCanceledException)
            {
                log(new LogEntry(LogLevel.Warning, "Run cancelled by user."));
                return Fail("Cancelled by user.", log, startTime, wasCancelled: true, alreadyLogged: true);
            }
            catch (Exception ex)
            {
                return Fail($"Unhandled exception: {ex.Message}", log, startTime);
            }
        }

        /// <summary>
        /// NEW (V010): also stamps StartTime/EndTime/RunDuration_sec on a failed/
        /// cancelled result (previously only the success path did), so a failed or
        /// cancelled roof's banner still shows real timing instead of blank fields.
        /// </summary>
        private static AutoSlopeDrainResult Fail(string message, Action<LogEntry> log, DateTime startTime,
            bool wasCancelled = false, bool alreadyLogged = false)
        {
            if (!alreadyLogged)
                log(new LogEntry(LogLevel.Error, message));

            var endTime = DateTime.Now;
            return new AutoSlopeDrainResult
            {
                Success = false,
                WasCancelled = wasCancelled,
                ErrorMessage = message,
                Status = AppConstants.Status_Failed,
                Version = ToolVersion,
                StartTime = startTime.ToString("HH:mm:ss"),
                EndTime = endTime.ToString("HH:mm:ss"),
                RunDuration_sec = (int)(endTime - startTime).TotalSeconds
            };
        }

        private static Face GetTopFace(RoofBase roof)
        {
            GeometryElement geomElem = roof.get_Geometry(new Options());
            Face topFace = null;
            double maxZ = double.MinValue;

            foreach (GeometryObject geomObj in geomElem)
            {
                if (geomObj is Solid solid)
                {
                    foreach (Face face in solid.Faces)
                    {
                        if (face == null) continue;
                        BoundingBoxUV bb = face.GetBoundingBox();
                        if (bb == null) continue;

                        UV midpointUV = new UV((bb.Min.U + bb.Max.U) / 2, (bb.Min.V + bb.Max.V) / 2);
                        XYZ midpoint = face.Evaluate(midpointUV);

                        if (midpoint != null && midpoint.Z > maxZ)
                        {
                            maxZ = midpoint.Z;
                            topFace = face;
                        }
                    }
                }
            }
            return topFace;
        }
    }
}
