﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.Asd_19.Models;
using Revit26_Plugin.Asd_19.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace Revit26_Plugin.Asd_19.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private readonly UIApplication _uiApp;
        private readonly DrainDetectionService _drainService;
        private readonly RoofSlopeProcessorService _slopeService;
        private readonly RoofBase _selectedRoof;

        public event PropertyChangedEventHandler PropertyChanged;

        private RoofData _currentRoof;
        private string _selectedSizeFilter = "All";
        private string _logText = "";

        // Flag to track if slope has been applied (permanently disabled)
        private bool _slopeApplied;
        public bool SlopeApplied
        {
            get => _slopeApplied;
            set
            {
                _slopeApplied = value;
                OnPropertyChanged(nameof(SlopeApplied));

                // Update command's can-execute state
                ((RelayCommand)ApplySlopesCommand).RaiseCanExecuteChanged();

                // Also update Export button state if needed
                ((RelayCommand)ExportResultsCommand).RaiseCanExecuteChanged();
            }
        }

        public ICommand ApplySlopesCommand { get; }
        public ICommand SelectAllCommand { get; }
        public ICommand SelectNoneCommand { get; }
        public ICommand InvertSelectionCommand { get; }
        public ICommand CancelCommand { get; }
        public ICommand ChangeRoofCommand { get; }
        public ICommand OkCommand { get; }
        public ICommand CopyLogCommand { get; }

        // Export commands
        public ICommand BrowseExportFolderCommand { get; }
        public ICommand ExportResultsCommand { get; }

        public ObservableCollection<DrainItem> AllDrains { get; } = new ObservableCollection<DrainItem>();
        public ObservableCollection<string> SizeFilters { get; } = new ObservableCollection<string>();

        // Export properties
        private string _exportFolderPath;
        public string ExportFolderPath
        {
            get => _exportFolderPath;
            set
            {
                _exportFolderPath = value;
                OnPropertyChanged(nameof(ExportFolderPath));
                AddLog($"Export folder set to: {value}");
            }
        }

        private bool _exportToCsv = true;
        public bool ExportToCsv
        {
            get => _exportToCsv;
            set
            {
                _exportToCsv = value;
                OnPropertyChanged(nameof(ExportToCsv));
                ((RelayCommand)ExportResultsCommand).RaiseCanExecuteChanged();
            }
        }

        private bool _includeVertexDetails = true;
        public bool IncludeVertexDetails
        {
            get => _includeVertexDetails;
            set
            {
                _includeVertexDetails = value;
                OnPropertyChanged(nameof(IncludeVertexDetails));
            }
        }

        // Slope options with manual entry support
        private string _slopeInput = "1.5";
        public string SlopeInput
        {
            get => _slopeInput;
            set
            {
                _slopeInput = value;
                OnPropertyChanged(nameof(SlopeInput));
                if (double.TryParse(value, out double result) && result > 0)
                {
                    AddLog($"Slope set to: {result}%");
                }
            }
        }

        public List<string> SlopeOptions { get; } = new List<string> { "1.0", "1.5", "2.0", "2.5", "3.0" };

        public string SelectedSizeFilter
        {
            get => _selectedSizeFilter;
            set
            {
                _selectedSizeFilter = value;
                OnPropertyChanged(nameof(SelectedSizeFilter));
                FilterDrains();
                AddLog($"Filter applied: {value}");
            }
        }

        public string LogText
        {
            get => _logText;
            set
            {
                _logText = value;
                OnPropertyChanged(nameof(LogText));
            }
        }

        private string _roofInfo;
        public string RoofInfo
        {
            get => _roofInfo;
            set
            {
                _roofInfo = value;
                OnPropertyChanged(nameof(RoofInfo));
            }
        }

        private string _resultsInfo;
        public string ResultsInfo
        {
            get => _resultsInfo;
            set
            {
                _resultsInfo = value;
                OnPropertyChanged(nameof(ResultsInfo));
            }
        }

        private int _selectedDrainsCount;
        public int SelectedDrainsCount
        {
            get => _selectedDrainsCount;
            set
            {
                _selectedDrainsCount = value;
                OnPropertyChanged(nameof(SelectedDrainsCount));
            }
        }

        public ICollectionView FilteredDrainsView { get; }

        // Action to close the window
        public Action CloseWindow { get; set; }

        public MainViewModel(UIApplication uiApp, RoofBase selectedRoof)
        {
            _uiApp = uiApp;
            _selectedRoof = selectedRoof;
            _drainService = new DrainDetectionService();
            _slopeService = new RoofSlopeProcessorService();

            // Initialize commands
            ApplySlopesCommand = new RelayCommand(ApplySlopes, CanApplySlopes);
            SelectAllCommand = new RelayCommand(SelectAllDrains);
            SelectNoneCommand = new RelayCommand(SelectNoneDrains);
            InvertSelectionCommand = new RelayCommand(InvertDrainSelection);
            CancelCommand = new RelayCommand(CancelOperation);
            ChangeRoofCommand = new RelayCommand(ChangeRoof);
            OkCommand = new RelayCommand(OkOperation);
            CopyLogCommand = new RelayCommand(CopyLogToClipboard);

            // Export commands
            BrowseExportFolderCommand = new RelayCommand(BrowseExportFolder);
            ExportResultsCommand = new RelayCommand(ExportResults, CanExportResults);

            // Setup filtered view
            FilteredDrainsView = CollectionViewSource.GetDefaultView(AllDrains);
            FilteredDrainsView.Filter = FilterDrainItem;

            // Set default export folder to match Part 01: AutoSlope_Reports
            ExportFolderPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "AutoSlope_Reports");

            // Create default folder if it doesn't exist
            if (!Directory.Exists(ExportFolderPath))
            {
                Directory.CreateDirectory(ExportFolderPath);
            }

            // Add initial log message
            AddLog("=== Auto Roof Sloper Initialized ===");
            AddLog("All vertices reset to zero elevation");
            AddLog("Detecting inner loop openings on top surface...");
            AddLog("Using 5mm tolerance to identify shape editing vertices on drain loops");
            AddLog($"Default export folder: {ExportFolderPath}");

            // Initialize with selected roof
            InitializeWithRoof(selectedRoof);
        }

        private void InitializeWithRoof(RoofBase roof)
        {
            try
            {
                AddLog($"Selected roof: {roof.Name}");
                RoofInfo = $"Selected Roof: {roof.Name} (Id: {roof.Id})";

                // Analyze roof
                _currentRoof = new RoofData { Roof = roof };
                AnalyzeRoofGeometry(_currentRoof);

                // Detect drains from inner loops only - PASS THE VERTICES for 5mm tolerance detection
                AddLog("Scanning for inner loop openings (excluding perimeter)...");
                AddLog("Finding shape editing vertices within 5mm tolerance of drain openings...");

                var detectedDrains = _drainService.DetectDrainsFromRoof(roof, _currentRoof.TopFace, _currentRoof.Vertices);
                _currentRoof.DetectedDrains = detectedDrains;

                // Update UI
                AllDrains.Clear();
                foreach (var drain in detectedDrains)
                {
                    AllDrains.Add(drain);

                    // Log drain information with vertex count
                    int vertexCount = drain.DrainVertices?.Count ?? 0;
                    AddLog($"Found opening: {drain.SizeCategory} ({drain.ShapeType}) with {vertexCount} shape vertices within 5mm tolerance");
                    AddLog($"  - Center at ({drain.CenterPoint.X:F0}, {drain.CenterPoint.Y:F0}, {drain.CenterPoint.Z:F0}) mm");

                    // Log first few vertex positions for verification
                    if (vertexCount > 0)
                    {
                        var firstVertex = drain.DrainVertices.First();
                        AddLog($"  - Sample vertex at ({firstVertex.Position.X * 304.8:F0}, {firstVertex.Position.Y * 304.8:F0}, {firstVertex.Position.Z * 304.8:F0}) mm");
                    }
                }

                // Update filters
                SizeFilters.Clear();
                var categories = _drainService.GenerateSizeCategories(detectedDrains);
                foreach (var category in categories)
                {
                    SizeFilters.Add(category);
                }

                if (detectedDrains.Count > 0)
                {
                    int totalDrainVertices = detectedDrains.Sum(d => d.DrainVertices?.Count ?? 0);
                    AddLog($"✓ Completed: Found {detectedDrains.Count} inner loop openings");
                    AddLog($"✓ Total {totalDrainVertices} shape vertices identified as drain points (5mm tolerance)");
                    AddLog("✓ Perimeter curves excluded");
                    AddLog("✓ All duplicates removed");
                    AddLog("✓ Drain vertices will be set to ZERO elevation during slope application");
                }
                else
                {
                    AddLog("ℹ No inner loop openings found on this roof");
                    AddLog("ℹ Make sure the roof has openings (holes) for drains");
                }

                UpdateSelectedCount();
            }
            catch (Exception ex)
            {
                AddLog($"✗ ERROR during roof analysis: {ex.Message}");
            }
        }

        private void ChangeRoof()
        {
            try
            {
                AddLog("Changing roof selection...");
                CloseWindow?.Invoke();
            }
            catch (Exception ex)
            {
                AddLog($"✗ ERROR: {ex.Message}");
            }
        }

        private void OkOperation()
        {
            AddLog("✓ Operation completed successfully.");
            CloseWindow?.Invoke();
        }

        /// <summary>
        /// Copy all log text to clipboard
        /// </summary>
        private void CopyLogToClipboard()
        {
            try
            {
                if (!string.IsNullOrEmpty(LogText))
                {
                    Clipboard.SetText(LogText);
                    AddLog("✓ Log copied to clipboard");
                }
                else
                {
                    AddLog("ℹ No log content to copy");
                }
            }
            catch (Exception ex)
            {
                AddLog($"✗ Failed to copy log: {ex.Message}");
            }
        }

        private bool FilterDrainItem(object obj)
        {
            var drain = obj as DrainItem;
            if (drain == null) return false;
            if (SelectedSizeFilter == "All") return true;

            var filtered = _drainService.FilterDrainsBySize(new List<DrainItem> { drain }, SelectedSizeFilter);
            return filtered.Any();
        }

        private void AnalyzeRoofGeometry(RoofData roofData)
        {
            try
            {
                var roof = roofData.Roof;

                // Get top face
                roofData.TopFace = GetTopFace(roof);
                if (roofData.TopFace == null)
                {
                    throw new Exception("Could not find top face of the roof.");
                }

                // Get vertices
                roofData.Vertices.Clear();
                var slabShapeEditor = roof.GetSlabShapeEditor();
                foreach (SlabShapeVertex vertex in slabShapeEditor.SlabShapeVertices)
                {
                    roofData.Vertices.Add(vertex);
                }

                AddLog($"Found {roofData.Vertices.Count} shape editing vertices on roof");
                AddLog($"Top face area: {CalculateFaceArea(roofData.TopFace):F2} m²");
            }
            catch (Exception ex)
            {
                throw new Exception($"Roof analysis failed: {ex.Message}");
            }
        }

        private double CalculateFaceArea(Face face)
        {
            try
            {
                var bb = face.GetBoundingBox();
                if (bb == null) return 0;

                double width = (bb.Max.U - bb.Min.U);
                double height = (bb.Max.V - bb.Min.V);
                return width * height * 0.0929; // Convert to m²
            }
            catch
            {
                return 0;
            }
        }

        private Face GetTopFace(RoofBase roof)
        {
            if (roof == null) return null;

            GeometryElement geomElem = roof.get_Geometry(new Options());
            Face topFace = null;
            double maxZ = double.MinValue;

            foreach (GeometryObject geomObj in geomElem)
            {
                if (geomObj is Solid solid)
                {
                    foreach (Face face in solid.Faces)
                    {
                        if (face == null) continue;

                        BoundingBoxUV bb = face.GetBoundingBox();
                        if (bb == null) continue;

                        UV midpointUV = new UV((bb.Min.U + bb.Max.U) / 2, (bb.Min.V + bb.Max.V) / 2);
                        XYZ midpoint = face.Evaluate(midpointUV);

                        if (midpoint != null && midpoint.Z > maxZ)
                        {
                            maxZ = midpoint.Z;
                            topFace = face;
                        }
                    }
                }
            }
            return topFace;
        }

        /// <summary>
        /// Browse for export folder - matches Part 01 behavior
        /// </summary>
        private void BrowseExportFolder()
        {
            try
            {
                // Create default folder if it doesn't exist - using AutoSlope_Reports
                if (string.IsNullOrEmpty(ExportFolderPath))
                {
                    ExportFolderPath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "AutoSlope_Reports");
                }

                // Create directory if it doesn't exist (helps with folder selection)
                if (!Directory.Exists(ExportFolderPath))
                {
                    Directory.CreateDirectory(ExportFolderPath);
                }

                // Use DialogService to select folder (same as Part 01)
                string selectedPath = DialogService.SelectFolder(ExportFolderPath);

                if (!string.IsNullOrEmpty(selectedPath))
                {
                    ExportFolderPath = selectedPath;
                    AddLog($"✓ Export folder set to: {ExportFolderPath}");

                    // Ensure directory exists
                    if (!Directory.Exists(ExportFolderPath))
                    {
                        Directory.CreateDirectory(ExportFolderPath);
                        AddLog($"  - Created directory: {ExportFolderPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                AddLog($"✗ Error selecting folder: {ex.Message}");
            }
        }

        private bool CanExportResults()
        {
            return _currentRoof != null &&
                   AllDrains.Any(d => d.IsSelected) &&
                   ExportToCsv &&
                   _slopeService.GetLastExportData() != null;
        }

        /// <summary>
        /// Export results to CSV - matches Part 01 behavior (auto-saves to configured folder)
        /// </summary>
        private void ExportResults()
        {
            try
            {
                if (!ExportToCsv)
                {
                    AddLog("ℹ CSV export is disabled. Enable it in settings.");
                    return;
                }

                // Check if we have data to export
                if (_currentRoof == null)
                {
                    AddLog("⚠ No roof data available. Please apply slopes first.");
                    return;
                }

                var vertexDataList = _slopeService.GetLastExportData();
                if (vertexDataList == null || vertexDataList.Count == 0)
                {
                    AddLog("⚠ No vertex data available. Please apply slopes first.");
                    return;
                }

                // Check and create export folder if needed - using AutoSlope_Reports
                if (string.IsNullOrEmpty(ExportFolderPath))
                {
                    ExportFolderPath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                        "AutoSlope_Reports");
                }

                if (!Directory.Exists(ExportFolderPath))
                {
                    try
                    {
                        Directory.CreateDirectory(ExportFolderPath);
                        AddLog($"Created export directory: {ExportFolderPath}");
                    }
                    catch (Exception ex)
                    {
                        AddLog($"⚠ Failed to create export directory: {ex.Message}");
                        return;
                    }
                }

                var selectedDrains = AllDrains.Where(d => d.IsSelected).ToList();

                // Create export config
                var exportConfig = new ExportConfig
                {
                    ExportPath = ExportFolderPath,
                    ExportToCsv = ExportToCsv,
                    IncludeVertexDetails = IncludeVertexDetails,
                    FileNamePrefix = "DrainDetection_",
                    IncludeTimestamp = true
                };

                AddLog("📊 Preparing export data...");
                AddLog($"Export folder: {ExportFolderPath}");

                // Export based on settings
                string exportedFile = null;

                if (IncludeVertexDetails)
                {
                    exportedFile = CsvExportHelper.ExportDetailedVertexData(
                        exportConfig,
                        vertexDataList,
                        _currentRoof.Roof,
                        selectedDrains,
                        double.Parse(SlopeInput),
                        AddLog);
                }
                else
                {
                    exportedFile = CsvExportHelper.ExportCompactVertexData(
                        exportConfig,
                        vertexDataList,
                        _currentRoof.Roof,
                        double.Parse(SlopeInput),
                        AddLog);
                }

                // Calculate metrics for summary
                var processedVertices = vertexDataList.Count(v => v.WasProcessed);
                var skippedVertices = vertexDataList.Count(v => !v.WasProcessed);

                double highestElevation = 0;
                double longestPath = 0;

                if (processedVertices > 0)
                {
                    highestElevation = vertexDataList.Where(v => v.WasProcessed).Max(v => v.ElevationOffsetMm);
                    longestPath = vertexDataList.Where(v => v.WasProcessed).Max(v => v.PathLengthMeters);
                }

                // Export summary
                var metrics = new DrainExportMetrics
                {
                    ProcessedVertices = processedVertices,
                    SkippedVertices = skippedVertices,
                    DrainCount = selectedDrains.Count,
                    HighestElevationMm = highestElevation,
                    LongestPathM = longestPath,
                    SlopePercent = double.Parse(SlopeInput),
                    RunDurationSec = _slopeService.LastRunDuration,
                    RunDate = DateTime.Now.ToString("dd-MM-yy HH:mm"),
                    RoofId = _currentRoof.Roof.Id.Value.ToString(),
                    RoofName = _currentRoof.Roof.Name
                };

                string summaryFile = CsvExportHelper.ExportSummaryOnly(
                    exportConfig,
                    metrics,
                    _currentRoof.Roof,
                    double.Parse(SlopeInput),
                    AddLog);

                // Show success message with file locations
                AddLog($"✓ Export completed successfully!");
                if (!string.IsNullOrEmpty(exportedFile))
                {
                    AddLog($"  - Vertex data: {Path.GetFileName(exportedFile)}");
                }
                if (!string.IsNullOrEmpty(summaryFile))
                {
                    AddLog($"  - Summary: {Path.GetFileName(summaryFile)}");
                }
                AddLog($"  - Location: {ExportFolderPath}");

                // Optional: Ask to open folder
                var result = MessageBox.Show(
                    "Export completed successfully!\n\nDo you want to open the export folder?",
                    "Export Complete",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    System.Diagnostics.Process.Start("explorer.exe", ExportFolderPath);
                }
            }
            catch (Exception ex)
            {
                AddLog($"✗ Export failed: {ex.Message}");
            }
        }

        /// <summary>
        /// Updated ApplySlopes method - uses pre-identified drain vertices
        /// </summary>
        private void ApplySlopes()
        {
            try
            {
                if (_currentRoof == null)
                {
                    AddLog("✗ ERROR: No roof data available.");
                    return;
                }

                // Parse slope input
                if (!double.TryParse(SlopeInput, out double slopePercentage) || slopePercentage <= 0)
                {
                    AddLog("✗ ERROR: Please enter a valid positive slope percentage.");
                    return;
                }

                var selectedDrains = AllDrains.Where(d => d.IsSelected).ToList();
                if (selectedDrains.Count == 0)
                {
                    AddLog("⚠ WARNING: No drains selected for slope application");
                    return;
                }

                // Count total drain vertices that will be set to zero
                int totalDrainVertices = selectedDrains.Sum(d => d.DrainVertices?.Count ?? 0);

                AddLog($"Applying {slopePercentage}% slope to {selectedDrains.Count} drains...");
                AddLog($"Found {totalDrainVertices} shape vertices on selected drain loops (5mm tolerance)");
                AddLog("These vertices will be set to ZERO elevation as drain points");
                AddLog("Processing... (this may take a moment)");

                // Process slopes and get results
                var results = _slopeService.ProcessRoofSlopes(_currentRoof, selectedDrains, slopePercentage, AddLog);

                // Update results display
                ResultsInfo = $"Results: {results.modifiedCount} vertices modified | " +
                             $"Max offset: {results.maxOffset:F1} mm | " +
                             $"Longest path: {results.longestPath:F2} m";

                AddLog($"✓ SUCCESS: Modified {results.modifiedCount} vertices");
                AddLog($"✓ Maximum elevation offset: {results.maxOffset:F1} mm");
                AddLog($"✓ Longest drainage path: {results.longestPath:F2} meters");
                AddLog($"✓ Slope calculation based on {totalDrainVertices} drain vertices (accurate drainage)");

                // Auto-export if enabled
                if (ExportToCsv && !string.IsNullOrEmpty(ExportFolderPath))
                {
                    AddLog("📊 Auto-exporting results...");
                    ExportResults();
                }

                // Update CanExecute for Export button
                ((RelayCommand)ExportResultsCommand).RaiseCanExecuteChanged();

                // PERMANENTLY DISABLE THE APPLY SLOPE BUTTON
                SlopeApplied = true;
                AddLog("🔒 Apply Slope button has been permanently disabled (operation completed)");
            }
            catch (Exception ex)
            {
                AddLog($"✗ ERROR during slope application: {ex.Message}");
            }
        }

        private void CancelOperation()
        {
            AddLog("Operation cancelled by user.");
            CloseWindow?.Invoke();
        }

        /// <summary>
        /// Updated CanApplySlopes method - checks if slope has already been applied
        /// </summary>
        private bool CanApplySlopes()
        {
            return _currentRoof != null &&
                   AllDrains.Any(d => d.IsSelected) &&
                   !SlopeApplied; // Permanently disabled after first application
        }

        private void SelectAllDrains()
        {
            foreach (var drain in AllDrains)
            {
                drain.IsSelected = true;
            }
            FilteredDrainsView.Refresh();
            UpdateSelectedCount();

            int totalVertices = AllDrains.Sum(d => d.DrainVertices?.Count ?? 0);
            AddLog($"All {AllDrains.Count} drains selected ({totalVertices} total drain vertices)");

            ((RelayCommand)ApplySlopesCommand).RaiseCanExecuteChanged();
            ((RelayCommand)ExportResultsCommand).RaiseCanExecuteChanged();
        }

        private void SelectNoneDrains()
        {
            foreach (var drain in AllDrains)
            {
                drain.IsSelected = false;
            }
            FilteredDrainsView.Refresh();
            UpdateSelectedCount();
            AddLog("All drains deselected");
            ((RelayCommand)ApplySlopesCommand).RaiseCanExecuteChanged();
            ((RelayCommand)ExportResultsCommand).RaiseCanExecuteChanged();
        }

        private void InvertDrainSelection()
        {
            foreach (var drain in AllDrains)
            {
                drain.IsSelected = !drain.IsSelected;
            }
            FilteredDrainsView.Refresh();
            UpdateSelectedCount();

            int selectedCount = AllDrains.Count(d => d.IsSelected);
            int totalVertices = AllDrains.Where(d => d.IsSelected).Sum(d => d.DrainVertices?.Count ?? 0);
            AddLog($"Selection inverted: {selectedCount} drains selected ({totalVertices} total drain vertices)");

            ((RelayCommand)ApplySlopesCommand).RaiseCanExecuteChanged();
            ((RelayCommand)ExportResultsCommand).RaiseCanExecuteChanged();
        }

        private void FilterDrains()
        {
            FilteredDrainsView.Refresh();
            UpdateSelectedCount();
        }

        private void UpdateSelectedCount()
        {
            int count = 0;
            foreach (var drain in FilteredDrainsView.Cast<DrainItem>())
            {
                if (drain.IsSelected)
                {
                    count++;
                }
            }
            SelectedDrainsCount = count;
        }

        public void AddLog(string message)
        {
            var timestamp = DateTime.Now.ToString("HH:mm:ss");
            LogText += $"[{timestamp}] {message}\n";

            // Auto-scroll to bottom
            OnPropertyChanged(nameof(LogText));
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // RelayCommand implementation for C# 7.3
    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute();
        }

        public void Execute(object parameter)
        {
            _execute();
        }

        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}