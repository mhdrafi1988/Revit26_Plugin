// =======================================================
// File: RidgePairResult.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.V021
// New in V021 — Ridge Point Detection (opt-in).
//
// One instance per adjacent drain-group pair (Delaunay-derived).
// Carries enough detail for the processing log, the "Ridge Points"
// UI metric cards, and the Excel detailed export's new Ridge sheet.
// =======================================================

using Autodesk.Revit.DB;

namespace Revit26_Plugin.AutoSlopeByPoint.V021.Core.Models
{
    public class RidgePairResult
    {
        /// <summary>1-based display index of this pair, in the order it was processed (shortest group-center distance first).</summary>
        public int PairIndex { get; set; }

        /// <summary>Index of the first drain group in the pair (into the engine's internal group list).</summary>
        public int GroupAIndex { get; set; }

        /// <summary>Index of the second drain group in the pair.</summary>
        public int GroupBIndex { get; set; }

        /// <summary>Center (centroid) of group A.</summary>
        public XYZ GroupACenter { get; set; }

        /// <summary>Center (centroid) of group B.</summary>
        public XYZ GroupBCenter { get; set; }

        /// <summary>Straight-line distance between group centers, internal feet.</summary>
        public double CenterDistanceFt { get; set; }

        /// <summary>True if a valid ridge vertex was found and applied in the "positive" perpendicular direction.</summary>
        public bool PositiveSideResolved { get; set; }

        /// <summary>True if a valid ridge vertex was found and applied in the "negative" perpendicular direction.</summary>
        public bool NegativeSideResolved { get; set; }

        /// <summary>Vertex index (into the roof's SlabShapeVertex list) chosen on the positive side, or -1 if none.</summary>
        public int PositiveSideVertexIndex { get; set; } = -1;

        /// <summary>Vertex index chosen on the negative side, or -1 if none.</summary>
        public int NegativeSideVertexIndex { get; set; } = -1;

        /// <summary>
        /// True if this pair was skipped entirely (no ridge vertex found on either
        /// side, within the roof's bounding-box search extent). Logged as Info,
        /// per spec — these vertices simply fall back to standard per-vertex Dijkstra.
        /// </summary>
        public bool Skipped => !PositiveSideResolved && !NegativeSideResolved;

        /// <summary>Count of ridge points actually resolved for this pair (0, 1, or 2).</summary>
        public int ResolvedCount => (PositiveSideResolved ? 1 : 0) + (NegativeSideResolved ? 1 : 0);
    }
}
