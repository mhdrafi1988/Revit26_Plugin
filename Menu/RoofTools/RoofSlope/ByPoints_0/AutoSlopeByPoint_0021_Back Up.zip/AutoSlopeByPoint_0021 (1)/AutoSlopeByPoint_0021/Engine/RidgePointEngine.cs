// =======================================================
// File: RidgePointEngine.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.V021
// New in V021 — Ridge Point Detection (opt-in, off by default).
//
// Responsibilities (per the confirmed spec / Q&A):
//   1. Cluster the flat DrainPoints cloud into drain groups by mutual
//      proximity, using the SAME tolerance value already used for
//      drain-tolerance expansion (no separate "group tolerance" input).
//   2. Build an adjacency graph over group centers via Delaunay
//      triangulation (a group can be adjacent to multiple neighbors).
//   3. For each adjacent pair (processed shortest-center-distance-first):
//        - center of each group = centroid of its points
//        - midpoint of the line between the two centers
//        - perpendicular line through the midpoint, in the roof's plane
//        - search both directions for the nearest EXISTING SlabShapeVertex,
//          bounded by the roof's bounding box
//        - if a vertex was already claimed by an earlier-processed pair,
//          skip it and take the next-nearest candidate instead
//        - if no vertex found in a direction, that side is left
//          unresolved (pair may be partially or fully skipped)
//
// Ridge ELEVATION is computed by the caller (AutoSlopeEngine), which
// already has the multi-source Dijkstra distances to every group.
// This class only answers "where are the ridge points, and which two
// groups do they mediate" — no elevation math here.
// =======================================================

using Autodesk.Revit.DB;
using Revit26_Plugin.AutoSlopeByPoint.V021.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.AutoSlopeByPoint.V021.Core.Engine
{
    /// <summary>A cluster of drain points that are mutually within the clustering tolerance.</summary>
    public class DrainGroup
    {
        public int GroupIndex;
        public List<XYZ> Points = new();
        public XYZ Center;

        /// <summary>Vertex indices (into the roof's SlabShapeVertex list) matching this group's points.</summary>
        public List<int> VertexIndices = new();
    }

    /// <summary>An adjacency edge between two drain groups, per Delaunay triangulation of group centers.</summary>
    public class GroupAdjacency
    {
        public int GroupAIndex;
        public int GroupBIndex;
        public double CenterDistanceFt;
    }

    public static class RidgePointEngine
    {
        /// <summary>
        /// Clusters drain points into groups using single-linkage proximity:
        /// two points are in the same group if within clusterToleranceFt of
        /// ANY other point already in that group (transitive union).
        /// </summary>
        public static List<DrainGroup> ClusterDrainPoints(
            List<XYZ> drainPoints, double clusterToleranceFt)
        {
            var groups = new List<DrainGroup>();
            if (drainPoints == null || drainPoints.Count == 0) return groups;

            int n = drainPoints.Count;
            var parent = new int[n];
            for (int i = 0; i < n; i++) parent[i] = i;

            int Find(int x) { while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
            void Union(int a, int b) { int ra = Find(a), rb = Find(b); if (ra != rb) parent[ra] = rb; }

            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (drainPoints[i].DistanceTo(drainPoints[j]) <= clusterToleranceFt)
                        Union(i, j);
                }
            }

            var byRoot = new Dictionary<int, DrainGroup>();
            for (int i = 0; i < n; i++)
            {
                int root = Find(i);
                if (!byRoot.TryGetValue(root, out var grp))
                {
                    grp = new DrainGroup { GroupIndex = byRoot.Count };
                    byRoot[root] = grp;
                    groups.Add(grp);
                }
                grp.Points.Add(drainPoints[i]);
            }

            // Re-index sequentially (0..count-1) since dictionary insertion order
            // already matches first-seen order, but GroupIndex was set at creation
            // time using byRoot.Count which is safe/unique — no re-sort needed.
            foreach (var grp in groups)
            {
                double cx = grp.Points.Average(p => p.X);
                double cy = grp.Points.Average(p => p.Y);
                double cz = grp.Points.Average(p => p.Z);
                grp.Center = new XYZ(cx, cy, cz);
            }

            return groups;
        }

        /// <summary>
        /// Matches each group's points to roof vertex indices (within drainMatchToleranceFt),
        /// populating DrainGroup.VertexIndices. Mirrors the matching tolerance used elsewhere
        /// in AutoSlopeEngine for consistency.
        /// </summary>
        public static void MatchGroupVertices(
            List<DrainGroup> groups, List<SlabShapeVertex> vertices, double drainMatchToleranceFt)
        {
            foreach (var grp in groups)
            {
                grp.VertexIndices.Clear();
                foreach (XYZ pt in grp.Points)
                {
                    for (int i = 0; i < vertices.Count; i++)
                    {
                        if (vertices[i].Position.DistanceTo(pt) <= drainMatchToleranceFt)
                        {
                            if (!grp.VertexIndices.Contains(i))
                                grp.VertexIndices.Add(i);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Builds the Delaunay triangulation of group centers (projected to the roof's
        /// working plane via topFace's UV) and returns the resulting edges as group
        /// adjacencies. Falls back to a full nearest-neighbor mesh if fewer than 3
        /// groups exist (Delaunay needs >=3 points to form triangles) — with 2 groups
        /// the only possible adjacency is trivially between the two, and with 1 group
        /// there are none.
        /// </summary>
        public static List<GroupAdjacency> BuildDelaunayAdjacency(List<DrainGroup> groups, Face topFace)
        {
            var result = new List<GroupAdjacency>();
            if (groups == null || groups.Count < 2) return result;

            if (groups.Count == 2)
            {
                result.Add(new GroupAdjacency
                {
                    GroupAIndex = groups[0].GroupIndex,
                    GroupBIndex = groups[1].GroupIndex,
                    CenterDistanceFt = groups[0].Center.DistanceTo(groups[1].Center)
                });
                return result;
            }

            // Project centers to 2D (UV on the roof's top face) for triangulation.
            var uvPoints = new List<UV>(groups.Count);
            foreach (var grp in groups)
            {
                IntersectionResult proj = topFace.Project(grp.Center);
                uvPoints.Add(proj != null ? proj.UVPoint : new UV(grp.Center.X, grp.Center.Y));
            }

            var edges = DelaunayTriangulation.ComputeEdges(uvPoints);

            foreach (var (ia, ib) in edges)
            {
                result.Add(new GroupAdjacency
                {
                    GroupAIndex = groups[ia].GroupIndex,
                    GroupBIndex = groups[ib].GroupIndex,
                    CenterDistanceFt = groups[ia].Center.DistanceTo(groups[ib].Center)
                });
            }

            return result;
        }

        /// <summary>
        /// For one adjacent group pair, searches both perpendicular directions from
        /// the pair's midpoint for the nearest existing roof vertex, bounded by the
        /// roof's bounding box. claimedVertices tracks vertex indices already taken
        /// by earlier-processed pairs (shortest-distance-first order) — those are
        /// skipped in favor of the next-nearest candidate.
        /// </summary>
        public static RidgePairResult FindRidgePoints(
            int pairIndex,
            DrainGroup groupA,
            DrainGroup groupB,
            List<SlabShapeVertex> vertices,
            Face topFace,
            HashSet<int> claimedVertices)
        {
            var result = new RidgePairResult
            {
                PairIndex = pairIndex,
                GroupAIndex = groupA.GroupIndex,
                GroupBIndex = groupB.GroupIndex,
                GroupACenter = groupA.Center,
                GroupBCenter = groupB.Center,
                CenterDistanceFt = groupA.Center.DistanceTo(groupB.Center)
            };

            XYZ a = groupA.Center;
            XYZ b = groupB.Center;
            XYZ mid = (a + b) * 0.5;

            XYZ along = (b - a);
            if (along.GetLength() < 0.001) return result; // coincident centers — nothing sensible to do

            along = along.Normalize();

            // Perpendicular, in-plane with the roof's top face at the midpoint.
            XYZ normal;
            try
            {
                IntersectionResult proj = topFace.Project(mid);
                normal = proj != null ? topFace.ComputeNormal(proj.UVPoint) : XYZ.BasisZ;
            }
            catch { normal = XYZ.BasisZ; }

            XYZ perp = along.CrossProduct(normal);
            if (perp.GetLength() < 0.001) perp = along.CrossProduct(XYZ.BasisZ);
            perp = perp.Normalize();

            BoundingBoxXYZ bbox = SafeGetBoundingBox(topFace);

            int posIdx = FindNearestOnRay(mid, perp, vertices, bbox, claimedVertices);
            int negIdx = FindNearestOnRay(mid, perp.Negate(), vertices, bbox, claimedVertices);

            if (posIdx >= 0)
            {
                result.PositiveSideResolved = true;
                result.PositiveSideVertexIndex = posIdx;
                claimedVertices.Add(posIdx);
            }

            if (negIdx >= 0)
            {
                result.NegativeSideResolved = true;
                result.NegativeSideVertexIndex = negIdx;
                claimedVertices.Add(negIdx);
            }

            return result;
        }

        /// <summary>
        /// Walks outward from origin along direction, and returns the vertex index
        /// closest to the ray (perpendicular distance) among those that lie roughly
        /// ahead of the origin (positive projection onto direction) and within the
        /// roof's bounding box. Skips any index already in claimed.
        /// "First point encountered" is interpreted as nearest-to-the-line rather
        /// than a literal sweep, per the confirmed spec (closest-to-perpendicular
        /// candidate wins).
        /// </summary>
        private static int FindNearestOnRay(
            XYZ origin, XYZ direction, List<SlabShapeVertex> vertices,
            BoundingBoxXYZ bbox, HashSet<int> claimed)
        {
            int best = -1;
            double bestPerpDist = double.MaxValue;
            double bestAlong = double.MaxValue;

            for (int i = 0; i < vertices.Count; i++)
            {
                if (claimed.Contains(i)) continue;

                XYZ p = vertices[i].Position;
                if (bbox != null && !IsWithinBoundingBox(p, bbox)) continue;

                XYZ toP = p - origin;
                double along = toP.DotProduct(direction);
                if (along <= 0.001) continue; // must be ahead, in this direction

                XYZ alongVec = direction * along;
                double perpDist = (toP - alongVec).GetLength();

                // Prefer the candidate closest to the perpendicular line; break ties
                // by whichever is encountered first along the direction (smaller 'along').
                if (perpDist < bestPerpDist - 1e-6 ||
                    (Math.Abs(perpDist - bestPerpDist) <= 1e-6 && along < bestAlong))
                {
                    bestPerpDist = perpDist;
                    bestAlong = along;
                    best = i;
                }
            }

            return best;
        }

        private static bool IsWithinBoundingBox(XYZ p, BoundingBoxXYZ bbox)
        {
            const double padFt = 0.05; // ~15mm slack for boundary-riding points
            return p.X >= bbox.Min.X - padFt && p.X <= bbox.Max.X + padFt &&
                   p.Y >= bbox.Min.Y - padFt && p.Y <= bbox.Max.Y + padFt &&
                   p.Z >= bbox.Min.Z - padFt && p.Z <= bbox.Max.Z + padFt;
        }

        private static BoundingBoxXYZ SafeGetBoundingBox(Face face)
        {
            try
            {
                BoundingBoxUV bb = face.GetBoundingBox();
                if (bb == null) return null;

                // Sample the 4 UV corners to build a real-space XYZ bounding box —
                // cheaper and more robust than trying to derive one analytically.
                var corners = new[]
                {
                    face.Evaluate(new UV(bb.Min.U, bb.Min.V)),
                    face.Evaluate(new UV(bb.Min.U, bb.Max.V)),
                    face.Evaluate(new UV(bb.Max.U, bb.Min.V)),
                    face.Evaluate(new UV(bb.Max.U, bb.Max.V)),
                };

                double minX = corners.Min(c => c.X), maxX = corners.Max(c => c.X);
                double minY = corners.Min(c => c.Y), maxY = corners.Max(c => c.Y);
                double minZ = corners.Min(c => c.Z), maxZ = corners.Max(c => c.Z);

                var box = new BoundingBoxXYZ
                {
                    Min = new XYZ(minX, minY, minZ),
                    Max = new XYZ(maxX, maxY, maxZ)
                };
                return box;
            }
            catch
            {
                return null;
            }
        }
    }
}
