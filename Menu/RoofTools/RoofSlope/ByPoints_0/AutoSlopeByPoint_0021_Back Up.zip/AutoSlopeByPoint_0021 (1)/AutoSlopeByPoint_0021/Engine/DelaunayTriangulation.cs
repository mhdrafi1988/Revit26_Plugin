// =======================================================
// File: DelaunayTriangulation.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.V021
// New in V021 — Ridge Point Detection (opt-in).
//
// Minimal Bowyer-Watson Delaunay triangulation over a 2D point set
// (Autodesk.Revit.DB.UV). Used to build the drain-group adjacency
// graph: a group is "adjacent" to another if a Delaunay edge connects
// their centers — i.e. no other group's center lies "between" them,
// per the confirmed spec.
//
// This is a self-contained O(n^2)-ish implementation appropriate for
// the expected small N (drain group counts are typically single or
// low double digits per roof) — not intended for large point clouds.
// =======================================================

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.AutoSlopeByPoint.V021.Core.Engine
{
    public static class DelaunayTriangulation
    {
        private struct Triangle
        {
            public int A, B, C;
            public UV Circumcenter;
            public double CircumRadiusSq;
        }

        /// <summary>
        /// Computes the Delaunay triangulation of the given points and returns
        /// the unique set of edges as (index, index) pairs (indices into the
        /// input list, i less than j).
        /// </summary>
        public static List<(int, int)> ComputeEdges(List<UV> points)
        {
            var edgeSet = new HashSet<(int, int)>();

            int n = points.Count;
            if (n < 2) return new List<(int, int)>();
            if (n == 2) { edgeSet.Add((0, 1)); return edgeSet.ToList(); }

            // Degenerate case: all points collinear (common for 2-3 drain groups
            // in a row) — Delaunay triangles can't form. Fall back to connecting
            // consecutive points along the dominant axis, which is the only
            // sensible "adjacency" for a collinear layout anyway.
            if (ArePointsCollinear(points))
            {
                var sorted = points
                    .Select((p, idx) => (p, idx))
                    .OrderBy(t => t.p.U).ThenBy(t => t.p.V)
                    .ToList();
                for (int k = 0; k < sorted.Count - 1; k++)
                {
                    int i1 = sorted[k].idx, i2 = sorted[k + 1].idx;
                    edgeSet.Add(i1 < i2 ? (i1, i2) : (i2, i1));
                }
                return edgeSet.ToList();
            }

            // Super-triangle large enough to contain all points.
            double minU = points.Min(p => p.U), maxU = points.Max(p => p.U);
            double minV = points.Min(p => p.V), maxV = points.Max(p => p.V);
            double dMax = Math.Max(maxU - minU, maxV - minV) * 10 + 10;
            double midU = (minU + maxU) / 2, midV = (minV + maxV) / 2;

            var pts = new List<UV>(points);
            int superA = pts.Count, superB = pts.Count + 1, superC = pts.Count + 2;
            pts.Add(new UV(midU - 2 * dMax, midV - dMax));
            pts.Add(new UV(midU + 2 * dMax, midV - dMax));
            pts.Add(new UV(midU, midV + 2 * dMax));

            var triangles = new List<Triangle> { MakeTriangle(pts, superA, superB, superC) };

            for (int pi = 0; pi < points.Count; pi++)
            {
                UV p = pts[pi];
                var badTriangles = new List<Triangle>();

                foreach (var t in triangles)
                {
                    double dx = p.U - t.Circumcenter.U;
                    double dy = p.V - t.Circumcenter.V;
                    if (dx * dx + dy * dy <= t.CircumRadiusSq + 1e-9)
                        badTriangles.Add(t);
                }

                // Find boundary of the polygonal hole (edges not shared by 2 bad triangles).
                var polygon = new List<(int, int)>();
                foreach (var t in badTriangles)
                {
                    var edges = new[] { (t.A, t.B), (t.B, t.C), (t.C, t.A) };
                    foreach (var e in edges)
                    {
                        bool shared = badTriangles.Any(other =>
                            !EqualsTriangle(other, t) && TriangleHasEdge(other, e));
                        if (!shared) polygon.Add(e);
                    }
                }

                triangles.RemoveAll(t => badTriangles.Any(bt => EqualsTriangle(bt, t)));

                foreach (var e in polygon)
                    triangles.Add(MakeTriangle(pts, e.Item1, e.Item2, pi));
            }

            // Remove any triangle touching the super-triangle vertices.
            triangles.RemoveAll(t =>
                t.A >= points.Count || t.B >= points.Count || t.C >= points.Count);

            foreach (var t in triangles)
            {
                AddEdge(edgeSet, t.A, t.B);
                AddEdge(edgeSet, t.B, t.C);
                AddEdge(edgeSet, t.C, t.A);
            }

            return edgeSet.ToList();
        }

        private static bool ArePointsCollinear(List<UV> points)
        {
            if (points.Count < 3) return true;
            UV p0 = points[0];
            UV dir = new UV(0, 0);
            for (int i = 1; i < points.Count; i++)
            {
                double du = points[i].U - p0.U, dv = points[i].V - p0.V;
                if (Math.Abs(du) > 1e-9 || Math.Abs(dv) > 1e-9)
                {
                    dir = new UV(du, dv);
                    break;
                }
            }
            if (dir.U == 0 && dir.V == 0) return true; // all points coincide

            foreach (var p in points)
            {
                double cross = (p.U - p0.U) * dir.V - (p.V - p0.V) * dir.U;
                if (Math.Abs(cross) > 1e-6) return false;
            }
            return true;
        }

        private static void AddEdge(HashSet<(int, int)> set, int i, int j)
        {
            if (i == j) return;
            set.Add(i < j ? (i, j) : (j, i));
        }

        private static bool TriangleHasEdge(Triangle t, (int, int) e)
        {
            var verts = new[] { t.A, t.B, t.C };
            return verts.Contains(e.Item1) && verts.Contains(e.Item2);
        }

        private static bool EqualsTriangle(Triangle x, Triangle y)
        {
            var xs = new[] { x.A, x.B, x.C }.OrderBy(v => v).ToArray();
            var ys = new[] { y.A, y.B, y.C }.OrderBy(v => v).ToArray();
            return xs[0] == ys[0] && xs[1] == ys[1] && xs[2] == ys[2];
        }

        private static Triangle MakeTriangle(List<UV> pts, int a, int b, int c)
        {
            UV pa = pts[a], pb = pts[b], pc = pts[c];
            ComputeCircumcircle(pa, pb, pc, out UV center, out double radiusSq);
            return new Triangle { A = a, B = b, C = c, Circumcenter = center, CircumRadiusSq = radiusSq };
        }

        private static void ComputeCircumcircle(UV a, UV b, UV c, out UV center, out double radiusSq)
        {
            double ax = a.U, ay = a.V, bx = b.U, by = b.V, cx = c.U, cy = c.V;
            double d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));

            if (Math.Abs(d) < 1e-12)
            {
                // Degenerate/near-collinear triangle: fall back to a center far away
                // so it never wins an in-circle test in practice.
                center = new UV(ax, ay);
                radiusSq = double.MaxValue;
                return;
            }

            double ax2ay2 = ax * ax + ay * ay;
            double bx2by2 = bx * bx + by * by;
            double cx2cy2 = cx * cx + cy * cy;

            double ux = (ax2ay2 * (by - cy) + bx2by2 * (cy - ay) + cx2cy2 * (ay - by)) / d;
            double uy = (ax2ay2 * (cx - bx) + bx2by2 * (ax - cx) + cx2cy2 * (bx - ax)) / d;

            center = new UV(ux, uy);
            double dx = ax - ux, dy = ay - uy;
            radiusSq = dx * dx + dy * dy;
        }
    }
}
