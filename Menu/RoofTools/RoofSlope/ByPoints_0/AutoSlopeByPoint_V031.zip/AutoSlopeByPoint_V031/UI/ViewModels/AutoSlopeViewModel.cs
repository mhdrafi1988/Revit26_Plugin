// =======================================================
// File: AutoSlopeViewModel.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.V031.UI.ViewModels
// Rewritten for V031 on Shared ToolViewModelBase (plan 1.1): IsRunning /
// Progress / SummaryText, the log collection (2,000 cap) and the Copy /
// Clear log commands come from the base class.
// Changes vs V030 (codes refer to claude/AutoSlopeByPoint_V030_Refactor_Plan.md):
//   B2  defaults come from AutoSlopeConstants via AutoSlopeSettings
//   B3  drainage distance and max link length are separate decimal inputs
//   B4  no garbled strings
//   B7  Run snapshots an immutable AutoSlopeRequest; inputs lock while running
//   B8  real start / end / total seconds
//   B9  every file open goes through DialogService.TryOpenFile
//   2.1 6 result tiles, "—" before the first run, plan-view badge
//   2.3 inline validation; Run disabled with the reason in the status strip
//   2.5 one RunState drives the UI; Run again after a run
//   D2  Drain mode option; re-pick drains from the window
// =======================================================

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Data;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Events;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.AutoSlopeByPoint.V031.Core.Models;
using Revit26_Plugin.AutoSlopeByPoint.V031.Core.Services;
using Revit26_Plugin.AutoSlopeByPoint.V031.Infrastructure.ExternalEvents;
using Revit26_Plugin.AutoSlopeByPoint.V031.Infrastructure.Helpers;
using Revit26_Plugin.AutoSlopeByPoint.V031.Infrastructure.RoofOps;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.Shared.Services;
using Revit26_Plugin.Shared.ViewModels;

namespace Revit26_Plugin.AutoSlopeByPoint.V031.UI.ViewModels
{
    public sealed record DrainModeOption(DrainMode Mode, string Label, string Hint);

    public sealed partial class AutoSlopeViewModel : ToolViewModelBase, IDisposable
    {
        private const string Dash = "—";
        private const int PumpIntervalMs = 100;

        private readonly UIApplication _app;
        private readonly Dispatcher _dispatcher;
        private readonly long _roofIdValue;
        private readonly string _projectTitle;
        private List<Point3> _picks;
        private CancellationTokenSource _cts;
        private AutoSlopeResult _lastResult;
        private DateTime _runStart;
        private DateTime _lastPump = DateTime.MinValue;
        private RunState _stateBeforePicking = RunState.Ready;
        private bool _loading = true;
        private bool _disposed;

        public AutoSlopeViewModel(UIApplication app, RoofBase roof, List<Point3> picks)
        {
            _app = app;
            _dispatcher = Dispatcher.CurrentDispatcher;
            _roofIdValue = roof.Id.Value;
            _projectTitle = roof.Document?.Title ?? "Unknown project";
            _picks = picks ?? new List<Point3>();

            RoofInfo info = ProjectQueries.DescribeRoof(roof);
            RoofText = $"{info.TypeName} · Id {info.IdValue}";
            RoofLevelText = $"Level: {info.BaseLevelName}";

            var lineStyles = ProjectQueries.GetLineStyles(roof.Document);
            MarkerGroups = new ObservableCollection<CircleMarkerGroupViewModel>
            {
                new CircleMarkerGroupViewModel(MarkerGroupKind.Drain, "Drains",
                    "A circle on each drain point.", AutoSlopeConstants.DefaultDrainColor, lineStyles),
                new CircleMarkerGroupViewModel(MarkerGroupKind.HighestPoint, "Highest point",
                    "A circle on every point tied at the highest calculated elevation.", AutoSlopeConstants.DefaultHighestColor, lineStyles),
                new CircleMarkerGroupViewModel(MarkerGroupKind.AllowedOffset, "Allowed offset",
                    "A circle on every point at or above the threshold, except points already marked highest.", AutoSlopeConstants.DefaultOffsetColor, lineStyles),
            };
            foreach (var g in MarkerGroups) g.PropertyChanged += OnMarkerGroupChanged;

            LogView = CollectionViewSource.GetDefaultView(LogEntries);
            LogView.Filter = PassesLogFilter;
            LogEntries.CollectionChanged += OnLogChanged;

            if (lineStyles.Count == 0)
                AddLog(LogLevel.Warning, "This project has no line styles, so circle markers use the default line style.");

            LoadSettings();
            UpdateViewBadge(_app.ActiveUIDocument?.ActiveView);
            _app.ViewActivated += OnViewActivated;

            AutoSlopeEventManager.Init();
            _loading = false;

            ResetTiles();
            Revalidate();
            UpdateLogSummary();
        }

        // ══ Header ═══════════════════════════════════════════════════════════

        public string ToolTitle => "Auto Slope By Point";
        public string VersionText => "v" + AutoSlopeRunner.ToolVersion;
        public string RoofText { get; }
        public string RoofLevelText { get; }

        [ObservableProperty]
        private bool isPlanView;

        [ObservableProperty]
        private string viewBadgeText;

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(StateText))]
        [NotifyPropertyChangedFor(nameof(RunButtonText))]
        [NotifyPropertyChangedFor(nameof(IsInputEnabled))]
        [NotifyPropertyChangedFor(nameof(IsCancelVisible))]
        [NotifyCanExecuteChangedFor(nameof(RunCommand))]
        [NotifyCanExecuteChangedFor(nameof(CancelRunCommand))]
        [NotifyCanExecuteChangedFor(nameof(RepickDrainsCommand))]
        [NotifyCanExecuteChangedFor(nameof(ExportResultsCommand))]
        [NotifyCanExecuteChangedFor(nameof(BrowseFolderCommand))]
        private RunState state = RunState.Ready;

        public string StateText => State switch
        {
            RunState.Picking => "Picking drains",
            RunState.Running => "Running",
            RunState.Done => "Completed",
            RunState.Cancelled => "Cancelled · roof unchanged",
            RunState.Failed => "Failed · roof unchanged",
            _ => "Ready"
        };

        public string RunButtonText => State switch
        {
            RunState.Running => "Running…",
            RunState.Ready or RunState.Picking => "Run AutoSlope",
            _ => "Run again"
        };

        public bool IsInputEnabled => State != RunState.Running && State != RunState.Picking;
        public bool IsCancelVisible => State == RunState.Running;

        /// <summary>Bound to the shell; true only while no percentage is known.</summary>
        [ObservableProperty]
        private bool isIndeterminate;

        // Result tiles
        [ObservableProperty] private string processedText = Dash;
        [ObservableProperty] private string skippedText = Dash;
        [ObservableProperty] private string drainsText = Dash;
        [ObservableProperty] private string highestText = Dash;
        [ObservableProperty] private string longestPathText = Dash;
        [ObservableProperty] private string runTimeText = Dash;
        [ObservableProperty] private string runTimeSubText = "Start → End";

        // ══ Inputs ═══════════════════════════════════════════════════════════

        public IReadOnlyList<string> SlopeOptions { get; } =
            AutoSlopeConstants.SlopePresets.Select(InputParsing.Format).ToList();

        [ObservableProperty] private string slopeText;
        [ObservableProperty] private string slopeError;
        [ObservableProperty] private string slopeHint;

        [ObservableProperty] private string maxDrainDistanceText;
        [ObservableProperty] private string maxDrainDistanceError;

        [ObservableProperty] private string maxEdgeLengthText;
        [ObservableProperty] private string maxEdgeLengthError;

        public IReadOnlyList<DrainModeOption> DrainModeOptions { get; } = new List<DrainModeOption>
        {
            new DrainModeOption(DrainMode.SnapToNearestPoint, "Snap to the nearest shape point",
                "Each pick uses the closest existing roof shape point. A pick far from any point is logged."),
            new DrainModeOption(DrainMode.AddPointAtPick, "Add a shape point at each pick",
                "Adds a new roof shape point exactly where you clicked and uses it as the drain."),
        };

        [ObservableProperty] private DrainModeOption selectedDrainMode;

        [ObservableProperty] private bool includeNearbyPoints;
        [ObservableProperty] private string snapRadiusText;
        [ObservableProperty] private string snapRadiusError;

        [ObservableProperty] private bool insertCurveIntersectionPoints;

        public ObservableCollection<CircleMarkerGroupViewModel> MarkerGroups { get; }

        [ObservableProperty] private bool markersExpanded;

        public string MarkerChipsText
        {
            get
            {
                var on = MarkerGroups.Where(g => g.IsEnabled).Select(g => g.ChipText).ToList();
                return on.Count == 0 ? "Off" : string.Join(" · ", on);
            }
        }

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(CanAskToOpen))]
        private bool exportToExcel;

        [ObservableProperty] private string exportFolderPath;
        [ObservableProperty] private bool askToOpenAfterExport;
        public bool CanAskToOpen => ExportToExcel;

        public string DrainCountText => _picks.Count == 1 ? "1 drain point picked" : $"{_picks.Count} drain points picked";

        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(RunCommand))]
        private string validationMessage;

        // Re-validate whenever an input changes.
        partial void OnSlopeTextChanged(string value) => Revalidate();
        partial void OnMaxDrainDistanceTextChanged(string value) => Revalidate();
        partial void OnMaxEdgeLengthTextChanged(string value) => Revalidate();
        partial void OnIncludeNearbyPointsChanged(bool value) => Revalidate();
        partial void OnSnapRadiusTextChanged(string value) => Revalidate();
        partial void OnExportToExcelChanged(bool value) => Revalidate();
        partial void OnExportFolderPathChanged(string value) => Revalidate();

        private void OnMarkerGroupChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(CircleMarkerGroupViewModel.RadiusError) ||
                e.PropertyName == nameof(CircleMarkerGroupViewModel.ThresholdError)) return;
            OnPropertyChanged(nameof(MarkerChipsText));
            Revalidate();
        }

        private void Revalidate()
        {
            if (_loading) return;

            var errors = new List<string>();

            SlopeError = InputParsing.CheckRange(SlopeText,
                AutoSlopeConstants.SlopeMin, AutoSlopeConstants.SlopeMax, "Slope", "%", out double slope);
            SlopeHint = SlopeError == null ? $"≈ {slope * 100:0} mm rise per 10 m" : string.Empty;
            if (SlopeError != null) errors.Add(SlopeError);

            MaxDrainDistanceError = InputParsing.CheckRange(MaxDrainDistanceText,
                AutoSlopeConstants.DrainDistanceMinM, AutoSlopeConstants.DrainDistanceMaxM,
                "Drainage distance", "m", out _);
            if (MaxDrainDistanceError != null) errors.Add(MaxDrainDistanceError);

            MaxEdgeLengthError = null;
            bool autoEdge = string.IsNullOrWhiteSpace(MaxEdgeLengthText)
                || (InputParsing.TryParse(MaxEdgeLengthText, out double edge) && edge == 0);
            if (!autoEdge)
            {
                MaxEdgeLengthError = InputParsing.CheckRange(MaxEdgeLengthText,
                    AutoSlopeConstants.EdgeLengthMinM, AutoSlopeConstants.EdgeLengthMaxM,
                    "Max link length", "m (or 0 for automatic)", out _);
                if (MaxEdgeLengthError != null) errors.Add(MaxEdgeLengthError);
            }

            SnapRadiusError = null;
            if (IncludeNearbyPoints)
            {
                SnapRadiusError = InputParsing.CheckRange(SnapRadiusText,
                    AutoSlopeConstants.SnapRadiusMinMm, AutoSlopeConstants.SnapRadiusMaxMm,
                    "Nearby radius", "mm", out _);
                if (SnapRadiusError != null) errors.Add(SnapRadiusError);
            }

            foreach (var g in MarkerGroups)
                errors.AddRange(g.Validate());

            if (ExportToExcel && string.IsNullOrWhiteSpace(ExportFolderPath))
                errors.Add("Choose an export folder, or turn Excel export off.");

            ValidationMessage = errors.FirstOrDefault();
            UpdateIdleSummary();
        }

        // ══ Run ══════════════════════════════════════════════════════════════

        private bool CanRun() =>
            IsInputEnabled
            && string.IsNullOrEmpty(ValidationMessage)
            && _picks.Count > 0
            && AutoSlopeEventManager.Handler?.HasPending != true;

        [RelayCommand(CanExecute = nameof(CanRun))]
        private void Run()
        {
            Revalidate();
            if (!string.IsNullOrEmpty(ValidationMessage)) return;

            AutoSlopeRequest request = BuildRequest();

            LogEntries.Clear();
            _cts = new CancellationTokenSource();
            _runStart = DateTime.Now;
            _lastPump = DateTime.MinValue;

            State = RunState.Running;
            IsRunning = true;
            IsIndeterminate = true; // until the first progress report arrives
            Progress = 0;
            SummaryText = $"Started {_runStart:HH:mm:ss} · waiting for Revit…";
            ResetTiles();
            RunTimeText = "Running";
            RunTimeSubText = $"Started {_runStart:HH:mm:ss}";

            var job = new RunJob(request, OnRunProgress, Log, _cts.Token, OnRunCompleted);
            if (!AutoSlopeEventManager.Submit(job))
            {
                AddLog(LogLevel.Error, "Revit did not accept the request (it may be busy). Try Run again.");
                FinishRun(AutoSlopeResult.Failed("Revit did not accept the request.", _runStart));
            }
        }

        private AutoSlopeRequest BuildRequest()
        {
            InputParsing.TryParse(SlopeText, out double slope);
            InputParsing.TryParse(MaxDrainDistanceText, out double distance);
            InputParsing.TryParse(MaxEdgeLengthText, out double edge);
            InputParsing.TryParse(SnapRadiusText, out double radius);
            var offsetGroup = MarkerGroups.First(g => g.Kind == MarkerGroupKind.AllowedOffset);

            return new AutoSlopeRequest
            {
                RoofIdValue = _roofIdValue,
                PickedPoints = _picks.ToList(),
                SlopePercent = slope,
                MaxDrainDistanceM = distance,
                MaxEdgeLengthM = Math.Max(0, edge),
                DrainMode = SelectedDrainMode?.Mode ?? DrainMode.SnapToNearestPoint,
                IncludeNearbyPoints = IncludeNearbyPoints,
                SnapRadiusMm = radius,
                InsertCurveIntersectionPoints = InsertCurveIntersectionPoints,
                ExportToExcel = ExportToExcel,
                ExportFolder = ExportFolderPath,
                Markers = MarkerGroups.Select(g => g.ToStyle()).ToList(),
                AllowedOffsetThresholdMm = offsetGroup.ThresholdMm,
                ProjectTitle = _projectTitle
            };
        }

        /// <summary>Called synchronously on Revit's thread during the run.</summary>
        private void OnRunProgress(RunProgressInfo info)
        {
            IsIndeterminate = false;
            Progress = Math.Max(Progress, info.OverallPercent);
            string within = info.PercentWithinPhase.HasValue ? $" · {info.PercentWithinPhase.Value:0} %" : string.Empty;
            SummaryText = _cts?.IsCancellationRequested == true
                ? "Cancelling…"
                : $"Started {_runStart:HH:mm:ss} · {info.PhaseLabel}{within}";

            if ((DateTime.Now - _lastPump).TotalMilliseconds >= PumpIntervalMs)
            {
                _lastPump = DateTime.Now;
                UiPumpHelper.DoEvents(); // repaint + let a Cancel click through
            }
        }

        private void Log(LogLevel level, string message) => AddLog(level, message);

        private void OnRunCompleted(AutoSlopeResult result) => FinishRun(result);

        private void FinishRun(AutoSlopeResult result)
        {
            _cts?.Dispose();
            _cts = null;
            IsRunning = false;
            IsIndeterminate = false;
            Progress = 0;

            if (result.Success)
            {
                _lastResult = result;
                State = RunState.Done;
                ShowResultTiles(result);
                SummaryText =
                    $"Done · {result.VerticesProcessed} processed, {result.VerticesSkipped} skipped · " +
                    $"Start {result.StartTime:HH:mm:ss} · End {result.EndTime:HH:mm:ss} · Total {result.DurationSeconds:0.0} s" +
                    (string.IsNullOrEmpty(result.ExportedFilePath) ? string.Empty : " · Excel exported");
                SaveSettings();

                if (!string.IsNullOrEmpty(result.ExportedFilePath) && AskToOpenAfterExport)
                {
                    string path = result.ExportedFilePath;
                    _dispatcher.BeginInvoke(new Action(() => OfferToOpen(path)));
                }
            }
            else
            {
                _lastResult = null;
                State = result.WasCancelled ? RunState.Cancelled : RunState.Failed;
                ResetTiles();
                RunTimeText = result.WasCancelled ? "Stopped" : "Failed";
                RunTimeSubText = $"{result.StartTime:HH:mm:ss} → {result.EndTime:HH:mm:ss}";
                SummaryText = result.WasCancelled
                    ? $"Cancelled at {result.EndTime:HH:mm:ss} (started {result.StartTime:HH:mm:ss}) · nothing was changed in the model"
                    : $"Failed · {result.ErrorMessage} · nothing was changed in the model";
            }
        }

        private bool CanCancelRun() => State == RunState.Running;

        [RelayCommand(CanExecute = nameof(CanCancelRun))]
        private void CancelRun()
        {
            if (_cts == null || _cts.IsCancellationRequested) return;
            _cts.Cancel();
            SummaryText = "Cancelling…";
            AddLog(LogLevel.Warning, "Cancel requested. The run stops at the next check and every change is rolled back.");
        }

        // ══ Re-pick drains ═══════════════════════════════════════════════════

        private bool CanRepickDrains() => IsInputEnabled && AutoSlopeEventManager.Handler?.HasPending != true;

        [RelayCommand(CanExecute = nameof(CanRepickDrains))]
        private void RepickDrains()
        {
            _stateBeforePicking = State;
            State = RunState.Picking;
            SummaryText = "Pick drain points in the Revit view, then click Finish. Esc keeps the current drains.";

            var job = new RepickJob(_roofIdValue, OnDrainsPicked, OnRepickCancelled);
            if (!AutoSlopeEventManager.Submit(job))
            {
                AddLog(LogLevel.Error, "Revit did not accept the request (it may be busy). Try again.");
                OnRepickCancelled();
            }
        }

        private void OnDrainsPicked(List<Point3> points)
        {
            _picks = points;
            OnPropertyChanged(nameof(DrainCountText));
            AddLog(LogLevel.Info, $"Drains re-picked: {DrainCountText}.");
            State = RunState.Ready;
            ResetTiles();
            Revalidate();
            RunCommand.NotifyCanExecuteChanged();
        }

        private void OnRepickCancelled()
        {
            State = _stateBeforePicking;
            AddLog(LogLevel.Info, $"Re-pick cancelled. Keeping {DrainCountText}.");
            UpdateIdleSummary();
        }

        // ══ Export ═══════════════════════════════════════════════════════════

        private bool CanBrowseFolder() => IsInputEnabled;

        [RelayCommand(CanExecute = nameof(CanBrowseFolder))]
        private void BrowseFolder()
        {
            string selected = DialogService.SelectFolder(ExportFolderPath);
            if (string.IsNullOrEmpty(selected)) return;
            ExportFolderPath = selected;
            AddLog(LogLevel.Info, $"Export folder: {selected}");
        }

        private bool CanExportResults() => State == RunState.Done && _lastResult?.Success == true;

        [RelayCommand(CanExecute = nameof(CanExportResults))]
        private void ExportResults()
        {
            string path = DialogService.SaveExcel(ExportFolderPath, ExcelExportService.DefaultFileName(_lastResult));
            if (string.IsNullOrEmpty(path)) return;

            string error = ExcelExportService.ExportTo(path, _lastResult, Log);
            if (error != null)
            {
                AddLog(LogLevel.Error, $"Export failed: {error}");
                return;
            }

            AddLog(LogLevel.Success, $"Results exported: {path}");
            if (AskToOpenAfterExport) OfferToOpen(path);
        }

        private void OfferToOpen(string path)
        {
            if (!DialogService.AskToOpen(path)) return;
            string error = DialogService.TryOpenFile(path);
            if (error != null) AddLog(LogLevel.Warning, $"Could not open the file: {error}");
        }

        // ══ Log ══════════════════════════════════════════════════════════════

        public ICollectionView LogView { get; }

        [ObservableProperty] private LogFilter activeLogFilter = LogFilter.All;
        [ObservableProperty] private string logSummaryText;
        [ObservableProperty] private string latestLogText;
        [ObservableProperty] private int warningCount;
        [ObservableProperty] private int errorCount;

        [RelayCommand]
        private void SetLogFilter(string filter)
        {
            if (Enum.TryParse(filter, out LogFilter f))
            {
                ActiveLogFilter = f;
                LogView.Refresh();
            }
        }

        private bool PassesLogFilter(object item)
        {
            if (item is not LogEntry e) return false;
            return ActiveLogFilter switch
            {
                LogFilter.Warnings => e.Level == LogLevel.Warning,
                LogFilter.Errors => e.Level == LogLevel.Error,
                _ => true
            };
        }

        private void OnLogChanged(object sender, NotifyCollectionChangedEventArgs e) => UpdateLogSummary();

        private void UpdateLogSummary()
        {
            int n = LogEntries.Count;
            WarningCount = LogEntries.Count(x => x.Level == LogLevel.Warning);
            ErrorCount = LogEntries.Count(x => x.Level == LogLevel.Error);

            string text = n == 1 ? "1 line" : $"{n} lines";
            if (WarningCount > 0) text += WarningCount == 1 ? " · 1 warning" : $" · {WarningCount} warnings";
            if (ErrorCount > 0) text += ErrorCount == 1 ? " · 1 error" : $" · {ErrorCount} errors";
            LogSummaryText = text;

            LogEntry last = n > 0 ? LogEntries[n - 1] : null;
            LatestLogText = last == null ? "No entries yet." : $"[{last.Time:HH:mm:ss}] {last.Message}";
        }

        [RelayCommand]
        private void SaveLog()
        {
            try
            {
                string folder = string.IsNullOrWhiteSpace(ExportFolderPath)
                    ? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                    : ExportFolderPath;
                string path = LogExportService.Export("AutoSlopeByPoint", LogEntries, folder);
                AddLog(LogLevel.Success, $"Log saved: {path}");
            }
            catch (Exception ex)
            {
                AddLog(LogLevel.Error, $"Could not save the log: {ex.Message}");
            }
        }

        // ══ Tiles / summary helpers ══════════════════════════════════════════

        private void ResetTiles()
        {
            ProcessedText = Dash;
            SkippedText = Dash;
            DrainsText = $"{_picks.Count} → {Dash}";
            HighestText = Dash;
            LongestPathText = Dash;
            RunTimeText = Dash;
            RunTimeSubText = "Start → End";
        }

        private void ShowResultTiles(AutoSlopeResult r)
        {
            ProcessedText = r.VerticesProcessed.ToString("N0");
            SkippedText = r.VerticesSkipped.ToString("N0");
            DrainsText = $"{r.PickedDrainCount} → {r.FinalDrainCount}";
            HighestText = $"{r.HighestElevationMm:0} mm";
            LongestPathText = $"{r.LongestPathM:0.00} m";
            RunTimeText = $"{r.DurationSeconds:0.0} s";
            RunTimeSubText = $"{r.StartTime:HH:mm:ss} → {r.EndTime:HH:mm:ss}";
        }

        private void UpdateIdleSummary()
        {
            if (State == RunState.Running || State == RunState.Picking) return;

            if (!string.IsNullOrEmpty(ValidationMessage))
                SummaryText = "Can't run yet · " + ValidationMessage;
            else if (State == RunState.Ready)
                SummaryText = $"Ready · {DrainCountText}";
        }

        // ══ Active view badge ════════════════════════════════════════════════

        private void OnViewActivated(object sender, ViewActivatedEventArgs e) => UpdateViewBadge(e.CurrentActiveView);

        private void UpdateViewBadge(View view)
        {
            ViewInfo v = ProjectQueries.DescribeView(view);
            IsPlanView = v.IsPlan;
            ViewBadgeText = v.IsPlan
                ? $"Plan view · {v.Name}"
                : $"Active view is not a plan ({v.Name}) · circle markers will be skipped";
        }

        // ══ Settings ═════════════════════════════════════════════════════════

        private void LoadSettings()
        {
            AutoSlopeSettings s = AutoSlopeSettingsStore.Load();

            MarkerGroups[0].Apply(s.DrainMarkerGroup);
            MarkerGroups[1].Apply(s.HighestPointMarkerGroup);
            MarkerGroups[2].Apply(s.AllowedOffsetMarkerGroup);
            MarkerGroups[2].ThresholdText = InputParsing.Format(s.AllowedOffsetThresholdMm);

            SlopeText = InputParsing.Format(s.SlopePercent);
            MaxDrainDistanceText = InputParsing.Format(s.MaxDrainDistanceM);
            MaxEdgeLengthText = InputParsing.Format(s.MaxEdgeLengthM);
            SelectedDrainMode = DrainModeOptions.FirstOrDefault(o => o.Mode == s.DrainMode) ?? DrainModeOptions[0];
            IncludeNearbyPoints = s.IncludeNearbyPoints;
            SnapRadiusText = InputParsing.Format(s.SnapRadiusMm);
            InsertCurveIntersectionPoints = s.InsertCurveIntersectionPoints;

            ExportFolderPath = string.IsNullOrWhiteSpace(s.ExportFolderPath)
                ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), AutoSlopeConstants.DefaultExportFolder)
                : s.ExportFolderPath;
            ExportToExcel = s.ExportToExcel;
            AskToOpenAfterExport = s.AskToOpenAfterExport;
        }

        /// <summary>Saved after a successful run and when the window closes.</summary>
        public void SaveSettings()
        {
            InputParsing.TryParse(SlopeText, out double slope);
            InputParsing.TryParse(MaxDrainDistanceText, out double distance);
            InputParsing.TryParse(MaxEdgeLengthText, out double edge);
            InputParsing.TryParse(SnapRadiusText, out double radius);
            var d = new AutoSlopeSettings();

            var settings = new AutoSlopeSettings
            {
                DrainMarkerGroup = MarkerGroups[0].ToSettings(),
                HighestPointMarkerGroup = MarkerGroups[1].ToSettings(),
                AllowedOffsetMarkerGroup = MarkerGroups[2].ToSettings(),
                AllowedOffsetThresholdMm = MarkerGroups[2].ThresholdMm,
                SlopePercent = slope > 0 ? slope : d.SlopePercent,
                MaxDrainDistanceM = distance > 0 ? distance : d.MaxDrainDistanceM,
                MaxEdgeLengthM = Math.Max(0, edge),
                DrainMode = SelectedDrainMode?.Mode ?? DrainMode.SnapToNearestPoint,
                IncludeNearbyPoints = IncludeNearbyPoints,
                SnapRadiusMm = radius > 0 ? radius : d.SnapRadiusMm,
                InsertCurveIntersectionPoints = InsertCurveIntersectionPoints,
                ExportFolderPath = ExportFolderPath,
                ExportToExcel = ExportToExcel,
                AskToOpenAfterExport = AskToOpenAfterExport
            };

            if (!AutoSlopeSettingsStore.Save(settings))
                AddLog(LogLevel.Warning, $"Settings could not be saved to {AutoSlopeSettingsStore.SettingsPath}.");
        }

        // ══ Window close ═════════════════════════════════════════════════════

        /// <summary>The window asks before closing; closing is blocked while a run is in progress.</summary>
        public bool CanClose()
        {
            if (State != RunState.Running) return true;
            AddLog(LogLevel.Warning, "Close is blocked while a run is in progress. Press Cancel (or Esc) first.");
            return false;
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            try { _app.ViewActivated -= OnViewActivated; } catch { /* Revit shutting down */ }
            LogEntries.CollectionChanged -= OnLogChanged;
            foreach (var g in MarkerGroups) g.PropertyChanged -= OnMarkerGroupChanged;
            _cts?.Cancel();
        }
    }
}
