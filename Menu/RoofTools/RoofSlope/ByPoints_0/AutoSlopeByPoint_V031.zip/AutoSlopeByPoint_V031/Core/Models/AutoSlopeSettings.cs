// =======================================================
// File: AutoSlopeSettings.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.V031.Core.Models
// Changes vs V030:
//   - Every default comes from AutoSlopeConstants (V030 B2: this POCO's own
//     defaults — 1 m threshold, 50 mm tolerance, Black markers — overrode
//     the real defaults on a clean machine).
//   - ThresholdMeters (int) split into MaxDrainDistanceM + MaxEdgeLengthM
//     (double) — V030 B3.
//   - New: DrainMode, IncludeNearbyPoints (V031 D2).
//   - Saved to settings.v031.json so V030 (kept as fallback) and V031 never
//     read each other's file.
// Line styles are persisted by NAME (ElementIds are per project).
// =======================================================

namespace Revit26_Plugin.AutoSlopeByPoint.V031.Core.Models
{
    public class CircleMarkerGroupSettings
    {
        public bool IsEnabled { get; set; } = true;
        public string LineStyleName { get; set; }
        public string ColorName { get; set; }
        public double RadiusMm { get; set; } = AutoSlopeConstants.DefaultMarkerRadiusMm;
        public bool ShowOffsetText { get; set; } = true;
    }

    public class AutoSlopeSettings
    {
        // ── Circle markers ───────────────────────────────────────────────
        public CircleMarkerGroupSettings DrainMarkerGroup { get; set; } =
            new CircleMarkerGroupSettings { ColorName = AutoSlopeConstants.DefaultDrainColor };

        public CircleMarkerGroupSettings HighestPointMarkerGroup { get; set; } =
            new CircleMarkerGroupSettings { ColorName = AutoSlopeConstants.DefaultHighestColor };

        public CircleMarkerGroupSettings AllowedOffsetMarkerGroup { get; set; } =
            new CircleMarkerGroupSettings { ColorName = AutoSlopeConstants.DefaultOffsetColor };

        public double AllowedOffsetThresholdMm { get; set; } = AutoSlopeConstants.DefaultAllowedOffsetThresholdMm;

        // ── Run inputs ───────────────────────────────────────────────────
        public double SlopePercent { get; set; } = AutoSlopeConstants.DefaultSlopePercent;
        public double MaxDrainDistanceM { get; set; } = AutoSlopeConstants.DefaultMaxDrainDistanceM;
        public double MaxEdgeLengthM { get; set; } = AutoSlopeConstants.DefaultMaxEdgeLengthM;
        public DrainMode DrainMode { get; set; } = DrainMode.SnapToNearestPoint;
        public bool IncludeNearbyPoints { get; set; } = true;
        public double SnapRadiusMm { get; set; } = AutoSlopeConstants.DefaultSnapRadiusMm;
        public bool InsertCurveIntersectionPoints { get; set; } = true;

        // ── Export ───────────────────────────────────────────────────────
        public string ExportFolderPath { get; set; }
        public bool ExportToExcel { get; set; } = true;
        public bool AskToOpenAfterExport { get; set; }
    }
}
