# AutoSlopeByPoint V031

New version folder (per TOOL_VERSIONING.md). V030 stays on disk and on the ribbon as the fallback.
Every change is tagged with its code from `claude/AutoSlopeByPoint_V030_Refactor_Plan.md`.

> **Build status: not compiled yet.** This was written without Revit's API or a Windows .NET build.
> Every C# file passes a syntax parse, the XAML is well-formed, and every XAML binding and resource
> key was cross-checked against the ViewModels and `Shared/SharedStyles.xaml` v3.1. Expect, at most,
> a few small compile fixes on the first build. Then run the test list at the end in Revit before
> putting it on the ribbon.

## Install into the repo

1. Copy the `AutoSlopeByPoint_V031` folder next to `AutoSlopeByPoint_V030` under `Menu/…`.
   It is an SDK-style project, so the `.cs` and `.xaml` files are picked up with no `.csproj` edit.
2. **ToolCatalog** (`Shared/Services/ToolCatalog.cs`): add this line. It gives the window title,
   error dialogs and the `AutoSlope_Versions` parameter the right version. Until it is added, the
   code falls back to `31.0.0`.
   ```csharp
   public static readonly ToolInfo AutoSlopeByPointV031 = Add("Auto Slope By Point", "31.0.0", "V031", "Revit26_Plugin.AutoSlopeByPoint.V031");
   ```
3. **Ribbon** (`RoofToolsRibbon.cs`, "By Point" pulldown): add a button that points at
   ```
   Revit26_Plugin.AutoSlopeByPoint.V031.Commands.AutoSlopeCommand
   ```
   for example:
   ```csharp
   new PushButtonData("Btn_AutoSlopeByPoint_031", "By Point V031", assemblyPath,
       "Revit26_Plugin.AutoSlopeByPoint.V031.Commands.AutoSlopeCommand")
   {
       ToolTip = ToolCatalog.AutoSlopeByPointV031.Tip("Slopes a roof towards picked drain points.")
   };
   ```
4. **CHANGELOG.md**: paste the entry from the bottom of this file.

No new NuGet packages. It uses CommunityToolkit.Mvvm and EPPlus, the same as V030.

## Folder map

```
Commands/AutoSlopeCommand.cs           thin entry, ToolGuard-wrapped, selection filters
Core/Models/                           Revit-free: Point3, request/result/settings, enums, constants, colours
Core/Services/                         Revit-free: ShortestPathSolver, SpatialGrid2D, PointClustering, RunPhases, InputParsing
Infrastructure/ExternalEvents/         handler + event manager, RunJob, RepickJob
Infrastructure/RoofOps/                Revit-side steps: AutoSlopeRunner (orchestrator), RoofPreparer,
                                       DrainResolver, PathGraphBuilder, ElevationApplier, ModelReadback,
                                       CircleMarkerService, AutoSlopeParameterWriter, geometry helpers,
                                       ProjectQueries, SelectionFilters, RevitConvert
Infrastructure/Helpers/                settings store, dialogs, Excel export, UI pump
UI/ViewModels/                         AutoSlopeViewModel : ToolViewModelBase, CircleMarkerGroupViewModel
UI/Views/                              window (ToolWindowShell), 2 small converters
```

`Core/` no longer references the Revit API or Infrastructure (ARCHITECTURE.md §3). V030 broke that rule.

## What changed

### Bugs fixed
| Code | Fix |
|---|---|
| B1 | Cancel or any failure **rolls back the whole run**. Before, the reset roof was kept. Only a successful run calls `Assimilate()`. |
| B2 | First-run defaults: 1.5 %, 100 m distance, 500 mm radius, Blue / Red / Orange markers. Before, they were 1 m, 50 mm and all Black. |
| B3 | "Threshold" is split into **Max drainage distance** and an advanced **Max link length** (0 = same as the distance, which matches V030). Both accept decimals. |
| B4 | The garbled `â€¦` text is gone. |
| B5/B6 | The tool version comes from ToolCatalog. The hard-coded "P.10.00" is removed. |
| B7 | Run takes an immutable snapshot of the inputs. Inputs lock while running. Esc cancels. Close is blocked mid-run. |
| B8 | Real start time, end time and seconds (one decimal). |
| B9 | Every file open is guarded. |
| B10/B11 | No hidden fixed 10 mm dedupe. Each error is logged once. |

### Drain detection and engine
| Code | Fix |
|---|---|
| D1 | `DrainResolver` returns the exact set of drain shape points. The engine no longer matches again by radius, which used to undo the same-edge/opening rule. |
| D2 | New **Drain mode**: *Snap to the nearest shape point* (always resolves; warns past 1 m) or *Add a shape point at each pick*. A pick can no longer end the run with "no vertices matched". |
| D3 | Matching and marker clustering use plan (XY) distance, so re-running on an already-sloped roof gives the same drains. |
| D4 | The solver records which drain each point's path actually reaches, and the next point along it. Excel's DrainIndex is now correct. |
| D5 | Points beyond the distance, and points with no path, are counted and logged separately. Excel has a Status column. |
| D6 | Roof, editor, picks, shape points and top face are all checked before anything changes. |
| D7 | The run warns when Revit adjusted any point, which explains a Highest Point marker that differs from the header tile. |

### Structure
- The 514-line engine is now a thin `AutoSlopeRunner` plus one class per step.
- `AutoSlopeViewModel` inherits Shared `ToolViewModelBase`, which provides the log, Copy / Clear and shell status.
- The command and handler run through `ToolGuard`. The handler holds one pending job, not a static mutable payload.
- The window's owner is Revit's main window. Only one window opens at a time; a second click brings it to the front.
- Speed: the path graph uses a spatial grid, adjacency lists and a `PriorityQueue`, and the read-back uses a hash lookup.
  With the default link length the graph is **identical to V030's**. Set a shorter link length to make large roofs faster.
- Unchanged on purpose: the face-sampling validity test for links (P1c). Replacing it changes which links are
  accepted, so it needs before/after comparisons on real roofs first.

### Window (ToolWindowShell v1.1)
- Header: state, roof and active-view badges, plus 6 result tiles: Processed, Skipped,
  Drains picked → used, Highest elevation, Longest path, and Run time (start → end). Tiles show "—" before a run.
- Body: the Roof & drains card has **Re-pick drains**. The Slope card has a live "≈ X mm per 10 m" hint and a
  warning that a run resets existing points. Then Drain mode, Curves, the circle markers (one template ×3 with
  colour swatches), Export, and a note about the parameters written.
- The log is **closed by default**. When closed it shows the line count, warning and error counts, and the latest
  line. When open it has filter chips, Copy all, Copy selected, Save log… and Clear.
- Footer: Export results… writes the full workbook, not a placeholder. Cancel shows only while running.
  Run changes to "Run again" after a run, and Close.
- Minimum size is 900×620, down from 1160×800. There are no inline colours, and root brushes use `DynamicResource`.

### Settings
- Saved to `%AppData%\Revit26_Plugin\AutoSlopeByPoint\settings.v031.json`. This is a new file, so V030's
  (possibly wrong) defaults are not carried over.

## To check on the first Revit test
These depend on Revit behaviour that couldn't be run here:
1. **Re-pick drains** calls `Selection.PickObjects` from the ExternalEvent handler. This normally works from a
   modeless window, but confirm it.
2. **Add a shape point at each pick**: confirm the added point lands flat on the reset roof (it uses `AddPoint` on
   the top-face projection), including on a roof with a base offset.
3. **Cancel while "Applying elevations"**: confirm the run stops and the roof is unchanged.
4. **EPPlus licence**: `LicenseContext.NonCommercial` is kept from V030. Check it for commercial use (not legal advice).

## Test list (no test project)
- [ ] Cancel during "Building path graph" → the roof is unchanged, and Undo history shows no AutoSlope step.
- [ ] A failure after reset (e.g. delete the roof's points) → the roof is unchanged.
- [ ] Clean settings folder → defaults are 1.5 % / 100 m / 500 mm / Blue-Red-Orange.
- [ ] Snap mode, pick mid-panel → the run succeeds, with a warning if the pick is over 1 m from a point.
- [ ] Add mode, pick mid-panel → a new shape point at the pick becomes the drain.
- [ ] Pick next to an opening with a 500 mm radius → only points on the picked edge/opening become drains.
- [ ] Run, then Run again with a different slope → same drain count, and one undo step per run.
- [ ] Drain behind an opening → Excel DrainIndex matches the drain the path reaches.
- [ ] Non-plan active view → amber badge; markers skipped with a warning; slope still applied.
- [ ] Same roof, V030 vs V031 with default link length → same processed/skipped counts and highest elevation.
- [ ] Shorter link length (e.g. 5 m) on a large roof → noticeably faster; check for "no path" warnings.
- [ ] Window at 1366×768 / 150 % scaling → fully usable through the body scroll.
- [ ] A second ribbon click while the window is open → the window comes to the front, with no second window.

## CHANGELOG entry

```
## 2026-10-14 — AutoSlopeByPoint V031

- New folder AutoSlopeByPoint_V031 (V030 kept as fallback). Full review in
  claude/AutoSlopeByPoint_V030_Refactor_Plan.md.
- Fixes: cancel/failure now roll back the whole run (V030 kept a flattened
  roof); first-run defaults; threshold split into drainage distance + max
  link length; garbled text; version from ToolCatalog; inputs snapshotted
  and locked while running; real start/end/total times.
- Drains: exact drain point set (same-edge rule no longer undone), Drain mode
  (snap to nearest / add point at pick), plan-distance matching, path-based
  drain index in Excel, read-only checks before any change.
- Structure: Core is Revit-free again; engine split into steps; ViewModel on
  ToolViewModelBase; ToolGuard on command + handler; single window; owner set.
- Window: ToolWindowShell v1.1 with 6 MetricTiles, plan-view badge, inline
  validation, Re-pick drains, log closed by default with filter chips,
  full-workbook manual export, min size 900×620.
- ToolCatalog: + AutoSlopeByPointV031 (31.0.0). Ribbon: By Point pulldown + V031.
```
