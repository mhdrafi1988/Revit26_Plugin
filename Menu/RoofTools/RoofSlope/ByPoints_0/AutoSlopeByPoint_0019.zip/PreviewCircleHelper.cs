// =======================================================
// File: PreviewCircleHelper.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.V019
// Purpose: "Show Circles" preview feature.
//   1. Groups the run's drain points by mutual proximity using
//      the SAME EnableDrainTolerance/DrainToleranceMm values the
//      engine already uses for drain-point tolerance expansion
//      (per convention: no separate grouping tolerance field).
//      If tolerance is disabled or 0, each drain point is its
//      own group (no merging).
//   2. Draws one DetailCurve circle at each group's centroid,
//      plus one DetailCurve circle at the run's highest-elevation
//      point — same LineStyle/color/size for both, no visual
//      distinction between the two circle kinds.
//   3. Only draws anything if the ACTIVE VIEW is a plan view
//      (ViewPlan). DetailCurves are view-specific and only valid
//      in a plan/section/drafting context; per spec, any other
//      active view type is skipped entirely (logged, not an error).
//   4. Caller (engine) is responsible for wrapping this in its
//      OWN separate Transaction, run as the LAST step of a run,
//      after the slope-apply transaction has already committed.
//      Old circles from prior runs are intentionally NOT purged.
// =======================================================

using Autodesk.Revit.DB;
using Revit26_Plugin.AutoSlopeByPoint.V019.Core.Models;
using Revit26_Plugin.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.AutoSlopeByPoint.V019.Infrastructure.Helpers
{
    public static class PreviewCircleHelper
    {
        /// <summary>
        /// Groups points by proximity within toleranceFt using simple
        /// union-find style clustering (transitive: if A-B and B-C are both
        /// within tolerance, A/B/C become one group even if A-C alone
        /// exceeds tolerance). If toleranceFt &lt;= 0, every point is its
        /// own group.
        /// </summary>
        public static List<List<XYZ>> GroupByTolerance(List<XYZ> points, double toleranceFt)
        {
            var groups = new List<List<XYZ>>();
            if (points == null || points.Count == 0) return groups;

            if (toleranceFt <= 0)
            {
                foreach (var p in points)
                    groups.Add(new List<XYZ> { p });
                return groups;
            }

            var assigned = new bool[points.Count];

            for (int i = 0; i < points.Count; i++)
            {
                if (assigned[i]) continue;

                var group = new List<XYZ> { points[i] };
                assigned[i] = true;

                // Expand the group transitively: keep scanning until no more
                // unassigned points are within tolerance of ANY point already in the group.
                bool grew = true;
                while (grew)
                {
                    grew = false;
                    for (int j = 0; j < points.Count; j++)
                    {
                        if (assigned[j]) continue;
                        if (group.Any(gp => gp.DistanceTo(points[j]) <= toleranceFt))
                        {
                            group.Add(points[j]);
                            assigned[j] = true;
                            grew = true;
                        }
                    }
                }

                groups.Add(group);
            }

            return groups;
        }

        public static XYZ Centroid(List<XYZ> points)
        {
            double x = points.Average(p => p.X);
            double y = points.Average(p => p.Y);
            double z = points.Average(p => p.Z);
            return new XYZ(x, y, z);
        }

        /// <summary>
        /// Draws the full set of preview circles for this run. Must be called
        /// inside an already-open Transaction. Returns the count of circles drawn
        /// (0 if skipped due to non-plan active view or no valid line style found).
        /// </summary>
        public static int DrawPreviewCircles(
            Document doc,
            View activeView,
            List<XYZ> drainPoints,
            XYZ highestPointPosition,
            bool enableDrainTolerance,
            int drainToleranceMm,
            CircleSettings settings,
            Action<LogEntry> log)
        {
            if (settings == null || !settings.ShowCircles)
                return 0;

            if (activeView is not ViewPlan)
            {
                log?.Invoke(new LogEntry(LogLevel.Info,
                    "Show Circles: active view is not a plan view — preview circles skipped."));
                return 0;
            }

            if (drainPoints == null || drainPoints.Count == 0)
            {
                log?.Invoke(new LogEntry(LogLevel.Warning,
                    "Show Circles: no drain points available — preview circles skipped."));
                return 0;
            }

            GraphicsStyle lineStyle = FindLineStyle(doc, settings.LineTypeName);
            if (lineStyle == null)
            {
                log?.Invoke(new LogEntry(LogLevel.Warning,
                    $"Show Circles: line style '{settings.LineTypeName}' not found — preview circles skipped."));
                return 0;
            }

            Color color = ResolveColor(settings.ColorName);
            double radiusFt = UnitUtils.ConvertToInternalUnits(settings.CircleSizeMm / 2.0, UnitTypeId.Millimeters);

            double toleranceFt = enableDrainTolerance && drainToleranceMm > 0
                ? UnitUtils.ConvertToInternalUnits(drainToleranceMm, UnitTypeId.Millimeters)
                : 0;

            List<List<XYZ>> groups = GroupByTolerance(drainPoints, toleranceFt);

            log?.Invoke(new LogEntry(LogLevel.Info,
                $"Show Circles: {drainPoints.Count} drain point(s) grouped into {groups.Count} group(s) " +
                $"(tolerance = {(toleranceFt > 0 ? $"{drainToleranceMm} mm" : "disabled — 1 point per group")})."));

            int drawn = 0;

            foreach (var group in groups)
            {
                XYZ centroid = Centroid(group);
                if (TryDrawCircle(doc, activeView, centroid, radiusFt, lineStyle, color, log))
                    drawn++;
            }

            if (highestPointPosition != null)
            {
                if (TryDrawCircle(doc, activeView, highestPointPosition, radiusFt, lineStyle, color, log))
                    drawn++;
            }
            else
            {
                log?.Invoke(new LogEntry(LogLevel.Warning,
                    "Show Circles: highest point position unavailable — circle for highest point skipped."));
            }

            log?.Invoke(new LogEntry(LogLevel.Success,
                $"Show Circles: drew {drawn} preview circle(s) ({groups.Count} drain group(s) + highest point)."));

            return drawn;
        }

        /// <summary>
        /// Draws one full circle as TWO half-circle DetailCurve arcs.
        /// NOTE: Revit's Arc.Create throws on a full 2*PI sweep (a 0..2π arc is
        /// degenerate/zero-length in the Revit API), and NewDetailCurve only
        /// accepts a single bounded Curve — not a closed loop — so a true circle
        /// cannot be created as one DetailCurve. Splitting into two 0..π half-arcs
        /// (sharing both endpoints) is the standard workaround and renders as one
        /// unbroken circle. Both halves get the same LineStyle/color override.
        /// Returns true only if BOTH halves were created successfully; if the
        /// second half fails after the first succeeded, the first is deleted so
        /// we never leave a stray half-arc behind.
        /// </summary>
        private static bool TryDrawCircle(
            Document doc, View view, XYZ center, double radiusFt,
            GraphicsStyle lineStyle, Color color, Action<LogEntry> log)
        {
            ElementId firstHalfId = null;
            try
            {
                // NOTE: DetailCurves are view-specific 2D annotations. For a
                // ViewPlan, Revit places the curve at the view's own cut/display
                // plane — the Z component of `center` has NO effect on where the
                // circle appears; only X/Y matter. view.ViewDirection is used as
                // the plane normal since that's the correct orientation for a
                // plan view's sketch plane.
                Plane plane = Plane.CreateByNormalAndOrigin(view.ViewDirection, center);

                Arc half1 = Arc.Create(plane, radiusFt, 0, Math.PI);
                Arc half2 = Arc.Create(plane, radiusFt, Math.PI, 2 * Math.PI);

                DetailCurve curve1 = doc.Create.NewDetailCurve(view, half1);
                firstHalfId = curve1?.Id;
                DetailCurve curve2 = doc.Create.NewDetailCurve(view, half2);

                if (curve1 == null || curve2 == null)
                {
                    if (firstHalfId != null) doc.Delete(firstHalfId);
                    return false;
                }

                var ogs = new OverrideGraphicSettings();
                ogs.SetProjectionLineColor(color);

                foreach (var dc in new[] { curve1, curve2 })
                {
                    dc.LineStyle = lineStyle;
                    view.SetElementOverrides(dc.Id, ogs);
                }

                return true;
            }
            catch (Exception ex)
            {
                if (firstHalfId != null)
                {
                    try { doc.Delete(firstHalfId); } catch { /* best-effort cleanup only */ }
                }
                log?.Invoke(new LogEntry(LogLevel.Warning,
                    $"Show Circles: failed to draw circle at ({center.X:F2}, {center.Y:F2}): {ex.Message}"));
                return false;
            }
        }

        private static GraphicsStyle FindLineStyle(Document doc, string lineTypeName)
        {
            if (string.IsNullOrWhiteSpace(lineTypeName)) return null;

            return new FilteredElementCollector(doc)
                .OfClass(typeof(GraphicsStyle))
                .Cast<GraphicsStyle>()
                .FirstOrDefault(gs => string.Equals(gs.Name, lineTypeName, StringComparison.OrdinalIgnoreCase));
        }

        private static Color ResolveColor(string colorName) => colorName switch
        {
            "Red"    => new Color(217, 83, 79),
            "Green"  => new Color(46, 158, 100),
            "Orange" => new Color(224, 146, 46),
            "Black"  => new Color(0, 0, 0),
            _        => new Color(45, 108, 223) // Blue (default) — matches BrushAppleBlue
        };
    }
}
