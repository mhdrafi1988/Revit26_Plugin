// =======================================================
// File: AutoSlopeParameterWriter.cs
// Fixes:
//   #6  WriteAll now accepts a runDate string instead of
//       calling DateTime.Now independently. The engine
//       captures the date once and passes it here, so the
//       parameter value in Revit always matches the value
//       shown in the UI.
// =======================================================

using Autodesk.Revit.DB;
using Revit26_Plugin.AutoSlopeByPoint.V009.Core.Models;
using Revit26_Plugin.AutoSlopeByPoint.V009.Infrastructure.Helpers;
using System;

namespace Revit26_Plugin.AutoSlopeByPoint.V009.Core.Parameters
{
    public static class AutoSlopeParameterWriter
    {
        // Fix #6: runDate parameter added — no longer calls DateTime.Now internally
        // Now returns the computed status code (1=OK, 2=Partial, 3=Failed) so
        // callers (e.g. AutoSlopeEngine) can pass it through to AutoSlopeResult
        // for Excel export without duplicating the success/fail counting logic.
        public static int WriteAll(
            Document doc,
            RoofBase roof,
            AutoSlopePayload data,
            double highestElevation_mm,
            double longestPath_m,
            int processed,
            int skipped,
            int runDuration_sec,
            int finalDrainCount,
            string runDate,            // ← new: supplied by AutoSlopeEngine
            string version = "P.10.00")
        {
            if (doc == null || roof == null)
                return AppConstants.Status_Failed;

            int successCount = 0;
            int failCount    = 0;
            int statusValue;

            using (Transaction tx = new Transaction(doc, "AutoSlope – Update Roof Parameters"))
            {
                tx.Start();

                TrySetDouble(roof,
                    AppConstants.Param_HighestElevation,
                    UnitUtils.ConvertToInternalUnits(highestElevation_mm, UnitTypeId.Millimeters),
                    ref successCount, ref failCount);

                TrySetInt(roof,
                    AppConstants.Param_VerticesProcessed,
                    processed,
                    ref successCount, ref failCount);

                TrySetInt(roof,
                    AppConstants.Param_VerticesSkipped,
                    skipped,
                    ref successCount, ref failCount);

                TrySetInt(roof,
                    AppConstants.Param_DrainCount,
                    finalDrainCount,
                    ref successCount, ref failCount);

                TrySetInt(roof,
                    AppConstants.Param_RunDuration,
                    runDuration_sec,
                    ref successCount, ref failCount);

                TrySetDouble(roof,
                    AppConstants.Param_LongestPath,
                    longestPath_m,
                    ref successCount, ref failCount);

                TrySetDouble(roof,
                    AppConstants.Param_SlopePercent,
                    data.SlopePercent / 100.0,
                    ref successCount, ref failCount);

                TrySetString(roof,
                    AppConstants.Param_SlopePercent_Text,
                    $"{data.SlopePercent}%",
                    ref successCount, ref failCount);

                TrySetDouble(roof,
                    AppConstants.Param_Threshold,
                    data.ThresholdMeters * 1000.0,
                    ref successCount, ref failCount);

                // Fix #6: use the runDate passed in rather than a second DateTime.Now
                TrySetString(roof,
                    AppConstants.Param_RunDate,
                    runDate,
                    ref successCount, ref failCount);

                TrySetString(roof,
                    AppConstants.Param_Versions,
                    version,
                    ref successCount, ref failCount);

                TrySetInt(roof,
                    AppConstants.Param_DrainToleranceMm,
                    data.EnableDrainTolerance ? (int)Math.Round((double)data.DrainToleranceMm) : 0,
                    ref successCount, ref failCount);

                TrySetInt(roof,
                    AppConstants.Param_DrainToleranceEnabled,
                    data.EnableDrainTolerance ? 1 : 0,
                    ref successCount, ref failCount);

                statusValue = successCount == 0
                    ? AppConstants.Status_Failed
                    : failCount > 0
                        ? AppConstants.Status_Partial
                        : AppConstants.Status_OK;

                TrySetInt(roof,
                    AppConstants.Param_Status,
                    statusValue,
                    ref successCount, ref failCount);

                tx.Commit();
            }

            data?.Log?.Invoke(new Revit26_Plugin.Shared.Models.LogEntry(
                Revit26_Plugin.Shared.Models.LogLevel.Info,
                $"AutoSlope Parameters: {successCount} updated, {failCount} skipped"));

            return statusValue;
        }

        // ── Private helpers ──────────────────────────────────────────────────

        private static void TrySetInt(
            Element elem, string paramName, int value,
            ref int ok, ref int fail)
        {
            try
            {
                Parameter p = elem.LookupParameter(paramName);
                if (p == null || p.IsReadOnly || p.StorageType != StorageType.Integer)
                { fail++; return; }
                p.Set(value);
                ok++;
            }
            catch { fail++; }
        }

        private static void TrySetDouble(
            Element elem, string paramName, double value,
            ref int ok, ref int fail)
        {
            try
            {
                Parameter p = elem.LookupParameter(paramName);
                if (p == null || p.IsReadOnly || p.StorageType != StorageType.Double)
                { fail++; return; }
                p.Set(value);
                ok++;
            }
            catch { fail++; }
        }

        private static void TrySetString(
            Element elem, string paramName, string value,
            ref int ok, ref int fail)
        {
            try
            {
                Parameter p = elem.LookupParameter(paramName);
                if (p == null || p.IsReadOnly || p.StorageType != StorageType.String)
                { fail++; return; }
                p.Set(value);
                ok++;
            }
            catch { fail++; }
        }
    }
}
