// =======================================================
// File: RidgeDetector.cs
// Namespace: Revit26_Plugin.AutoSlopeByPoint.WithRidge
// Purpose:
//   Drain-group-based ridge detection.
//
// How it works:
//   1. Drain points are clustered into groups using a
//      user-defined grouping radius (DrainGroupRadiusMm).
//      Two drains within that XY distance share a group.
//   2. If fewer than 2 groups exist → no ridge possible.
//   3. The farthest pair of groups (by centroid XY distance)
//      defines the ridge zone.
//   4. The facing drains — nearest drain in each group
//      toward the other group — define the ridge line in XY.
//   5. Any roof vertex whose XY perpendicular distance to
//      that line is within RidgeLineToleranceMm is a ridge
//      member. Z is ignored throughout.
//   6. For each ridge member: find which of the two groups
//      is farther (Dijkstra path distance). The path to the
//      nearest drain in that farther group is used for
//      elevation.
//   7. Non-ridge vertices fall through to geometric drain
//      assignment (Q7 — most-aligned drain).
// =======================================================

using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.AutoSlopeByPoint.WithRidge.Core.Engine
{
    public static class RidgeDetector
    {
        // ── Public result types ───────────────────────────────────────────────

        /// <summary>
        /// Pre-computed ridge context built once before the main vertex loop.
        /// Passed into EvaluateVertex() for each vertex.
        /// Null when no ridge is possible (fewer than 2 drain groups).
        /// </summary>
        public class RidgeContext
        {
            /// <summary>XYZ position of the facing drain from group A (nearest to group B).</summary>
            public XYZ DrainNearA_Pos { get; set; }
            /// <summary>Index into the vertices list of Drain-Near-A.</summary>
            public int DrainNearA_Idx { get; set; }

            /// <summary>XYZ position of the facing drain from group B (nearest to group A).</summary>
            public XYZ DrainNearB_Pos { get; set; }
            /// <summary>Index into the vertices list of Drain-Near-B.</summary>
            public int DrainNearB_Idx { get; set; }

            /// <summary>All drain indices that belong to group A.</summary>
            public List<int> GroupA_Indices { get; set; }
            /// <summary>All drain indices that belong to group B.</summary>
            public List<int> GroupB_Indices { get; set; }

            // Ridge line in XY — derived from the two facing drain positions.
            // Stored as: a point on the line (DrainNearA projected to XY)
            // and a unit direction vector.
            internal XYZ LineOrigin   { get; set; }
            internal XYZ LineDir      { get; set; }   // unit vector in XY
            internal double LineLengthFt { get; set; }

            /// <summary>Ridge line tolerance in Revit internal units (feet).</summary>
            public double RidgeLineToleranceFt { get; set; }
        }

        /// <summary>Result returned for each vertex from EvaluateVertex().</summary>
        public class RidgeResult
        {
            public bool IsRidge { get; set; }

            // When IsRidge = true
            public double PathToUse_ft  { get; set; }
            public int    DrainA        { get; set; } = -1;  // Drain-Near-A index
            public int    DrainB        { get; set; } = -1;  // Drain-Near-B index
            public double PathA_ft      { get; set; }        // path to near-A (informational)
            public double PathB_ft      { get; set; }        // path to target (far group)

            // When IsRidge = false — geometric drain for Q7
            public int    GeometricDrainIndex   { get; set; } = -1;
            public double GeometricDrainPath_ft { get; set; }
        }

        // ── Step 1-4: build RidgeContext once before the main loop ───────────

        /// <summary>
        /// Clusters drain points, finds the farthest pair of groups,
        /// identifies the two facing drains and builds the XY ridge line.
        /// Returns null if no ridge is possible.
        /// </summary>
        /// <param name="drainIndices">All matched drain vertex indices.</param>
        /// <param name="drainPositions">drainIndex → XYZ position.</param>
        /// <param name="groupRadiusFt">Drain grouping radius in feet.</param>
        /// <param name="lineToleranceFt">Ridge line membership tolerance in feet.</param>
        public static RidgeContext BuildContext(
            IEnumerable<int>         drainIndices,
            Dictionary<int, XYZ>     drainPositions,
            double                   groupRadiusFt,
            double                   lineToleranceFt)
        {
            var idxList = drainIndices.ToList();
            if (idxList.Count < 2) return null;

            // ── Cluster drains by XY proximity ───────────────────────────────
            var groups = ClusterDrains(idxList, drainPositions, groupRadiusFt);
            if (groups.Count < 2) return null;

            // ── Find the farthest pair of groups by centroid XY distance ─────
            (List<int> gA, List<int> gB) = FindFarthestGroupPair(groups, drainPositions);

            XYZ centroidA = GroupCentroidXY(gA, drainPositions);
            XYZ centroidB = GroupCentroidXY(gB, drainPositions);

            // ── Facing drains: nearest drain in each group toward the other ──
            int nearA = NearestDrainToPoint(gA, drainPositions, centroidB);
            int nearB = NearestDrainToPoint(gB, drainPositions, centroidA);

            XYZ posA = ToXY(drainPositions[nearA]);
            XYZ posB = ToXY(drainPositions[nearB]);

            XYZ lineVec = posB - posA;
            double len  = lineVec.GetLength();
            if (len < 0.001) return null;   // coincident facing drains — no ridge

            return new RidgeContext
            {
                DrainNearA_Pos       = drainPositions[nearA],
                DrainNearA_Idx       = nearA,
                DrainNearB_Pos       = drainPositions[nearB],
                DrainNearB_Idx       = nearB,
                GroupA_Indices       = gA,
                GroupB_Indices       = gB,
                LineOrigin           = posA,
                LineDir              = lineVec.Multiply(1.0 / len),
                LineLengthFt         = len,
                RidgeLineToleranceFt = lineToleranceFt
            };
        }

        // ── Step 5-6: evaluate each vertex ───────────────────────────────────

        /// <summary>
        /// Decides whether a vertex is on the ridge line and, if so,
        /// computes its elevation path.
        /// </summary>
        /// <param name="vertexPos">Position of the vertex being tested.</param>
        /// <param name="pathsByDrain">drainIndex → Dijkstra path in feet for this vertex.</param>
        /// <param name="ctx">Pre-built RidgeContext (from BuildContext).</param>
        /// <param name="thresholdFt">Max path threshold.</param>
        public static RidgeResult EvaluateVertex(
            XYZ                      vertexPos,
            Dictionary<int, double>  pathsByDrain,
            RidgeContext             ctx,
            double                   thresholdFt)
        {
            if (ctx == null)
                return FallbackResult(vertexPos, pathsByDrain, ctx, thresholdFt);

            // ── Step 5: XY perpendicular distance to ridge line ───────────────
            XYZ vxy    = ToXY(vertexPos);
            XYZ toVert = vxy - ctx.LineOrigin;

            // Project onto line direction to get closest point
            double proj   = toVert.DotProduct(ctx.LineDir);
            XYZ   closest = ctx.LineOrigin + ctx.LineDir.Multiply(proj);
            double perpDist = (vxy - closest).GetLength();

            if (perpDist > ctx.RidgeLineToleranceFt)
                return FallbackResult(vertexPos, pathsByDrain, ctx, thresholdFt);

            // ── Step 6: which group is farther? ──────────────────────────────
            // Average Dijkstra path distance to each group
            double avgPathA = AverageGroupPath(ctx.GroupA_Indices, pathsByDrain, thresholdFt);
            double avgPathB = AverageGroupPath(ctx.GroupB_Indices, pathsByDrain, thresholdFt);

            // Far group = the group with the larger average path from this vertex
            List<int> farGroup  = avgPathA >= avgPathB ? ctx.GroupA_Indices : ctx.GroupB_Indices;
            List<int> nearGroup = avgPathA >= avgPathB ? ctx.GroupB_Indices : ctx.GroupA_Indices;

            // Nearest reachable drain in the far group
            int targetDrain = NearestReachableDrain(farGroup, pathsByDrain, thresholdFt);
            if (targetDrain < 0)
            {
                // Far group unreachable — fall back to near group
                targetDrain = NearestReachableDrain(nearGroup, pathsByDrain, thresholdFt);
            }

            if (targetDrain < 0)
                return FallbackResult(vertexPos, pathsByDrain, ctx, thresholdFt);

            double pathToTarget = pathsByDrain.TryGetValue(targetDrain, out double p) ? p : double.PositiveInfinity;
            if (double.IsInfinity(pathToTarget) || pathToTarget > thresholdFt)
                return FallbackResult(vertexPos, pathsByDrain, ctx, thresholdFt);

            // Informational: path to the facing drain on the near side
            int nearFacing = avgPathA >= avgPathB ? ctx.DrainNearB_Idx : ctx.DrainNearA_Idx;
            double pathNear = pathsByDrain.TryGetValue(nearFacing, out double pn) ? pn : 0;

            return new RidgeResult
            {
                IsRidge      = true,
                DrainA       = ctx.DrainNearA_Idx,
                DrainB       = ctx.DrainNearB_Idx,
                PathA_ft     = pathNear,
                PathB_ft     = pathToTarget,
                PathToUse_ft = pathToTarget
            };
        }

        // ── Clustering ────────────────────────────────────────────────────────

        /// <summary>
        /// Single-linkage clustering: two drains are in the same group
        /// if their XY distance is within groupRadiusFt.
        /// </summary>
        private static List<List<int>> ClusterDrains(
            List<int>            idxList,
            Dictionary<int, XYZ> positions,
            double               radiusFt)
        {
            // Union-Find
            var parent = idxList.ToDictionary(i => i, i => i);

            int Find(int x)
            {
                while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; }
                return x;
            }

            void Union(int a, int b)
            {
                int ra = Find(a), rb = Find(b);
                if (ra != rb) parent[ra] = rb;
            }

            for (int i = 0; i < idxList.Count; i++)
                for (int j = i + 1; j < idxList.Count; j++)
                {
                    double d = XYDist(positions[idxList[i]], positions[idxList[j]]);
                    if (d <= radiusFt) Union(idxList[i], idxList[j]);
                }

            return idxList
                .GroupBy(Find)
                .Select(g => g.ToList())
                .ToList();
        }

        /// <summary>Finds the pair of groups whose XY centroids are farthest apart.</summary>
        private static (List<int>, List<int>) FindFarthestGroupPair(
            List<List<int>>      groups,
            Dictionary<int, XYZ> positions)
        {
            List<int> bestA = groups[0], bestB = groups[1];
            double    bestD = 0;

            for (int i = 0; i < groups.Count; i++)
            for (int j = i + 1; j < groups.Count; j++)
            {
                double d = XYDist(
                    GroupCentroidXY(groups[i], positions),
                    GroupCentroidXY(groups[j], positions));
                if (d > bestD) { bestD = d; bestA = groups[i]; bestB = groups[j]; }
            }

            return (bestA, bestB);
        }

        // ── Geometric drain assignment (Q7 fallback) ──────────────────────────

        private static RidgeResult FallbackResult(
            XYZ                     vertexPos,
            Dictionary<int, double> pathsByDrain,
            RidgeContext            ctx,
            double                  thresholdFt)
        {
            var reachable = pathsByDrain
                .Where(kvp => !double.IsInfinity(kvp.Value) && kvp.Value <= thresholdFt)
                .OrderBy(kvp => kvp.Value)
                .ToList();

            if (reachable.Count == 0)
                return new RidgeResult { IsRidge = false, GeometricDrainIndex = -1 };

            if (reachable.Count == 1)
                return new RidgeResult
                {
                    IsRidge               = false,
                    GeometricDrainIndex   = reachable[0].Key,
                    GeometricDrainPath_ft = reachable[0].Value
                };

            // Outward vector weighted by inverse path — closest drain pulls hardest
            Dictionary<int, XYZ> drainPositions = null;
            if (ctx != null)
            {
                drainPositions = new Dictionary<int, XYZ>();
                foreach (var idx in ctx.GroupA_Indices) drainPositions[idx] = ctx.DrainNearA_Pos;
                foreach (var idx in ctx.GroupB_Indices) drainPositions[idx] = ctx.DrainNearB_Pos;
            }

            // Fallback: just use the shortest-path drain when no positions available
            if (drainPositions == null || drainPositions.Count == 0)
                return new RidgeResult
                {
                    IsRidge               = false,
                    GeometricDrainIndex   = reachable[0].Key,
                    GeometricDrainPath_ft = reachable[0].Value
                };

            XYZ outward = XYZ.Zero;
            foreach (var kvp in reachable)
            {
                if (!drainPositions.TryGetValue(kvp.Key, out XYZ dPos)) continue;
                XYZ away = ToXY(vertexPos - dPos);
                if (away.GetLength() < 0.001) continue;
                double w = kvp.Value > 0 ? 1.0 / kvp.Value : 1.0;
                outward = outward.Add(away.Normalize().Multiply(w));
            }
            if (outward.GetLength() < 0.001)
                return new RidgeResult
                {
                    IsRidge               = false,
                    GeometricDrainIndex   = reachable[0].Key,
                    GeometricDrainPath_ft = reachable[0].Value
                };

            outward = outward.Normalize();

            int    best    = reachable[0].Key;
            double bestDot = double.MaxValue;
            foreach (var kvp in reachable)
            {
                if (!drainPositions.TryGetValue(kvp.Key, out XYZ dPos)) continue;
                XYZ vec = ToXY(dPos - vertexPos);
                if (vec.GetLength() < 0.001) continue;
                double dot = outward.DotProduct(vec.Normalize());
                if (dot < bestDot) { bestDot = dot; best = kvp.Key; }
            }

            return new RidgeResult
            {
                IsRidge               = false,
                GeometricDrainIndex   = best,
                GeometricDrainPath_ft = pathsByDrain.TryGetValue(best, out double bp)
                                        ? bp : double.PositiveInfinity
            };
        }

        // ── Small helpers ─────────────────────────────────────────────────────

        /// <summary>Centroid of a group's XY positions.</summary>
        private static XYZ GroupCentroidXY(List<int> group, Dictionary<int, XYZ> positions)
        {
            double sx = 0, sy = 0;
            foreach (int idx in group) { sx += positions[idx].X; sy += positions[idx].Y; }
            return new XYZ(sx / group.Count, sy / group.Count, 0);
        }

        /// <summary>Index of the drain in 'group' whose XY position is nearest to 'target'.</summary>
        private static int NearestDrainToPoint(
            List<int> group, Dictionary<int, XYZ> positions, XYZ target)
            => group.OrderBy(idx => XYDist(positions[idx], target)).First();

        /// <summary>
        /// Index of the nearest reachable drain in 'group' by Dijkstra path.
        /// Returns -1 if none reachable within threshold.
        /// </summary>
        private static int NearestReachableDrain(
            List<int>               group,
            Dictionary<int, double> pathsByDrain,
            double                  thresholdFt)
        {
            int    best     = -1;
            double bestPath = double.MaxValue;
            foreach (int idx in group)
            {
                if (!pathsByDrain.TryGetValue(idx, out double p)) continue;
                if (double.IsInfinity(p) || p > thresholdFt) continue;
                if (p < bestPath) { bestPath = p; best = idx; }
            }
            return best;
        }

        /// <summary>Average Dijkstra path to reachable drains in a group. Returns ∞ if none.</summary>
        private static double AverageGroupPath(
            List<int>               group,
            Dictionary<int, double> pathsByDrain,
            double                  thresholdFt)
        {
            var valid = group
                .Where(idx => pathsByDrain.TryGetValue(idx, out double p)
                              && !double.IsInfinity(p) && p <= thresholdFt)
                .Select(idx => pathsByDrain[idx])
                .ToList();
            return valid.Count > 0 ? valid.Average() : double.PositiveInfinity;
        }

        /// <summary>XY-only distance between two XYZ points.</summary>
        private static double XYDist(XYZ a, XYZ b)
            => Math.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y));

        /// <summary>Projects XYZ to the XY plane (Z = 0).</summary>
        private static XYZ ToXY(XYZ v) => new XYZ(v.X, v.Y, 0);
    }
}
