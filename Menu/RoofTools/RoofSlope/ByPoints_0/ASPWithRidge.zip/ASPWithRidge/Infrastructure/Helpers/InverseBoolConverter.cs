using System;
using System.Globalization;
using System.Windows.Data;

namespace Revit26_Plugin.AutoSlopeByPoint.WithRidge.Infrastructure.Helpers
{
    public class InverseBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : value;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : value;
    }
}
