using Autodesk.Revit.UI;
using Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003.UI.ViewModels;
using System.Windows;

namespace Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003.UI.Views
{
    public partial class AutoSlopeByPointTwoSlopesWindow : Window
    {
        private AutoSlopeViewModel _viewModel;

        // Only one constructor — ViewModel is always created in AutoSlopeCommand
        // and passed in here. The old constructor that created its own ViewModel
        // has been removed because it cannot satisfy the new constructor signature
        // (VertexSelectionHandler + ExternalEvent must be created inside
        // IExternalCommand.Execute, not here).
        public AutoSlopeByPointTwoSlopesWindow(AutoSlopeViewModel viewModel)
        {
            InitializeComponent();

            _viewModel = viewModel;
            _viewModel.SetParentWindow(this);
            DataContext = _viewModel;

            this.Focus();
        }

        /// <summary>Keeps the ViewModel's SelectedLogEntries in sync so
        /// "Copy Selected" can act on the user's selection.</summary>
        private void LogList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (_viewModel != null && sender is System.Windows.Controls.ListBox list)
                _viewModel.SelectedLogEntries = list.SelectedItems;
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (_viewModel != null)
            {
                // Persist settings and flush the log before the window goes away.
                _viewModel.SaveSettingsOnClose();
                _viewModel.AutoSaveLog();
                _viewModel.ParentWindow = null;
            }

            base.OnClosing(e);
        }
    }
}