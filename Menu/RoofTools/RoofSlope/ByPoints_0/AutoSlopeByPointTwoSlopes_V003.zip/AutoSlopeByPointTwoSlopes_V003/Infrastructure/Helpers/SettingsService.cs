// SettingsService.cs
// Namespace: Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003
// Per-tool JSON settings at %AppData%\Revit26_Plugin\{ToolName}\settings.json
// (System.Text.Json POCO). Never throws — every failure is reported through the
// caller's log sink as a Warning and the tool falls back to defaults.

using Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003.Core.Models;
using System;
using System.IO;
using System.Text.Json;

namespace Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003.Infrastructure.Helpers
{
    public static class SettingsService
    {
        private const string ToolName = "AutoSlopeByPointTwoSlopes";

        private static string Folder => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Revit26_Plugin", ToolName);

        private static string FilePath => Path.Combine(Folder, "settings.json");

        private static readonly JsonSerializerOptions Options =
            new JsonSerializerOptions { WriteIndented = true };

        /// <summary>Returns null when no settings file exists or it cannot be read.</summary>
        public static AutoSlopeTwoSlopesSettings Load(Action<string> warn = null)
        {
            try
            {
                if (!File.Exists(FilePath)) return null;
                var json = File.ReadAllText(FilePath);
                if (string.IsNullOrWhiteSpace(json)) return null;
                return JsonSerializer.Deserialize<AutoSlopeTwoSlopesSettings>(json);
            }
            catch (Exception ex)
            {
                warn?.Invoke($"Could not load settings ({ex.GetType().Name}: {ex.Message}). Using defaults.");
                return null;
            }
        }

        /// <summary>Silent-skip on failure — settings persistence must never block the tool.</summary>
        public static void Save(AutoSlopeTwoSlopesSettings settings, Action<string> warn = null)
        {
            if (settings == null) return;
            try
            {
                Directory.CreateDirectory(Folder);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, Options));
            }
            catch (Exception ex)
            {
                warn?.Invoke($"Could not save settings ({ex.GetType().Name}: {ex.Message}).");
            }
        }
    }
}
