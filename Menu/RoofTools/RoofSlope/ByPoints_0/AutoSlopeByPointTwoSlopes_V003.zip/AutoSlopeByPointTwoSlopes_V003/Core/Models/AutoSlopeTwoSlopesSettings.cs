// AutoSlopeTwoSlopesSettings.cs
// Namespace: Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003
// POCO persisted as JSON at %AppData%\Revit26_Plugin\AutoSlopeByPointTwoSlopes\settings.json
// via System.Text.Json (project settings rule). Loaded on window open,
// saved on close and after every successful Run.

namespace Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003.Core.Models
{
    /// <summary>Per-tool persisted user settings. Plain POCO — no Revit types.</summary>
    public class AutoSlopeTwoSlopesSettings
    {
        public double SlopePercent { get; set; }
        public double SpecialSlopePercent { get; set; }
        public double RemainingSlopePercent { get; set; }
        public double ThresholdMeters { get; set; }
        public double DrainToleranceMm { get; set; }
        public bool EnableDrainTolerance { get; set; }
        public bool ExportToExcel { get; set; }
        public string ExportFolderPath { get; set; }
        public bool IncludeVertexDetails { get; set; }
    }
}
