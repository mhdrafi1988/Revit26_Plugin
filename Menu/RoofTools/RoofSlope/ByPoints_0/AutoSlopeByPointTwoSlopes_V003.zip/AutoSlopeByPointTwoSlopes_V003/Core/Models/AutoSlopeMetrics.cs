namespace Revit26_Plugin.AutoSlopeByPointTwoSlopes.V003.Core.Models
{
    public class AutoSlopeMetrics
    {
        public int Processed;
        public int Skipped;
        public double HighestElevation;
        public double LongestPath;
    }
}