using System;
using System.Collections.Generic;

namespace Revit26_Plugin.TaperedEpsPattern2D.V003.Core.Pattern
{
    /// <summary>Boards and grid lines of the contour-row layout (all slope faces).</summary>
    public sealed class RowLayoutResult
    {
        public IReadOnlyList<BoardPiece> Boards { get; init; } = Array.Empty<BoardPiece>();
        public IReadOnlyList<PatternSegment> GridLines { get; init; } = Array.Empty<PatternSegment>();
    }
}
