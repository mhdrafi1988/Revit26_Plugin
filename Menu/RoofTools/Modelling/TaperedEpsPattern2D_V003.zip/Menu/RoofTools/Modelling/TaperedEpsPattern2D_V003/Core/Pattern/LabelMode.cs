namespace Revit26_Plugin.TaperedEpsPattern2D.V003.Core.Pattern
{
    public enum LabelMode
    {
        None,
        Id,
        Code
    }
}
