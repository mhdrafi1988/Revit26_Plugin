using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Revit26_Plugin.TaperedEpsPattern2D.V003.Core.Pattern
{
    /// <summary>
    /// Contour-row layout ("Each edge" in V003). On every slope face:
    /// <list type="bullet">
    /// <item>Rows are the bands between thickness contours: row n spans n−1 … n board widths from the edge.
    ///   The last row at the ridge/apex takes what is left.</item>
    /// <item>Each row starts at the hip on both ends and fills inward with full boards, so the hip
    ///   pieces have the same shape in every row and mirror the neighbouring face's hip pieces.</item>
    /// <item>The make-up cut sits in the middle of the row. If the gap is more than one board, a full
    ///   board is centred with two equal slips; if those slips would be under the minimum piece size,
    ///   the gap is split into two equal halves instead.</item>
    /// </list>
    /// Board edges that are not on the face boundary become grid lines, joined along each line.
    /// </summary>
    public static class RowLayoutBuilder
    {
        private const double Eps = 1e-9;

        public static RowLayoutResult Build(ThicknessField thickness, IReadOnlyList<SlopeFace> faces,
            Pattern2DSettings settings, double minLengthM)
        {
            Polygon2D outline = thickness.Distances.Outline;
            double l = settings.BoardLengthM;
            double w = settings.BoardWidthM;
            var boards = new List<BoardPiece>();
            var lines = new List<PatternSegment>();

            foreach (SlopeFace face in faces)
            {
                GridFrame frame = GridFrame.ForFace(face.Polygon, outline.Edge(face.EdgeIndex).Direction, settings);
                double vBase = frame.VMin; // the roof edge line
                Vec2 ToWorld(Vec2 q) => frame.ToWorld(q.X, q.Y + vBase);
                Polygon2D local = new Polygon2D(face.Polygon.Vertices.Select(p =>
                {
                    Vec2 q = frame.ToLocal(p);
                    return new Vec2(q.X, q.Y - vBase);
                }));
                double maxV = local.Vertices.Max(p => p.Y);
                var faceEdges = new List<Segment2D>();

                for (int row = 1; (row - 1) * w < maxV - GeometryTolerance.Vertex; row++)
                {
                    double v0 = (row - 1) * w;
                    double v1 = Math.Min(row * w, maxV);
                    bool partialRow = v1 - v0 < w - GeometryTolerance.Vertex;

                    Polygon2D strip = ConvexClipper.ClipAll(local, new[]
                    {
                        new HalfPlane(new Vec2(0, 1), -v0),
                        new HalfPlane(new Vec2(0, -1), v1)
                    });
                    if (strip.IsEmpty || strip.Area < GeometryTolerance.MinLoopArea * 1e-2)
                    {
                        continue;
                    }

                    if (ConvexClipper.ClipLine(local, new Vec2(0, v0), Vec2.UnitX) is not Segment2D outer)
                    {
                        continue;
                    }

                    double a0 = Math.Min(outer.Start.X, outer.End.X);
                    double b0 = Math.Max(outer.Start.X, outer.End.X);
                    List<double> joints = Joints(a0, b0, l, Pattern2DSettings.MinBoardSizeM);

                    int cellCount = joints.Count - 1;
                    for (int i = 0; i < cellCount; i++)
                    {
                        double lo = i == 0 ? double.NegativeInfinity : joints[i];
                        double hi = i == cellCount - 1 ? double.PositiveInfinity : joints[i + 1];
                        var cuts = new List<HalfPlane>();
                        if (!double.IsInfinity(lo))
                        {
                            cuts.Add(new HalfPlane(Vec2.UnitX, -lo));
                        }

                        if (!double.IsInfinity(hi))
                        {
                            cuts.Add(new HalfPlane(-Vec2.UnitX, hi));
                        }

                        Polygon2D pieceLocal = ConvexClipper.ClipAll(strip, cuts);
                        if (pieceLocal.IsEmpty || pieceLocal.Area < GeometryTolerance.MinLoopArea * 1e-2)
                        {
                            continue;
                        }

                        PieceKind kind = Classify(pieceLocal, partialRow, l * w, i, cellCount);
                        double xRef = kind == PieceKind.HipLeft ? a0
                            : kind == PieceKind.HipRight ? b0
                            : pieceLocal.Vertices.Min(p => p.X);
                        bool mirror = kind == PieceKind.HipRight;

                        Polygon2D world = new Polygon2D(pieceLocal.Vertices.Select(ToWorld)).ToCounterClockwise();
                        boards.Add(new BoardPiece
                        {
                            Id = string.Format(CultureInfo.InvariantCulture, "E{0}-R{1:00}-P{2:00}", face.EdgeIndex + 1, row, i + 1),
                            Row = row,
                            Column = i + 1,
                            Polygon = world,
                            IsFull = kind == PieceKind.Full,
                            Kind = kind,
                            EdgeIndex = face.EdgeIndex,
                            ShapeKey = ShapeKey(pieceLocal, xRef, v0, mirror),
                            MinThicknessMm = world.Vertices.Min(thickness.ThicknessAt),
                            MaxThicknessMm = world.Vertices.Max(thickness.ThicknessAt)
                        });

                        foreach (Segment2D e in world.Edges)
                        {
                            if (e.Length >= GeometryTolerance.Merge && !face.Polygon.IsOnBoundaryLine(e, GeometryTolerance.Merge))
                            {
                                faceEdges.Add(e);
                            }
                        }
                    }
                }

                foreach (Segment2D s in CollinearUnion.Union(faceEdges, GeometryTolerance.Merge))
                {
                    if (s.Length >= minLengthM)
                    {
                        lines.Add(new PatternSegment(PatternLayer.Grid, s, edgeIndex: face.EdgeIndex));
                    }
                }
            }

            return new RowLayoutResult { Boards = RowPieceCoder.Assign(boards), GridLines = lines };
        }

        /// <summary>Joint positions along one row, from hip (a0) to hip (b0), both ends included.</summary>
        public static List<double> Joints(double a0, double b0, double length, double minPiece)
        {
            double mid = (a0 + b0) / 2;
            var left = new List<double> { a0 };
            for (int k = 1; a0 + k * length <= mid + Eps; k++)
            {
                left.Add(a0 + k * length);
            }

            var right = new List<double> { b0 };
            for (int k = 1; b0 - k * length >= mid - Eps; k++)
            {
                right.Add(b0 - k * length);
            }

            double gap = right[right.Count - 1] - left[left.Count - 1];
            var all = new List<double>(left);
            if (gap > length + Eps)
            {
                double slip = (gap - length) / 2;
                if (slip >= minPiece - Eps)
                {
                    all.Add(mid - length / 2);
                    all.Add(mid + length / 2);
                }
                else
                {
                    all.Add(mid);
                }
            }

            all.AddRange(right);
            all.Sort();
            var unique = new List<double>();
            foreach (double j in all)
            {
                if (unique.Count == 0 || j - unique[unique.Count - 1] > GeometryTolerance.Vertex)
                {
                    unique.Add(j);
                }
            }

            return unique;
        }

        private static PieceKind Classify(Polygon2D piece, bool partialRow, double fullArea, int index, int count)
        {
            if (partialRow)
            {
                return PieceKind.RidgeRow;
            }

            if (Math.Abs(piece.Area - fullArea) < 1e-6)
            {
                return PieceKind.Full;
            }

            if (count == 1)
            {
                return PieceKind.Cut;
            }

            return index == 0 ? PieceKind.HipLeft : index == count - 1 ? PieceKind.HipRight : PieceKind.Filler;
        }

        /// <summary>Vertices relative to the row (mm), mirrored for right-hand hip pieces, sorted.</summary>
        private static string ShapeKey(Polygon2D local, double xRef, double v0, bool mirror) =>
            string.Join(";", local.Vertices
                .Select(p => (X: (long)Math.Round(((mirror ? xRef - p.X : p.X - xRef)) * 1000), Y: (long)Math.Round((p.Y - v0) * 1000)))
                .Distinct()
                .OrderBy(p => p.X).ThenBy(p => p.Y)
                .Select(p => p.X.ToString(CultureInfo.InvariantCulture) + "," + p.Y.ToString(CultureInfo.InvariantCulture)));
    }
}
