# Tapered EPS Layout V001 — integration guide

**Namespace:** `Revit26_Plugin.TaperedEpsLayout.V001`
**Folder:** `Menu/RoofTools/Insulation/TaperedEpsLayout_V001/`
**Ribbon command:** `Revit26_Plugin.TaperedEpsLayout.V001.Commands.TaperedEpsLayoutCommand`

The zip mirrors the repo root, so the folders drop straight in.

```
Menu/RoofTools/Insulation/TaperedEpsLayout_V001/
  Commands/        TaperedEpsLayoutCommand.cs
  Core/Models/     plain data (Vec2, LayoutSettings, BoardPiece, BoardCode, LayoutResult, …)
  Core/Engine/     layout maths, no Revit/WPF references (validator, slope field, grid cutter, grouping)
  Infrastructure/
    Revit/           boundary reader, DirectShapes, shared parameters, plan view, tags, units
    ExternalEvents/  SelectRoofHandler, RunHandler, EpsRevitBridge (per-window, no statics)
    Export/          ExcelExporter (ClosedXML)
    Helpers/         EpsSettingsStore (last-used inputs, JSON in %AppData%\SloperPro)
  UI/ViewModels/   TaperedEpsLayoutViewModel, BoardCodeRowViewModel, LegendItem
  UI/Views/        TaperedEpsLayoutWindow.xaml(.cs), LayoutPreviewControl.cs
Resources/Icons/RoofTools/TaperedEps_16.png, TaperedEps_32.png
Tests/Revit26_Plugin.Tests/          xUnit project (Core only)
Patches/                             csproj, ribbon, CHANGELOG and icon-prompt snippets
Docs/TaperedEpsLayout_Preview.html   the interactive HTML preview
```

## Steps

1. Copy `Menu/`, `Resources/` and `Tests/` into the repo root (nothing existing is overwritten).
2. Add the three ItemGroups from `Patches/Revit26_Plugin.csproj.snippet.xml` to `Revit26_Plugin.csproj`.
   The `Compile Remove="Tests\**"` line matters — without it the SDK glob compiles the tests into the add-in.
3. Paste `Patches/RoofToolsRibbon.snippet.cs` into `RoofToolsRibbon.Build(...)`.
4. Add the test project to the solution and run it:
   `dotnet sln add Tests/Revit26_Plugin.Tests/Revit26_Plugin.Tests.csproj`, then `dotnet test Tests/Revit26_Plugin.Tests`.
5. Build, start Revit, and run the first-use check below.
6. Append `Patches/CHANGELOG.entry.md` to `Claude/CHANGELOG.md` and `Patches/Icon_Prompts.entry.md` to
   `Claude/LOGO PROMPT FOLDER/Icon_Prompts.md`.

## Check these names on first build

The repo wasn't reachable while this was written, so the code relies on names documented in `CLAUDE.md`,
`UI_UX_PATTERNS.md` and `CHANGELOG.md`. A mismatch shows up as a compile error (C#/XAML) or as default styling
(resource keys, because every shared key is a `DynamicResource`).

| What | Used as | If it differs |
|---|---|---|
| Shell control | `shell:ToolWindowShell` with `Title`, `Subtitle`, `Version`, `IsRunning`, `Progress`, `SummaryText`, `IsIndeterminate`, `HeaderContent`, `BodyContent`, `FooterContent` | Rename in `TaperedEpsLayoutWindow.xaml` (compile error points to it) |
| Shell behaviours | `shell:ShellBehaviors.MaxHeightRatio`, `ForwardMouseWheel` | Same file |
| Shared dictionaries | `pack://application:,,,/Revit26_Plugin;component/Shared/SharedStyles.xaml` and `…/Shared/Controls/ToolWindowShellTemplate.xaml`, merged in code-behind | Copy the URIs from SectionAutoRenamer V026's window. A wrong URI only logs a warning. |
| Styles | `MetricTile{Info,Warning,Danger,Success}` + `MetricTileLabel…` / `MetricTileNumber…`, `PrimaryButton`, `RunButton`, `LogHeaderToggle` | Rename in XAML |
| Brushes (documented) | `BrushCardBackground`, `BrushNavyPrimary`, `BrushInputBackground`, `BrushLog{Background,Text,Success,Warning,Error}`, `BrushSoft{Success,Danger}Background`, `BrushTintInfo`, `BrushDetail{Muted,Value}Text` | Rename in XAML |
| Brushes (assumed) | `BrushBorder` (card border), `BrushDanger` (input error text) | Add the tokens to SharedStyles, or point to existing ones |
| Ribbon helpers | `ImageUtils.Load`, `RibbonLayoutHelper.VersionTip` | Already used by every `*Ribbon.cs` |

**Log model:** the tool uses its own `EpsLogMessage` / `EpsLogLevel` (same levels and the same
`HH:mm:ss  Level  Message` text as `Shared/LogEntry`). The shared `LogEntry` constructor couldn't be checked,
so swapping to it is a small follow-up rather than a guess that might not compile.

## Behaviour (confirmed decisions, 2026-10-12)

- **Input:** one flat roof or floor. The tool reads its top face, which must be one convex loop of straight edges.
  It is rejected with a clear message if it is sloped, has openings, arcs or concave corners.
- **Placement:** board bottoms sit on that top face.
- **Thickness:** H(p) = tmin + slope% × 10 mm/m × distance to the nearest edge. The minimum is at the perimeter
  and the maximum on the ridge.
- **Boards:** one Generic Model DirectShape per piece, named `<Prefix>-<ID>`. Each has `EPS_ID`, `EPS_Code`,
  `EPS_Hand`, `EPS_H1…H8`, `EPS_Area` and `EPS_Volume` (Length/Area/Volume specs, fixed GUIDs). The shared
  parameter file is `%AppData%\SloperPro\TaperedEps_SharedParameters.txt`; the user's own setting is restored after binding.
- **Transactions:** everything runs in one TransactionGroup. The boards are **all-or-nothing**: if any board
  fails, the whole run is rolled back and the footer shows "0 placed | … | N failed". The plan view and tags
  run in their own transactions. If either fails, a warning is logged and the boards are kept.
- **Plan view:** "EPS Layout - <Level>" (with " (2)" etc. if the name is taken). No view template is applied.
  The cut plane is 1.2 m above the boards. Boards are colour-filled in 10 mm bands, using the same palette as
  the window preview.
- **Excel:** the file is chosen before the run. It is written only if the Revit part succeeded. It has two
  sheets: Board Codes and All Pieces, each with a Placed column.
- **Board Schedule:** an unchecked code is skipped (not placed). Check states survive a recompute when the set
  of codes doesn't change.
- **Large layouts:** above 5,000 boards, Run asks for confirmation first.

Engine conventions are pinned by the tests:
- A tie for longest edge goes to the first edge counter-clockwise.
- The grid origin is the minimum corner of the bounding box in the grid frame.
- Row A is on the low side of the grid.
- Classification precedence is Hip > Edge > Full.
- Signatures are rounded to 0.1 mm / 1 mm / 1e-4.

## What was verified before packaging

- **Engine:** all 31 tests pass. This covers the six acceptance shapes, which give exact piece and code counts,
  60 mm and 3.413 m³ for the 12 × 8 rectangle, and 70 mm for the 10 × 10 square. It also covers the area check,
  no thickness below tmin, the L-shape error, and the mirrored-hand pair.
  NuGet was blocked in the build sandbox, so the test files ran against a minimal xUnit stand-in.
  `dotnet test` in the repo is the real run.
- **Revit layer:** `Infrastructure/` and `Core/` compile cleanly against stand-ins of the Revit 2026 API and
  ClosedXML. They also compile with simulated WinForms / System.Drawing global usings: the WPF and Revit files
  scope their usings, so `View`, `Color` and `MessageBox` don't clash.
- **Not verified here:** WPF/XAML compilation, CommunityToolkit source generation, and running inside Revit.
  These need Windows and Revit.

## First-use check in Revit

1. Draw a 12 × 8 m floor (or a flat footprint roof) and run the tool with it selected. Expect 112 boards,
   8 codes, max 60.0 mm, 3.413 m³ in the header.
2. Uncheck one code, then Run with all three outputs on. Expect the 3D boards on the slab top and the new plan
   view coloured and tagged. The Excel file should have both sheets, with the unchecked code marked Placed = No.
3. Undo once in Revit. The whole run should disappear, because it is one TransactionGroup.
4. Pick an L-shaped or sloped roof. Expect a clear message in the Roof Selection card and Run disabled.

## Known limits (V001)

- Convex outlines only. Split L/U-shaped roofs into convex parts.
- No openings and no arcs. Water always falls to the perimeter (no internal drains).
- `EPS_H1…H8` hold the first 8 corners. Rarer pieces with more corners are counted in the log and listed with
  their corner count in Excel.
- ClosedXML brings `DocumentFormat.OpenXml`. If another add-in loaded into Revit uses a different version, the
  first Excel export may report an assembly-load error. In that case switch `ExcelExporter` to the library the
  repo already uses.
