namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>RGB colour for a thickness band — plain bytes so Core, the WPF preview and Revit overrides share one palette.</summary>
    public readonly record struct BandColor(byte R, byte G, byte B)
    {
        /// <summary>Relative luminance 0..1, used to pick dark or light label text.</summary>
        public double Luminance => (0.2126 * R + 0.7152 * G + 0.0722 * B) / 255.0;
    }
}
