using System.Collections.Generic;
using System.Linq;
using ClosedXML.Excel;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Export
{
    /// <summary>
    /// Writes the board schedule: "Board Codes" (one row per code) and "All Pieces" (one row per piece).
    /// Both sheets include every code/piece with a Placed column, so skipped codes stay visible.
    /// Pure file output — no Revit API, safe to call on the UI thread.
    /// </summary>
    public static class ExcelExporter
    {
        public static void Export(string path, LayoutResult layout, ISet<string> placedCodes, string prefix)
        {
            using var wb = new XLWorkbook();
            WriteCodes(wb.Worksheets.Add("Board Codes"), layout, placedCodes);
            WritePieces(wb.Worksheets.Add("All Pieces"), layout, placedCodes, prefix);
            wb.SaveAs(path);
        }

        private static void WriteCodes(IXLWorksheet ws, LayoutResult layout, ISet<string> placed)
        {
            string[] head = { "Code", "Type", "Hand", "Qty", "Placed", "Min mm", "Max mm", "Area m²", "Volume m³" };
            for (int c = 0; c < head.Length; c++) ws.Cell(1, c + 1).Value = head[c];

            int r = 2;
            foreach (BoardCode code in layout.Codes)
            {
                ws.Cell(r, 1).Value = code.Code;
                ws.Cell(r, 2).Value = code.Type.ToString();
                ws.Cell(r, 3).Value = code.HandText;
                ws.Cell(r, 4).Value = code.Quantity;
                ws.Cell(r, 5).Value = placed.Contains(code.Code) ? "Yes" : "No";
                ws.Cell(r, 6).Value = code.MinHeight;
                ws.Cell(r, 7).Value = code.MaxHeight;
                ws.Cell(r, 8).Value = code.TotalArea;
                ws.Cell(r, 9).Value = code.TotalVolume;
                r++;
            }

            ws.Cell(r, 1).Value = "Total";
            ws.Cell(r, 4).Value = layout.Codes.Sum(c => c.Quantity);
            ws.Cell(r, 8).Value = layout.Codes.Sum(c => c.TotalArea);
            ws.Cell(r, 9).Value = layout.Codes.Sum(c => c.TotalVolume);
            ws.Row(r).Style.Font.Bold = true;

            Format(ws, head.Length, r, (6, "0.0"), (7, "0.0"), (8, "0.000"), (9, "0.000"));
        }

        private static void WritePieces(IXLWorksheet ws, LayoutResult layout, ISet<string> placed, string prefix)
        {
            var head = new List<string> { "Element", "ID", "Code", "Type", "Hand", "Placed", "Corners" };
            for (int i = 1; i <= 8; i++) head.Add($"H{i} mm");
            head.Add("Area m²");
            head.Add("Volume m³");
            for (int c = 0; c < head.Count; c++) ws.Cell(1, c + 1).Value = head[c];

            int r = 2;
            foreach (BoardPiece p in layout.Pieces)
            {
                ws.Cell(r, 1).Value = $"{prefix}-{p.Id}";
                ws.Cell(r, 2).Value = p.Id;
                ws.Cell(r, 3).Value = p.Code;
                ws.Cell(r, 4).Value = p.Type.ToString();
                ws.Cell(r, 5).Value = p.HandText;
                ws.Cell(r, 6).Value = placed.Contains(p.Code) ? "Yes" : "No";
                ws.Cell(r, 7).Value = p.Heights.Count;
                for (int i = 0; i < 8 && i < p.Heights.Count; i++) ws.Cell(r, 8 + i).Value = p.Heights[i];
                ws.Cell(r, 16).Value = p.Area;
                ws.Cell(r, 17).Value = p.Volume;
                r++;
            }

            var formats = new List<(int, string)>();
            for (int c = 8; c <= 15; c++) formats.Add((c, "0.0"));
            formats.Add((16, "0.000"));
            formats.Add((17, "0.0000"));
            Format(ws, head.Count, r - 1, formats.ToArray());
        }

        private static void Format(IXLWorksheet ws, int columns, int lastRow, params (int Column, string Format)[] numberFormats)
        {
            IXLRange header = ws.Range(1, 1, 1, columns);
            header.Style.Font.Bold = true;
            header.Style.Fill.BackgroundColor = XLColor.FromArgb(0x1E, 0x3A, 0x5F); // SharedStyles NavyPrimary
            header.Style.Font.FontColor = XLColor.White;

            foreach ((int column, string format) in numberFormats)
                ws.Range(2, column, System.Math.Max(2, lastRow), column).Style.NumberFormat.Format = format;

            ws.SheetView.FreezeRows(1);
            ws.Range(1, 1, System.Math.Max(1, lastRow), columns).SetAutoFilter();
            ws.Columns(1, columns).AdjustToContents();
        }
    }
}
