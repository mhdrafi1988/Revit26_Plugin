namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>
    /// Mirrors Shared/LogLevel.cs (Info, Warning, Error, Success, Debug). Kept local in V001 because the
    /// shared LogEntry constructor could not be checked when this tool was written — see README_INTEGRATION.md.
    /// </summary>
    public enum EpsLogLevel
    {
        Info = 0,
        Warning = 1,
        Error = 2,
        Success = 3,
        Debug = 4
    }
}
