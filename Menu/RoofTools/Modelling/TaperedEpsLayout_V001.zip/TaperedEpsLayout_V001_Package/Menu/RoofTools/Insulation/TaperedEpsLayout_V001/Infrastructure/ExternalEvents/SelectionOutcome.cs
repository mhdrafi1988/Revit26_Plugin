using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents
{
    /// <summary>Result of a "Select Roof" pick, handed back to the ViewModel.</summary>
    public sealed class SelectionOutcome
    {
        public bool Cancelled { get; set; }
        public BoundaryReadResult Read { get; set; }
        public IReadOnlyList<TagTypeOption> TagTypes { get; set; }
        public string Error { get; set; } = string.Empty;
    }
}
