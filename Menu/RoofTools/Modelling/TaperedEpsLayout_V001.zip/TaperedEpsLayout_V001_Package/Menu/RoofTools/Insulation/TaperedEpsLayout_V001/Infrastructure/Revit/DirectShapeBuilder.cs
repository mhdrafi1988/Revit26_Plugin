using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>
    /// One Generic Model DirectShape per board: flat bottom, planar sloped top at the corner thicknesses,
    /// vertical sides. Faces are wound so normals point outwards. Call inside a transaction.
    /// </summary>
    public static class DirectShapeBuilder
    {
        public const string ApplicationId = "Revit26_Plugin.SloperPro";
        public const string ApplicationDataId = "TaperedEpsLayout.V001";

        public static DirectShape Create(Document doc, BoardPiece piece, double baseZFeet, string name)
        {
            List<XYZ> bottom = piece.Vertices.Select(v => RevitUnits.ToFeet(v, baseZFeet)).ToList();
            List<XYZ> top = piece.Vertices
                .Select((v, i) => RevitUnits.ToFeet(v, baseZFeet + RevitUnits.MillimetresToFeet(piece.Heights[i])))
                .ToList();

            var builder = new TessellatedShapeBuilder
            {
                Target = TessellatedShapeBuilderTarget.Solid,
                Fallback = TessellatedShapeBuilderFallback.Mesh,
                GraphicsStyleId = ElementId.InvalidElementId
            };

            builder.OpenConnectedFaceSet(true);

            // Vertices are CCW in plan: the top keeps that order (normal +Z), the bottom is reversed (normal −Z).
            var reversedBottom = new List<XYZ>(bottom);
            reversedBottom.Reverse();
            builder.AddFace(new TessellatedFace(reversedBottom, ElementId.InvalidElementId));
            builder.AddFace(new TessellatedFace(top, ElementId.InvalidElementId));

            int n = bottom.Count;
            for (int i = 0; i < n; i++)
            {
                int j = (i + 1) % n;
                // a→b runs CCW, so bottom(a), bottom(b), top(b), top(a) faces outwards.
                builder.AddFace(new TessellatedFace(new List<XYZ> { bottom[i], bottom[j], top[j], top[i] }, ElementId.InvalidElementId));
            }

            builder.CloseConnectedFaceSet();
            builder.Build();
            TessellatedShapeBuilderResult result = builder.GetBuildResult();
            if (result.Outcome == TessellatedShapeBuilderOutcome.Nothing)
                throw new InvalidOperationException($"Revit could not build the geometry for board {piece.Id}.");

            DirectShape ds = DirectShape.CreateElement(doc, new ElementId(BuiltInCategory.OST_GenericModel));
            ds.ApplicationId = ApplicationId;
            ds.ApplicationDataId = ApplicationDataId;
            ds.SetShape(result.GetGeometricalObjects());
            ds.SetName(name);
            return ds;
        }
    }
}
