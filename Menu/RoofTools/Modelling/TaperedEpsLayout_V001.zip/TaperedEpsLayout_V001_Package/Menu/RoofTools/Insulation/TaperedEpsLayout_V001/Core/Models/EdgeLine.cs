namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>
    /// Boundary edge as a line Nx·x + Ny·y + C = 0 with (Nx, Ny) the inward unit normal,
    /// so Distance(p) is the signed distance into the roof (Li(p) in the spec).
    /// </summary>
    public readonly record struct EdgeLine(double Nx, double Ny, double C)
    {
        public double Distance(Vec2 p) => Nx * p.X + Ny * p.Y + C;
    }
}
