using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>Entry point: outline (project XY, metres) + settings → board layout. Pure, thread-safe.</summary>
    public static class LayoutEngine
    {
        public static LayoutResult Compute(IReadOnlyList<Vec2> outline, LayoutSettings s)
        {
            if (s == null) return LayoutResult.Invalid("No settings.");
            if (s.BoardWidth <= 0 || s.BoardLength <= 0) return LayoutResult.Invalid("Board size must be greater than zero.");
            if (s.SlopePercent <= 0) return LayoutResult.Invalid("Slope must be greater than zero.");
            if (s.MinThicknessMm <= 0) return LayoutResult.Invalid("Minimum thickness must be greater than zero.");

            ValidationResult v = PolygonValidator.Validate(outline);
            if (!v.IsValid) return LayoutResult.Invalid(v.Message);

            IReadOnlyList<Vec2> polygon = v.Polygon;
            double angle = GridFrame.FindAngle(polygon, s.Direction);
            var frame = new GridFrame(angle);
            List<Vec2> gridPolygon = frame.ToGrid(polygon);

            var slope = new SlopeEngine(gridPolygon, s.SlopePercent, s.MinThicknessMm);
            List<RawPiece> raw = GridCutter.Cut(gridPolygon, slope.Edges, s, out int columns, out int rows);

            var pieces = new List<BoardPiece>(raw.Count);
            foreach (RawPiece r in raw)
            {
                IReadOnlyList<Vec2> gv = r.GridVertices;
                List<double> h = gv.Select(slope.Height).ToList();

                // Volume of a prism with a planar top: fan triangles × mean corner thickness (exact for planar tops).
                double volume = 0;
                for (int t = 1; t < gv.Count - 1; t++)
                {
                    double triArea = Polygon2.SignedArea(new[] { gv[0], gv[t], gv[t + 1] });
                    volume += triArea * (h[0] + h[t] + h[t + 1]) / 3.0 / 1000.0;
                }

                pieces.Add(new BoardPiece(
                    PieceNamer.Id(r.Row, r.Column, r.SubIndex, r.SubCount),
                    r.Row, r.Column, r.Type,
                    frame.ToWorld(gv), gv, h,
                    Polygon2.SignedArea(gv), volume, h.Min(), h.Max()));
            }

            List<BoardCode> codes = PieceGrouper.Assign(pieces);
            return LayoutResult.Create(s, polygon, angle, columns, rows, pieces, codes);
        }
    }
}
