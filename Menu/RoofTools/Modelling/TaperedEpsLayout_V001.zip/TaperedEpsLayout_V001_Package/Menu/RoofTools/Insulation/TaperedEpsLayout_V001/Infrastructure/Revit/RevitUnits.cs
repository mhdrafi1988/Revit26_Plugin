using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>The only place this tool converts between Revit internal units (feet) and metres / mm.</summary>
    public static class RevitUnits
    {
        public static double FeetToMetres(double feet) => UnitUtils.ConvertFromInternalUnits(feet, UnitTypeId.Meters);
        public static double MetresToFeet(double metres) => UnitUtils.ConvertToInternalUnits(metres, UnitTypeId.Meters);
        public static double MillimetresToFeet(double mm) => UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters);
        public static double SquareMetresToInternal(double m2) => UnitUtils.ConvertToInternalUnits(m2, UnitTypeId.SquareMeters);
        public static double CubicMetresToInternal(double m3) => UnitUtils.ConvertToInternalUnits(m3, UnitTypeId.CubicMeters);

        public static Vec2 ToMetres(XYZ p) => new Vec2(FeetToMetres(p.X), FeetToMetres(p.Y));

        public static XYZ ToFeet(Vec2 p, double zFeet) => new XYZ(MetresToFeet(p.X), MetresToFeet(p.Y), zFeet);
    }
}
