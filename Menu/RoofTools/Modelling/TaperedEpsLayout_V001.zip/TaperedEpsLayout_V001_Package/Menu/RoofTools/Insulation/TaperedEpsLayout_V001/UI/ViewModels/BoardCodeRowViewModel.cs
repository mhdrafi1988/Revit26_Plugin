using System;
using CommunityToolkit.Mvvm.ComponentModel;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.UI.ViewModels
{
    /// <summary>One Board Schedule row. Checked = this code's boards are placed; unchecked = skipped.</summary>
    public partial class BoardCodeRowViewModel : ObservableObject
    {
        private Action<BoardCodeRowViewModel> _onCheckedChanged;

        public BoardCodeRowViewModel(BoardCode source, bool isChecked, Action<BoardCodeRowViewModel> onCheckedChanged)
        {
            Source = source;
            IsChecked = isChecked;
            _onCheckedChanged = onCheckedChanged; // assigned after the initial value so construction doesn't fire it
        }

        public BoardCode Source { get; }
        public string Code => Source.Code;
        public string Type => Source.Type.ToString();
        public string Hand => Source.LeftCount == 0 && Source.RightCount == 0 ? "S" : $"L{Source.LeftCount} · R{Source.RightCount}";
        public int Quantity => Source.Quantity;
        public double MinMm => Source.MinHeight;
        public double MaxMm => Source.MaxHeight;
        public double Area => Source.TotalArea;
        public double Volume => Source.TotalVolume;

        [ObservableProperty]
        private bool isChecked;

        partial void OnIsCheckedChanged(bool value) => _onCheckedChanged?.Invoke(this);

        /// <summary>Text the schedule filter box matches against.</summary>
        public string SearchText => $"{Code} {Type} {Hand}";
    }
}
