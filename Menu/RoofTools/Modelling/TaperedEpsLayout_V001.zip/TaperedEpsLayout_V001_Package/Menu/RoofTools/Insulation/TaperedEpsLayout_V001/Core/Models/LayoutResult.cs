using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    public sealed class LayoutResult
    {
        private LayoutResult() { }

        public bool IsValid { get; private set; }
        public string Message { get; private set; } = string.Empty;

        public LayoutSettings Settings { get; private set; }

        /// <summary>Cleaned counter-clockwise outline, project XY metres.</summary>
        public IReadOnlyList<Vec2> Polygon { get; private set; } = Array.Empty<Vec2>();

        /// <summary>Grid direction, radians from project X.</summary>
        public double GridAngle { get; private set; }
        public int Columns { get; private set; }
        public int Rows { get; private set; }

        public IReadOnlyList<BoardPiece> Pieces { get; private set; } = Array.Empty<BoardPiece>();
        public IReadOnlyList<BoardCode> Codes { get; private set; } = Array.Empty<BoardCode>();

        public double RoofArea { get; private set; }
        public double PieceArea { get; private set; }
        public double TotalVolume { get; private set; }
        public double MinThickness { get; private set; }
        public double MaxThickness { get; private set; }
        public int HipCount { get; private set; }

        public static LayoutResult Invalid(string message) => new LayoutResult { IsValid = false, Message = message };

        public static LayoutResult Create(LayoutSettings settings, IReadOnlyList<Vec2> polygon, double gridAngle,
                                          int columns, int rows, IReadOnlyList<BoardPiece> pieces, IReadOnlyList<BoardCode> codes)
        {
            return new LayoutResult
            {
                IsValid = true,
                Settings = settings,
                Polygon = polygon,
                GridAngle = gridAngle,
                Columns = columns,
                Rows = rows,
                Pieces = pieces,
                Codes = codes,
                RoofArea = Polygon2.Area(polygon),
                PieceArea = pieces.Sum(p => p.Area),
                TotalVolume = pieces.Sum(p => p.Volume),
                MinThickness = pieces.Count == 0 ? 0 : pieces.Min(p => p.MinHeight),
                MaxThickness = pieces.Count == 0 ? 0 : pieces.Max(p => p.MaxHeight),
                HipCount = pieces.Count(p => p.Type == PieceType.Hip)
            };
        }
    }
}
