namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>A loaded Generic Model tag type ("Family : Type"). IdValue ≤ 0 means "none loaded".</summary>
    public sealed record TagTypeOption(long IdValue, string Label)
    {
        public static TagTypeOption None => new TagTypeOption(-1, "(no Generic Model tag loaded)");

        public bool IsNone => IdValue <= 0;

        public override string ToString() => Label;
    }
}
