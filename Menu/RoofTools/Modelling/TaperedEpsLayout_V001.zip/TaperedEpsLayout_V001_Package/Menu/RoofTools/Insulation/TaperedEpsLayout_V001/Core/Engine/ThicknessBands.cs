using System;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// 10 mm thickness bands and their colours. One palette for the window preview and the Revit
    /// plan-view overrides, so both read the same. Pieces are coloured by their max thickness.
    /// </summary>
    public sealed class ThicknessBands
    {
        public const double BandMm = 10.0;

        // Thin → thick: pale sand to deep brown.
        private static readonly BandColor[] Ramp =
        {
            new BandColor(0xFB, 0xF1, 0xCF), new BandColor(0xF5, 0xDB, 0x99), new BandColor(0xED, 0xBC, 0x69),
            new BandColor(0xE0, 0x9A, 0x4C), new BandColor(0xCC, 0x75, 0x3C), new BandColor(0xAE, 0x52, 0x33),
            new BandColor(0x83, 0x37, 0x2D), new BandColor(0x5C, 0x28, 0x28)
        };

        public ThicknessBands(double minMm, double maxMm)
        {
            Low = Math.Floor(minMm / BandMm) * BandMm;
            double high = Math.Max(Low + BandMm, Math.Ceiling(maxMm / BandMm) * BandMm);
            Count = (int)Math.Round((high - Low) / BandMm);
        }

        public double Low { get; }
        public int Count { get; }

        public int IndexOf(double thicknessMm) =>
            Math.Max(0, Math.Min(Count - 1, (int)Math.Floor((thicknessMm - Low) / BandMm + 1e-9)));

        public BandColor ColorOf(int index)
        {
            double t = Count == 1 ? 0.5 : (double)index / (Count - 1);
            double x = Math.Max(0, Math.Min(1, t)) * (Ramp.Length - 1);
            int i = Math.Min(Ramp.Length - 2, (int)Math.Floor(x));
            double f = x - i;
            BandColor a = Ramp[i], b = Ramp[i + 1];
            return new BandColor(Lerp(a.R, b.R, f), Lerp(a.G, b.G, f), Lerp(a.B, b.B, f));
        }

        public BandColor ColorFor(double thicknessMm) => ColorOf(IndexOf(thicknessMm));

        public string Label(int index) => $"{Low + index * BandMm:0}–{Low + (index + 1) * BandMm:0}";

        private static byte Lerp(byte a, byte b, double f) => (byte)Math.Round(a + (b - a) * f);
    }
}
