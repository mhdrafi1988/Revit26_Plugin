using System;
using System.Collections.Generic;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>Plain polygon helpers (vertex lists, metres).</summary>
    public static class Polygon2
    {
        /// <summary>Shoelace area: positive when counter-clockwise.</summary>
        public static double SignedArea(IReadOnlyList<Vec2> p)
        {
            double a = 0;
            for (int i = 0; i < p.Count; i++)
            {
                Vec2 q = p[(i + 1) % p.Count];
                a += p[i].X * q.Y - q.X * p[i].Y;
            }
            return a / 2;
        }

        public static double Area(IReadOnlyList<Vec2> p) => Math.Abs(SignedArea(p));

        /// <summary>Vertex average — good enough for labels and tag points on convex pieces.</summary>
        public static Vec2 VertexCentroid(IReadOnlyList<Vec2> p)
        {
            double x = 0, y = 0;
            foreach (Vec2 v in p) { x += v.X; y += v.Y; }
            return new Vec2(x / p.Count, y / p.Count);
        }

        public static BoundingBox2 Bounds(IReadOnlyList<Vec2> p)
        {
            double minX = double.MaxValue, minY = double.MaxValue, maxX = double.MinValue, maxY = double.MinValue;
            foreach (Vec2 v in p)
            {
                minX = Math.Min(minX, v.X); minY = Math.Min(minY, v.Y);
                maxX = Math.Max(maxX, v.X); maxY = Math.Max(maxY, v.Y);
            }
            return new BoundingBox2(minX, minY, maxX, maxY);
        }

        /// <summary>Point-in-convex-polygon (either orientation), boundary counts as inside.</summary>
        public static bool ContainsConvex(IReadOnlyList<Vec2> p, Vec2 pt)
        {
            int sign = 0;
            for (int i = 0; i < p.Count; i++)
            {
                Vec2 a = p[i], b = p[(i + 1) % p.Count];
                double c = (b - a).Cross(pt - a);
                if (Math.Abs(c) < 1e-12) continue;
                int s = c > 0 ? 1 : -1;
                if (sign == 0) sign = s;
                else if (s != sign) return false;
            }
            return true;
        }
    }
}
