namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    // Usings inside the namespace so Revit's View/Color win over WinForms/System.Drawing global usings.
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Autodesk.Revit.DB;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

    /// <summary>Creates "EPS Layout - &lt;Level&gt;" and colours each board by its 10 mm thickness band. Call inside a transaction.</summary>
    public static class PlanViewService
    {
        public static ViewPlan CreateView(Document doc, ElementId levelId, string levelName, double boardBaseZFeet, List<EpsLogMessage> log)
        {
            ViewFamilyType planType = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewFamilyType))
                .Cast<ViewFamilyType>()
                .FirstOrDefault(t => t.ViewFamily == ViewFamily.FloorPlan)
                ?? throw new InvalidOperationException("The model has no Floor Plan view type.");

            ViewPlan view = ViewPlan.Create(doc, planType.Id, levelId);
            if (view.ViewTemplateId != ElementId.InvalidElementId)
                view.ViewTemplateId = ElementId.InvalidElementId; // a template could lock the view range
            view.Name = UniqueViewName(doc, $"EPS Layout - {levelName}");

            if (doc.GetElement(levelId) is Level level)
            {
                try { SetViewRange(view, levelId, boardBaseZFeet - level.Elevation); }
                catch (Exception ex)
                {
                    log.Add(EpsLogMessage.Now(EpsLogLevel.Warning, $"View range left at the default ({ex.Message}). Boards may be hidden if the roof is far above its level."));
                }
            }
            return view;
        }

        public static void ColourByThickness(Document doc, View view, IReadOnlyList<PlacedBoard> boards, LayoutResult layout, List<EpsLogMessage> log)
        {
            FillPatternElement solid = new FilteredElementCollector(doc)
                .OfClass(typeof(FillPatternElement))
                .Cast<FillPatternElement>()
                .FirstOrDefault(f => f.GetFillPattern().IsSolidFill);

            if (solid == null)
            {
                log.Add(EpsLogMessage.Now(EpsLogLevel.Warning, "No solid fill pattern in the model — boards were not colour-coded."));
                return;
            }

            var bands = new ThicknessBands(layout.MinThickness, layout.MaxThickness);
            foreach (PlacedBoard b in boards)
            {
                BandColor c = bands.ColorFor(b.Piece.MaxHeight);
                var color = new Autodesk.Revit.DB.Color(c.R, c.G, c.B);
                var ogs = new OverrideGraphicSettings();
                ogs.SetSurfaceForegroundPatternId(solid.Id);
                ogs.SetSurfaceForegroundPatternColor(color);
                ogs.SetCutForegroundPatternId(solid.Id);
                ogs.SetCutForegroundPatternColor(color);
                view.SetElementOverrides(b.ElementId, ogs);
            }
        }

        /// <summary>Cut plane 1.2 m above the board base, so the boards always show in projection.</summary>
        private static void SetViewRange(ViewPlan view, ElementId levelId, double baseAboveLevelFeet)
        {
            PlanViewRange range = view.GetViewRange();
            double top = baseAboveLevelFeet + RevitUnits.MillimetresToFeet(2000);
            double cut = baseAboveLevelFeet + RevitUnits.MillimetresToFeet(1200);
            double bottom = baseAboveLevelFeet - RevitUnits.MillimetresToFeet(300);

            foreach (PlanViewPlane plane in new[] { PlanViewPlane.TopClipPlane, PlanViewPlane.CutPlane, PlanViewPlane.BottomClipPlane, PlanViewPlane.ViewDepthPlane })
                range.SetLevelId(plane, levelId);

            range.SetOffset(PlanViewPlane.TopClipPlane, top);
            range.SetOffset(PlanViewPlane.CutPlane, cut);
            range.SetOffset(PlanViewPlane.BottomClipPlane, bottom);
            range.SetOffset(PlanViewPlane.ViewDepthPlane, bottom);
            view.SetViewRange(range);
        }

        private static string UniqueViewName(Document doc, string baseName)
        {
            var taken = new HashSet<string>(new FilteredElementCollector(doc)
                .OfClass(typeof(View))
                .Cast<View>()
                .Where(v => !v.IsTemplate)
                .Select(v => v.Name), StringComparer.OrdinalIgnoreCase);

            if (!taken.Contains(baseName)) return baseName;
            for (int i = 2; ; i++)
            {
                string name = $"{baseName} ({i})";
                if (!taken.Contains(name)) return name;
            }
        }
    }
}
