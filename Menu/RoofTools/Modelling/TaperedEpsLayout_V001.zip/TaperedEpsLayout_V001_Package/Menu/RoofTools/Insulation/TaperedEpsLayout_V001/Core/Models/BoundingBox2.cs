namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    public readonly record struct BoundingBox2(double MinX, double MinY, double MaxX, double MaxY)
    {
        public double Width => MaxX - MinX;
        public double Height => MaxY - MinY;
        public Vec2 Centre => new Vec2((MinX + MaxX) / 2, (MinY + MaxY) / 2);
    }
}
