using System.Collections.Generic;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>
    /// The picked roof/floor as plain data: top-face outline in metres (project XY) and its elevation.
    /// Revit ids are stored as their long values so Core stays Revit-free.
    /// </summary>
    public sealed class RoofBoundary
    {
        public RoofBoundary(IReadOnlyList<Vec2> polygon, double topElevationM, string elementLabel,
                            long elementIdValue, string levelName, long levelIdValue)
        {
            Polygon = polygon;
            TopElevationM = topElevationM;
            ElementLabel = elementLabel;
            ElementIdValue = elementIdValue;
            LevelName = levelName;
            LevelIdValue = levelIdValue;
        }

        public IReadOnlyList<Vec2> Polygon { get; }
        public double TopElevationM { get; }
        public string ElementLabel { get; }
        public long ElementIdValue { get; }
        public string LevelName { get; }
        public long LevelIdValue { get; }
    }
}
