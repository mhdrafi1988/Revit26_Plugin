using System.Collections.Generic;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>
    /// The EPS shared parameters. Thicknesses, area and volume use Length / Area / Volume specs so they
    /// display in the project's units (mm, m², m³ in a metric template) and schedule correctly.
    /// </summary>
    public static class EpsParameters
    {
        public const string Id = "EPS_ID";
        public const string Code = "EPS_Code";
        public const string Hand = "EPS_Hand";
        public const string Area = "EPS_Area";
        public const string Volume = "EPS_Volume";
        public const int CornerSlots = 8;

        public static string Corner(int oneBased) => "EPS_H" + oneBased;

        public static readonly IReadOnlyList<EpsParameterDefinition> All = new List<EpsParameterDefinition>
        {
            new EpsParameterDefinition(Id,     SpecTypeId.String.Text, "dc355f09-9905-51fd-86cd-f75d47a41a25", "Board piece ID, e.g. A01a"),
            new EpsParameterDefinition(Code,   SpecTypeId.String.Text, "89e71c9b-a167-598e-8242-bcd3a6641b86", "Board code, e.g. F01, E03, H02"),
            new EpsParameterDefinition(Hand,   SpecTypeId.String.Text, "a5b08db9-cec8-5bdc-be56-e03bac1c7c11", "S symmetric, L / R mirrored hands"),
            new EpsParameterDefinition(Corner(1), SpecTypeId.Length, "43962e0c-2f7a-593d-8d29-4da30618f3c1", "Thickness at corner 1"),
            new EpsParameterDefinition(Corner(2), SpecTypeId.Length, "0889b350-2813-504d-982e-aef6f2882cc6", "Thickness at corner 2"),
            new EpsParameterDefinition(Corner(3), SpecTypeId.Length, "398323cc-932c-5e59-b72c-9945ec77a0a4", "Thickness at corner 3"),
            new EpsParameterDefinition(Corner(4), SpecTypeId.Length, "f7c87cb9-2016-5df4-a676-ab0a71083b30", "Thickness at corner 4"),
            new EpsParameterDefinition(Corner(5), SpecTypeId.Length, "6e3a6702-2bda-5280-8a1e-59bf2c1204ea", "Thickness at corner 5"),
            new EpsParameterDefinition(Corner(6), SpecTypeId.Length, "1a9a0651-7466-555d-ae1d-e2c3a85bc82c", "Thickness at corner 6"),
            new EpsParameterDefinition(Corner(7), SpecTypeId.Length, "c4641ff4-f6d2-5991-9392-c730400505df", "Thickness at corner 7"),
            new EpsParameterDefinition(Corner(8), SpecTypeId.Length, "dbfdb029-4daa-54c4-965f-5f75f8f82911", "Thickness at corner 8"),
            new EpsParameterDefinition(Area,   SpecTypeId.Area,   "0ef10b11-d0ab-59d3-982a-1c4fad7f2334", "Plan area of the piece"),
            new EpsParameterDefinition(Volume, SpecTypeId.Volume, "e51834a6-15ff-5f7c-9839-7884040b3378", "EPS volume of the piece"),
        };
    }
}
