using System;
using System.Collections.Generic;
using System.IO;
using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using RevitApplication = Autodesk.Revit.ApplicationServices.Application;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>
    /// Binds the EPS_* shared parameters to Generic Models (instance). Uses the tool's own shared parameter
    /// file in %AppData%\SloperPro and puts the user's file setting back afterwards. Call inside a transaction.
    /// </summary>
    public static class SharedParameterSetup
    {
        private const string GroupName = "Tapered EPS";

        public static string SharedParameterFilePath =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         "SloperPro", "TaperedEps_SharedParameters.txt");

        /// <returns>True when every EPS parameter is bound (new or existing).</returns>
        public static bool Ensure(Document doc, RevitApplication app, List<EpsLogMessage> log)
        {
            var missing = new List<EpsParameterDefinition>();
            foreach (EpsParameterDefinition p in EpsParameters.All)
                if (!IsBound(doc, p.Name)) missing.Add(p);

            if (missing.Count == 0)
            {
                log.Add(EpsLogMessage.Now(EpsLogLevel.Info, "EPS shared parameters already bound to Generic Models."));
                return true;
            }

            string original = app.SharedParametersFilename;
            try
            {
                string path = SharedParameterFilePath;
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                if (!File.Exists(path)) File.WriteAllText(path, string.Empty);

                app.SharedParametersFilename = path;
                DefinitionFile file = app.OpenSharedParameterFile();
                if (file == null)
                    throw new InvalidOperationException($"Could not open the shared parameter file {path}.");

                DefinitionGroup group = file.Groups.get_Item(GroupName) ?? file.Groups.Create(GroupName);

                CategorySet categories = app.Create.NewCategorySet();
                categories.Insert(Category.GetCategory(doc, BuiltInCategory.OST_GenericModel));

                int bound = 0;
                foreach (EpsParameterDefinition p in missing)
                {
                    Definition def = group.Definitions.get_Item(p.Name);
                    if (def == null)
                    {
                        var options = new ExternalDefinitionCreationOptions(p.Name, p.Spec)
                        {
                            GUID = p.Guid,
                            Description = p.Description,
                            UserModifiable = true
                        };
                        def = group.Definitions.Create(options);
                    }

                    InstanceBinding binding = app.Create.NewInstanceBinding(categories);
                    if (doc.ParameterBindings.Insert(def, binding, GroupTypeId.Data)) bound++;
                    else log.Add(EpsLogMessage.Now(EpsLogLevel.Warning, $"Could not bind {p.Name} to Generic Models."));
                }

                log.Add(EpsLogMessage.Now(EpsLogLevel.Info, $"Bound {bound} EPS shared parameter(s) to Generic Models."));
                return bound == missing.Count;
            }
            finally
            {
                try { app.SharedParametersFilename = original ?? string.Empty; }
                catch { /* the user's file may have moved; leaving ours set is harmless */ }
            }
        }

        private static bool IsBound(Document doc, string name)
        {
            DefinitionBindingMapIterator it = doc.ParameterBindings.ForwardIterator();
            while (it.MoveNext())
                if (it.Key != null && it.Key.Name == name) return true;
            return false;
        }
    }
}
