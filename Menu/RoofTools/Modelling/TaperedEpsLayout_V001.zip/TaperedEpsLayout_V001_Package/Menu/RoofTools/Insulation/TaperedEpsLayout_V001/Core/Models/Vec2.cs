using System;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>2D point / vector in metres (plan).</summary>
    public readonly record struct Vec2(double X, double Y)
    {
        public static Vec2 operator +(Vec2 a, Vec2 b) => new Vec2(a.X + b.X, a.Y + b.Y);
        public static Vec2 operator -(Vec2 a, Vec2 b) => new Vec2(a.X - b.X, a.Y - b.Y);
        public static Vec2 operator *(Vec2 a, double k) => new Vec2(a.X * k, a.Y * k);

        public double Length => Math.Sqrt(X * X + Y * Y);
        public double Dot(Vec2 o) => X * o.X + Y * o.Y;
        public double Cross(Vec2 o) => X * o.Y - Y * o.X;

        /// <summary>Rotates counter-clockwise about the origin.</summary>
        public Vec2 Rotate(double angleRad)
        {
            double c = Math.Cos(angleRad), s = Math.Sin(angleRad);
            return new Vec2(X * c - Y * s, X * s + Y * c);
        }
    }
}
