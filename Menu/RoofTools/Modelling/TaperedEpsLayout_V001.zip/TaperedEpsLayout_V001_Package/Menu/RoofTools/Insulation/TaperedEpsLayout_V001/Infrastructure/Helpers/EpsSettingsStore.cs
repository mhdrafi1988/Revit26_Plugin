using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Helpers
{
    /// <summary>Last-used inputs as JSON in %AppData%\SloperPro. Load falls back to defaults on any failure (repo convention).</summary>
    public static class EpsSettingsStore
    {
        private static readonly JsonSerializerOptions Options = new JsonSerializerOptions
        {
            WriteIndented = true,
            Converters = { new JsonStringEnumConverter() }
        };

        public static string FilePath =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                         "SloperPro", "TaperedEpsLayout_V001.settings.json");

        public static EpsUserSettings Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return new EpsUserSettings();
                return JsonSerializer.Deserialize<EpsUserSettings>(File.ReadAllText(FilePath), Options) ?? new EpsUserSettings();
            }
            catch
            {
                return new EpsUserSettings();
            }
        }

        public static bool Save(EpsUserSettings settings)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, Options));
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
