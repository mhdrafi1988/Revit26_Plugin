namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    public enum GridOrigin
    {
        BoundingBoxCorner = 0,
        CentredOnShape = 1
    }
}
