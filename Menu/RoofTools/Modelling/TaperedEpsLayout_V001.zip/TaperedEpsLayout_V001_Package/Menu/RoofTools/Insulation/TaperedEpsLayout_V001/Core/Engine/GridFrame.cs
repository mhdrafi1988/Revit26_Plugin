using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>Rotation between project XY and the board-grid frame (grid X runs along the chosen direction).</summary>
    public sealed class GridFrame
    {
        public GridFrame(double angleRad) => Angle = angleRad;

        public double Angle { get; }

        public Vec2 ToGrid(Vec2 world) => world.Rotate(-Angle);
        public Vec2 ToWorld(Vec2 grid) => grid.Rotate(Angle);

        public List<Vec2> ToGrid(IEnumerable<Vec2> world) => world.Select(ToGrid).ToList();
        public List<Vec2> ToWorld(IEnumerable<Vec2> grid) => grid.Select(ToWorld).ToList();

        /// <summary>Longest edge wins; a tie keeps the first edge in counter-clockwise order.</summary>
        public static double FindAngle(IReadOnlyList<Vec2> ccwPolygon, GridDirection direction)
        {
            if (direction == GridDirection.ProjectXAxis) return 0;

            double angle = 0, longest = -1;
            int n = ccwPolygon.Count;
            for (int i = 0; i < n; i++)
            {
                Vec2 d = ccwPolygon[(i + 1) % n] - ccwPolygon[i];
                double len = d.Length;
                if (len > longest + 1e-9)
                {
                    longest = len;
                    angle = System.Math.Atan2(d.Y, d.X);
                }
            }
            return angle;
        }
    }
}
