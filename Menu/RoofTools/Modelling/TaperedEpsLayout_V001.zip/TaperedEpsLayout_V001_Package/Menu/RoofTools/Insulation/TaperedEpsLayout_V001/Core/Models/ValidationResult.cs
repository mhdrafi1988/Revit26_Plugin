using System.Collections.Generic;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    public sealed class ValidationResult
    {
        private ValidationResult(bool isValid, string message, IReadOnlyList<Vec2> polygon)
        {
            IsValid = isValid;
            Message = message;
            Polygon = polygon;
        }

        public bool IsValid { get; }
        public string Message { get; }

        /// <summary>Cleaned, counter-clockwise outline (only when valid).</summary>
        public IReadOnlyList<Vec2> Polygon { get; }

        public static ValidationResult Ok(IReadOnlyList<Vec2> polygon) => new ValidationResult(true, string.Empty, polygon);
        public static ValidationResult Fail(string message) => new ValidationResult(false, message, null);
    }
}
