namespace Revit26_Plugin.TaperedEpsLayout.V001.UI.Views
{
    // Usings inside the namespace so WPF Point/Color/Brush win over any WinForms/System.Drawing global usings.
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Controls.Primitives;
    using System.Windows.Input;
    using System.Windows.Media;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

    /// <summary>
    /// Live 2D plan of the board layout, coloured by 10 mm thickness band (same palette as the Revit plan view).
    /// Skipped codes are drawn neutral, the focused code is emphasised, and hovering a board shows its details.
    /// Drawn in OnRender (one StreamGeometry per board) so large layouts stay responsive.
    /// </summary>
    public sealed class LayoutPreviewControl : FrameworkElement
    {
        private const double Pad = 14;

        public static readonly DependencyProperty LayoutProperty = Register(nameof(Layout), typeof(LayoutResult), null);
        public static readonly DependencyProperty SkippedCodesProperty = Register(nameof(SkippedCodes), typeof(IReadOnlyCollection<string>), null);
        public static readonly DependencyProperty FocusCodeProperty = Register(nameof(FocusCode), typeof(string), null);
        public static readonly DependencyProperty LabelModeProperty = Register(nameof(LabelMode), typeof(int), 0);
        public static readonly DependencyProperty PiecePrefixProperty = Register(nameof(PiecePrefix), typeof(string), "EPS");

        private readonly ToolTip _tip = new ToolTip { Placement = PlacementMode.Mouse };
        private BoardPiece _hovered;
        private double _scale, _offsetX, _offsetY;
        private BoundingBox2 _bounds;

        public LayoutPreviewControl()
        {
            _tip.PlacementTarget = this;
            ClipToBounds = true;
            SnapsToDevicePixels = true;
        }

        public LayoutResult Layout { get => (LayoutResult)GetValue(LayoutProperty); set => SetValue(LayoutProperty, value); }
        public IReadOnlyCollection<string> SkippedCodes { get => (IReadOnlyCollection<string>)GetValue(SkippedCodesProperty); set => SetValue(SkippedCodesProperty, value); }
        public string FocusCode { get => (string)GetValue(FocusCodeProperty); set => SetValue(FocusCodeProperty, value); }

        /// <summary>0 = piece ID, 1 = board code, 2 = no labels.</summary>
        public int LabelMode { get => (int)GetValue(LabelModeProperty); set => SetValue(LabelModeProperty, value); }

        public string PiecePrefix { get => (string)GetValue(PiecePrefixProperty); set => SetValue(PiecePrefixProperty, value); }

        private static DependencyProperty Register(string name, Type type, object defaultValue) =>
            DependencyProperty.Register(name, type, typeof(LayoutPreviewControl),
                new FrameworkPropertyMetadata(defaultValue, FrameworkPropertyMetadataOptions.AffectsRender));

        protected override void OnRender(DrawingContext dc)
        {
            var area = new Rect(RenderSize);
            dc.DrawRectangle(ResourceBrush("BrushCardBackground", Brushes.White), null, area);

            LayoutResult r = Layout;
            if (r == null || !r.IsValid || r.Pieces.Count == 0)
            {
                string msg = r == null ? "Select a roof to see the board layout." : r.Message;
                DrawCentredText(dc, msg, area, r == null ? ResourceBrush("BrushDetailMutedText", Brushes.Gray) : ResourceBrush("BrushDanger", Brushes.Firebrick));
                return;
            }

            _bounds = Polygon2.Bounds(r.Polygon);
            _scale = Math.Min((area.Width - 2 * Pad) / Math.Max(_bounds.Width, 1e-6), (area.Height - 2 * Pad) / Math.Max(_bounds.Height, 1e-6));
            if (_scale <= 0) return;
            _offsetX = (area.Width - _bounds.Width * _scale) / 2;
            _offsetY = (area.Height - _bounds.Height * _scale) / 2;

            var bands = new ThicknessBands(r.MinThickness, r.MaxThickness);
            var bandBrushes = new Brush[bands.Count];
            for (int i = 0; i < bands.Count; i++)
            {
                BandColor c = bands.ColorOf(i);
                var b = new SolidColorBrush(Color.FromRgb(c.R, c.G, c.B));
                b.Freeze();
                bandBrushes[i] = b;
            }

            Brush skippedBrush = ResourceBrush("BrushTintInfo", Brushes.Gainsboro);
            var seamPen = new Pen(ResourceBrush("BrushCardBackground", Brushes.White), 0.8); seamPen.Freeze();
            var outlinePen = new Pen(ResourceBrush("BrushNavyPrimary", Brushes.SteelBlue), 2.0); outlinePen.Freeze();
            var hoverPen = new Pen(ResourceBrush("BrushNavyPrimary", Brushes.SteelBlue), 2.0); hoverPen.Freeze();

            IReadOnlyCollection<string> skipped = SkippedCodes ?? Array.Empty<string>();
            string focus = FocusCode;
            double cellPx = Math.Min(r.Settings.BoardWidth, r.Settings.BoardLength) * _scale;
            bool labels = LabelMode != 2 && cellPx >= 22;
            double fontSize = Math.Max(7, Math.Min(12, cellPx * 0.24));
            double dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;

            foreach (BoardPiece p in r.Pieces)
            {
                bool isSkipped = skipped.Contains(p.Code);
                bool dim = focus != null && focus != p.Code;
                if (dim) dc.PushOpacity(0.22);

                Brush fill = isSkipped ? skippedBrush : bandBrushes[bands.IndexOf(p.MaxHeight)];
                dc.DrawGeometry(fill, seamPen, ScreenShape(p.Vertices));

                if (labels && p.Area * _scale * _scale > cellPx * cellPx * 0.18)
                {
                    string text = LabelMode == 1 ? p.Code + (p.Hand == PieceHand.S ? string.Empty : p.HandText) : p.Id;
                    Brush ink = isSkipped || bandBrushes.Length == 0
                        ? ResourceBrush("BrushDetailMutedText", Brushes.DimGray)
                        : (bands.ColorFor(p.MaxHeight).Luminance < 0.45 ? Brushes.White : Brushes.Black);
                    var ft = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                                               new Typeface("Segoe UI"), p.Type == PieceType.Hip ? fontSize * 0.8 : fontSize, ink, dpi);
                    Point c = ToScreen(Polygon2.VertexCentroid(p.Vertices));
                    dc.DrawText(ft, new Point(c.X - ft.Width / 2, c.Y - ft.Height / 2));
                }

                if (dim) dc.Pop();
            }

            dc.DrawGeometry(null, outlinePen, ScreenShape(r.Polygon));
            if (_hovered != null && r.Pieces.Contains(_hovered)) dc.DrawGeometry(null, hoverPen, ScreenShape(_hovered.Vertices));
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            LayoutResult r = Layout;
            if (r == null || !r.IsValid || _scale <= 0) { HideTip(); return; }

            Vec2 world = ToWorld(e.GetPosition(this));
            BoardPiece hit = r.Pieces.FirstOrDefault(p => Polygon2.ContainsConvex(p.Vertices, world));
            if (hit == _hovered) return;

            _hovered = hit;
            InvalidateVisual();
            if (hit == null) { HideTip(); return; }

            bool isSkipped = (SkippedCodes ?? Array.Empty<string>()).Contains(hit.Code);
            string heights = string.Join("  ", hit.Heights.Select((h, i) => $"H{i + 1} {h:0.0}"));
            _tip.Content =
                $"{PiecePrefix}-{hit.Id} · {hit.Code} {hit.HandText}{(isSkipped ? " · skipped" : string.Empty)}\n" +
                $"{hit.Type} · {hit.Area:0.000} m² · {hit.Volume:0.0000} m³\n" +
                $"{heights} mm";
            _tip.IsOpen = false;
            _tip.IsOpen = true;
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            _hovered = null;
            HideTip();
            InvalidateVisual();
        }

        private void HideTip() => _tip.IsOpen = false;

        private Point ToScreen(Vec2 v) =>
            new Point(_offsetX + (v.X - _bounds.MinX) * _scale, _offsetY + (_bounds.MaxY - v.Y) * _scale);

        private Vec2 ToWorld(Point p) =>
            new Vec2((p.X - _offsetX) / _scale + _bounds.MinX, _bounds.MaxY - (p.Y - _offsetY) / _scale);

        private StreamGeometry ScreenShape(IReadOnlyList<Vec2> vertices)
        {
            var g = new StreamGeometry();
            using (StreamGeometryContext ctx = g.Open())
            {
                ctx.BeginFigure(ToScreen(vertices[0]), true, true);
                for (int i = 1; i < vertices.Count; i++) ctx.LineTo(ToScreen(vertices[i]), true, true);
            }
            g.Freeze();
            return g;
        }

        private void DrawCentredText(DrawingContext dc, string text, Rect area, Brush brush)
        {
            var ft = new FormattedText(text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                                       new Typeface("Segoe UI"), 13, brush, VisualTreeHelper.GetDpi(this).PixelsPerDip)
            {
                MaxTextWidth = Math.Max(50, area.Width - 40),
                TextAlignment = TextAlignment.Center
            };
            dc.DrawText(ft, new Point(20, (area.Height - ft.Height) / 2));
        }

        /// <summary>SharedStyles brush if present; the fallback only keeps the preview readable if a key is renamed.</summary>
        private Brush ResourceBrush(string key, Brush fallback) => TryFindResource(key) as Brush ?? fallback;
    }
}
