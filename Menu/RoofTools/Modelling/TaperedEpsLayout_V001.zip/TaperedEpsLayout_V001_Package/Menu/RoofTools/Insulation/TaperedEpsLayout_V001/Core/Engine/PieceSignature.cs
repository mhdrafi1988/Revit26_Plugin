using System;
using System.Collections.Generic;
using System.Globalization;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// Shape signature for grouping boards into codes. Each corner contributes (thickness, length of the
    /// outgoing edge, cosine of the interior angle), rounded to 0.1 mm / 1 mm / 1e-4. Pieces are convex,
    /// so the cosine identifies the angle. The minimum cyclic rotation removes the starting corner; reading
    /// the corners in reverse gives the mirror image. Equal forward/reverse minima → symmetric (S);
    /// otherwise the piece whose forward reading is the smaller one is L, its mirror R.
    /// </summary>
    public static class PieceSignature
    {
        public static (string Key, PieceHand Hand) Compute(IReadOnlyList<Vec2> ccwVertices, IReadOnlyList<double> heights)
        {
            string forward = MinRotation(Sequence(ccwVertices, heights));

            var rv = new List<Vec2>(ccwVertices); rv.Reverse();
            var rh = new List<double>(heights); rh.Reverse();
            string reverse = MinRotation(Sequence(rv, rh));

            int cmp = string.CompareOrdinal(forward, reverse);
            PieceHand hand = cmp == 0 ? PieceHand.S : (cmp < 0 ? PieceHand.L : PieceHand.R);
            return (cmp <= 0 ? forward : reverse, hand);
        }

        private static List<string> Sequence(IReadOnlyList<Vec2> v, IReadOnlyList<double> h)
        {
            int n = v.Count;
            var output = new List<string>(n);
            for (int i = 0; i < n; i++)
            {
                Vec2 prev = v[(i - 1 + n) % n], cur = v[i], next = v[(i + 1) % n];
                Vec2 u = prev - cur, w = next - cur;
                double cos = u.Dot(w) / (u.Length * w.Length);
                output.Add($"{Fx(h[i], 1)}|{Fx(w.Length, 3)}|{Fx(cos, 4)}");
            }
            return output;
        }

        private static string MinRotation(List<string> seq)
        {
            string best = null;
            for (int i = 0; i < seq.Count; i++)
            {
                var parts = new List<string>(seq.Count);
                for (int k = 0; k < seq.Count; k++) parts.Add(seq[(i + k) % seq.Count]);
                string s = string.Join(";", parts);
                if (best == null || string.CompareOrdinal(s, best) < 0) best = s;
            }
            return best ?? string.Empty;
        }

        /// <summary>Fixed decimals, invariant culture, never "-0.0".</summary>
        private static string Fx(double value, int decimals)
        {
            string s = value.ToString("F" + decimals, CultureInfo.InvariantCulture);
            if (s.StartsWith("-", StringComparison.Ordinal) && s.TrimStart('-').Trim('0', '.').Length == 0)
                s = s.Substring(1);
            return s;
        }
    }
}
