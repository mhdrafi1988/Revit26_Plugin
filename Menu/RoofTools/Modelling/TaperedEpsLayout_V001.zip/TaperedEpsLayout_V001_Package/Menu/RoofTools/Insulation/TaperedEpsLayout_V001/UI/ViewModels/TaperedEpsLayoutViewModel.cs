namespace Revit26_Plugin.TaperedEpsLayout.V001.UI.ViewModels
{
    // Usings sit inside the namespace so WPF types win over any project-wide WinForms/System.Drawing global usings.
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Data;
    using System.Windows.Media;
    using System.Windows.Threading;
    using CommunityToolkit.Mvvm.ComponentModel;
    using CommunityToolkit.Mvvm.Input;
    using Microsoft.Win32;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
    using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Export;
    using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents;
    using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Helpers;
    using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit;

    /// <summary>
    /// Window state for Tapered EPS Layout. The layout engine runs off the UI thread on every committed input
    /// change; Revit work goes through EpsRevitBridge (ExternalEvent). No Revit API calls here.
    /// </summary>
    public partial class TaperedEpsLayoutViewModel : ObservableObject, IDisposable
    {
        public const string ToolTitle = "Tapered EPS Layout";
        public const string ToolVersion = "V001";
        private const int LargeLayoutWarning = 5000;
        private const string InvalidNameChars = "{}[]|;<>?`~\\:";

        private readonly EpsRevitBridge _bridge;
        private readonly string _modelTitle;
        private readonly Dispatcher _dispatcher;
        private readonly DispatcherTimer _debounce;
        private RoofBoundary _boundary;
        private int _computeSequence;
        private bool _suppressInputEvents;
        private bool _suppressRowEvents;
        private string _lastRunSummary;
        private bool _disposed;

        public TaperedEpsLayoutViewModel(EpsRevitBridge bridge, string modelTitle,
                                         IReadOnlyList<TagTypeOption> tagTypes, BoundaryReadResult preselected)
        {
            _bridge = bridge;
            _modelTitle = modelTitle ?? "Model";
            _dispatcher = Dispatcher.CurrentDispatcher;
            _debounce = new DispatcherTimer(DispatcherPriority.Background, _dispatcher) { Interval = TimeSpan.FromMilliseconds(250) };
            _debounce.Tick += (s, e) => RecomputeNow();

            Subtitle = $"Revit 2026 · Build {BuildDate()}";
            CodesView = CollectionViewSource.GetDefaultView(Codes);
            CodesView.Filter = PassesFilter;
            LogEntries.CollectionChanged += (s, e) => OnPropertyChanged(nameof(LogHeader));

            EpsUserSettings saved = EpsSettingsStore.Load();
            ApplyUserSettings(saved);
            SetTagTypes(tagTypes, saved.TagTypeLabel);

            Log(EpsLogLevel.Info, $"{ToolTitle} {ToolVersion} opened on “{_modelTitle}”.");
            if (preselected != null) ApplyBoundary(preselected);
            else Log(EpsLogLevel.Info, "Click Select Roof and pick a flat roof or floor slab.");
            UpdateRunState();
        }

        public event Action RequestClose;
        public event Action SelectionStarted;
        public event Action SelectionEnded;

        // ── Header ────────────────────────────────────────────────────────────
        public string Title => ToolTitle;
        public string Version => ToolVersion;
        public string Subtitle { get; }

        [ObservableProperty] private string boardsMetric = "—";
        [ObservableProperty] private string codesMetric = "—";
        [ObservableProperty] private string hipMetric = "—";
        [ObservableProperty] private string maxThicknessMetric = "—";
        [ObservableProperty] private string volumeMetric = "—";
        [ObservableProperty] private string roofAreaMetric = "—";

        // ── Shell footer status strip ────────────────────────────────────────
        [ObservableProperty]
        [NotifyCanExecuteChangedFor(nameof(SelectRoofCommand))]
        [NotifyCanExecuteChangedFor(nameof(ResetCommand))]
        [NotifyCanExecuteChangedFor(nameof(RefreshCommand))]
        private bool isRunning;

        [ObservableProperty] private double progress;
        [ObservableProperty] private string summaryText = "Select a roof to start";
        [ObservableProperty] private string runBlockReason = string.Empty;

        // ── Roof Selection ───────────────────────────────────────────────────
        [ObservableProperty] private bool hasRoof;
        [ObservableProperty] private string roofElement = "None selected";
        [ObservableProperty] private string roofLevel = "—";
        [ObservableProperty] private string roofEdges = "—";
        [ObservableProperty] private string roofTopFace = "—";
        [ObservableProperty] private bool shapeOk;
        [ObservableProperty] private string shapeMessage = "No roof selected";

        // ── Board Settings ───────────────────────────────────────────────────
        [ObservableProperty] private string boardWidthText = "1.00";
        [ObservableProperty] private string boardLengthText = "1.00";
        [ObservableProperty] private string slopeText = "1.0";
        [ObservableProperty] private string minThicknessText = "20";
        [ObservableProperty] private string boardWidthError = string.Empty;
        [ObservableProperty] private string boardLengthError = string.Empty;
        [ObservableProperty] private string slopeError = string.Empty;
        [ObservableProperty] private string minThicknessError = string.Empty;
        [ObservableProperty] private int gridDirectionIndex;
        [ObservableProperty] private int gridOriginIndex;

        // ── Output Options ───────────────────────────────────────────────────
        [ObservableProperty] private bool create3DPieces = true;
        [ObservableProperty] private bool createPlanView = true;
        [ObservableProperty] private bool createExcel = true;
        [ObservableProperty] private TagTypeOption selectedTagType;
        [ObservableProperty] private bool tagWarningVisible;
        [ObservableProperty] private string piecePrefix = "EPS";
        [ObservableProperty] private string prefixError = string.Empty;
        public ObservableCollection<TagTypeOption> TagTypes { get; } = new ObservableCollection<TagTypeOption>();

        // ── Layout Preview ───────────────────────────────────────────────────
        [ObservableProperty] private LayoutResult layout;
        [ObservableProperty] private IReadOnlyCollection<string> skippedCodes = new HashSet<string>();
        [ObservableProperty] private string focusCode;
        [ObservableProperty] private int labelModeIndex;
        [ObservableProperty] private string previewCaption = string.Empty;
        public ObservableCollection<LegendItem> LegendItems { get; } = new ObservableCollection<LegendItem>();

        // ── Board Schedule ───────────────────────────────────────────────────
        public ObservableCollection<BoardCodeRowViewModel> Codes { get; } = new ObservableCollection<BoardCodeRowViewModel>();
        public ICollectionView CodesView { get; }
        [ObservableProperty] private string filterText = string.Empty;
        [ObservableProperty] private BoardCodeRowViewModel selectedCode;
        [ObservableProperty] private string scheduleSummary = string.Empty;

        // ── Log (collapsed by default, repo convention) ─────────────────────
        public ObservableCollection<EpsLogMessage> LogEntries { get; } = new ObservableCollection<EpsLogMessage>();
        [ObservableProperty] private bool isLogExpanded;
        public string LogHeader => $"Log ({LogEntries.Count})";

        // ── Input change hooks ───────────────────────────────────────────────
        partial void OnBoardWidthTextChanged(string value) => OnInputChanged();
        partial void OnBoardLengthTextChanged(string value) => OnInputChanged();
        partial void OnSlopeTextChanged(string value) => OnInputChanged();
        partial void OnMinThicknessTextChanged(string value) => OnInputChanged();
        partial void OnGridDirectionIndexChanged(int value) => OnInputChanged();
        partial void OnGridOriginIndexChanged(int value) => OnInputChanged();
        partial void OnPiecePrefixChanged(string value) { ValidatePrefix(); UpdateRunState(); }
        partial void OnCreate3DPiecesChanged(bool value) => UpdateRunState();
        partial void OnCreatePlanViewChanged(bool value) { UpdateTagWarning(); UpdateRunState(); }
        partial void OnCreateExcelChanged(bool value) => UpdateRunState();
        partial void OnSelectedTagTypeChanged(TagTypeOption value) => UpdateTagWarning();
        partial void OnFilterTextChanged(string value) { CodesView.Refresh(); UpdateScheduleSummary(); }
        partial void OnSelectedCodeChanged(BoardCodeRowViewModel value) => FocusCode = value?.Code;

        private void OnInputChanged()
        {
            if (_suppressInputEvents) return;
            ValidateInputs(commit: true);
            _lastRunSummary = null;
            _debounce.Stop();
            _debounce.Start();
            UpdateRunState();
        }

        // ── Commands ─────────────────────────────────────────────────────────
        private bool CanSelectRoof() => !IsRunning;

        [RelayCommand(CanExecute = nameof(CanSelectRoof))]
        private void SelectRoof()
        {
            SelectionStarted?.Invoke();
            bool raised = _bridge.RequestSelection(
                outcome => _dispatcher.BeginInvoke(new Action(() => OnSelectionFinished(outcome))),
                out string error);
            if (!raised)
            {
                SelectionEnded?.Invoke();
                Log(EpsLogLevel.Error, error);
            }
        }

        private bool CanRun() => string.IsNullOrEmpty(ComputeRunBlockReason());

        [RelayCommand(CanExecute = nameof(CanRun))]
        private void Run()
        {
            LayoutResult layoutAtRun = Layout;
            HashSet<string> placedCodes = Codes.Where(c => c.IsChecked).Select(c => c.Code).ToHashSet();
            List<BoardPiece> toPlace = layoutAtRun.Pieces.Where(p => placedCodes.Contains(p.Code)).ToList();
            int skipped = layoutAtRun.Pieces.Count - toPlace.Count;
            string prefix = PiecePrefix.Trim();
            bool revitWork = Create3DPieces || CreatePlanView;

            if (Create3DPieces && toPlace.Count > LargeLayoutWarning &&
                MessageBox.Show($"This creates {toPlace.Count:N0} board elements, which can take several minutes and make the model heavier. Continue?",
                                ToolTitle, MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            string excelPath = null;
            if (CreateExcel)
            {
                excelPath = AskExcelPath();
                if (excelPath == null) Log(EpsLogLevel.Warning, "Excel schedule skipped — no file chosen.");
            }
            if (!revitWork && excelPath == null) return;

            IsRunning = true;
            Progress = 0;
            SummaryText = "Running…";
            UpdateRunState();
            Log(EpsLogLevel.Info, $"Run started — {toPlace.Count} boards to place, {skipped} skipped.");

            if (!revitWork)
            {
                FinishRun(new RunOutcome { Skipped = skipped, Succeeded = true }, excelPath, layoutAtRun, placedCodes, prefix);
                return;
            }

            var request = new RunRequest
            {
                Boundary = _boundary,
                Layout = layoutAtRun,
                Pieces = toPlace,
                SkippedCount = skipped,
                Prefix = prefix,
                Create3DPieces = Create3DPieces,
                CreatePlanView = CreatePlanView,
                TagTypeIdValue = SelectedTagType?.IdValue ?? -1
            };

            bool raised = _bridge.RequestRun(request,
                outcome => _dispatcher.BeginInvoke(new Action(() => FinishRun(outcome, excelPath, layoutAtRun, placedCodes, prefix))),
                out string error);
            if (!raised)
            {
                Log(EpsLogLevel.Error, error);
                IsRunning = false;
                UpdateRunState();
            }
        }

        private bool CanReset() => !IsRunning;

        [RelayCommand(CanExecute = nameof(CanReset))]
        private void Reset()
        {
            ApplyUserSettings(new EpsUserSettings());
            FilterText = string.Empty;
            SetAllRows(Codes, true);
            Log(EpsLogLevel.Info, "Settings reset to defaults.");
            RecomputeNow();
        }

        private bool CanRefresh() => !IsRunning;

        [RelayCommand(CanExecute = nameof(CanRefresh))]
        private void Refresh() => RecomputeNow();

        [RelayCommand]
        private void Close() => RequestClose?.Invoke();

        [RelayCommand]
        private void SelectAllVisible() => SetAllRows(CodesView.Cast<BoardCodeRowViewModel>(), true);

        [RelayCommand]
        private void ClearVisible() => SetAllRows(CodesView.Cast<BoardCodeRowViewModel>(), false);

        // ── Selection ────────────────────────────────────────────────────────
        private void OnSelectionFinished(SelectionOutcome outcome)
        {
            SelectionEnded?.Invoke();
            if (outcome.Cancelled) { Log(EpsLogLevel.Info, "Selection cancelled."); return; }
            if (!string.IsNullOrEmpty(outcome.Error)) { Log(EpsLogLevel.Error, outcome.Error); return; }
            if (outcome.TagTypes != null) SetTagTypes(outcome.TagTypes, SelectedTagType?.Label);
            if (outcome.Read != null) ApplyBoundary(outcome.Read);
        }

        private void ApplyBoundary(BoundaryReadResult read)
        {
            if (!read.IsValid)
            {
                _boundary = null;
                HasRoof = false;
                RoofElement = string.IsNullOrEmpty(read.ElementLabel) ? "None selected" : read.ElementLabel;
                RoofLevel = RoofEdges = RoofTopFace = "—";
                ShapeOk = false;
                ShapeMessage = read.Error;
                Log(EpsLogLevel.Error, read.Error);
                ApplyLayout(null);
                return;
            }

            _boundary = read.Boundary;
            HasRoof = true;
            RoofElement = _boundary.ElementLabel;
            RoofLevel = _boundary.LevelName;
            RoofEdges = $"{_boundary.Polygon.Count} straight edges";
            RoofTopFace = $"{_boundary.TopElevationM:0.000} m";
            Log(EpsLogLevel.Info, $"Picked {_boundary.ElementLabel} on {_boundary.LevelName}.");
            _lastRunSummary = null;
            RecomputeNow();
        }

        // ── Layout ───────────────────────────────────────────────────────────
        private async void RecomputeNow()
        {
            _debounce.Stop();
            if (_boundary == null || HasInputErrors()) { UpdateRunState(); return; }

            LayoutSettings settings = CurrentSettings();
            IReadOnlyList<Vec2> outline = _boundary.Polygon;
            int sequence = ++_computeSequence;

            LayoutResult result;
            try { result = await Task.Run(() => LayoutEngine.Compute(outline, settings)).ConfigureAwait(false); }
            catch (Exception ex) { result = LayoutResult.Invalid("The layout could not be calculated: " + ex.Message); }

            await _dispatcher.InvokeAsync(() =>
            {
                if (sequence != _computeSequence || _disposed) return; // a newer input change superseded this run
                ApplyLayout(result);
            });
        }

        private void ApplyLayout(LayoutResult result)
        {
            Layout = result;

            var previouslySkipped = Codes.Where(c => !c.IsChecked).Select(c => c.Code).ToHashSet();
            bool sameCodes = result != null && result.IsValid && Codes.Select(c => c.Code).SequenceEqual(result.Codes.Select(c => c.Code));
            Codes.Clear();
            LegendItems.Clear();

            if (result == null || !result.IsValid)
            {
                BoardsMetric = CodesMetric = HipMetric = MaxThicknessMetric = VolumeMetric = RoofAreaMetric = "—";
                PreviewCaption = string.Empty;
                if (result != null)
                {
                    ShapeOk = false;
                    ShapeMessage = result.Message;
                    Log(EpsLogLevel.Error, result.Message);
                }
            }
            else
            {
                ShapeOk = true;
                ShapeMessage = "Convex · single loop · straight edges";
                RoofEdges = $"{result.Polygon.Count} straight edges";

                foreach (BoardCode code in result.Codes)
                    Codes.Add(new BoardCodeRowViewModel(code, !(sameCodes && previouslySkipped.Contains(code.Code)), OnRowCheckedChanged));

                BoardsMetric = result.Pieces.Count.ToString("N0");
                CodesMetric = result.Codes.Count.ToString("N0");
                HipMetric = result.HipCount.ToString("N0");
                MaxThicknessMetric = $"{result.MaxThickness:0.0} mm";
                VolumeMetric = $"{result.TotalVolume:0.000} m³";
                RoofAreaMetric = $"{result.RoofArea:0.00} m²";

                LayoutSettings s = result.Settings;
                PreviewCaption = $"{result.Columns} × {result.Rows} grid · {s.BoardWidth:0.00} × {s.BoardLength:0.00} m · {result.GridAngle * 180 / Math.PI:0.0}°";

                var bands = new ThicknessBands(result.MinThickness, result.MaxThickness);
                for (int i = 0; i < bands.Count; i++)
                {
                    BandColor c = bands.ColorOf(i);
                    var brush = new SolidColorBrush(Color.FromRgb(c.R, c.G, c.B));
                    brush.Freeze();
                    LegendItems.Add(new LegendItem(bands.Label(i), brush));
                }

                Log(EpsLogLevel.Info,
                    $"Layout: {result.Pieces.Count} boards, {result.Codes.Count} codes, {result.HipCount} hip pieces, " +
                    $"max {result.MaxThickness:0.0} mm, {result.TotalVolume:0.000} m³.");
            }

            RefreshSkipped();
            UpdateScheduleSummary();
            UpdateRunState();
        }

        private void OnRowCheckedChanged(BoardCodeRowViewModel row)
        {
            if (_suppressRowEvents) return;
            _lastRunSummary = null;
            RefreshSkipped();
            UpdateScheduleSummary();
            UpdateRunState();
        }

        private void SetAllRows(IEnumerable<BoardCodeRowViewModel> rows, bool value)
        {
            _suppressRowEvents = true;
            try { foreach (BoardCodeRowViewModel r in rows.ToList()) r.IsChecked = value; }
            finally { _suppressRowEvents = false; }
            OnRowCheckedChanged(null);
        }

        private void RefreshSkipped() =>
            SkippedCodes = Codes.Where(c => !c.IsChecked).Select(c => c.Code).ToHashSet();

        private bool PassesFilter(object item)
        {
            if (string.IsNullOrWhiteSpace(FilterText)) return true;
            return item is BoardCodeRowViewModel row &&
                   row.SearchText.IndexOf(FilterText.Trim(), StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void UpdateScheduleSummary()
        {
            if (Layout == null || !Layout.IsValid) { ScheduleSummary = string.Empty; return; }
            int visible = CodesView.Cast<object>().Count();
            int placedBoards = Codes.Where(c => c.IsChecked).Sum(c => c.Quantity);
            ScheduleSummary = $"Showing {visible} of {Codes.Count} codes · {placedBoards} of {Layout.Pieces.Count} boards will be placed";
        }

        // ── Run completion ───────────────────────────────────────────────────
        private void FinishRun(RunOutcome outcome, string excelPath, LayoutResult layoutAtRun, ISet<string> placedCodes, string prefix)
        {
            if (_disposed) return;
            foreach (EpsLogMessage m in outcome.Messages) LogEntries.Add(m);

            if (excelPath != null)
            {
                if (!outcome.Succeeded)
                {
                    Log(EpsLogLevel.Warning, "Excel schedule not written because the Revit run was rolled back.");
                }
                else
                {
                    try
                    {
                        ExcelExporter.Export(excelPath, layoutAtRun, placedCodes, prefix);
                        Log(EpsLogLevel.Success, $"Excel schedule saved: {excelPath}");
                    }
                    catch (IOException ex)
                    {
                        Log(EpsLogLevel.Error, $"Excel schedule not saved — close the file if it is open in Excel, then run again. ({ex.Message})");
                    }
                    catch (Exception ex)
                    {
                        Log(EpsLogLevel.Error, $"Excel schedule not saved: {ex.Message}");
                    }
                }
            }

            _lastRunSummary = $"{outcome.Placed} placed | {outcome.Skipped} skipped | {outcome.Failed} failed";
            Log(outcome.Succeeded ? EpsLogLevel.Success : EpsLogLevel.Error, $"Run finished — {_lastRunSummary}.");
            Progress = 100;
            IsRunning = false;
            UpdateRunState();
        }

        private string AskExcelPath()
        {
            string name = _modelTitle.EndsWith(".rvt", StringComparison.OrdinalIgnoreCase) ? _modelTitle[..^4] : _modelTitle;
            foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');

            var dialog = new SaveFileDialog
            {
                Title = "Save EPS schedule",
                Filter = "Excel workbook (*.xlsx)|*.xlsx",
                FileName = $"{name}_EPS_Schedule.xlsx",
                AddExtension = true,
                OverwritePrompt = true
            };
            return dialog.ShowDialog() == true ? dialog.FileName : null;
        }

        // ── Validation & run gating ──────────────────────────────────────────
        private void ValidateInputs(bool commit)
        {
            _suppressInputEvents = true;
            try
            {
                BoardWidthError = ValidateBoard(BoardWidthText, "width", commit, v => BoardWidthText = v);
                BoardLengthError = ValidateBoard(BoardLengthText, "length", commit, v => BoardLengthText = v);
                SlopeError = ValidateRange(SlopeText, LayoutSettings.MinSlope, LayoutSettings.MaxSlope, "%");
                MinThicknessError = ValidateRange(MinThicknessText, LayoutSettings.MinThickness, LayoutSettings.MaxThickness, "mm");
            }
            finally { _suppressInputEvents = false; }
            ValidatePrefix();
        }

        private string ValidateBoard(string text, string which, bool commit, Action<string> setText)
        {
            if (!TryParse(text, out double v)) return "Enter a number";
            if (v < LayoutSettings.MinBoard) return $"Minimum {LayoutSettings.MinBoard:0.00} m";
            if (v > LayoutSettings.MaxBoard)
            {
                if (commit)
                {
                    setText(LayoutSettings.MaxBoard.ToString("0.00", CultureInfo.InvariantCulture));
                    Log(EpsLogLevel.Warning, $"Board {which} {v:0.00} m is above the 1.00 m maximum — clamped to 1.00 m.");
                }
                return string.Empty;
            }
            return string.Empty;
        }

        private static string ValidateRange(string text, double min, double max, string unit)
        {
            if (!TryParse(text, out double v)) return "Enter a number";
            return v < min || v > max ? $"Enter a value from {min:0.##} to {max:0.##} {unit}" : string.Empty;
        }

        private void ValidatePrefix()
        {
            string p = PiecePrefix?.Trim() ?? string.Empty;
            PrefixError = p.Length == 0 ? "Enter a prefix"
                : p.IndexOfAny(InvalidNameChars.ToCharArray()) >= 0 ? "Remove { } [ ] | ; < > ? ` ~ \\ :"
                : string.Empty;
        }

        private bool HasInputErrors() =>
            !string.IsNullOrEmpty(BoardWidthError) || !string.IsNullOrEmpty(BoardLengthError) ||
            !string.IsNullOrEmpty(SlopeError) || !string.IsNullOrEmpty(MinThicknessError);

        private string ComputeRunBlockReason()
        {
            if (IsRunning) return "Running…";
            if (_boundary == null) return "Select a roof first";
            if (Layout == null || !Layout.IsValid) return "This roof shape is not supported";
            if (HasInputErrors() || !string.IsNullOrEmpty(PrefixError)) return "Fix the highlighted inputs";
            if (!Codes.Any(c => c.IsChecked)) return "Check at least one board code";
            if (!Create3DPieces && !CreatePlanView && !CreateExcel) return "Choose at least one output";
            return string.Empty;
        }

        private void UpdateRunState()
        {
            RunBlockReason = IsRunning ? string.Empty : ComputeRunBlockReason();
            RunCommand.NotifyCanExecuteChanged();
            if (IsRunning) return;

            if (_lastRunSummary != null) SummaryText = _lastRunSummary;
            else if (Layout != null && Layout.IsValid)
            {
                int toPlace = Codes.Where(c => c.IsChecked).Sum(c => c.Quantity);
                SummaryText = $"Ready — {toPlace} to place | {Layout.Pieces.Count - toPlace} skipped";
                Progress = 0;
            }
            else
            {
                SummaryText = _boundary == null ? "Select a roof to start" : "Waiting for a valid layout";
                Progress = 0;
            }
        }

        private void UpdateTagWarning() =>
            TagWarningVisible = CreatePlanView && (SelectedTagType == null || SelectedTagType.IsNone);

        // ── Settings ─────────────────────────────────────────────────────────
        private LayoutSettings CurrentSettings()
        {
            TryParse(BoardWidthText, out double bw);
            TryParse(BoardLengthText, out double bh);
            TryParse(SlopeText, out double slope);
            TryParse(MinThicknessText, out double tmin);
            return new LayoutSettings(bw, bh, slope, tmin, (GridDirection)GridDirectionIndex, (GridOrigin)GridOriginIndex);
        }

        private void ApplyUserSettings(EpsUserSettings s)
        {
            _suppressInputEvents = true;
            try
            {
                BoardWidthText = Format(Clamp(s.BoardWidth, LayoutSettings.MinBoard, LayoutSettings.MaxBoard), "0.00");
                BoardLengthText = Format(Clamp(s.BoardLength, LayoutSettings.MinBoard, LayoutSettings.MaxBoard), "0.00");
                SlopeText = Format(Clamp(s.SlopePercent, LayoutSettings.MinSlope, LayoutSettings.MaxSlope), "0.0#");
                MinThicknessText = Format(Clamp(s.MinThicknessMm, LayoutSettings.MinThickness, LayoutSettings.MaxThickness), "0.#");
                GridDirectionIndex = (int)s.Direction;
                GridOriginIndex = (int)s.Origin;
                PiecePrefix = string.IsNullOrWhiteSpace(s.PiecePrefix) ? "EPS" : s.PiecePrefix;
                Create3DPieces = s.Create3DPieces;
                CreatePlanView = s.CreatePlanView;
                CreateExcel = s.CreateExcel;
            }
            finally { _suppressInputEvents = false; }
            ValidateInputs(commit: false);
            UpdateTagWarning();
        }

        private EpsUserSettings ToUserSettings()
        {
            LayoutSettings d = LayoutSettings.Default;
            double Read(string text, double fallback) => TryParse(text, out double v) ? v : fallback;
            return new EpsUserSettings
            {
                BoardWidth = Read(BoardWidthText, d.BoardWidth),
                BoardLength = Read(BoardLengthText, d.BoardLength),
                SlopePercent = Read(SlopeText, d.SlopePercent),
                MinThicknessMm = Read(MinThicknessText, d.MinThicknessMm),
                Direction = (GridDirection)GridDirectionIndex,
                Origin = (GridOrigin)GridOriginIndex,
                PiecePrefix = string.IsNullOrEmpty(PrefixError) ? PiecePrefix.Trim() : "EPS",
                Create3DPieces = Create3DPieces,
                CreatePlanView = CreatePlanView,
                CreateExcel = CreateExcel,
                TagTypeLabel = SelectedTagType?.Label ?? string.Empty
            };
        }

        private void SetTagTypes(IReadOnlyList<TagTypeOption> options, string preferredLabel)
        {
            TagTypes.Clear();
            if (options == null || options.Count == 0) TagTypes.Add(TagTypeOption.None);
            else foreach (TagTypeOption o in options) TagTypes.Add(o);

            SelectedTagType = TagTypes.FirstOrDefault(t => t.Label == preferredLabel) ?? TagTypes[0];
            UpdateTagWarning();
        }

        // ── Helpers ──────────────────────────────────────────────────────────
        public void Log(EpsLogLevel level, string text)
        {
            if (!string.IsNullOrEmpty(text)) LogEntries.Add(EpsLogMessage.Now(level, text));
        }

        private static bool TryParse(string text, out double value) =>
            double.TryParse((text ?? string.Empty).Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value);

        private static string Format(double v, string format) => v.ToString(format, CultureInfo.InvariantCulture);

        private static double Clamp(double v, double min, double max) => Math.Max(min, Math.Min(max, v));

        private static string BuildDate()
        {
            try { return File.GetLastWriteTime(typeof(TaperedEpsLayoutViewModel).Assembly.Location).ToString("yyyy-MM-dd"); }
            catch { return "—"; }
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _debounce.Stop();
            EpsSettingsStore.Save(ToUserSettings());
            _bridge?.Dispose();
        }
    }
}
