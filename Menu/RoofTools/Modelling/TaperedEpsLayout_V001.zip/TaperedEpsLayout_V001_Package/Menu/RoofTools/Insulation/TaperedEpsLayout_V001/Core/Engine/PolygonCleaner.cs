using System;
using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>Removes duplicate and collinear vertices (default tolerance 1 mm).</summary>
    public static class PolygonCleaner
    {
        public const double DefaultTolerance = 1e-3;

        public static List<Vec2> Clean(IReadOnlyList<Vec2> polygon, double tolerance = DefaultTolerance)
        {
            var p = new List<Vec2>(polygon);
            bool changed = true;
            while (changed && p.Count >= 3)
            {
                changed = false;
                for (int i = 0; i < p.Count && p.Count >= 3; i++)
                {
                    Vec2 a = p[(i - 1 + p.Count) % p.Count], b = p[i], c = p[(i + 1) % p.Count];
                    if ((b - a).Length < tolerance) { p.RemoveAt(i); changed = true; break; }

                    Vec2 chord = c - a;
                    double len = chord.Length;
                    if (len < tolerance) continue;

                    // Perpendicular distance of b from chord a→c.
                    double d = Math.Abs(chord.Cross(b - a)) / len;
                    if (d < tolerance) { p.RemoveAt(i); changed = true; break; }
                }
            }
            return p;
        }
    }
}
