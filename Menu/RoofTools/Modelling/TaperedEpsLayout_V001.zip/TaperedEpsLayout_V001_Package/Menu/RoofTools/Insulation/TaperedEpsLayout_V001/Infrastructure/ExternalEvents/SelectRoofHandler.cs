using System;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents
{
    /// <summary>
    /// Picks one roof/floor and reads its outline. Instance state only (no statics) — one handler per window,
    /// created once by the command together with its ExternalEvent.
    /// </summary>
    public sealed class SelectRoofHandler : IExternalEventHandler
    {
        private readonly Document _document;
        private Action<SelectionOutcome> _callback;

        public SelectRoofHandler(Document document) => _document = document;

        /// <summary>Set by EpsRevitBridge just before Raise(); cleared when the handler runs.</summary>
        public void Prepare(Action<SelectionOutcome> callback) => _callback = callback;

        public void Execute(UIApplication app)
        {
            Action<SelectionOutcome> callback = _callback;
            _callback = null;
            var outcome = new SelectionOutcome();
            try
            {
                UIDocument uidoc = app.ActiveUIDocument;
                if (uidoc == null || !uidoc.Document.Equals(_document))
                {
                    outcome.Error = $"Switch back to “{_document.Title}” — this window works on that model.";
                    return;
                }

                Reference picked = uidoc.Selection.PickObject(ObjectType.Element, new RoofPickFilter(), "Pick a flat roof or floor slab");
                Element element = _document.GetElement(picked);
                outcome.Read = RoofBoundaryReader.Read(element);
                outcome.TagTypes = TagTypeProvider.GetGenericModelTagTypes(_document);
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                outcome.Cancelled = true;
            }
            catch (Exception ex)
            {
                outcome.Error = ex.Message;
            }
            finally
            {
                callback?.Invoke(outcome);
            }
        }

        public string GetName() => "Tapered EPS Layout V001 — Select Roof";
    }
}
