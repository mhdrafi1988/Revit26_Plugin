namespace Revit26_Plugin.TaperedEpsLayout.V001.UI.ViewModels
{
    /// <summary>One thickness band under the preview, e.g. "20–30" with its swatch.</summary>
    public sealed record LegendItem(string Label, System.Windows.Media.Brush Swatch);
}
