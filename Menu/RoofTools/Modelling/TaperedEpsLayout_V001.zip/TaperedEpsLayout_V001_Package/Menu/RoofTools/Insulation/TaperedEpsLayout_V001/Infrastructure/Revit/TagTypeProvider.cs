using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    public static class TagTypeProvider
    {
        /// <summary>Loaded Generic Model tag types, sorted by "Family : Type". Read-only; no transaction needed.</summary>
        public static List<TagTypeOption> GetGenericModelTagTypes(Document doc)
        {
            return new FilteredElementCollector(doc)
                .OfCategory(BuiltInCategory.OST_GenericModelTags)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .Select(s => new TagTypeOption(s.Id.Value, $"{s.FamilyName} : {s.Name}"))
                .OrderBy(o => o.Label)
                .ToList();
        }
    }
}
