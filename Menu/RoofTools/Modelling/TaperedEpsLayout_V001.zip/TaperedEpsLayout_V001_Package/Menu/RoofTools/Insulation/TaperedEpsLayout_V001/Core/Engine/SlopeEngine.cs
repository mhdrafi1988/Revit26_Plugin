using System;
using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// Thickness field H(p) = tmin + k · min_i Li(p), with Li the inward distance to edge i and
    /// k = slope % × 10 mm/m. Each edge governs one planar "slope face" (where its Li is the minimum),
    /// so the field is the inverted hip roof of the outline: tmin at the perimeter, highest at the ridge.
    /// </summary>
    public sealed class SlopeEngine
    {
        public SlopeEngine(IReadOnlyList<Vec2> ccwPolygon, double slopePercent, double minThicknessMm)
        {
            int n = ccwPolygon.Count;
            var lines = new EdgeLine[n];
            for (int i = 0; i < n; i++)
            {
                Vec2 a = ccwPolygon[i], b = ccwPolygon[(i + 1) % n];
                double len = (b - a).Length;
                // Inward normal of a CCW polygon is the edge direction rotated +90°.
                double nx = -(b.Y - a.Y) / len, ny = (b.X - a.X) / len;
                lines[i] = new EdgeLine(nx, ny, -(nx * a.X + ny * a.Y));
            }
            Edges = lines;
            RiseMmPerMetre = slopePercent * 10.0;
            MinThicknessMm = minThicknessMm;
        }

        public IReadOnlyList<EdgeLine> Edges { get; }
        public double RiseMmPerMetre { get; }
        public double MinThicknessMm { get; }

        public double Height(Vec2 p)
        {
            double m = double.PositiveInfinity;
            foreach (EdgeLine e in Edges) m = Math.Min(m, e.Distance(p));
            return MinThicknessMm + RiseMmPerMetre * Math.Max(0, m);
        }
    }
}
