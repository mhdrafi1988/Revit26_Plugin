using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents
{
    /// <summary>
    /// Creates the boards, plan view and tags inside one TransactionGroup.
    /// Boards are all-or-nothing (confirmed decision, 2026-10-12): any failure while creating them rolls the
    /// whole run back. A failing plan view or tag only logs a warning and keeps the boards.
    /// Instance state only (no statics) — one handler per window.
    /// </summary>
    public sealed class RunHandler : IExternalEventHandler
    {
        private readonly Document _document;
        private RunRequest _request;
        private Action<RunOutcome> _callback;

        public RunHandler(Document document) => _document = document;

        /// <summary>Set by EpsRevitBridge just before Raise(); cleared when the handler runs.</summary>
        public void Prepare(RunRequest request, Action<RunOutcome> callback)
        {
            _request = request;
            _callback = callback;
        }

        public void Execute(UIApplication app)
        {
            RunRequest request = _request;
            Action<RunOutcome> callback = _callback;
            _request = null;
            _callback = null;
            if (request == null) return;

            var outcome = new RunOutcome { Skipped = request.SkippedCount };
            var sw = Stopwatch.StartNew();
            try
            {
                Run(app, request, outcome);
                outcome.Succeeded = true;
                outcome.Add(EpsLogLevel.Info, $"Revit work finished in {sw.Elapsed.TotalSeconds:0.0} s.");
            }
            catch (Exception ex)
            {
                outcome.Succeeded = false;
                outcome.Placed = 0;
                outcome.Failed = request.Create3DPieces ? request.Pieces.Count : 0;
                outcome.Add(EpsLogLevel.Error, $"Run failed and was rolled back — nothing was changed in the model. {ex.Message}");
            }
            finally
            {
                callback?.Invoke(outcome);
            }
        }

        public string GetName() => "Tapered EPS Layout V001 — Run";

        private void Run(UIApplication app, RunRequest r, RunOutcome o)
        {
            Document doc = _document;
            if (doc == null || !doc.IsValidObject) throw new InvalidOperationException("The model this window was opened for is no longer open.");
            if (doc.IsReadOnly) throw new InvalidOperationException("The model is read-only.");

            double baseZ = RevitUnits.MetresToFeet(r.Boundary.TopElevationM);
            var placed = new List<PlacedBoard>();

            using (var group = new TransactionGroup(doc, "Tapered EPS Layout V001"))
            {
                group.Start();

                if (r.Create3DPieces)
                {
                    bool paramsBound;
                    using (var t = new Transaction(doc, "EPS shared parameters"))
                    {
                        t.Start();
                        paramsBound = SharedParameterSetup.Ensure(doc, app.Application, o.Messages);
                        t.Commit();
                    }

                    int paramMisses = 0;
                    using (var t = new Transaction(doc, "EPS boards"))
                    {
                        t.Start();
                        foreach (BoardPiece piece in r.Pieces)
                        {
                            // Throws on failure → the using blocks roll back this transaction and the whole group.
                            DirectShape ds = DirectShapeBuilder.Create(doc, piece, baseZ, $"{r.Prefix}-{piece.Id}");
                            paramMisses += EpsParameterWriter.Write(ds, piece);
                            placed.Add(new PlacedBoard(piece, ds.Id));
                        }
                        t.Commit();
                    }

                    o.Placed = placed.Count;
                    o.Add(EpsLogLevel.Success, $"Created {placed.Count} board DirectShapes (Generic Models) on {r.Boundary.LevelName}.");
                    if (!paramsBound || paramMisses > 0)
                        o.Add(EpsLogLevel.Warning, $"{paramMisses} EPS parameter value(s) could not be written. Check that EPS_* parameters are bound to Generic Models.");

                    int manyCorners = r.Pieces.Count(p => p.Heights.Count > EpsParameters.CornerSlots);
                    if (manyCorners > 0)
                        o.Add(EpsLogLevel.Warning, $"{manyCorners} board(s) have more than 8 corners — EPS_H1…H8 hold the first 8; the Excel schedule lists the corner count.");
                }

                if (r.CreatePlanView)
                {
                    if (placed.Count == 0)
                        o.Add(EpsLogLevel.Warning, "Plan view skipped — it colours and tags the 3D boards. Tick “3D pieces” as well.");
                    else
                        CreatePlanView(doc, r, placed, baseZ, o);
                }

                group.Assimilate();
            }
        }

        private static void CreatePlanView(Document doc, RunRequest r, List<PlacedBoard> placed, double baseZ, RunOutcome o)
        {
            ViewPlan view;
            try
            {
                using var t = new Transaction(doc, "EPS plan view");
                t.Start();
                view = PlanViewService.CreateView(doc, new ElementId(r.Boundary.LevelIdValue), r.Boundary.LevelName, baseZ, o.Messages);
                PlanViewService.ColourByThickness(doc, view, placed, r.Layout, o.Messages);
                t.Commit();
                o.ViewName = view.Name;
                o.Add(EpsLogLevel.Success, $"Plan view “{view.Name}” created, boards coloured in 10 mm thickness bands.");
            }
            catch (Exception ex)
            {
                o.Add(EpsLogLevel.Warning, $"Plan view not created ({ex.Message}). The boards were kept.");
                return;
            }

            if (r.TagTypeIdValue <= 0)
            {
                o.Add(EpsLogLevel.Warning, "No Generic Model tag family loaded — tags skipped. Load one and run again to tag the boards.");
                return;
            }

            try
            {
                using var t = new Transaction(doc, "EPS tags");
                t.Start();
                (int tagged, int failed) = PieceTagger.Tag(doc, view, new ElementId(r.TagTypeIdValue), placed, baseZ);
                t.Commit();
                o.Add(failed == 0 ? EpsLogLevel.Success : EpsLogLevel.Warning,
                      failed == 0 ? $"Tagged {tagged} boards." : $"Tagged {tagged} boards; {failed} could not be tagged.");
            }
            catch (Exception ex)
            {
                o.Add(EpsLogLevel.Warning, $"Tags not placed ({ex.Message}). The boards and view were kept.");
            }
        }
    }
}
