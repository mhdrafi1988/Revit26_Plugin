namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>Inputs to the layout engine. Board sizes in metres, slope in %, thickness in mm.</summary>
    public sealed record LayoutSettings(
        double BoardWidth,
        double BoardLength,
        double SlopePercent,
        double MinThicknessMm,
        GridDirection Direction,
        GridOrigin Origin)
    {
        public const double MinBoard = 0.25, MaxBoard = 1.00;
        public const double MinSlope = 0.1, MaxSlope = 5.0;
        public const double MinThickness = 10, MaxThickness = 300;

        public static LayoutSettings Default =>
            new LayoutSettings(1.00, 1.00, 1.0, 20, GridDirection.AlongLongestEdge, GridOrigin.BoundingBoxCorner);

        /// <summary>Thickness rise per metre of distance from the perimeter: 1 % = 10 mm/m.</summary>
        public double RiseMmPerMetre => SlopePercent * 10.0;
    }
}
