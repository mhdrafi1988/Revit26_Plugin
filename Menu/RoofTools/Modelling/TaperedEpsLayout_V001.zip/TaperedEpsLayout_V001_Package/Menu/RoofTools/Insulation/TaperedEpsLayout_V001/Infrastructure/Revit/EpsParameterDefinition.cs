using System;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>One EPS shared parameter: name, data type and a fixed GUID so every project gets the same definition.</summary>
    public sealed class EpsParameterDefinition
    {
        public EpsParameterDefinition(string name, ForgeTypeId spec, string guid, string description)
        {
            Name = name;
            Spec = spec;
            Guid = new Guid(guid);
            Description = description;
        }

        public string Name { get; }
        public ForgeTypeId Spec { get; }
        public Guid Guid { get; }
        public string Description { get; }
    }
}
