namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>Last-used window inputs, saved as JSON between sessions.</summary>
    public sealed class EpsUserSettings
    {
        public double BoardWidth { get; set; } = 1.00;
        public double BoardLength { get; set; } = 1.00;
        public double SlopePercent { get; set; } = 1.0;
        public double MinThicknessMm { get; set; } = 20;
        public GridDirection Direction { get; set; } = GridDirection.AlongLongestEdge;
        public GridOrigin Origin { get; set; } = GridOrigin.BoundingBoxCorner;
        public string PiecePrefix { get; set; } = "EPS";
        public bool Create3DPieces { get; set; } = true;
        public bool CreatePlanView { get; set; } = true;
        public bool CreateExcel { get; set; } = true;
        public string TagTypeLabel { get; set; } = string.Empty;
    }
}
