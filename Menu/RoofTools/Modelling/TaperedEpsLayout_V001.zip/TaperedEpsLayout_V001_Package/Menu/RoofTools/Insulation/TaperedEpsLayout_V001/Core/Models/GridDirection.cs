namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    public enum GridDirection
    {
        AlongLongestEdge = 0,
        ProjectXAxis = 1
    }
}
