using System.Collections.Generic;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>A cut piece straight out of the grid cutter, in grid-frame coordinates.</summary>
    public sealed record RawPiece(int Row, int Column, PieceType Type, int SubIndex, int SubCount, IReadOnlyList<Vec2> GridVertices);
}
