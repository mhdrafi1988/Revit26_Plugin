using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    public static class PieceClassifier
    {
        /// <summary>Hip wins over Edge: a boundary cell that is also split across slope faces is a Hip.</summary>
        public static PieceType Classify(int subPieceCount, double clippedCellArea, double fullCellArea)
        {
            if (subPieceCount > 1) return PieceType.Hip;
            return clippedCellArea < fullCellArea - 1e-6 ? PieceType.Edge : PieceType.Full;
        }
    }
}
