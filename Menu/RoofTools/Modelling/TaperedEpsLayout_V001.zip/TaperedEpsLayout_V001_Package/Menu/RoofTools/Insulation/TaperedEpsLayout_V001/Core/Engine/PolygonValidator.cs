using System;
using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// V001 accepts a single closed, simple, convex loop of straight edges. Arcs and extra loops are
    /// rejected earlier by the Revit reader, which sees the curves; this class sees points only.
    /// </summary>
    public static class PolygonValidator
    {
        private const double ConvexTolerance = 1e-9;

        public static ValidationResult Validate(IReadOnlyList<Vec2> raw)
        {
            if (raw == null || raw.Count < 3)
                return ValidationResult.Fail("The boundary has fewer than 3 corners.");

            List<Vec2> p = PolygonCleaner.Clean(raw);
            if (p.Count < 3)
                return ValidationResult.Fail("The boundary collapses after removing duplicate and collinear points.");

            int n = p.Count;
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (j == i + 1 || (i == 0 && j == n - 1)) continue;
                    if (SegmentsCross(p[i], p[(i + 1) % n], p[j], p[(j + 1) % n]))
                        return ValidationResult.Fail($"The boundary crosses itself (edges {i + 1} and {j + 1}).");
                }
            }

            if (Polygon2.SignedArea(p) < 0) p.Reverse();

            for (int i = 0; i < n; i++)
            {
                Vec2 a = p[i], b = p[(i + 1) % n], c = p[(i + 2) % n];
                if ((b - a).Cross(c - b) < -ConvexTolerance)
                    return ValidationResult.Fail(
                        $"The boundary is concave at corner {(i + 1) % n + 1}. V001 supports convex outlines only — split the roof into convex parts.");
            }

            return ValidationResult.Ok(p);
        }

        private static bool SegmentsCross(Vec2 a, Vec2 b, Vec2 c, Vec2 d)
        {
            static int Orient(Vec2 p, Vec2 q, Vec2 r) => Math.Sign((q - p).Cross(r - p));
            return Orient(a, b, c) * Orient(a, b, d) < 0 && Orient(c, d, a) * Orient(c, d, b) < 0;
        }
    }
}
