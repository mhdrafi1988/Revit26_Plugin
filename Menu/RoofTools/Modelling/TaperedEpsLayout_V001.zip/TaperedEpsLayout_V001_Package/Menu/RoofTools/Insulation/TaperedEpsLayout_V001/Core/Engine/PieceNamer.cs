namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// IDs: row letter (A from the low side of the grid, then Z → AA …), 2-digit column from the grid's
    /// low side, and a/b/c… when one cell holds several pieces. Rows without pieces are not lettered.
    /// </summary>
    public static class PieceNamer
    {
        public static string RowName(int rowIndex)
        {
            string s = string.Empty;
            int r = rowIndex + 1;
            while (r > 0)
            {
                int m = (r - 1) % 26;
                s = (char)('A' + m) + s;
                r = (r - 1) / 26;
            }
            return s;
        }

        public static string Id(int rowIndex, int columnIndex, int subIndex, int subCount)
        {
            string id = RowName(rowIndex) + (columnIndex + 1).ToString("00");
            return subCount > 1 ? id + (char)('a' + subIndex) : id;
        }
    }
}
