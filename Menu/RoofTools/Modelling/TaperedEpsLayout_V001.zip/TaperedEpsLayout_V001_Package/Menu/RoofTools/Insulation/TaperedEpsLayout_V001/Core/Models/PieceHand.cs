namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>S = its own mirror image; L / R = the two hands of a mirrored pair sharing one board code.</summary>
    public enum PieceHand
    {
        S = 0,
        L = 1,
        R = 2
    }
}
