namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    // Usings inside the namespace so Revit's View wins over a WinForms global using (System.Windows.Forms.View).
    using System.Collections.Generic;
    using Autodesk.Revit.DB;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

    /// <summary>Tags each board at its centroid with the chosen Generic Model tag. Call inside a transaction.</summary>
    public static class PieceTagger
    {
        public static (int Tagged, int Failed) Tag(Document doc, View view, ElementId tagTypeId,
                                                   IReadOnlyList<PlacedBoard> boards, double baseZFeet)
        {
            if (doc.GetElement(tagTypeId) is FamilySymbol symbol && !symbol.IsActive)
            {
                symbol.Activate();
                doc.Regenerate();
            }

            int tagged = 0, failed = 0;
            foreach (PlacedBoard b in boards)
            {
                try
                {
                    Element element = doc.GetElement(b.ElementId);
                    XYZ point = RevitUnits.ToFeet(Polygon2.VertexCentroid(b.Piece.Vertices), baseZFeet);
                    IndependentTag.Create(doc, tagTypeId, view.Id, new Reference(element), false, TagOrientation.Horizontal, point);
                    tagged++;
                }
                catch (System.Exception)
                {
                    // One untaggable board (e.g. the tag family can't host it) must not stop the rest.
                    failed++;
                }
            }
            return (tagged, failed);
        }
    }
}
