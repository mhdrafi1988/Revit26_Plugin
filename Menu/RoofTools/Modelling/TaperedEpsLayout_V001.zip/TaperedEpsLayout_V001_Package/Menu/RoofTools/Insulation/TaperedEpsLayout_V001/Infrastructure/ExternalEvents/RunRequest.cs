using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents
{
    /// <summary>Everything RunHandler needs, captured on the UI thread before Raise().</summary>
    public sealed class RunRequest
    {
        public RoofBoundary Boundary { get; set; }
        public LayoutResult Layout { get; set; }

        /// <summary>Pieces whose code is checked in the Board Schedule.</summary>
        public IReadOnlyList<BoardPiece> Pieces { get; set; }

        public int SkippedCount { get; set; }
        public string Prefix { get; set; } = "EPS";
        public bool Create3DPieces { get; set; }
        public bool CreatePlanView { get; set; }

        /// <summary>Tag type ElementId value; ≤ 0 when no tag family is loaded.</summary>
        public long TagTypeIdValue { get; set; } = -1;
    }
}
