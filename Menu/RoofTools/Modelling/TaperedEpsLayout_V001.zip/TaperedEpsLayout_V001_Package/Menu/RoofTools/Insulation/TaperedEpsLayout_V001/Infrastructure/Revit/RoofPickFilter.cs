using Autodesk.Revit.DB;
using Autodesk.Revit.UI.Selection;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>Lets the user pick roofs and floors only. Flatness is checked afterwards by RoofBoundaryReader.</summary>
    public sealed class RoofPickFilter : ISelectionFilter
    {
        public static bool IsSupported(Element element) => element is RoofBase || element is Floor;

        public bool AllowElement(Element elem) => IsSupported(elem);

        public bool AllowReference(Reference reference, XYZ position) => false;
    }
}
