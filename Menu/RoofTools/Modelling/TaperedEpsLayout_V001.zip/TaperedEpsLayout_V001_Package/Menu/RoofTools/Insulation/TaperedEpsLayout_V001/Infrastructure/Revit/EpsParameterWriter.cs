using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>Writes EPS_* values onto a board's DirectShape. Corner slots beyond the piece's corner count stay empty.</summary>
    public static class EpsParameterWriter
    {
        /// <returns>Number of parameters that could not be found or set on the element.</returns>
        public static int Write(Element element, BoardPiece piece)
        {
            int misses = 0;
            misses += SetText(element, EpsParameters.Id, piece.Id);
            misses += SetText(element, EpsParameters.Code, piece.Code);
            misses += SetText(element, EpsParameters.Hand, piece.HandText);

            for (int i = 0; i < EpsParameters.CornerSlots && i < piece.Heights.Count; i++)
                misses += SetDouble(element, EpsParameters.Corner(i + 1), RevitUnits.MillimetresToFeet(piece.Heights[i]));

            misses += SetDouble(element, EpsParameters.Area, RevitUnits.SquareMetresToInternal(piece.Area));
            misses += SetDouble(element, EpsParameters.Volume, RevitUnits.CubicMetresToInternal(piece.Volume));
            return misses;
        }

        private static int SetText(Element e, string name, string value)
        {
            Parameter p = e.LookupParameter(name);
            return p != null && !p.IsReadOnly && p.StorageType == StorageType.String && p.Set(value) ? 0 : 1;
        }

        private static int SetDouble(Element e, string name, double internalValue)
        {
            Parameter p = e.LookupParameter(name);
            return p != null && !p.IsReadOnly && p.StorageType == StorageType.Double && p.Set(internalValue) ? 0 : 1;
        }
    }
}
