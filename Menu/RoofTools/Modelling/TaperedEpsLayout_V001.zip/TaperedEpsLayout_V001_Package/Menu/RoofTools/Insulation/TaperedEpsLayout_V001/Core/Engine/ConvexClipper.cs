using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>Sutherland–Hodgman clipping of a convex polygon against one half-plane.</summary>
    public static class ConvexClipper
    {
        private const double InsideTolerance = 1e-12;

        /// <summary>Keeps the part where a·x + b·y + c ≥ 0. Orientation is preserved.</summary>
        public static List<Vec2> ClipHalfPlane(IReadOnlyList<Vec2> polygon, double a, double b, double c)
        {
            var output = new List<Vec2>(polygon.Count + 2);
            int n = polygon.Count;
            for (int i = 0; i < n; i++)
            {
                Vec2 p = polygon[i], q = polygon[(i + 1) % n];
                double dp = a * p.X + b * p.Y + c, dq = a * q.X + b * q.Y + c;
                bool inP = dp >= -InsideTolerance, inQ = dq >= -InsideTolerance;

                if (inP) output.Add(p);
                if (inP != inQ)
                {
                    double t = dp / (dp - dq);
                    output.Add(new Vec2(p.X + t * (q.X - p.X), p.Y + t * (q.Y - p.Y)));
                }
            }
            return output;
        }

        public static List<Vec2> ClipHalfPlane(IReadOnlyList<Vec2> polygon, EdgeLine line) =>
            ClipHalfPlane(polygon, line.Nx, line.Ny, line.C);
    }
}
