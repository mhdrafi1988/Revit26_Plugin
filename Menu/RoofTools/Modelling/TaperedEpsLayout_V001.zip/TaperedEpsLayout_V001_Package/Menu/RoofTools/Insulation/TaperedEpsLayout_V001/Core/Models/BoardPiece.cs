using System.Collections.Generic;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>
    /// One EPS board piece. Vertices are counter-clockwise; Heights[i] is the board thickness (mm) at Vertices[i].
    /// </summary>
    public sealed class BoardPiece
    {
        public BoardPiece(string id, int row, int column, PieceType type,
                          IReadOnlyList<Vec2> vertices, IReadOnlyList<Vec2> gridVertices,
                          IReadOnlyList<double> heights, double area, double volume,
                          double minHeight, double maxHeight)
        {
            Id = id; Row = row; Column = column; Type = type;
            Vertices = vertices; GridVertices = gridVertices; Heights = heights;
            Area = area; Volume = volume; MinHeight = minHeight; MaxHeight = maxHeight;
        }

        public string Id { get; }
        public int Row { get; }
        public int Column { get; }
        public PieceType Type { get; }

        /// <summary>Project XY, metres.</summary>
        public IReadOnlyList<Vec2> Vertices { get; }

        /// <summary>Same vertices in the rotated grid frame (used for signatures).</summary>
        public IReadOnlyList<Vec2> GridVertices { get; }

        /// <summary>Thickness at each vertex, mm.</summary>
        public IReadOnlyList<double> Heights { get; }

        public double Area { get; }      // m²
        public double Volume { get; }    // m³
        public double MinHeight { get; } // mm
        public double MaxHeight { get; } // mm

        public string Code { get; internal set; } = string.Empty;
        public PieceHand Hand { get; internal set; }
        public string SignatureKey { get; internal set; } = string.Empty;

        public string HandText => Hand.ToString();
    }
}
