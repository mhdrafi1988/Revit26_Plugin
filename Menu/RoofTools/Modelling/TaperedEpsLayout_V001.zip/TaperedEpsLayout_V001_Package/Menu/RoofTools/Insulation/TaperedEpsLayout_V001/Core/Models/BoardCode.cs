namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>One distinct board shape (congruent or mirrored pieces with identical corner heights).</summary>
    public sealed class BoardCode
    {
        public BoardCode(string code, PieceType type, int quantity, int leftCount, int rightCount,
                         double minHeight, double maxHeight, double totalArea, double totalVolume)
        {
            Code = code; Type = type; Quantity = quantity; LeftCount = leftCount; RightCount = rightCount;
            MinHeight = minHeight; MaxHeight = maxHeight; TotalArea = totalArea; TotalVolume = totalVolume;
        }

        public string Code { get; }
        public PieceType Type { get; }
        public int Quantity { get; }
        public int LeftCount { get; }
        public int RightCount { get; }
        public double MinHeight { get; }   // mm
        public double MaxHeight { get; }   // mm
        public double TotalArea { get; }   // m²
        public double TotalVolume { get; } // m³

        /// <summary>"S" for symmetric codes, otherwise e.g. "L4/R4".</summary>
        public string HandText => LeftCount == 0 && RightCount == 0 ? "S" : $"L{LeftCount}/R{RightCount}";
    }
}
