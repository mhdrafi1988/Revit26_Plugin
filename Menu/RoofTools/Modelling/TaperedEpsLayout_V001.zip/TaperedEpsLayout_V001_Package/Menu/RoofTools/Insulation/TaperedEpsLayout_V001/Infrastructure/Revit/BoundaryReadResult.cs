using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    public sealed class BoundaryReadResult
    {
        private BoundaryReadResult(RoofBoundary boundary, string error, string elementLabel)
        {
            Boundary = boundary;
            Error = error;
            ElementLabel = elementLabel;
        }

        public RoofBoundary Boundary { get; }
        public string Error { get; }

        /// <summary>Set even when reading failed, so the window can show what was picked.</summary>
        public string ElementLabel { get; }

        public bool IsValid => Boundary != null;

        public static BoundaryReadResult Ok(RoofBoundary boundary) => new BoundaryReadResult(boundary, string.Empty, boundary.ElementLabel);
        public static BoundaryReadResult Fail(string error, string elementLabel = "") => new BoundaryReadResult(null, error, elementLabel);
    }
}
