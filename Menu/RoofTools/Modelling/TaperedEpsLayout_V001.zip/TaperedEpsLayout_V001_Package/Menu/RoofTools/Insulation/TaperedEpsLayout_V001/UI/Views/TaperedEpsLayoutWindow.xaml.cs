namespace Revit26_Plugin.TaperedEpsLayout.V001.UI.Views
{
    // Usings inside the namespace so WPF types win over any WinForms/System.Drawing global usings.
    using System;
    using System.ComponentModel;
    using System.Linq;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
    using Revit26_Plugin.TaperedEpsLayout.V001.UI.ViewModels;

    public partial class TaperedEpsLayoutWindow : Window
    {
        // Same pack URIs the other ToolWindowShell windows use — check against SectionAutoRenamer V026 if styling is missing.
        private static readonly string[] SharedDictionaries =
        {
            "pack://application:,,,/Revit26_Plugin;component/Shared/SharedStyles.xaml",
            "pack://application:,,,/Revit26_Plugin;component/Shared/Controls/ToolWindowShellTemplate.xaml"
        };

        private readonly TaperedEpsLayoutViewModel _vm;

        public TaperedEpsLayoutWindow(TaperedEpsLayoutViewModel vm)
        {
            _vm = vm;
            InitializeComponent();
            MergeSharedResources();
            DataContext = vm;

            vm.RequestClose += Close;
            vm.SelectionStarted += Hide;
            vm.SelectionEnded += () => { Show(); Activate(); };
            vm.LogEntries.CollectionChanged += (s, e) =>
            {
                if (LogList.Items.Count > 0) LogList.ScrollIntoView(LogList.Items[LogList.Items.Count - 1]);
            };
            Closed += (s, e) => _vm.Dispose();
        }

        /// <summary>Merged here (not in XAML) so a moved dictionary logs a warning instead of failing to open the window.</summary>
        private void MergeSharedResources()
        {
            foreach (string uri in SharedDictionaries)
            {
                try
                {
                    Resources.MergedDictionaries.Add(new ResourceDictionary { Source = new Uri(uri, UriKind.Absolute) });
                }
                catch (Exception ex)
                {
                    _vm.Log(EpsLogLevel.Warning, $"Shared styles not loaded ({uri}): {ex.Message}");
                }
            }
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (_vm.IsRunning)
            {
                MessageBox.Show(this, "Revit is still creating the boards. Close the window when the run has finished.",
                                TaperedEpsLayoutViewModel.ToolTitle, MessageBoxButton.OK, MessageBoxImage.Information);
                e.Cancel = true;
            }
            base.OnClosing(e);
        }

        /// <summary>Enter commits a numeric field (they update on LostFocus so typing doesn't recalculate mid-number).</summary>
        private void Input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && sender is TextBox box)
                box.GetBindingExpression(TextBox.TextProperty)?.UpdateSource();
        }

        private void CopyAll_Click(object sender, RoutedEventArgs e) =>
            CopyLines(_vm.LogEntries.Select(m => m.ToString()));

        private void CopySelected_Click(object sender, RoutedEventArgs e) =>
            CopyLines(_vm.LogEntries.Where(m => LogList.SelectedItems.Contains(m)).Select(m => m.ToString()));

        private void CopyLines(System.Collections.Generic.IEnumerable<string> lines)
        {
            string text = string.Join(Environment.NewLine, lines);
            if (text.Length == 0) return;
            try { Clipboard.SetText(text); }
            catch (Exception ex) { _vm.Log(EpsLogLevel.Warning, $"Could not copy to the clipboard: {ex.Message}"); }
        }
    }
}
