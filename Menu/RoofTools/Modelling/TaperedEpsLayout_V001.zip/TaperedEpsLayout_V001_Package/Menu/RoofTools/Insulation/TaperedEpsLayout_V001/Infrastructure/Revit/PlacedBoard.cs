using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>A board piece and the DirectShape created for it.</summary>
    public sealed record PlacedBoard(BoardPiece Piece, ElementId ElementId);
}
