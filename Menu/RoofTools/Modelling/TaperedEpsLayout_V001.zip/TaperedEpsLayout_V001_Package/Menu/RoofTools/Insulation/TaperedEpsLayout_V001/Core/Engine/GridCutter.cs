using System;
using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// Cuts the outline (already in the grid frame) into board pieces: each cell is clipped to the outline,
    /// then split by slope face so every piece has one planar top. Slivers under 5e-4 m² are dropped.
    /// </summary>
    public static class GridCutter
    {
        public const double MinPieceArea = 5e-4;

        public static List<RawPiece> Cut(IReadOnlyList<Vec2> gridPolygon, IReadOnlyList<EdgeLine> edges,
                                         LayoutSettings s, out int columns, out int rows)
        {
            BoundingBox2 bb = Polygon2.Bounds(gridPolygon);
            double bw = s.BoardWidth, bh = s.BoardLength;
            int nc = (int)Math.Ceiling(bb.Width / bw - 1e-9);
            int nr = (int)Math.Ceiling(bb.Height / bh - 1e-9);
            double ox = bb.MinX, oy = bb.MinY;

            if (s.Origin == GridOrigin.CentredOnShape)
            {
                // One extra cell each way so a centred grid still covers the whole outline.
                nc += 1; nr += 1;
                ox = bb.Centre.X - nc * bw / 2;
                oy = bb.Centre.Y - nr * bh / 2;
            }
            columns = nc; rows = nr;

            var output = new List<RawPiece>();
            double fullArea = bw * bh;
            int letteredRow = 0;

            for (int r = 0; r < nr; r++)
            {
                bool rowHasPieces = false;
                for (int c = 0; c < nc; c++)
                {
                    double x0 = ox + c * bw, y0 = oy + r * bh;
                    List<Vec2> cell = new List<Vec2>
                    {
                        new Vec2(x0, y0), new Vec2(x0 + bw, y0), new Vec2(x0 + bw, y0 + bh), new Vec2(x0, y0 + bh)
                    };
                    foreach (EdgeLine e in edges)
                    {
                        cell = ConvexClipper.ClipHalfPlane(cell, e);
                        if (cell.Count < 3) break;
                    }
                    cell = PolygonCleaner.Clean(cell);
                    if (cell.Count < 3) continue;
                    double cellArea = Polygon2.SignedArea(cell);
                    if (cellArea < MinPieceArea) continue;

                    List<List<Vec2>> subs = SplitBySlopeFace(cell, edges);
                    if (subs.Count == 0) continue;

                    PieceType type = PieceClassifier.Classify(subs.Count, cellArea, fullArea);
                    for (int i = 0; i < subs.Count; i++)
                        output.Add(new RawPiece(letteredRow, c, type, i, subs.Count, subs[i]));
                    rowHasPieces = true;
                }
                if (rowHasPieces) letteredRow++;
            }
            return output;
        }

        private static List<List<Vec2>> SplitBySlopeFace(List<Vec2> cell, IReadOnlyList<EdgeLine> edges)
        {
            var subs = new List<List<Vec2>>();
            for (int i = 0; i < edges.Count; i++)
            {
                List<Vec2> p = cell;
                for (int j = 0; j < edges.Count && p.Count >= 3; j++)
                {
                    if (j == i) continue;
                    // Face i is where edge i is the nearest edge: Lj − Li ≥ 0 for every other j.
                    EdgeLine a = edges[j], b = edges[i];
                    p = ConvexClipper.ClipHalfPlane(p, a.Nx - b.Nx, a.Ny - b.Ny, a.C - b.C);
                }
                p = PolygonCleaner.Clean(p);
                if (p.Count >= 3 && Polygon2.SignedArea(p) >= MinPieceArea) subs.Add(p);
            }

            // Stable order inside a cell: by vertex-centroid Y, then X.
            subs.Sort((a, b) =>
            {
                Vec2 ca = Polygon2.VertexCentroid(a), cb = Polygon2.VertexCentroid(b);
                return Math.Abs(ca.Y - cb.Y) > 1e-6 ? ca.Y.CompareTo(cb.Y) : ca.X.CompareTo(cb.X);
            });
            return subs;
        }
    }
}
