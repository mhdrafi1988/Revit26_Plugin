using System;
using Autodesk.Revit.UI;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents
{
    /// <summary>
    /// The window's link to Revit: both handlers and their ExternalEvents, created once by the command
    /// (a valid API context) and owned by one ViewModel. Deliberately not static, unlike older tools'
    /// EventManager — the spec forbids static state in handlers (tool spec, confirmed 2026-10-12).
    /// </summary>
    public sealed class EpsRevitBridge : IDisposable
    {
        private readonly SelectRoofHandler _selectHandler;
        private readonly RunHandler _runHandler;
        private ExternalEvent _selectEvent;
        private ExternalEvent _runEvent;

        public EpsRevitBridge(SelectRoofHandler selectHandler, ExternalEvent selectEvent, RunHandler runHandler, ExternalEvent runEvent)
        {
            _selectHandler = selectHandler;
            _selectEvent = selectEvent;
            _runHandler = runHandler;
            _runEvent = runEvent;
        }

        public bool RequestSelection(Action<SelectionOutcome> callback, out string error)
        {
            _selectHandler.Prepare(callback);
            return Raise(_selectEvent, out error);
        }

        public bool RequestRun(RunRequest request, Action<RunOutcome> callback, out string error)
        {
            _runHandler.Prepare(request, callback);
            return Raise(_runEvent, out error);
        }

        private static bool Raise(ExternalEvent ev, out string error)
        {
            error = string.Empty;
            if (ev == null) { error = "The window was closed."; return false; }

            ExternalEventRequest result = ev.Raise();
            if (result == ExternalEventRequest.Accepted || result == ExternalEventRequest.Pending) return true;

            error = result == ExternalEventRequest.Denied
                ? "Revit is busy. Finish or cancel the current command, then try again."
                : "Revit did not respond. Try again.";
            return false;
        }

        public void Dispose()
        {
            _selectEvent?.Dispose();
            _runEvent?.Dispose();
            _selectEvent = null;
            _runEvent = null;
        }
    }
}
