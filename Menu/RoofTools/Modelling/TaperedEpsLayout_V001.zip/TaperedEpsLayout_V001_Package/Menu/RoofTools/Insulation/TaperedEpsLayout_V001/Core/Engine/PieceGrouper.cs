using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine
{
    /// <summary>
    /// Groups pieces of the same type by signature and numbers the groups F01…, E01…, H01…,
    /// ordered by min thickness, then max thickness, then piece area. Sets Code / Hand on each piece.
    /// </summary>
    public static class PieceGrouper
    {
        public static List<BoardCode> Assign(IReadOnlyList<BoardPiece> pieces)
        {
            var groups = new Dictionary<string, List<BoardPiece>>();
            var order = new List<string>();

            foreach (BoardPiece p in pieces)
            {
                (string key, PieceHand hand) = PieceSignature.Compute(p.GridVertices, p.Heights);
                p.Hand = hand;
                p.SignatureKey = key;

                string groupKey = p.Type + "#" + key;
                if (!groups.TryGetValue(groupKey, out List<BoardPiece> list))
                {
                    list = new List<BoardPiece>();
                    groups[groupKey] = list;
                    order.Add(groupKey);
                }
                list.Add(p);
            }

            var codes = new List<BoardCode>();
            foreach (PieceType type in new[] { PieceType.Full, PieceType.Edge, PieceType.Hip })
            {
                List<List<BoardPiece>> ofType = order
                    .Where(k => groups[k][0].Type == type)
                    .Select(k => groups[k])
                    .OrderBy(g => g[0].MinHeight)
                    .ThenBy(g => g[0].MaxHeight)
                    .ThenBy(g => g[0].Area)
                    .ToList();

                char prefix = type.ToString()[0];
                for (int i = 0; i < ofType.Count; i++)
                {
                    List<BoardPiece> g = ofType[i];
                    string code = prefix + (i + 1).ToString("00");
                    foreach (BoardPiece p in g) p.Code = code;

                    codes.Add(new BoardCode(
                        code, type, g.Count,
                        g.Count(p => p.Hand == PieceHand.L),
                        g.Count(p => p.Hand == PieceHand.R),
                        g[0].MinHeight, g[0].MaxHeight,
                        g.Sum(p => p.Area), g.Sum(p => p.Volume)));
                }
            }
            return codes;
        }
    }
}
