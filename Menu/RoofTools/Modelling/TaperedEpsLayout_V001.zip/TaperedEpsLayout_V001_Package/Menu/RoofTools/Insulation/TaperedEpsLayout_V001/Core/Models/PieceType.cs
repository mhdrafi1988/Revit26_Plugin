namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>Full = whole cell; Edge = cut by the roof boundary; Hip = cell split across slope faces (wins over Edge).</summary>
    public enum PieceType
    {
        Full = 0,
        Edge = 1,
        Hip = 2
    }
}
