using System.Collections.Generic;
using Autodesk.Revit.DB;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit
{
    /// <summary>
    /// Reads the flat top face of a roof or floor: its single outline (metres) and elevation.
    /// The boards sit on this face (confirmed decision, 2026-10-12: top face of slab, not roof base).
    /// </summary>
    public static class RoofBoundaryReader
    {
        private const double FlatNormalZ = 0.9999;

        public static BoundaryReadResult Read(Element element)
        {
            if (element == null || !RoofPickFilter.IsSupported(element) || !(element is HostObject host))
                return BoundaryReadResult.Fail("Pick a roof or a floor slab.");

            string label = $"{element.Category?.Name ?? "Element"} : {element.Name} · {element.Id.Value}";
            Document doc = element.Document;

            PlanarFace top = null;
            bool sawSloped = false;
            foreach (Reference r in HostObjectUtils.GetTopFaces(host))
            {
                if (host.GetGeometryObjectFromReference(r) is PlanarFace face && face.FaceNormal.Z >= FlatNormalZ)
                {
                    if (top == null || face.Area > top.Area) top = face;
                }
                else
                {
                    sawSloped = true;
                }
            }

            if (top == null)
                return BoundaryReadResult.Fail(sawSloped
                    ? "The top of this element is sloped or curved. V001 needs a flat roof or slab."
                    : "Could not find the top face of this element.", label);

            IList<CurveLoop> loops = top.GetEdgesAsCurveLoops();
            if (loops.Count != 1)
                return BoundaryReadResult.Fail(
                    $"The top face has {loops.Count} loops (openings or separate parts). V001 supports one outline without openings.", label);

            var points = new List<Vec2>();
            foreach (Curve curve in loops[0])
            {
                if (!(curve is Line))
                    return BoundaryReadResult.Fail("The outline has arcs or curved edges. V001 supports straight edges only.", label);
                points.Add(RevitUnits.ToMetres(curve.GetEndPoint(0)));
            }

            if (!(doc.GetElement(element.LevelId) is Level level))
                return BoundaryReadResult.Fail("This element has no level, so the plan view cannot be placed.", label);

            var boundary = new RoofBoundary(points, RevitUnits.FeetToMetres(top.Origin.Z), label,
                                            element.Id.Value, level.Name, level.Id.Value);
            return BoundaryReadResult.Ok(boundary);
        }
    }
}
