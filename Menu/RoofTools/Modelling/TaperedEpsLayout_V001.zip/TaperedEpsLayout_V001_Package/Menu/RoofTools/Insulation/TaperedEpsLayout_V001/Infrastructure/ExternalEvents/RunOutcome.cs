using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents
{
    /// <summary>What RunHandler did, handed back to the ViewModel for the footer summary and log.</summary>
    public sealed class RunOutcome
    {
        public int Placed { get; set; }
        public int Skipped { get; set; }
        public int Failed { get; set; }
        public bool Succeeded { get; set; }
        public string ViewName { get; set; } = string.Empty;
        public List<EpsLogMessage> Messages { get; } = new List<EpsLogMessage>();

        public void Add(EpsLogLevel level, string text) => Messages.Add(EpsLogMessage.Now(level, text));
    }
}
