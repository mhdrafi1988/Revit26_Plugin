// Tapered EPS Layout V001 — lays tapered EPS boards on a flat roof/slab, falling to the perimeter.
//
// Confirmed decisions (2026-10-12):
//   - Namespace Revit26_Plugin.TaperedEpsLayout.V001, folder Menu/RoofTools/Insulation/TaperedEpsLayout_V001.
//   - Boards sit on the TOP FACE of the picked roof/floor (not the roof base elevation in the original spec).
//   - Boards are created all-or-nothing in one transaction; plan view / tag failures are warnings only.
//   - ExternalEvent handlers are per-window instances (no static EventManager), created here once.
//   - Shared parameters use Length / Area / Volume specs; EPS_H1…H8 hold the first 8 corners.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Interop;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.ExternalEvents;
using Revit26_Plugin.TaperedEpsLayout.V001.Infrastructure.Revit;
using Revit26_Plugin.TaperedEpsLayout.V001.UI.ViewModels;
using Revit26_Plugin.TaperedEpsLayout.V001.UI.Views;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Commands
{
    [Transaction(TransactionMode.Manual)]
    public class TaperedEpsLayoutCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp.ActiveUIDocument;
                if (uidoc == null)
                {
                    TaskDialog.Show("Tapered EPS Layout", "Open a project first.");
                    return Result.Cancelled;
                }

                Document doc = uidoc.Document;
                if (doc.IsFamilyDocument)
                {
                    TaskDialog.Show("Tapered EPS Layout", "This tool works in a project, not in the Family Editor.");
                    return Result.Cancelled;
                }

                List<TagTypeOption> tagTypes = TagTypeProvider.GetGenericModelTagTypes(doc);

                // A single preselected roof/floor is loaded straight away; otherwise the user clicks Select Roof.
                BoundaryReadResult preselected = null;
                ICollection<ElementId> selection = uidoc.Selection.GetElementIds();
                if (selection.Count == 1)
                {
                    Element element = doc.GetElement(selection.First());
                    if (RoofPickFilter.IsSupported(element)) preselected = RoofBoundaryReader.Read(element);
                }

                var selectHandler = new SelectRoofHandler(doc);
                var runHandler = new RunHandler(doc);
                var bridge = new EpsRevitBridge(selectHandler, ExternalEvent.Create(selectHandler),
                                                runHandler, ExternalEvent.Create(runHandler));

                var viewModel = new TaperedEpsLayoutViewModel(bridge, doc.Title, tagTypes, preselected);
                var window = new TaperedEpsLayoutWindow(viewModel);
                new WindowInteropHelper(window).Owner = uiapp.MainWindowHandle;
                window.Show();
                return Result.Succeeded;
            }
            catch (OperationCanceledException)
            {
                return Result.Cancelled;
            }
            catch (Autodesk.Revit.Exceptions.OperationCanceledException)
            {
                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                TaskDialog.Show("Tapered EPS Layout", ex.Message);
                return Result.Failed;
            }
        }
    }
}
