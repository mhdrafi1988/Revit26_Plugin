using System;

namespace Revit26_Plugin.TaperedEpsLayout.V001.Core.Models
{
    /// <summary>One log line. ToString() matches Shared/LogEntry: "HH:mm:ss  Level  Message".</summary>
    public sealed record EpsLogMessage(DateTime Time, EpsLogLevel Level, string Text)
    {
        public static EpsLogMessage Now(EpsLogLevel level, string text) => new EpsLogMessage(DateTime.Now, level, text);

        public string TimeText => Time.ToString("HH:mm:ss");

        public override string ToString() => $"{TimeText}  {Level,-8}{Text}";
    }
}
