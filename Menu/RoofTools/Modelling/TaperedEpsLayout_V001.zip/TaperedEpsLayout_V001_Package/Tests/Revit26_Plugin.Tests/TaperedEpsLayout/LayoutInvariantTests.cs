using System;
using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsLayout
{
    public class LayoutInvariantTests
    {
        public static IEnumerable<object[]> Shapes()
        {
            yield return new object[] { "12x8", AcceptanceShapes.Rect(12, 8), 1.0 };
            yield return new object[] { "10x10", AcceptanceShapes.Rect(10, 10), 1.0 };
            yield return new object[] { "triangle", AcceptanceShapes.Triangle, 1.0 };
            yield return new object[] { "pentagon", AcceptanceShapes.Pentagon, 1.0 };
            yield return new object[] { "hexagon", AcceptanceShapes.Hexagon(6), 1.0 };
            yield return new object[] { "12x8 @0.5", AcceptanceShapes.Rect(12, 8), 0.5 };
        }

        private static LayoutResult Run(IReadOnlyList<Vec2> shape, double board) =>
            LayoutEngine.Compute(shape, AcceptanceShapes.TestSettings with { BoardWidth = board, BoardLength = board });

        [Theory]
        [MemberData(nameof(Shapes))]
        public void TotalPieceArea_EqualsPolygonArea(string name, IReadOnlyList<Vec2> shape, double board)
        {
            LayoutResult r = Run(shape, board);
            Assert.True(Math.Abs(r.PieceArea - r.RoofArea) <= 1e-3, $"{name}: Δ = {r.PieceArea - r.RoofArea}");
        }

        [Theory]
        [MemberData(nameof(Shapes))]
        public void NoHeightBelowMinimum(string name, IReadOnlyList<Vec2> shape, double board)
        {
            LayoutResult r = Run(shape, board);
            Assert.True(r.Pieces.SelectMany(p => p.Heights).All(h => h >= 20 - 1e-9), name);
        }

        [Theory]
        [MemberData(nameof(Shapes))]
        public void PieceIds_AreUnique_AndEveryPieceHasACode(string name, IReadOnlyList<Vec2> shape, double board)
        {
            LayoutResult r = Run(shape, board);
            Assert.Equal(r.Pieces.Count, r.Pieces.Select(p => p.Id).Distinct().Count());
            Assert.All(r.Pieces, p => Assert.False(string.IsNullOrEmpty(p.Code), name));
            Assert.Equal(r.Pieces.Count, r.Codes.Sum(c => c.Quantity));
        }

        [Fact]
        public void MirroredHipTriangles_ShareOneCode_WithOppositeHands()
        {
            LayoutResult r = Run(AcceptanceShapes.Rect(12, 8), 1.0);
            BoardPiece a = r.Pieces.Single(p => p.Id == "A01a");
            BoardPiece b = r.Pieces.Single(p => p.Id == "A01b");
            Assert.Equal(PieceType.Hip, a.Type);
            Assert.Equal(a.Code, b.Code);
            Assert.NotEqual(a.Hand, b.Hand);
            Assert.NotEqual(PieceHand.S, a.Hand);
        }

        [Fact]
        public void ProjectXGrid_And_CentredOrigin_StillCoverTheRoof()
        {
            LayoutSettings s = AcceptanceShapes.TestSettings with { Direction = GridDirection.ProjectXAxis, Origin = GridOrigin.CentredOnShape };
            LayoutResult r = LayoutEngine.Compute(AcceptanceShapes.Hexagon(6), s);
            Assert.True(r.IsValid);
            Assert.True(Math.Abs(r.PieceArea - r.RoofArea) <= 1e-3);
        }
    }
}
