using System.Collections.Generic;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsLayout
{
    /// <summary>Acceptance numbers from the tool spec: slope 1 %, tmin 20 mm, 1 × 1 m boards, grid along longest edge.</summary>
    public class LayoutEngineAcceptanceTests
    {
        private static LayoutResult Run(IReadOnlyList<Vec2> shape, double board = 1.0)
        {
            LayoutSettings s = AcceptanceShapes.TestSettings with { BoardWidth = board, BoardLength = board };
            LayoutResult r = LayoutEngine.Compute(shape, s);
            Assert.True(r.IsValid, r.Message);
            return r;
        }

        [Fact]
        public void Rectangle_12x8()
        {
            LayoutResult r = Run(AcceptanceShapes.Rect(12, 8));
            Assert.Equal(112, r.Pieces.Count);
            Assert.Equal(8, r.Codes.Count);
            Assert.Equal(60.0, r.MaxThickness, 6);
            Assert.Equal(3.413, r.TotalVolume, 3);
        }

        [Fact]
        public void Square_10x10()
        {
            LayoutResult r = Run(AcceptanceShapes.Rect(10, 10));
            Assert.Equal(120, r.Pieces.Count);
            Assert.Equal(9, r.Codes.Count);
            Assert.Equal(70.0, r.MaxThickness, 6);
        }

        [Fact]
        public void Triangle()
        {
            LayoutResult r = Run(AcceptanceShapes.Triangle);
            Assert.Equal(91, r.Pieces.Count);
            Assert.Equal(83, r.Codes.Count);
        }

        [Fact]
        public void Pentagon()
        {
            LayoutResult r = Run(AcceptanceShapes.Pentagon);
            Assert.Equal(161, r.Pieces.Count);
            Assert.Equal(125, r.Codes.Count);
        }

        [Fact]
        public void RegularHexagon_R6()
        {
            LayoutResult r = Run(AcceptanceShapes.Hexagon(6));
            Assert.Equal(156, r.Pieces.Count);
            Assert.Equal(75, r.Codes.Count);
        }

        [Fact]
        public void Rectangle_12x8_HalfMetreBoards()
        {
            LayoutResult r = Run(AcceptanceShapes.Rect(12, 8), 0.5);
            Assert.Equal(416, r.Pieces.Count);
            Assert.Equal(16, r.Codes.Count);
        }
    }
}
