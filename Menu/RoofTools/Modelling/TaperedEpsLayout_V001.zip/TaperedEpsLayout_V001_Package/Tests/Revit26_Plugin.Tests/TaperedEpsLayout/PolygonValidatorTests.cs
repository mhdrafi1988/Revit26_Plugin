using Revit26_Plugin.TaperedEpsLayout.V001.Core.Engine;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsLayout
{
    public class PolygonValidatorTests
    {
        [Fact]
        public void ConcaveLShape_ReturnsValidationError_NotACrash()
        {
            LayoutResult r = LayoutEngine.Compute(AcceptanceShapes.LShape, AcceptanceShapes.TestSettings);
            Assert.False(r.IsValid);
            Assert.Contains("concave", r.Message);
        }

        [Fact]
        public void ClockwiseInput_IsReorientedCounterClockwise()
        {
            var cw = new[] { new Vec2(0, 0), new Vec2(0, 8), new Vec2(12, 8), new Vec2(12, 0) };
            ValidationResult v = PolygonValidator.Validate(cw);
            Assert.True(v.IsValid);
            Assert.True(Polygon2.SignedArea(v.Polygon) > 0);
        }

        [Fact]
        public void CollinearSketchSegments_AreMerged()
        {
            var split = new[] { new Vec2(0, 0), new Vec2(6, 0), new Vec2(12, 0), new Vec2(12, 8), new Vec2(0, 8) };
            ValidationResult v = PolygonValidator.Validate(split);
            Assert.True(v.IsValid);
            Assert.Equal(4, v.Polygon.Count);
        }

        [Fact]
        public void SelfIntersectingBowtie_IsRejected()
        {
            var bowtie = new[] { new Vec2(0, 0), new Vec2(10, 10), new Vec2(10, 0), new Vec2(0, 10) };
            Assert.False(PolygonValidator.Validate(bowtie).IsValid);
        }

        [Fact]
        public void TooFewPoints_IsRejected()
        {
            Assert.False(PolygonValidator.Validate(new[] { new Vec2(0, 0), new Vec2(1, 0) }).IsValid);
        }
    }
}
