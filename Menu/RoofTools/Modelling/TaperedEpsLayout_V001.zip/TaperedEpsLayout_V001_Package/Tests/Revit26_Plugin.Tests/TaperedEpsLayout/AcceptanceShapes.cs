using System;
using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsLayout.V001.Core.Models;

namespace Revit26_Plugin.Tests.TaperedEpsLayout
{
    internal static class AcceptanceShapes
    {
        public static readonly LayoutSettings TestSettings =
            new LayoutSettings(1.0, 1.0, 1.0, 20, GridDirection.AlongLongestEdge, GridOrigin.BoundingBoxCorner);

        public static IReadOnlyList<Vec2> Rect(double w, double h) =>
            new[] { new Vec2(0, 0), new Vec2(w, 0), new Vec2(w, h), new Vec2(0, h) };

        public static IReadOnlyList<Vec2> Triangle =>
            new[] { new Vec2(0, 0), new Vec2(12, 0), new Vec2(5, 9) };

        public static IReadOnlyList<Vec2> Pentagon =>
            new[] { new Vec2(0, 0), new Vec2(12, 0), new Vec2(14, 5), new Vec2(7, 10), new Vec2(-1, 6) };

        public static IReadOnlyList<Vec2> Hexagon(double r) =>
            Enumerable.Range(0, 6).Select(i => new Vec2(r * Math.Cos(i * Math.PI / 3), r * Math.Sin(i * Math.PI / 3))).ToArray();

        public static IReadOnlyList<Vec2> LShape =>
            new[] { new Vec2(0, 0), new Vec2(10, 0), new Vec2(10, 4), new Vec2(4, 4), new Vec2(4, 8), new Vec2(0, 8) };
    }
}
