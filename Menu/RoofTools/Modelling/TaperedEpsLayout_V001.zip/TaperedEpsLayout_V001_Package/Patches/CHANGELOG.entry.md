## 2026-10-12 — Tapered EPS Layout V001 (new tool)

- New tool `Menu/RoofTools/Insulation/TaperedEpsLayout_V001` (namespace
  `Revit26_Plugin.TaperedEpsLayout.V001`), on ToolWindowShell from the start.
  Picks a flat, convex roof or floor and lays tapered EPS boards falling to
  the perimeter (H = tmin + slope × distance to the nearest edge). Outputs:
  one Generic Model DirectShape per board with `EPS_*` shared parameters, an
  "EPS Layout - <Level>" plan view coloured in 10 mm bands + tags, and an
  `.xlsx` schedule (ClosedXML). Live preview and Board Schedule in the window.
- Confirmed decisions (2026-10-12): boards sit on the element's top face;
  boards are all-or-nothing in one transaction (plan view / tags failing is a
  warning); handlers are per-window instances created in the command — no
  static `EventManager` (deliberate deviation from older tools).
- First test project: `Tests/Revit26_Plugin.Tests` (xUnit, net8.0). It links
  the tool's `Core/` source directly, so it needs no Revit install. 31 tests,
  including the spec's acceptance shapes. Approved change to the "no test
  project" known gap.
- `Revit26_Plugin.csproj`: `Compile/None/Page Remove="Tests\**"`, ClosedXML
  package reference, `TaperedEps_16/32.png` embedded.
- Ribbon: new Insulation panel on the Roof Tools build with "Tapered EPS V001".
