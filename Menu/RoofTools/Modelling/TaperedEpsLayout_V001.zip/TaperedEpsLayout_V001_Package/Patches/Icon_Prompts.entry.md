### Tapered EPS Layout (Roof Tools → Insulation) — `TaperedEps_16.png` / `TaperedEps_32.png`

A placeholder icon ships with V001 (drawn programmatically). To regenerate:

> Flat vector icon, 32×32 and 16×16, transparent background. Side section of a flat roof: a navy (#1E3A5F)
> horizontal slab at the bottom; on top, a low tapered insulation layer that is thin at both ends and thickest
> in the middle (a shallow gable shape), split into 4–6 vertical board segments in warm sand-to-orange tones
> separated by thin white seams; a thin navy line along the tapered top. No text, no perspective, crisp at 16 px.
