// Tapered EPS Layout V001 — paste inside RoofToolsRibbon.Build(application, tabName, assemblyPath),
// after the existing Roof Tools panels. Uses the repo's ImageUtils and RibbonLayoutHelper as-is.
// The fully-qualified command name is not compiler-checked — keep it in sync with the namespace.

RibbonPanel insulationPanel = application.CreateRibbonPanel(tabName, "Insulation");

var taperedEps = new PushButtonData(
    "Btn_TaperedEpsLayout_V001",
    "Tapered EPS\nV001",
    assemblyPath,
    "Revit26_Plugin.TaperedEpsLayout.V001.Commands.TaperedEpsLayoutCommand")
{
    Image = ImageUtils.Load("Revit26_Plugin.Resources.Icons.RoofTools.TaperedEps_16.png"),
    LargeImage = ImageUtils.Load("Revit26_Plugin.Resources.Icons.RoofTools.TaperedEps_32.png"),
    ToolTip = RibbonLayoutHelper.VersionTip(
        "Tapered EPS Layout", "V001",
        "Lays tapered EPS boards on a flat roof or slab, falling to the perimeter: 3D boards, colour-coded plan view and Excel schedule.")
};

insulationPanel.AddItem(taperedEps);

// Alternative: to put it in an existing Roof Tools panel instead, add `taperedEps` to that panel's
// list passed to RibbonLayoutHelper.AddStackedButtons(...) — the helper backfills LargeImage for a lone button.
