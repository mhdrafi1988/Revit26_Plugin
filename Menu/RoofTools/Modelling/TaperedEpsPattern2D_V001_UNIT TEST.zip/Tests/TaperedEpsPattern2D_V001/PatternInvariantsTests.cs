using System;
using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsPattern2D.V001.Core.Pattern;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsPattern2D.V001
{
    /// <summary>Every line inside the outline, none shorter than 1 mm, no duplicates — on many shapes and settings.</summary>
    public class PatternInvariantsTests
    {
        private const double OneMm = 0.001;

        private static IEnumerable<(string Name, Polygon2D Outline, Pattern2DSettings Settings)> Cases()
        {
            Pattern2DSettings baseSettings = TestShapes.AcceptanceSettings;
            yield return ("12x8", TestShapes.Rectangle(12, 8), baseSettings);
            yield return ("10x10", TestShapes.Rectangle(10, 10), baseSettings);
            yield return ("12x8 rotated 30°", TestShapes.Transformed(TestShapes.Rectangle(12, 8), 30, new Vec2(105.3, -42.7)), baseSettings);
            yield return ("hexagon", TestShapes.RegularPolygon(6, 7.5), baseSettings with { BoardLengthM = 0.6, BoardWidthM = 0.4 });
            yield return ("triangle", new Polygon2D(new[] { new Vec2(0, 0), new Vec2(14, 0), new Vec2(3, 9) }), baseSettings);
            yield return ("pentagon centred projX", TestShapes.Pentagon(),
                baseSettings with { GridDirection = GridDirectionMode.ProjectX, GridOrigin = GridOriginMode.Centred, BoardLengthM = 0.75, BoardWidthM = 0.5, ContourIntervalMm = 5, SlopePercent = 1.7 });
            yield return ("thin 30x1.2", TestShapes.Rectangle(30, 1.2), baseSettings with { BoardLengthM = 0.25, BoardWidthM = 0.25 });
        }

        [Fact]
        public void EveryLine_LiesInsideOutline()
        {
            foreach (var c in Cases())
            {
                Pattern2DResult r = Pattern2DEngine.Generate(c.Outline.ToCounterClockwise(), c.Settings);
                Assert.True(r.IsValid, c.Name);
                Assert.NotEmpty(r.Segments);
                foreach (PatternSegment s in r.Segments)
                {
                    Assert.True(r.Outline.ContainsConvex(s.Segment.Start, OneMm), $"{c.Name}: {s.Layer} start {s.Segment}");
                    Assert.True(r.Outline.ContainsConvex(s.Segment.End, OneMm), $"{c.Name}: {s.Layer} end {s.Segment}");
                }
            }
        }

        [Fact]
        public void NoLine_IsShorterThan1mm()
        {
            foreach (var c in Cases())
            {
                Pattern2DResult r = Pattern2DEngine.Generate(c.Outline.ToCounterClockwise(), c.Settings);
                Assert.True(r.Segments.All(s => s.Segment.Length >= OneMm), c.Name);
            }
        }

        [Fact]
        public void NoDuplicateLines()
        {
            foreach (var c in Cases())
            {
                Pattern2DResult r = Pattern2DEngine.Generate(c.Outline.ToCounterClockwise(), c.Settings);
                var all = r.Segments.Select(s => s.Segment).ToList();
                for (int i = 0; i < all.Count; i++)
                {
                    for (int j = i + 1; j < all.Count; j++)
                    {
                        Assert.False(all[i].SameAs(all[j], OneMm), $"{c.Name}: duplicate {all[i]}");
                    }
                }
            }
        }

        [Fact]
        public void RotatedRectangle_GivesSameCountsAsAxisAligned()
        {
            Pattern2DResult a = Pattern2DEngine.Generate(TestShapes.Rectangle(12, 8), TestShapes.AcceptanceSettings);
            Pattern2DResult b = Pattern2DEngine.Generate(
                TestShapes.Transformed(TestShapes.Rectangle(12, 8), 30, new Vec2(105.3, -42.7)), TestShapes.AcceptanceSettings);

            foreach (PatternLayer layer in Enum.GetValues(typeof(PatternLayer)))
            {
                Assert.Equal(a.StatsOf(layer).LineCount, b.StatsOf(layer).LineCount);
                Assert.Equal(a.StatsOf(layer).TotalLengthM, b.StatsOf(layer).TotalLengthM, 6);
            }

            Assert.Equal(a.MaxThicknessMm, b.MaxThicknessMm, 6);
            Assert.Equal(a.BoardCount, b.BoardCount);
        }

        [Fact]
        public void BoardPieces_TileTheOutlineExactly()
        {
            foreach (var c in Cases())
            {
                Pattern2DResult r = Pattern2DEngine.Generate(c.Outline.ToCounterClockwise(), c.Settings);
                double sum = r.Boards.Sum(b => b.Polygon.Area);
                Assert.True(Math.Abs(sum - r.Outline.Area) < 1e-3, $"{c.Name}: {sum} vs {r.Outline.Area}");
            }
        }
    }
}
