using System;
using System.Linq;
using Revit26_Plugin.TaperedEpsPattern2D.V001.Core.Pattern;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsPattern2D.V001
{
    public class LayerBuilderTests
    {
        [Fact]
        public void RegularHexagon_Has6HipsMeetingAtCentre()
        {
            Pattern2DResult r = Pattern2DEngine.Generate(TestShapes.RegularPolygon(6, 5), TestShapes.AcceptanceSettings);

            var hips = r.SegmentsOf(PatternLayer.HipRidge).Select(s => s.Segment).ToList();
            Assert.Equal(6, hips.Count);
            Assert.True(hips.All(s => Math.Abs(s.Length - 5) < 1e-6));
        }

        [Fact]
        public void Triangle_Has3Hips()
        {
            var tri = new Polygon2D(new[] { new Vec2(0, 0), new Vec2(14, 0), new Vec2(3, 9) });
            Pattern2DResult r = Pattern2DEngine.Generate(tri, TestShapes.AcceptanceSettings);

            Assert.Equal(3, r.StatsOf(PatternLayer.HipRidge).LineCount);
        }

        [Fact]
        public void CentredOrigin_SplitsLeftoverEqually()
        {
            // 12.5 m along: leftover 0.5 m → 0.25 m cut pieces at both ends → 13 cross lines; 8 m across → 7.
            Pattern2DSettings s = TestShapes.AcceptanceSettings with { GridOrigin = GridOriginMode.Centred };
            Pattern2DResult r = Pattern2DEngine.Generate(TestShapes.Rectangle(12.5, 8), s);

            var grid = r.SegmentsOf(PatternLayer.Grid).Select(x => x.Segment).ToList();
            Assert.Equal(13, grid.Count(g => Math.Abs(g.Direction.X) < 1e-9));
            Assert.Equal(7, grid.Count(g => Math.Abs(g.Direction.Y) < 1e-9));
            double firstCross = grid.Where(g => Math.Abs(g.Direction.X) < 1e-9).Min(g => g.Start.X);
            Assert.Equal(0.25, firstCross, 6);
        }

        [Fact]
        public void LongestEdgeTie_UsesFirstEdgeCounterClockwise()
        {
            Vec2 dir = GridFrame.LongestEdgeDirection(TestShapes.Rectangle(10, 10));
            Assert.Equal(1.0, dir.X, 9);
            Assert.Equal(0.0, dir.Y, 9);
        }

        [Fact]
        public void ProjectX_IgnoresLongestEdge()
        {
            Polygon2D rotated = TestShapes.Transformed(TestShapes.Rectangle(12, 8), 30, Vec2.Zero);
            Pattern2DResult r = Pattern2DEngine.Generate(rotated, TestShapes.AcceptanceSettings with { GridDirection = GridDirectionMode.ProjectX });

            Assert.True(r.SegmentsOf(PatternLayer.Grid).All(s =>
                Math.Abs(s.Segment.Direction.X) < 1e-9 || Math.Abs(s.Segment.Direction.Y) < 1e-9));
        }

        [Fact]
        public void DisabledLayers_ProduceNoLines()
        {
            Pattern2DSettings s = TestShapes.AcceptanceSettings with { DrawGrid = false, DrawHipRidge = false, DrawContours = false };
            Pattern2DResult r = Pattern2DEngine.Generate(TestShapes.Rectangle(12, 8), s);

            Assert.True(r.IsValid);
            Assert.Empty(r.Segments);
            Assert.False(s.AnyLayerEnabled);
            Assert.Equal(96, r.BoardCount); // boards/tiles are still computed
        }

        [Fact]
        public void Labels_OnePerBoard_ByIdOrCode()
        {
            Pattern2DResult byId = Pattern2DEngine.Generate(TestShapes.Rectangle(12, 8), TestShapes.AcceptanceSettings with { Labels = LabelMode.Id });
            Pattern2DResult byCode = Pattern2DEngine.Generate(TestShapes.Rectangle(12, 8), TestShapes.AcceptanceSettings with { Labels = LabelMode.Code });

            Assert.Equal(96, byId.Labels.Count);
            Assert.Equal(96, byId.Labels.Select(l => l.Text).Distinct().Count());
            Assert.Equal(byId.CodeCount, byCode.Labels.Select(l => l.Text).Distinct().Count());
            Assert.Equal("R01-C01", byId.Labels.First(l => l.Position.X < 1 && l.Position.Y < 1).Text);
        }

        [Fact]
        public void BoardThickness_RangesFromTminToMax()
        {
            Pattern2DResult r = Pattern2DEngine.Generate(TestShapes.Rectangle(12, 8), TestShapes.AcceptanceSettings);

            Assert.Equal(20.0, r.Boards.Min(b => b.MinThicknessMm), 6);
            Assert.Equal(60.0, r.Boards.Max(b => b.MaxThicknessMm), 6);
            Assert.True(r.Boards.All(b => b.IsFull));
            // Corner board R01-C01 spans 0..1 m from two edges → 20..30 mm.
            BoardPiece corner = r.Boards.Single(b => b.Id == "R01-C01");
            Assert.Equal(30.0, corner.MaxThicknessMm, 6);
        }

        [Fact]
        public void InvalidSettings_ReturnErrors_NotExceptions()
        {
            Pattern2DSettings bad = TestShapes.AcceptanceSettings with { BoardWidthM = 0.2, SlopePercent = 0, ContourIntervalMm = 0 };
            Pattern2DResult r = Pattern2DEngine.Generate(TestShapes.Rectangle(12, 8), bad);

            Assert.False(r.IsValid);
            Assert.Equal(3, r.Errors.Count);
        }

        [Fact]
        public void ContourInterval_IgnoredWhenContoursOff()
        {
            Pattern2DSettings s = TestShapes.AcceptanceSettings with { DrawContours = false, ContourIntervalMm = 0 };
            Assert.Empty(SettingsValidator.Validate(s));
        }

        [Fact]
        public void ConvexClipper_ClipsLineToChord()
        {
            Segment2D? chord = ConvexClipper.ClipLine(TestShapes.Rectangle(12, 8), new Vec2(3, -100), new Vec2(0, 1));
            Assert.True(chord.HasValue);
            Assert.Equal(8.0, chord!.Value.Length, 9);

            Assert.Null(ConvexClipper.ClipLine(TestShapes.Rectangle(12, 8), new Vec2(20, 0), new Vec2(0, 1)));
        }
    }
}
