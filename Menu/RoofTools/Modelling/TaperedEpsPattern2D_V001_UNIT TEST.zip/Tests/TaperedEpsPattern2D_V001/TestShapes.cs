using System;
using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsPattern2D.V001.Core.Pattern;

namespace Revit26_Plugin.Tests.TaperedEpsPattern2D.V001
{
    /// <summary>Outlines and settings shared by the acceptance tests (metres).</summary>
    internal static class TestShapes
    {
        /// <summary>Slope 1 %, tmin 20 mm, 1 × 1 m boards, longest edge, corner origin, contours every 10 mm.</summary>
        public static Pattern2DSettings AcceptanceSettings => new Pattern2DSettings
        {
            BoardLengthM = 1.0,
            BoardWidthM = 1.0,
            SlopePercent = 1.0,
            MinThicknessMm = 20.0,
            GridDirection = GridDirectionMode.LongestEdge,
            GridOrigin = GridOriginMode.BoundingBoxCorner,
            DrawGrid = true,
            DrawHipRidge = true,
            DrawContours = true,
            ContourIntervalMm = 10.0,
            Labels = LabelMode.None
        };

        public static Polygon2D Rectangle(double w, double h) =>
            new Polygon2D(new[] { new Vec2(0, 0), new Vec2(w, 0), new Vec2(w, h), new Vec2(0, h) });

        public static Polygon2D Transformed(Polygon2D p, double angleDeg, Vec2 offset)
        {
            double a = angleDeg * Math.PI / 180.0;
            double c = Math.Cos(a), s = Math.Sin(a);
            return new Polygon2D(p.Vertices.Select(v => new Vec2(c * v.X - s * v.Y, s * v.X + c * v.Y) + offset));
        }

        public static Polygon2D RegularPolygon(int sides, double radius) =>
            new Polygon2D(Enumerable.Range(0, sides).Select(i =>
            {
                double a = 2 * Math.PI * i / sides;
                return new Vec2(radius * Math.Cos(a), radius * Math.Sin(a));
            }));

        /// <summary>Irregular convex pentagon with no parallel edges.</summary>
        public static Polygon2D Pentagon() =>
            new Polygon2D(new[] { new Vec2(0, 0), new Vec2(9.3, -1.2), new Vec2(13.1, 4.4), new Vec2(7.7, 10.6), new Vec2(-1.8, 6.3) });

        /// <summary>Concave L-shape as a list of sketch segments.</summary>
        public static IReadOnlyList<Segment2D> LShapeSegments() => ToSegments(new[]
        {
            new Vec2(0, 0), new Vec2(10, 0), new Vec2(10, 4), new Vec2(4, 4), new Vec2(4, 10), new Vec2(0, 10)
        });

        public static IReadOnlyList<Segment2D> ToSegments(IReadOnlyList<Vec2> v) =>
            Enumerable.Range(0, v.Count).Select(i => new Segment2D(v[i], v[(i + 1) % v.Count])).ToList();

        public static IReadOnlyList<IReadOnlyList<Segment2D>> OneLoop(IReadOnlyList<Segment2D> segments) =>
            new List<IReadOnlyList<Segment2D>> { segments };
    }
}
