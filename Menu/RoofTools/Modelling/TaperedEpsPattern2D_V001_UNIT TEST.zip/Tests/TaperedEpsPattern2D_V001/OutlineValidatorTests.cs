using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.TaperedEpsPattern2D.V001.Core.Pattern;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsPattern2D.V001
{
    public class OutlineValidatorTests
    {
        [Fact]
        public void ClockwiseSketch_IsReorientedCounterClockwise()
        {
            var cw = new[] { new Vec2(0, 0), new Vec2(0, 8), new Vec2(12, 8), new Vec2(12, 0) };
            OutlineValidationResult v = OutlineValidator.Validate(TestShapes.OneLoop(TestShapes.ToSegments(cw)));

            Assert.True(v.IsValid);
            Assert.True(v.Outline!.IsCounterClockwise);
            Assert.Equal("Rectangle", v.ShapeName);
        }

        [Fact]
        public void CollinearSketchSegments_AreMerged()
        {
            var split = new[] { new Vec2(0, 0), new Vec2(5, 0), new Vec2(12, 0), new Vec2(12, 3), new Vec2(12, 8), new Vec2(0, 8) };
            OutlineValidationResult v = OutlineValidator.Validate(TestShapes.OneLoop(TestShapes.ToSegments(split)));

            Assert.True(v.IsValid);
            Assert.Equal(4, v.Outline!.Count);
        }

        [Fact]
        public void ShuffledAndReversedSegments_AreChained()
        {
            var segs = TestShapes.ToSegments(new[] { new Vec2(0, 0), new Vec2(10, 0), new Vec2(10, 10), new Vec2(0, 10) }).ToList();
            var shuffled = new List<Segment2D> { segs[2], segs[0].Reversed, segs[3], segs[1].Reversed };
            OutlineValidationResult v = OutlineValidator.Validate(TestShapes.OneLoop(shuffled));

            Assert.True(v.IsValid);
            Assert.Equal("Square", v.ShapeName);
            Assert.Equal(100.0, v.Outline!.Area, 9);
        }

        [Fact]
        public void TwoLoops_AreRejectedAsOpenings()
        {
            var outer = TestShapes.ToSegments(TestShapes.Rectangle(12, 8).Vertices);
            var hole = TestShapes.ToSegments(TestShapes.Transformed(TestShapes.Rectangle(2, 2), 0, new Vec2(5, 3)).Vertices);
            OutlineValidationResult v = OutlineValidator.Validate(new List<IReadOnlyList<Segment2D>> { outer, hole });

            Assert.False(v.IsValid);
            Assert.Contains("Openings", v.Errors[0]);
        }

        [Fact]
        public void CurvedSegments_AreRejected()
        {
            OutlineValidationResult v = OutlineValidator.Validate(
                TestShapes.OneLoop(TestShapes.ToSegments(TestShapes.Rectangle(12, 8).Vertices)), nonLinearCurveCount: 1);

            Assert.False(v.IsValid);
            Assert.Contains("straight lines", v.Errors[0]);
        }

        [Fact]
        public void OpenLoop_IsRejected()
        {
            var open = TestShapes.ToSegments(TestShapes.Rectangle(12, 8).Vertices).Take(3).ToList();
            OutlineValidationResult v = OutlineValidator.Validate(TestShapes.OneLoop(open));

            Assert.False(v.IsValid);
            Assert.Contains("not closed", v.Errors[0]);
        }

        [Fact]
        public void SelfOverlappingStar_IsNotConvex()
        {
            var star = Enumerable.Range(0, 5)
                .Select(i => TestShapes.RegularPolygon(5, 5).Vertices[(i * 2) % 5])
                .ToList();
            OutlineValidationResult v = OutlineValidator.Validate(TestShapes.OneLoop(TestShapes.ToSegments(star)));

            Assert.False(v.IsValid);
        }
    }
}
