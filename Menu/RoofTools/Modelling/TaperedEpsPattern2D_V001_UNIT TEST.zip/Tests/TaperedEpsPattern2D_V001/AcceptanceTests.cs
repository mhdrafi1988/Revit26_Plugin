using System;
using System.Linq;
using Revit26_Plugin.TaperedEpsPattern2D.V001.Core.Pattern;
using Xunit;

namespace Revit26_Plugin.Tests.TaperedEpsPattern2D.V001
{
    /// <summary>The acceptance cases from the tool brief.</summary>
    public class AcceptanceTests
    {
        private static Pattern2DResult Run(Polygon2D outline) =>
            Pattern2DEngine.Generate(outline, TestShapes.AcceptanceSettings);

        [Fact]
        public void Rectangle12x8_Has18ContinuousGridLines_Totalling172m()
        {
            Pattern2DResult r = Run(TestShapes.Rectangle(12, 8));

            Assert.True(r.IsValid);
            var grid = r.SegmentsOf(PatternLayer.Grid).Select(s => s.Segment).ToList();
            Assert.Equal(18, grid.Count);
            Assert.Equal(11, grid.Count(s => Math.Abs(s.Length - 8) < 1e-6));   // cross lines
            Assert.Equal(7, grid.Count(s => Math.Abs(s.Length - 12) < 1e-6));   // along lines
            Assert.Equal(172.0, r.StatsOf(PatternLayer.Grid).TotalLengthM, 6);
        }

        [Fact]
        public void Rectangle12x8_Has4HipsAnd1Ridge4mLong()
        {
            Pattern2DResult r = Run(TestShapes.Rectangle(12, 8));

            var hips = r.SegmentsOf(PatternLayer.HipRidge).Select(s => s.Segment).ToList();
            Assert.Equal(5, hips.Count);
            Assert.Equal(4, hips.Count(s => Math.Abs(s.Length - Math.Sqrt(32)) < 1e-6));
            Segment2D ridge = Assert.Single(hips.Where(s => Math.Abs(s.Direction.Y) < 1e-9).ToList());
            Assert.Equal(4.0, ridge.Length, 6);
            Assert.Equal(4.0, ridge.Start.Y, 6);
        }

        [Fact]
        public void Rectangle12x8_Has3ContourLoops_12Lines_Max60mm()
        {
            Pattern2DResult r = Run(TestShapes.Rectangle(12, 8));

            Assert.Equal(new[] { 30.0, 40.0, 50.0 }, r.Contours.Select(c => Math.Round(c.ThicknessMm, 6)).ToArray());
            Assert.Equal(12, r.StatsOf(PatternLayer.Contour).LineCount);
            Assert.Equal(60.0, r.MaxThicknessMm, 6);
        }

        [Fact]
        public void Square10x10_Has18GridLines_4Hips_NoRidge()
        {
            Pattern2DResult r = Run(TestShapes.Rectangle(10, 10));

            Assert.Equal(18, r.StatsOf(PatternLayer.Grid).LineCount);
            Assert.Equal(180.0, r.StatsOf(PatternLayer.Grid).TotalLengthM, 6);

            var hips = r.SegmentsOf(PatternLayer.HipRidge).Select(s => s.Segment).ToList();
            Assert.Equal(4, hips.Count);
            Assert.True(hips.All(s => Math.Abs(s.Length - Math.Sqrt(50)) < 1e-6));
        }

        [Fact]
        public void Square10x10_Has4ContourLoops_16Lines_Max70mm()
        {
            Pattern2DResult r = Run(TestShapes.Rectangle(10, 10));

            Assert.Equal(new[] { 30.0, 40.0, 50.0, 60.0 }, r.Contours.Select(c => Math.Round(c.ThicknessMm, 6)).ToArray());
            Assert.Equal(16, r.StatsOf(PatternLayer.Contour).LineCount);
            Assert.Equal(70.0, r.MaxThicknessMm, 6);
        }

        [Fact]
        public void ConcaveLShape_IsValidationError_NotException()
        {
            OutlineValidationResult v = OutlineValidator.Validate(TestShapes.OneLoop(TestShapes.LShapeSegments()));

            Assert.False(v.IsValid);
            Assert.Null(v.Outline);
            Assert.Contains("split the roof into convex parts", v.Errors[0]);
            Assert.Equal("Concave", v.ShapeName);

            Pattern2DResult r = Pattern2DEngine.Generate(v.Outline, TestShapes.AcceptanceSettings);
            Assert.False(r.IsValid);
            Assert.Empty(r.Segments);
        }
    }
}
