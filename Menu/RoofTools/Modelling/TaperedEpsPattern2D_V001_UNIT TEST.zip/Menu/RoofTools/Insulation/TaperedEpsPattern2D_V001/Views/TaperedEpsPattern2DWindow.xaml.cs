using System;
using Revit26_Plugin.Shared.UI;
using Revit26_Plugin.TaperedEpsPattern2D.V001.ViewModels;

namespace Revit26_Plugin.TaperedEpsPattern2D.V001.Views
{
    /// <summary>Modeless tool window. All logic lives in <see cref="TaperedEpsPattern2DViewModel"/>.</summary>
    public partial class TaperedEpsPattern2DWindow : ToolWindowShell
    {
        public TaperedEpsPattern2DWindow(TaperedEpsPattern2DViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
            viewModel.RequestClose += OnRequestClose;
            Closed += (_, _) => viewModel.RequestClose -= OnRequestClose;
        }

        private void OnRequestClose(object? sender, EventArgs e) => Close();
    }
}
