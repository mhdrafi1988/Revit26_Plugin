using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.TaperedEpsPattern2D.V001.Core.Pattern
{
    /// <summary>Everything the preview, the metric tiles and the Revit writer need.</summary>
    public sealed class Pattern2DResult
    {
        public bool IsValid => Errors.Count == 0;
        public IReadOnlyList<string> Errors { get; init; } = Array.Empty<string>();

        public Polygon2D Outline { get; init; } = Polygon2D.Empty;
        public GridFrame? Frame { get; init; }
        public IReadOnlyList<SlopeFace> Faces { get; init; } = Array.Empty<SlopeFace>();
        public IReadOnlyList<BoardPiece> Boards { get; init; } = Array.Empty<BoardPiece>();
        public IReadOnlyList<ContourLoop> Contours { get; init; } = Array.Empty<ContourLoop>();
        public IReadOnlyList<PatternSegment> Segments { get; init; } = Array.Empty<PatternSegment>();
        public IReadOnlyList<PatternLabel> Labels { get; init; } = Array.Empty<PatternLabel>();

        public double MaxThicknessMm { get; init; }

        public int BoardCount => Boards.Count;
        public int CodeCount => Boards.Select(b => b.Code).Distinct().Count();

        public IEnumerable<PatternSegment> SegmentsOf(PatternLayer layer) => Segments.Where(s => s.Layer == layer);

        public LayerStats StatsOf(PatternLayer layer)
        {
            List<PatternSegment> list = SegmentsOf(layer).ToList();
            return new LayerStats(layer, list.Count, list.Sum(s => s.Segment.Length));
        }

        public IReadOnlyList<LayerStats> AllStats() =>
            Enum.GetValues(typeof(PatternLayer)).Cast<PatternLayer>().Select(StatsOf).ToList();

        public static Pattern2DResult Failed(IReadOnlyList<string> errors) => new Pattern2DResult { Errors = errors };
    }
}
