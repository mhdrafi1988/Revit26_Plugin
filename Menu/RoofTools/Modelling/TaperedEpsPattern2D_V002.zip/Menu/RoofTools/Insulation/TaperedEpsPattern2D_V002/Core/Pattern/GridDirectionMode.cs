namespace Revit26_Plugin.TaperedEpsPattern2D.V002.Core.Pattern
{
    public enum GridDirectionMode
    {
        /// <summary>Board length runs along the longest outline edge (tie → first edge CCW).</summary>
        LongestEdge,

        /// <summary>Board length runs along the project (internal) X axis.</summary>
        ProjectX,

        /// <summary>Board length runs parallel to the outline edge <c>Pattern2DSettings.AlignEdgeIndex</c>.</summary>
        SelectedEdge
    }
}
