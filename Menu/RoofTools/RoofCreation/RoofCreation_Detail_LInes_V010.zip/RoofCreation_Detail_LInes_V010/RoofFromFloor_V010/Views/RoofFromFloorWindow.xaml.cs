using Autodesk.Revit.UI;
using Revit26_Plugin.RoofFromFloor.V010.ViewModels;
using Revit26_Plugin.Shared.Models;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;

namespace Revit26_Plugin.RoofFromFloor.V010.Views
{
    public partial class RoofFromFloorWindow : Window
    {
        public RoofFromFloorWindow(UIApplication app)
        {
            InitializeComponent();

            // Converters registered here instead of XAML to avoid design-time
            // assembly resolution errors in the VS XAML editor.
            InitConverters();

            var vm = new RoofFromFloorViewModel(app, this);
            DataContext = vm;

            vm.LogEntries.CollectionChanged += LogEntries_CollectionChanged;
        }

        private void InitConverters()
        {
            Resources["BoolToVisibility"]    = new BoolToVisibilityConverter();
            Resources["InverseBoolToVisibility"] = new InverseBoolToVisibilityConverter();
            Resources["InverseBool"]         = new InverseBoolConverter();
            Resources["LogLevelColor"]       = new LogLevelToColorConverter();
        }

        private void LogEntries_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            LogScroller.ScrollToBottom();
        }
    }
}
