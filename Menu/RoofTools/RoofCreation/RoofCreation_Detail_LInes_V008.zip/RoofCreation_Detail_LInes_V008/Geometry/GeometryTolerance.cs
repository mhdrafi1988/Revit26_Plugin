namespace Revit26_Plugin.RoofFromFloor.V008.Geometry
{
    public static class GeometryTolerance
    {
        // 10 mm in feet
        public const double EndpointTolerance = 0.0328084;
    }
}
