using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace Revit26_Plugin.RoofPointElevationSync.V002
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIDocument uiDoc = commandData.Application.ActiveUIDocument;

            var window = new MainWindow(uiDoc)
            {
                Owner = null
            };
            // Modeless, Close-only per Autodesk API dialog guideline (no OK/Cancel that could
            // desync from a live Revit selection state).
            window.Show();

            return Result.Succeeded;
        }
    }
}
