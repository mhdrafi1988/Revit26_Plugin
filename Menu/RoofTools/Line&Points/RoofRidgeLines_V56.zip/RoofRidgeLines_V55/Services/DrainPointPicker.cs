using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace Revit26_Plugin.RoofTools.LineAndPoints.RoofRidgeLines.V55.Services
{
    /// <summary>
    /// Utility to pick drain points on a roof, snapped to the nearest known vertex.
    /// </summary>
    public static class DrainPointPicker
    {
        /// <summary>
        /// Lets the user pick points on the roof surface and returns the nearest known vertex
        /// for each pick. No document modification is required to obtain the candidate
        /// vertices — see <see cref="GetCandidateVertices"/>.
        /// </summary>
        /// <param name="uiDoc">Active UIDocument</param>
        /// <param name="roof">The roof on which drains are placed</param>
        /// <returns>List of XYZ positions (Z=0) of the selected drain vertices.</returns>
        /// <exception cref="InvalidOperationException">If no candidate vertices exist.</exception>
        /// <exception cref="Autodesk.Revit.Exceptions.OperationCanceledException">If user cancels picking.</exception>
        public static List<XYZ> PickDrainPoints(UIDocument uiDoc, RoofBase roof)
        {
            // Read-only — no transaction, no Shape Editing enable/rollback needed.
            List<XYZ> vertices = GetCandidateVertices(roof);

            if (vertices == null || vertices.Count == 0)
                throw new InvalidOperationException("The roof has no vertices or boundary to pick drains against.");

            // Let user pick points on the roof. OperationCanceledException propagates
            // naturally to the caller — no rollback needed since nothing was changed.
            IList<Reference> pickedRefs = uiDoc.Selection.PickObjects(
                ObjectType.PointOnElement,
                "Pick drain points on the roof surface. Press ESC to cancel.");

            // Validate that all picked points belong to the selected roof
            var drainPoints = new List<XYZ>();
            foreach (var refPick in pickedRefs)
            {
                if (refPick.ElementId != roof.Id)
                    throw new InvalidOperationException("One or more points were not picked on the selected roof.");
                drainPoints.Add(refPick.GlobalPoint);
            }

            if (drainPoints.Count == 0)
                throw new InvalidOperationException("No drain points were picked.");

            // Snap each clicked point to the nearest candidate vertex
            var finalDrainLocations = new List<XYZ>();
            foreach (var clickedPt in drainPoints)
            {
                XYZ nearest = FindNearestVertex(clickedPt, vertices);
                finalDrainLocations.Add(new XYZ(nearest.X, nearest.Y, 0));
            }

            return finalDrainLocations;
        }

        /// <summary>
        /// Returns the vertices to snap picks against, without ever calling
        /// <see cref="SlabShapeEditor.Enable"/> and without any transaction:
        /// <list type="bullet">
        /// <item>If Shape Editing is already enabled on the roof (e.g. drain points were
        /// already placed by an earlier tool such as AutoSlopeByPoint), its existing
        /// <see cref="SlabShapeEditor.SlabShapeVertices"/> are read directly — these may
        /// include interior points that aren't on the boundary.</item>
        /// <item>If Shape Editing has never been enabled (or the roof type doesn't support
        /// it), there are no SlabShapeVertex sub-elements to read — Revit only creates them
        /// once Enable() is called. In that case the equivalent data is the roof's boundary
        /// corner points, read directly from its sketch/solid geometry via
        /// <see cref="RoofBoundaryService"/> (the same read-only extraction already used
        /// elsewhere in the pipeline).</item>
        /// </list>
        /// </summary>
        private static List<XYZ> GetCandidateVertices(RoofBase roof)
        {
            SlabShapeEditor editor = roof.GetSlabShapeEditor();

            if (editor != null && editor.IsEnabled)
            {
                var existing = editor.SlabShapeVertices
                    .Cast<SlabShapeVertex>()
                    .Select(v => v.Position)
                    .Where(p => p != null)
                    .ToList();

                if (existing.Count > 0)
                    return existing;
            }

            // Shape Editing not enabled (or yielded nothing) — fall back to the
            // roof's boundary geometry, no Shape Editing required.
            return new RoofBoundaryService().ExtractBoundary(roof);
        }

        private static XYZ FindNearestVertex(XYZ clickedPoint, List<XYZ> vertices)
        {
            double minDistSq = double.MaxValue;
            XYZ nearest = null;
            foreach (var v in vertices)
            {
                double dx = clickedPoint.X - v.X;
                double dy = clickedPoint.Y - v.Y;
                double distSq = dx * dx + dy * dy;
                if (distSq < minDistSq)
                {
                    minDistSq = distSq;
                    nearest = v;
                }
            }
            return nearest ?? XYZ.Zero;
        }
    }
}