using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.Views
{
    /// <summary>
    /// Code-behind is intentionally minimal — all behavior is driven by
    /// WorksetsElementsBrowserViewModel via data binding and commands (MVVM).
    /// The exceptions are the Type-row click, which needs the raw mouse event
    /// (a TreeView item click doesn't distinguish "clicked the checkbox" from
    /// "clicked the label" through commands alone), and keeping the log view
    /// scrolled to the newest line.
    /// </summary>
    public partial class WorksetsElementsBrowserWindow : Window
    {
        private INotifyCollectionChanged _logCollection;

        public WorksetsElementsBrowserWindow()
        {
            InitializeComponent();
            DataContextChanged += OnDataContextChanged;
        }

        private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (_logCollection != null)
                _logCollection.CollectionChanged -= OnLogCollectionChanged;

            _logCollection = (e.NewValue as WorksetsElementsBrowserViewModel)?.LogEntries;

            if (_logCollection != null)
                _logCollection.CollectionChanged += OnLogCollectionChanged;
        }

        /// <summary>Keeps the newest log line in view without the ViewModel knowing about the ListBox.</summary>
        private void OnLogCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action != NotifyCollectionChangedAction.Add) return;
            if (LogList.Items.Count == 0) return;

            LogList.ScrollIntoView(LogList.Items[LogList.Items.Count - 1]);
        }

        private void TypeName_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (sender is not FrameworkElement element) return;
            if (element.DataContext is not TreeNodeViewModel node) return;
            if (node.Kind != ElementTreeNodeKind.Type) return;

            (DataContext as WorksetsElementsBrowserViewModel)?.OnTypeRowClicked(node);
            e.Handled = true;
        }

        private void ShowTypeIn3D_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not FrameworkElement element) return;
            if (element.DataContext is not TreeNodeViewModel node) return;
            if (node.Kind != ElementTreeNodeKind.Type) return;

            (DataContext as WorksetsElementsBrowserViewModel)?.OnTypeRowClicked(node);
            e.Handled = true;
        }

        /// <summary>Window never auto-closes on completion; this only runs when the user closes it. Settings are saved before the ViewModel releases its Revit resources.</summary>
        private void Window_Closing(object sender, CancelEventArgs e)
        {
            if (_logCollection != null)
            {
                _logCollection.CollectionChanged -= OnLogCollectionChanged;
                _logCollection = null;
            }

            (DataContext as WorksetsElementsBrowserViewModel)?.Shutdown();
        }
    }
}
