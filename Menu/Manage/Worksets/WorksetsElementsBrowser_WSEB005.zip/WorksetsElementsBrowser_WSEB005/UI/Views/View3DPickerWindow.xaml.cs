using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using Autodesk.Revit.UI;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.Views
{
    /// <summary>
    /// Modal 3D-view picker: typable/searchable list, offered both when the
    /// user clicks a Type row and when a checked-elements action button is
    /// pressed. Call <see cref="Initialize"/> before ShowDialog(); on a true
    /// DialogResult, <see cref="SelectedView"/> holds the user's pick.
    ///
    /// WSEB005: pre-selects the view used last time (persisted in settings.json).
    /// </summary>
    public partial class View3DPickerWindow : Window
    {
        public List<View3DOption> Views { get; set; } = new();
        public View3DOption SelectedView { get; private set; }

        public View3DPickerWindow()
        {
            InitializeComponent();
        }

        public void Initialize(string prompt, List<View3DOption> views, string preferredViewName = null)
        {
            PromptText.Text = prompt;
            Views = views ?? new List<View3DOption>();

            ViewsListBox.ItemsSource = CollectionViewSource.GetDefaultView(Views);

            if (Views.Count == 0) return;

            int preferredIndex = string.IsNullOrWhiteSpace(preferredViewName)
                ? -1
                : Views.FindIndex(view => string.Equals(view.Name, preferredViewName, StringComparison.OrdinalIgnoreCase));

            ViewsListBox.SelectedIndex = preferredIndex >= 0 ? preferredIndex : 0;
            ViewsListBox.ScrollIntoView(ViewsListBox.SelectedItem);
        }

        private void SearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (ViewsListBox.ItemsSource is not ICollectionView view) return;

            string query = SearchBox.Text.Trim();
            view.Filter = query.Length == 0
                ? (Predicate<object>)null
                : o => ((View3DOption)o).Name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0;

            if (ViewsListBox.Items.Count > 0)
                ViewsListBox.SelectedIndex = 0;
        }

        private void SearchBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TryConfirm();
                e.Handled = true;
            }
            else if (e.Key == Key.Down && ViewsListBox.Items.Count > 0)
            {
                ViewsListBox.Focus();
                if (ViewsListBox.SelectedIndex < 0) ViewsListBox.SelectedIndex = 0;
                e.Handled = true;
            }
        }

        private void ViewsListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e) => TryConfirm();

        private void OpenView_Click(object sender, RoutedEventArgs e) => TryConfirm();

        private void No_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void TryConfirm()
        {
            var selected = ViewsListBox.SelectedItem as View3DOption
                ?? ViewsListBox.Items.Cast<View3DOption>().FirstOrDefault();

            if (selected == null)
            {
                TaskDialog.Show("Worksets & Elements Browser", "No 3D view matches your search.");
                return;
            }

            SelectedView = selected;
            DialogResult = true;
            Close();
        }
    }
}
