using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Events;
using Autodesk.Revit.UI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Services;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Infrastructure.ExternalEvents;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Infrastructure.Helpers;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.Views;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels
{
    public partial class WorksetsElementsBrowserViewModel : ObservableObject, IDisposable
    {
        private const string ToolTitle = "Worksets & Elements Browser";
        private const int SearchDebounceMilliseconds = 250;

        private readonly UIDocument _uiDoc;
        private readonly UIApplication _uiApp;
        private readonly ExternalEvent _event;
        private readonly WorksetsElementsBrowserHandler _handler;
        private readonly Dispatcher _dispatcher;
        private readonly IntPtr _mainWindowHandle;
        private readonly WorksetTreeMapper _mapper = new();
        private readonly TreeChangeNotifier _notifier = new();
        private readonly DispatcherTimer _searchDebounce;

        private WsebSettings _settings = new();
        private TreeStatistics _statistics = new();
        private CheckedSelection _checkedSelection = new();
        private List<WorksetNodeData> _lastBuildWorksets = new();

        /// <summary>Set right before Raise() to tell OnHandlerRequestCompleted what follow-up to run once results land.</summary>
        private Action _pendingCompletion;

        /// <summary>True while settings are being applied, so restoring a stored filter does not count as a user change.</summary>
        private bool _isApplyingSettings;

        private bool _disposed;

        public ObservableCollection<TreeNodeViewModel> RootNodes { get; } = new();
        public ObservableCollection<LogEntry> LogEntries { get; } = new();
        public ObservableCollection<WorksetVisibilityOption> WorksetVisibilityOptions { get; } = new();

        [ObservableProperty] private string _documentTitle = string.Empty;
        [ObservableProperty] private string _searchText = string.Empty;
        [ObservableProperty] private bool _isBusy;
        [ObservableProperty] private string _summaryText = string.Empty;
        [ObservableProperty] private double _progress;   // ToolWindowShell status strip (CLAUDE.md v1.1)
        [ObservableProperty] private string _checkedSummaryText = "0 types checked · 0 elements";
        [ObservableProperty] private string _statusText = "Ready";
        [ObservableProperty] private string _treeCardTitle = "Worksets, Categories and Types";
        [ObservableProperty] private string _visibleWorksetText = string.Empty;
        [ObservableProperty] private string _worksetTotalLabel = "Worksets";
        [ObservableProperty] private int _worksetsWithElements;
        [ObservableProperty] private int _worksetsEmpty;
        [ObservableProperty] private int _worksetsViewSpecificOnly;
        [ObservableProperty] private int _worksetsClosed;
        [ObservableProperty] private bool _isEmptyOnlyMode;
        [ObservableProperty] private bool _isLogExpanded;
        [ObservableProperty] private string _logSummaryText = "0 entries";
        [ObservableProperty] private bool _isTreeStale;
        [ObservableProperty] private double _windowWidth = 900;
        [ObservableProperty] private double _windowHeight = 790;
        [ObservableProperty] private WorksetVisibilityOption _selectedVisibilityOption;

        public event Action CloseRequested;

        public WorksetsElementsBrowserViewModel(UIDocument uiDoc, IntPtr mainWindowHandle)
        {
            _uiDoc = uiDoc;
            _uiApp = uiDoc.Application;
            _mainWindowHandle = mainWindowHandle;
            _dispatcher = Dispatcher.CurrentDispatcher;

            _handler = new WorksetsElementsBrowserHandler(uiDoc);
            _handler.RequestCompleted += OnHandlerRequestCompleted;
            _event = ExternalEvent.Create(_handler);

            _notifier.Changed += RefreshCheckedSummary;
            LogEntries.CollectionChanged += OnLogEntriesChanged;

            _searchDebounce = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(SearchDebounceMilliseconds)
            };
            _searchDebounce.Tick += OnSearchDebounceTick;

            DocumentTitle = uiDoc.Document.Title;

            BuildVisibilityOptions();
            LoadSettings();

            // Idle windows go stale: the model can change under us while this
            // window sits open (UI standard v1.1). WSEB004 loaded once in the
            // constructor and never noticed.
            _uiApp.Application.DocumentChanged += OnDocumentChanged;

            RunLoadTree();
        }

        // ─────────────────────────────────────────────────────────────
        // Settings
        // ─────────────────────────────────────────────────────────────

        private void BuildVisibilityOptions()
        {
            WorksetVisibilityOptions.Add(new WorksetVisibilityOption(WorksetVisibilityMode.All, "All Worksets"));
            WorksetVisibilityOptions.Add(new WorksetVisibilityOption(WorksetVisibilityMode.WithElementsOnly, "With Elements Only"));
            WorksetVisibilityOptions.Add(new WorksetVisibilityOption(WorksetVisibilityMode.EmptyOnly, "Empty Only"));
            WorksetVisibilityOptions.Add(new WorksetVisibilityOption(WorksetVisibilityMode.ClosedOnly, "Closed Worksets"));
        }

        private void LoadSettings()
        {
            _settings = WsebSettingsService.Load(out string warning);

            _isApplyingSettings = true;
            try
            {
                var mode = Enum.TryParse(_settings.WorksetVisibility, out WorksetVisibilityMode parsed)
                    ? parsed
                    : WorksetVisibilityMode.WithElementsOnly;

                SelectedVisibilityOption = WorksetVisibilityOptions.FirstOrDefault(o => o.Mode == mode)
                                           ?? WorksetVisibilityOptions.First();

                IsLogExpanded = _settings.IsLogExpanded;
                WindowWidth = _settings.WindowWidth > 0 ? _settings.WindowWidth : 900;
                WindowHeight = _settings.WindowHeight > 0 ? _settings.WindowHeight : 790;
            }
            finally
            {
                _isApplyingSettings = false;
            }

            Log(LogLevel.Info, $"Settings loaded (schema v{_settings.SchemaVersion}) — {WsebSettingsService.SettingsPath}");
            if (!string.IsNullOrEmpty(warning))
                Log(LogLevel.Warning, warning);
        }

        private void SaveSettings()
        {
            _settings.WorksetVisibility = (SelectedVisibilityOption?.Mode ?? WorksetVisibilityMode.WithElementsOnly).ToString();
            _settings.IsLogExpanded = IsLogExpanded;
            _settings.WindowWidth = WindowWidth;
            _settings.WindowHeight = WindowHeight;

            if (!WsebSettingsService.Save(_settings, out string error))
                Log(LogLevel.Warning, error);
        }

        // ─────────────────────────────────────────────────────────────
        // Activity log
        // ─────────────────────────────────────────────────────────────

        private void Log(LogLevel level, string message)
        {
            LogEntries.Add(new LogEntry(level, message));
            WsebDebugLog.Write(level, message);
        }

        private void OnLogEntriesChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            int warnings = LogEntries.Count(entry => entry.Level == LogLevel.Warning);
            int errors = LogEntries.Count(entry => entry.Level == LogLevel.Error);

            var builder = new StringBuilder($"{LogEntries.Count} entr{(LogEntries.Count == 1 ? "y" : "ies")}");
            if (warnings > 0) builder.Append($" · {warnings} warning{(warnings == 1 ? "" : "s")}");
            if (errors > 0) builder.Append($" · {errors} error{(errors == 1 ? "" : "s")}");

            LogSummaryText = builder.ToString();
        }

        [RelayCommand]
        private void ToggleLog() => IsLogExpanded = !IsLogExpanded;

        [RelayCommand]
        private void CopyAllLog()
            => CopyToClipboard(string.Join(Environment.NewLine, LogEntries.Select(entry => entry.ToString())), "log");

        [RelayCommand]
        private void CopySelectedLog(object selectedItems)
        {
            var entries = (selectedItems as System.Collections.IList)?.Cast<object>().OfType<LogEntry>().ToList()
                          ?? new List<LogEntry>();

            if (entries.Count == 0)
            {
                Log(LogLevel.Warning, "Copy Selected: no log rows are selected.");
                return;
            }

            CopyToClipboard(string.Join(Environment.NewLine, entries.Select(entry => entry.ToString())), $"{entries.Count} log row(s)");
        }

        [RelayCommand]
        private void ClearLog()
        {
            LogEntries.Clear();
            Log(LogLevel.Info, "Log cleared.");
        }

        [RelayCommand]
        private void ExportLog()
        {
            string folder = ResolveFolder(_settings.LogExportFolder, "Choose a folder for the log file");
            if (string.IsNullOrEmpty(folder)) return;

            _settings.LogExportFolder = folder;

            if (LogExportHelper.WriteTextFile(folder, LogExportHelper.BuildLogFileName(),
                    LogExportHelper.BuildLogText(LogEntries), out string path, out string error))
                Log(LogLevel.Success, $"Log exported — {path}");
            else
                Log(LogLevel.Error, $"Log could not be exported: {error}");
        }

        /// <summary>Auto-save after an operation completes, to the suite's standard Logs folder — no dialog, no folder prompt.</summary>
        private void AutoSaveLog()
        {
            if (LogExportHelper.WriteTextFile(LogExportHelper.DefaultAutoSaveFolder,
                    LogExportHelper.BuildLogFileName(), LogExportHelper.BuildLogText(LogEntries),
                    out string path, out string error))
                WsebDebugLog.Write($"Log auto-saved to {path}");
            else
                Log(LogLevel.Warning, $"Log auto-save failed: {error}");
        }

        private void CopyToClipboard(string text, string what)
        {
            if (string.IsNullOrEmpty(text))
            {
                Log(LogLevel.Warning, $"Nothing to copy ({what}).");
                return;
            }

            try
            {
                Clipboard.SetText(text);
                Log(LogLevel.Success, $"Copied {what} to the clipboard.");
            }
            catch (Exception ex)
            {
                // The clipboard is a shared OS resource and can be locked by
                // another process — a Warning, never a blocking dialog.
                Log(LogLevel.Warning, $"Clipboard is unavailable right now ({ex.Message}).");
            }
        }

        /// <summary>Asks for an export folder once per session and reuses the answer (suite convention).</summary>
        private string ResolveFolder(string remembered, string title)
        {
            if (!string.IsNullOrWhiteSpace(remembered) && System.IO.Directory.Exists(remembered))
                return remembered;

            try
            {
                var dialog = new Microsoft.Win32.OpenFolderDialog
                {
                    Title = title,
                    Multiselect = false
                };

                if (dialog.ShowDialog() == true && !string.IsNullOrWhiteSpace(dialog.FolderName))
                    return dialog.FolderName;

                Log(LogLevel.Info, "Export cancelled — no folder chosen.");
                return string.Empty;
            }
            catch (Exception ex)
            {
                Log(LogLevel.Warning, $"Folder picker unavailable ({ex.Message}) — using the default Logs folder.");
                return LogExportHelper.DefaultAutoSaveFolder;
            }
        }

        // ─────────────────────────────────────────────────────────────
        // Filtering
        // ─────────────────────────────────────────────────────────────

        /// <summary>Debounced: the filter walks every node, and re-walking on each keystroke was visibly slow on a model with thousands of type rows.</summary>
        partial void OnSearchTextChanged(string value)
        {
            _searchDebounce.Stop();
            _searchDebounce.Start();
        }

        private void OnSearchDebounceTick(object sender, EventArgs e)
        {
            _searchDebounce.Stop();
            ApplyFilters();
        }

        partial void OnSelectedVisibilityOptionChanged(WorksetVisibilityOption value)
        {
            if (_isApplyingSettings) return;
            ApplyFilters();
            SaveSettings();
        }

        /// <summary>
        /// ONE pass that applies the search text and the workset-visibility
        /// mode together. In WSEB004 these were two independent passes over
        /// IsVisible, so typing in the search box re-showed worksets the
        /// hide-empty filter had hidden, and vice versa.
        /// </summary>
        private void ApplyFilters()
        {
            var mode = SelectedVisibilityOption?.Mode ?? WorksetVisibilityMode.All;
            string query = SearchText ?? string.Empty;

            foreach (var root in RootNodes)
                root.ApplyFilters(query, mode);

            int visible = RootNodes.Count(node => node.IsVisible);
            VisibleWorksetText = $"{visible:N0} of {RootNodes.Count:N0} shown";
            IsEmptyOnlyMode = mode == WorksetVisibilityMode.EmptyOnly;

            TreeCardTitle = mode switch
            {
                WorksetVisibilityMode.EmptyOnly => "Empty Worksets",
                WorksetVisibilityMode.ClosedOnly => "Closed Worksets",
                WorksetVisibilityMode.WithElementsOnly => "Worksets With Elements",
                _ => "Worksets, Categories and Types"
            };

            UpdateStatusText();
            NotifyCommandStates();

            Log(LogLevel.Info, $"Filter applied: WorksetVisibility={mode}, Search=\"{query}\" → {visible:N0} of {RootNodes.Count:N0} visible");
        }

        [RelayCommand]
        private void ResetFilters()
        {
            SearchText = string.Empty;
            SelectedVisibilityOption = WorksetVisibilityOptions.First(option => option.Mode == WorksetVisibilityMode.All);
            Log(LogLevel.Info, "Filters reset (checked rows left as they were).");
        }

        // ─────────────────────────────────────────────────────────────
        // Load / refresh
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Single choke point for every Raise() in this ViewModel. Guards
        /// against a second request starting while one is still in flight
        /// (e.g. a double-click on an action button) — without this, the
        /// second call would overwrite _handler's input properties and
        /// _pendingCompletion out from under the first request.
        /// </summary>
        private void RaiseRequest(WorksetsElementsBrowserRequest request, Action onCompleted)
        {
            if (IsBusy)
            {
                WsebDebugLog.Write($"RaiseRequest({request}) SKIPPED: already IsBusy");
                return;
            }

            IsBusy = true;
            _handler.Request = request;
            _pendingCompletion = onCompleted;

            var raiseResult = _event.Raise();
            WsebDebugLog.Write($"RaiseRequest({request}) -> Raise() returned {raiseResult}");
        }

        private void RunLoadTree() => RaiseRequest(WorksetsElementsBrowserRequest.LoadTree, HandleLoadTreeCompleted);

        [RelayCommand(CanExecute = nameof(CanRefresh))]
        private void Refresh()
        {
            Log(LogLevel.Info, "Refresh requested — rebuilding the tree (checked rows are cleared).");
            RunLoadTree();
        }

        private bool CanRefresh() => !IsBusy;

        private void HandleLoadTreeCompleted()
        {
            RootNodes.Clear();
            _lastBuildWorksets = new List<WorksetNodeData>();

            if (!_handler.LastRunSucceeded)
            {
                Log(LogLevel.Error, $"Tree load failed: {_handler.ErrorMessage}");
                TaskDialog.Show(ToolTitle, $"Could not load worksets and elements: {_handler.ErrorMessage}");
                return;
            }

            var build = _handler.LoadedTree;

            if (!build.IsWorkshared)
            {
                SummaryText = "Document is not workshared — no worksets";
                WorksetTotalLabel = "Worksets — none";
                VisibleWorksetText = string.Empty;
                StatusText = "This document has no worksharing enabled.";
                TaskDialog.Show(ToolTitle,
                    "This document is not workshared, so it has no worksets to browse.\n\n" +
                    "Enable worksharing (Collaborate tab) or open a workshared model, then reopen this tool.");
                return;
            }

            _lastBuildWorksets = build.Worksets;

            var roots = _mapper.Map(build, _notifier, out _statistics);
            foreach (var root in roots)
                RootNodes.Add(root);

            SummaryText = $"{_statistics.CategoryCount:N0} categor{(_statistics.CategoryCount == 1 ? "y" : "ies")} · " +
                          $"{_statistics.TypeCount:N0} type{(_statistics.TypeCount == 1 ? "" : "s")} · " +
                          $"{_statistics.ElementCount:N0} elements";

            WorksetTotalLabel = $"Worksets — {_statistics.WorksetCount:N0} Total";
            WorksetsWithElements = _statistics.WorksetsWithElements;
            WorksetsEmpty = _statistics.WorksetsEmpty;
            WorksetsViewSpecificOnly = _statistics.WorksetsViewSpecificOnly;
            WorksetsClosed = _statistics.WorksetsClosed;

            if (_statistics.WorksetsViewSpecificOnly > 0)
                Log(LogLevel.Warning,
                    $"{_statistics.WorksetsEmpty:N0} workset(s) are truly empty; " +
                    $"{_statistics.WorksetsViewSpecificOnly:N0} hold view-specific elements only (NOT safe to delete).");

            IsTreeStale = false;
            ApplyFilters();
            RefreshCheckedSummary();
        }

        // ─────────────────────────────────────────────────────────────
        // DocumentChanged — stale-tree notice
        // ─────────────────────────────────────────────────────────────

        private void OnDocumentChanged(object sender, DocumentChangedEventArgs e)
        {
            // Fires on Revit's thread, inside its own call stack — marshal to
            // the UI thread and touch nothing Revit-side here.
            try
            {
                if (!ReferenceEquals(e.GetDocument(), _uiDoc.Document)) return;

                // Our own isolate transactions would otherwise flag the tree as
                // stale the instant the user ran an action.
                var names = e.GetTransactionNames();
                if (names != null && names.Count > 0 &&
                    names.All(name => name != null && name.StartsWith(WorksetsElementsBrowserHandler.TransactionPrefix, StringComparison.Ordinal)))
                    return;
            }
            catch
            {
                return; // never let an event handler throw back into Revit
            }

            _dispatcher.BeginInvoke(new Action(() =>
            {
                if (_disposed || IsBusy) return;
                if (IsTreeStale) return;

                IsTreeStale = true;
                Log(LogLevel.Warning, "The model changed since this tree was loaded — counts may be stale. Use Refresh.");
            }));
        }

        // ─────────────────────────────────────────────────────────────
        // Checked summary
        // ─────────────────────────────────────────────────────────────

        private void RefreshCheckedSummary()
        {
            var selection = new CheckedSelection();
            foreach (var root in RootNodes)
                root.CollectChecked(selection);

            _checkedSelection = selection;

            CheckedSummaryText = $"{selection.CheckedTypeCount:N0} type{(selection.CheckedTypeCount == 1 ? "" : "s")} checked · " +
                                 $"{selection.ElementCount:N0} elements";

            UpdateStatusText();
            NotifyCommandStates();
        }

        private void UpdateStatusText()
        {
            if (IsBusy)
            {
                StatusText = "Working…";
                return;
            }

            var mode = SelectedVisibilityOption?.Mode ?? WorksetVisibilityMode.All;
            if (mode == WorksetVisibilityMode.EmptyOnly || mode == WorksetVisibilityMode.ClosedOnly)
            {
                int visible = RootNodes.Count(node => node.IsVisible);
                StatusText = $"{SelectedVisibilityOption?.DisplayName} — {visible:N0} workset(s), no elements to act on";
                return;
            }

            StatusText = _checkedSelection.HasElements
                ? $"Ready · {_checkedSelection.ElementCount:N0} elements checked"
                : "Ready · nothing checked";
        }

        private void NotifyCommandStates()
        {
            IsolateCheckedCommand.NotifyCanExecuteChanged();
            SelectCheckedCommand.NotifyCanExecuteChanged();
            IsolateAndSelectCheckedCommand.NotifyCanExecuteChanged();
            ShowCheckedIn3DCommand.NotifyCanExecuteChanged();
            CheckAllVisibleCommand.NotifyCanExecuteChanged();
            ClearChecksCommand.NotifyCanExecuteChanged();
            ExpandAllCommand.NotifyCanExecuteChanged();
            CollapseAllCommand.NotifyCanExecuteChanged();
            RefreshCommand.NotifyCanExecuteChanged();
            CopyEmptyWorksetNamesCommand.NotifyCanExecuteChanged();
            ExportEmptyWorksetListCommand.NotifyCanExecuteChanged();
        }

        partial void OnIsBusyChanged(bool value)
        {
            UpdateStatusText();
            NotifyCommandStates();
        }

        // ─────────────────────────────────────────────────────────────
        // Toolbar commands
        // ─────────────────────────────────────────────────────────────

        private bool CanCheckRows() => !IsBusy && RootNodes.Any(node => node.IsVisible && node.IsCheckable);

        [RelayCommand(CanExecute = nameof(CanCheckRows))]
        private void ExpandAll()
        {
            foreach (var root in RootNodes.Where(node => node.IsVisible))
                root.SetExpandedRecursive(true);
        }

        [RelayCommand(CanExecute = nameof(CanCheckRows))]
        private void CollapseAll()
        {
            foreach (var root in RootNodes)
                root.SetExpandedRecursive(false);
        }

        /// <summary>Applies to the visible/filtered rows only — see TreeNodeViewModel.SetCheckedVisibleOnly.</summary>
        [RelayCommand(CanExecute = nameof(CanCheckRows))]
        private void CheckAllVisible()
        {
            using (_notifier.Suspend())
            {
                foreach (var root in RootNodes)
                    root.SetCheckedVisibleOnly(true);
            }
            Log(LogLevel.Info, $"Checked all visible rows — {_checkedSelection.ElementCount:N0} element(s).");
        }

        [RelayCommand(CanExecute = nameof(CanCheckRows))]
        private void ClearChecks()
        {
            using (_notifier.Suspend())
            {
                foreach (var root in RootNodes)
                    root.IsChecked = false;
            }
            Log(LogLevel.Info, "Cleared all checked rows.");
        }

        // ─────────────────────────────────────────────────────────────
        // Empty-workset list output
        // ─────────────────────────────────────────────────────────────

        private List<WorksetNodeData> EmptyWorksetsForExport()
            => _lastBuildWorksets
                .Where(workset => workset.EmptyKind == WorksetEmptyKind.Empty
                                  || workset.EmptyKind == WorksetEmptyKind.ViewSpecificOnly)
                .ToList();

        private bool CanOutputEmptyList() => !IsBusy && EmptyWorksetsForExport().Count > 0;

        [RelayCommand(CanExecute = nameof(CanOutputEmptyList))]
        private void CopyEmptyWorksetNames()
        {
            var names = EmptyWorksetsForExport().Select(workset => workset.Name);
            CopyToClipboard(string.Join(Environment.NewLine, names), "empty workset names");
        }

        [RelayCommand(CanExecute = nameof(CanOutputEmptyList))]
        private void ExportEmptyWorksetList()
        {
            string folder = ResolveFolder(_settings.ListExportFolder, "Choose a folder for the empty-workset list");
            if (string.IsNullOrEmpty(folder)) return;

            _settings.ListExportFolder = folder;

            var builder = new StringBuilder();
            builder.AppendLine("Workset,Owner,Editable,Status,ViewSpecificElements,OtherElements");

            foreach (var workset in EmptyWorksetsForExport())
            {
                string status = workset.EmptyKind == WorksetEmptyKind.Empty
                    ? "Empty"
                    : "No model elements";

                builder.AppendLine(string.Join(",",
                    LogExportHelper.EscapeCsv(workset.Name),
                    LogExportHelper.EscapeCsv(workset.Owner),
                    LogExportHelper.EscapeCsv(workset.IsEditable ? "Yes" : "No"),
                    LogExportHelper.EscapeCsv(status),
                    workset.ViewSpecificElementCount.ToString(),
                    workset.OtherElementCount.ToString()));
            }

            if (LogExportHelper.WriteTextFile(folder, LogExportHelper.BuildEmptyWorksetListFileName(),
                    builder.ToString(), out string path, out string error))
                Log(LogLevel.Success, $"Empty-workset list exported — {path}");
            else
                Log(LogLevel.Error, $"Empty-workset list could not be exported: {error}");
        }

        // ─────────────────────────────────────────────────────────────
        // Checked-rows actions
        // ─────────────────────────────────────────────────────────────

        private bool CanRunCheckedAction() => !IsBusy && _checkedSelection.HasElements;

        [RelayCommand(CanExecute = nameof(CanRunCheckedAction))]
        private void IsolateChecked() => RunCheckedAction(ElementActionMode.Isolate);

        [RelayCommand(CanExecute = nameof(CanRunCheckedAction))]
        private void SelectChecked() => RunCheckedAction(ElementActionMode.Select);

        [RelayCommand(CanExecute = nameof(CanRunCheckedAction))]
        private void IsolateAndSelectChecked() => RunCheckedAction(ElementActionMode.IsolateAndSelect);

        /// <summary>The dedicated footer action — always Isolate + Select, the "just show me everything checked" one-click case.</summary>
        [RelayCommand(CanExecute = nameof(CanRunCheckedAction))]
        private void ShowCheckedIn3D() => RunCheckedAction(ElementActionMode.IsolateAndSelect);

        private void RunCheckedAction(ElementActionMode mode)
        {
            var ids = _checkedSelection.ToElementIdList();
            if (ids.Count == 0)
            {
                Log(LogLevel.Warning, "Action requested with nothing checked — ignored.");
                return;
            }

            Log(LogLevel.Info, $"Action requested: mode={mode}, {ids.Count:N0} element(s) from {_checkedSelection.CheckedTypeCount:N0} type row(s).");
            ShowInThreeD($"Show all {ids.Count:N0} checked element(s) in a 3D view?", ids, mode);
        }

        /// <summary>Invoked from the View's code-behind when the user clicks a Type row's name, or its dedicated "Show in 3D" button.</summary>
        public void OnTypeRowClicked(TreeNodeViewModel typeNode)
        {
            if (typeNode == null || typeNode.Kind != ElementTreeNodeKind.Type) return;
            if (IsBusy) return;

            string prompt = $"Show all {typeNode.ElementIds.Count:N0} elements of \"{typeNode.Name}\" in a 3D view?";

            var dialog = new TaskDialog(ToolTitle)
            {
                MainContent = prompt,
                CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No
            };

            if (dialog.Show() != TaskDialogResult.Yes) return;

            Log(LogLevel.Info, $"Type row clicked: '{typeNode.Name}' — {typeNode.ElementIds.Count:N0} element(s).");
            ShowInThreeD(prompt, typeNode.ElementIds.ToList(), ElementActionMode.IsolateAndSelect);
        }

        /// <summary>
        /// Loads the model's 3D views, lets the user pick one, then applies
        /// Isolate/Select/Both to it. Two Revit-API round trips chained
        /// through RaiseRequest — never call ExternalEvent.Raise() directly
        /// from inside a completion callback (see OnHandlerRequestCompleted).
        /// </summary>
        private void ShowInThreeD(string prompt, List<ElementId> ids, ElementActionMode mode)
        {
            RaiseRequest(WorksetsElementsBrowserRequest.LoadViews, () =>
            {
                if (!_handler.LastRunSucceeded)
                {
                    Log(LogLevel.Error, $"3D views could not be loaded: {_handler.ErrorMessage}");
                    TaskDialog.Show(ToolTitle, $"Could not load 3D views: {_handler.ErrorMessage}");
                    return;
                }

                if (_handler.LoadedViews.Count == 0)
                {
                    Log(LogLevel.Warning, "Model has no 3D views to show elements in.");
                    TaskDialog.Show(ToolTitle, "This model has no 3D views to show elements in.");
                    return;
                }

                var picker = new View3DPickerWindow();
                new System.Windows.Interop.WindowInteropHelper(picker).Owner = _mainWindowHandle;
                picker.Initialize(prompt, _handler.LoadedViews, _settings.LastTargetViewName);

                bool? dialogResult = picker.ShowDialog();
                WsebDebugLog.Write($"Picker closed: dialogResult={dialogResult}, SelectedView={picker.SelectedView?.Name}");

                if (dialogResult != true || picker.SelectedView == null)
                {
                    Log(LogLevel.Info, "View picker cancelled — no action taken.");
                    return;
                }

                _settings.LastTargetViewName = picker.SelectedView.Name;

                _handler.ActionElementIds = ids;
                _handler.TargetViewId = picker.SelectedView.ViewId;
                _handler.ActionMode = mode;

                Log(LogLevel.Info, $"Applying {mode} to {ids.Count:N0} element(s) in view '{picker.SelectedView.Name}'.");
                RaiseRequest(WorksetsElementsBrowserRequest.ApplyAction, HandleActionCompleted);
            });
        }

        private void HandleActionCompleted()
        {
            if (!_handler.LastRunSucceeded)
            {
                Log(LogLevel.Error, $"Action failed and was rolled back: {_handler.ErrorMessage}");
                TaskDialog.Show(ToolTitle, $"Could not complete the action:\n\n{_handler.ErrorMessage}\n\nThe model was left unchanged.");
            }

            SaveSettings();
            AutoSaveLog();
            // Window stays open per this project's window-lifecycle convention.
        }

        // ─────────────────────────────────────────────────────────────
        // Row context menu
        // ─────────────────────────────────────────────────────────────

        [RelayCommand]
        private void CopyNodeName(TreeNodeViewModel node)
        {
            if (node == null) return;
            CopyToClipboard(node.Name, $"name of '{node.Name}'");
        }

        [RelayCommand]
        private void CopyNodeElementIds(TreeNodeViewModel node)
        {
            if (node == null) return;

            var ids = node.CollectAllElementIds().Distinct().ToList();
            if (ids.Count == 0)
            {
                Log(LogLevel.Warning, $"'{node.Name}' has no elements to copy.");
                return;
            }

            CopyToClipboard(string.Join(Environment.NewLine, ids.Select(id => id.Value.ToString())), $"{ids.Count:N0} element id(s)");
        }

        [RelayCommand]
        private void SelectNode(TreeNodeViewModel node) => RunNodeRevitAction(node, WorksetsElementsBrowserRequest.SelectElements);

        [RelayCommand]
        private void IsolateNodeInActiveView(TreeNodeViewModel node) => RunNodeRevitAction(node, WorksetsElementsBrowserRequest.IsolateInActiveView);

        private void RunNodeRevitAction(TreeNodeViewModel node, WorksetsElementsBrowserRequest request)
        {
            if (node == null || IsBusy) return;

            var ids = node.CollectAllElementIds().Distinct().ToList();
            if (ids.Count == 0)
            {
                Log(LogLevel.Warning, $"'{node.Name}' has no elements to act on.");
                return;
            }

            _handler.ActionElementIds = ids;
            Log(LogLevel.Info, $"{request} requested from the row menu for '{node.Name}' — {ids.Count:N0} element(s).");
            RaiseRequest(request, HandleActionCompleted);
        }

        [RelayCommand]
        private void ExpandBranch(TreeNodeViewModel node) => node?.SetExpandedRecursive(true);

        [RelayCommand]
        private void CollapseBranch(TreeNodeViewModel node) => node?.SetExpandedRecursive(false);

        // ─────────────────────────────────────────────────────────────
        // Completion plumbing / lifetime
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Fires from inside the handler's own Execute(UIApplication), on
        /// Revit's UI thread but still nested in that call stack — Revit
        /// denies/ignores ExternalEvent.Raise() called reentrantly like that,
        /// and a modal ShowDialog() opened from the same nested frame is
        /// unreliable too. BeginInvoke (not Invoke) defers the continuation
        /// — including any chained Raise() for a follow-up request and any
        /// ShowDialog() — to run only after Execute() has fully returned and
        /// control is back with Revit's own message loop. Without this, the
        /// LoadViews -> pick a view -> ApplyAction chain silently did
        /// nothing: views never populated and isolate/select never ran.
        /// </summary>
        private void OnHandlerRequestCompleted()
        {
            var handlerLines = _handler.HandlerLog.ToList();

            _dispatcher.BeginInvoke(new Action(() =>
            {
                foreach (var entry in handlerLines)
                    LogEntries.Add(entry);

                IsBusy = false;

                var completion = _pendingCompletion;
                _pendingCompletion = null;
                completion?.Invoke();
            }));
        }

        [RelayCommand]
        private void Close() => CloseRequested?.Invoke();

        /// <summary>Called by the View on Closing: persists settings, then releases Revit resources.</summary>
        public void Shutdown()
        {
            SaveSettings();
            Dispose();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;

            try
            {
                _searchDebounce.Stop();
                _searchDebounce.Tick -= OnSearchDebounceTick;
                _notifier.Changed -= RefreshCheckedSummary;
                LogEntries.CollectionChanged -= OnLogEntriesChanged;
                _handler.RequestCompleted -= OnHandlerRequestCompleted;
                _uiApp.Application.DocumentChanged -= OnDocumentChanged;
            }
            catch (Exception ex)
            {
                WsebDebugLog.Write($"Dispose cleanup issue: {ex.Message}");
            }

            _event?.Dispose();
        }
    }
}
