namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels
{
    public enum ElementTreeNodeKind
    {
        Workset,
        Category,
        Type
    }
}
