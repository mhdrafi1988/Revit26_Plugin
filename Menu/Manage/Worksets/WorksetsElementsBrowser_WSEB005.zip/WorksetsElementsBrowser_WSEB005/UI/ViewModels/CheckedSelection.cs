using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels
{
    /// <summary>
    /// Accumulator for one walk of the tree: the distinct checked ElementIds
    /// and how many Type rows are checked. WSEB004 needed two separate full
    /// walks (one for ids, one for the type count) plus a LINQ Distinct pass;
    /// this collects both in a single walk with set-based de-duplication.
    /// </summary>
    public class CheckedSelection
    {
        public HashSet<ElementId> ElementIds { get; } = new();
        public int CheckedTypeCount { get; set; }

        public int ElementCount => ElementIds.Count;
        public bool HasElements => ElementIds.Count > 0;

        public List<ElementId> ToElementIdList() => ElementIds.ToList();
    }
}
