using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels
{
    /// <summary>
    /// One entry of the toolbar "Worksets:" ComboBox. Restricted selection
    /// (not typable) — four fixed options, so filter-as-you-type would add
    /// nothing; this is the stated exception to the suite's typable-ComboBox
    /// default.
    /// </summary>
    public class WorksetVisibilityOption
    {
        public WorksetVisibilityMode Mode { get; }
        public string DisplayName { get; }

        public WorksetVisibilityOption(WorksetVisibilityMode mode, string displayName)
        {
            Mode = mode;
            DisplayName = displayName;
        }

        public override string ToString() => DisplayName;
    }
}
