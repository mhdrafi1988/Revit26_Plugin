using System;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels
{
    /// <summary>
    /// One notifier per tree, shared by every node. Nodes call
    /// <see cref="Notify"/> when their checked state changes; the ViewModel
    /// subscribes once to <see cref="Changed"/>.
    ///
    /// Why this exists (WSEB005 fix): in WSEB004 each node raised its own
    /// CheckedChanged event, re-raised up a chain of per-child lambdas, and
    /// the ViewModel's handler walked the WHOLE tree twice to recount. Checking
    /// one workset therefore cascaded to every descendant and triggered one
    /// full double tree walk PER DESCENDANT — quadratic, and a multi-second
    /// UI freeze on a large model. A cascade now wraps itself in Suspend() and
    /// exactly one notification is raised when the outermost scope closes.
    /// It also removes the lambda chain, which kept dead nodes reachable after
    /// a reload.
    /// </summary>
    public sealed class TreeChangeNotifier
    {
        private int _suspendDepth;
        private bool _pending;

        public event Action Changed;

        /// <summary>Suppresses notifications until the returned scope is disposed; one notification fires then, if any were raised.</summary>
        public IDisposable Suspend()
        {
            _suspendDepth++;
            return new SuspendScope(this);
        }

        public void Notify()
        {
            if (_suspendDepth > 0)
            {
                _pending = true;
                return;
            }
            Changed?.Invoke();
        }

        private void Resume()
        {
            if (_suspendDepth > 0) _suspendDepth--;
            if (_suspendDepth != 0 || !_pending) return;

            _pending = false;
            Changed?.Invoke();
        }

        private sealed class SuspendScope : IDisposable
        {
            private readonly TreeChangeNotifier _owner;
            private bool _disposed;

            public SuspendScope(TreeChangeNotifier owner) => _owner = owner;

            public void Dispose()
            {
                if (_disposed) return;
                _disposed = true;
                _owner.Resume();
            }
        }
    }
}
