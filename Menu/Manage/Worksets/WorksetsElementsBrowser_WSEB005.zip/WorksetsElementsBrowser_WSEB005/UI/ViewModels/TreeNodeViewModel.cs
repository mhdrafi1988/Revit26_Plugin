using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Autodesk.Revit.DB;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels
{
    /// <summary>
    /// One row of the Workset -> Category -> Type tree. Carries a tri-state
    /// checkbox: checking/unchecking a parent cascades to every descendant,
    /// and a child's change bubbles back up to recompute its ancestors'
    /// checked/unchecked/indeterminate state — same behavior as a Windows
    /// Explorer checkbox tree.
    ///
    /// WSEB005: cascades notify through a shared TreeChangeNotifier (see that
    /// class for the quadratic-refresh bug this fixes), workset rows carry
    /// their WorksetEmptyKind and badge, and filtering is a SINGLE pass that
    /// combines the search text with the workset-visibility mode — in WSEB004
    /// the search filter and the hide-empty filter both wrote IsVisible
    /// independently, so whichever ran last silently undid the other.
    /// </summary>
    public partial class TreeNodeViewModel : ObservableObject
    {
        private readonly TreeChangeNotifier _notifier;

        public ElementTreeNodeKind Kind { get; }
        public string Name { get; }
        public int ElementCount { get; }
        public string Owner { get; }
        public string EditableBadge { get; }

        /// <summary>Workset rows only: how this workset is classified (see WorksetEmptyKind).</summary>
        public WorksetEmptyKind EmptyKind { get; }

        /// <summary>Workset rows only: "empty", "no model elements · N view-specific", "closed — not counted", or empty for a workset with content.</summary>
        public string EmptyBadge { get; }

        /// <summary>Only populated on Type nodes — the actual element instances this row represents.</summary>
        public IReadOnlyList<ElementId> ElementIds { get; }

        public ObservableCollection<TreeNodeViewModel> Children { get; } = new();
        public TreeNodeViewModel Parent { get; private set; }

        [ObservableProperty] private bool _isExpanded;
        [ObservableProperty] private bool _isVisible = true;

        /// <summary>
        /// False for a workset row with nothing to act on (empty, annotation-only
        /// or closed): its checkbox is disabled rather than silently checking
        /// something that yields no elements.
        /// </summary>
        public bool IsCheckable { get; }

        private bool? _isChecked = false;

        public bool? IsChecked
        {
            get => _isChecked;
            set => SetChecked(value, cascadeToChildren: true, notifyParent: true);
        }

        public TreeNodeViewModel(
            TreeChangeNotifier notifier,
            ElementTreeNodeKind kind,
            string name,
            int elementCount = 0,
            string owner = "",
            string editableBadge = "",
            IReadOnlyList<ElementId> elementIds = null,
            WorksetEmptyKind emptyKind = WorksetEmptyKind.HasElements,
            string emptyBadge = "")
        {
            _notifier = notifier ?? throw new ArgumentNullException(nameof(notifier));
            Kind = kind;
            Name = name;
            ElementCount = elementCount;
            Owner = owner;
            EditableBadge = editableBadge;
            ElementIds = elementIds ?? Array.Empty<ElementId>();
            EmptyKind = emptyKind;
            EmptyBadge = emptyBadge;

            IsCheckable = kind != ElementTreeNodeKind.Workset || emptyKind == WorksetEmptyKind.HasElements;
        }

        public void AddChild(TreeNodeViewModel child)
        {
            child.Parent = this;
            Children.Add(child);
        }

        // ─────────────────────────────────────────────────────────────
        // Checked state
        // ─────────────────────────────────────────────────────────────

        private void SetChecked(bool? value, bool cascadeToChildren, bool notifyParent)
        {
            if (_isChecked == value) return;

            // One notification for the whole cascade, not one per descendant.
            using (_notifier.Suspend())
            {
                _isChecked = value;
                OnPropertyChanged(nameof(IsChecked));
                _notifier.Notify();

                if (cascadeToChildren && value.HasValue)
                {
                    foreach (var child in Children)
                        child.SetChecked(value, cascadeToChildren: true, notifyParent: false);
                }

                if (notifyParent)
                    Parent?.RecomputeCheckedFromChildren();
            }
        }

        private void RecomputeCheckedFromChildren()
        {
            if (Children.Count == 0) return;

            bool allChecked = Children.All(c => c.IsChecked == true);
            bool allUnchecked = Children.All(c => c.IsChecked == false);

            bool? newValue = allChecked ? true : allUnchecked ? false : (bool?)null;
            if (_isChecked == newValue) return;

            _isChecked = newValue;
            OnPropertyChanged(nameof(IsChecked));
            _notifier.Notify();

            Parent?.RecomputeCheckedFromChildren();
        }

        /// <summary>
        /// Checks/unchecks this node and its descendants, but only where the
        /// row is currently visible. Matches the suite's Select-All rule
        /// (toolbar actions apply to the filtered rows only) — WSEB004's
        /// Check All also checked rows hidden by the filter, so an action could
        /// act on elements the user could not see.
        /// </summary>
        public void SetCheckedVisibleOnly(bool value)
        {
            if (!IsVisible) return;

            if (Kind == ElementTreeNodeKind.Type || Children.Count == 0)
            {
                if (IsCheckable)
                    SetChecked(value, cascadeToChildren: false, notifyParent: true);
                return;
            }

            foreach (var child in Children)
                child.SetCheckedVisibleOnly(value);
        }

        /// <summary>Every Type-node ElementId checked at or under this node, plus the checked-type count, in one walk.</summary>
        public void CollectChecked(CheckedSelection selection)
        {
            if (Kind == ElementTreeNodeKind.Type)
            {
                if (IsChecked == true)
                {
                    selection.CheckedTypeCount++;
                    foreach (var id in ElementIds)
                        selection.ElementIds.Add(id);
                }
                return;
            }

            foreach (var child in Children)
                child.CollectChecked(selection);
        }

        /// <summary>Every ElementId under this node regardless of checked state — used by the row context menu.</summary>
        public IEnumerable<ElementId> CollectAllElementIds()
        {
            if (Kind == ElementTreeNodeKind.Type)
            {
                foreach (var id in ElementIds) yield return id;
                yield break;
            }

            foreach (var child in Children)
                foreach (var id in child.CollectAllElementIds())
                    yield return id;
        }

        // ─────────────────────────────────────────────────────────────
        // Expand / collapse
        // ─────────────────────────────────────────────────────────────

        [RelayCommand]
        private void ToggleExpanded() => IsExpanded = !IsExpanded;

        public void SetExpandedRecursive(bool expanded)
        {
            if (Kind != ElementTreeNodeKind.Type)
                IsExpanded = expanded;

            foreach (var child in Children)
                child.SetExpandedRecursive(expanded);
        }

        // ─────────────────────────────────────────────────────────────
        // Filtering — one combined pass (search text + visibility mode)
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Call on workset (root) nodes only. A row is visible when it passes
        /// BOTH the workset-visibility mode and the name search.
        /// </summary>
        public void ApplyFilters(string query, WorksetVisibilityMode mode)
        {
            bool modeAllows = PassesVisibilityMode(mode);
            bool textMatches = ApplyTextFilter(query);
            IsVisible = modeAllows && textMatches;
        }

        private bool PassesVisibilityMode(WorksetVisibilityMode mode)
        {
            if (Kind != ElementTreeNodeKind.Workset) return true;

            return mode switch
            {
                WorksetVisibilityMode.WithElementsOnly => EmptyKind == WorksetEmptyKind.HasElements,

                // Both "nothing at all" and "annotations only" show here, badged
                // apart, so a cleanup decision sees the near-misses too.
                WorksetVisibilityMode.EmptyOnly => EmptyKind == WorksetEmptyKind.Empty
                                                   || EmptyKind == WorksetEmptyKind.ViewSpecificOnly,

                WorksetVisibilityMode.ClosedOnly => EmptyKind == WorksetEmptyKind.Closed,
                _ => true
            };
        }

        /// <summary>
        /// Recursive name filter: a node stays visible if its own name matches
        /// or any descendant does, and any ancestor of a match auto-expands so
        /// the match is actually on screen. Returns true if this node (or a
        /// descendant) matched.
        /// </summary>
        private bool ApplyTextFilter(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
            {
                foreach (var child in Children)
                {
                    child.IsVisible = true;
                    child.ApplyTextFilter(query);
                }
                IsVisible = true;
                return true;
            }

            bool selfMatch = Name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0;
            bool anyChildMatch = false;

            foreach (var child in Children)
            {
                bool childMatch = child.ApplyTextFilter(query);
                child.IsVisible = childMatch || selfMatch;
                anyChildMatch |= childMatch;
            }

            if (anyChildMatch) IsExpanded = true;

            IsVisible = selfMatch || anyChildMatch;
            return IsVisible;
        }
    }
}
