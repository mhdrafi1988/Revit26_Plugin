using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Autodesk.Revit.DB;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Services
{
    /// <summary>
    /// Builds the Workset -> Category -> Type hierarchy for the host document
    /// (linked-model elements are never shown in the tree).
    ///
    /// WSEB005 changes versus WSEB004:
    ///   * ONE collector pass over every non-ElementType element, split into
    ///     model / view-specific / other buckets, instead of a
    ///     view-independent-only pass. The extra buckets are what make the
    ///     emptiness test trustworthy — a workset holding only dimensions is
    ///     NOT empty, and WSEB004 said it was.
    ///   * Closed worksets are reported as Closed instead of empty. A closed
    ///     workset's elements are not loaded into the document at all, so a
    ///     collector sees nothing and WSEB004 happily listed it as empty —
    ///     dangerous, because that list is what a cleanup decision is made on.
    ///   * Type names are resolved through a cache: one doc.GetElement() per
    ///     TYPE instead of one per INSTANCE (~86,000 -> ~2,000 on a WAMI model).
    ///   * ElementId.IntegerValue (obsolete in the Revit 2024+ API) replaced by
    ///     ElementId.Value, and the link-category check no longer allocates a
    ///     fresh ElementId for every element.
    ///   * A non-workshared document is reported explicitly rather than
    ///     returning an empty list that looks like an empty model.
    /// </summary>
    public class WorksetTreeBuilder
    {
        private const long LinkCategoryId = (long)BuiltInCategory.OST_RvtLinks;

        public WorksetTreeBuildResult Build(Document doc)
        {
            var result = new WorksetTreeBuildResult();
            var stopwatch = Stopwatch.StartNew();

            if (doc == null || !doc.IsWorkshared)
            {
                result.IsWorkshared = false;
                stopwatch.Stop();
                result.ElapsedMilliseconds = stopwatch.ElapsedMilliseconds;
                return result;
            }

            result.IsWorkshared = true;

            var worksets = new FilteredWorksetCollector(doc)
                .OfKind(WorksetKind.UserWorkset)
                .ToList();

            var worksetsById = worksets.ToDictionary(ws => ws.Id.IntegerValue, ws => ws);

            // worksetId -> categoryName -> typeName -> element ids
            var grouped = new Dictionary<int, Dictionary<string, Dictionary<string, List<ElementId>>>>();
            var modelCounts = new Dictionary<int, int>();
            var viewSpecificCounts = new Dictionary<int, int>();
            var otherCounts = new Dictionary<int, int>();

            // One instance-level pass. Element types carry no workset assignment
            // worth browsing, so they stay excluded; everything else is counted.
            var elements = new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .ToElements();

            var typeNameCache = new Dictionary<ElementId, string>();

            foreach (var element in elements)
            {
                result.ElementsScanned++;

                var worksetParam = element.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM);
                if (worksetParam == null || !worksetParam.HasValue) continue;

                int worksetId = worksetParam.AsInteger();
                if (!worksetsById.ContainsKey(worksetId)) continue; // project-standard / view worksets are out of scope

                // View-specific content (annotations, dimensions, detail items,
                // tags) never enters the tree, but it is counted: its presence
                // is the difference between "empty" and "do not delete this".
                if (element.ViewSpecific)
                {
                    Increment(viewSpecificCounts, worksetId);
                    result.ViewSpecificElementsCounted++;
                    continue;
                }

                var category = element.Category;
                if (category == null || category.Id.Value == LinkCategoryId)
                {
                    // Real content the tree deliberately skips — still blocks "empty".
                    Increment(otherCounts, worksetId);
                    result.OtherElementsCounted++;
                    continue;
                }

                string categoryName = category.Name;
                string typeName = ResolveTypeName(doc, element, typeNameCache, result);

                if (!grouped.TryGetValue(worksetId, out var byCategory))
                {
                    byCategory = new Dictionary<string, Dictionary<string, List<ElementId>>>();
                    grouped[worksetId] = byCategory;
                }
                if (!byCategory.TryGetValue(categoryName, out var byType))
                {
                    byType = new Dictionary<string, List<ElementId>>();
                    byCategory[categoryName] = byType;
                }
                if (!byType.TryGetValue(typeName, out var ids))
                {
                    ids = new List<ElementId>();
                    byType[typeName] = ids;
                }
                ids.Add(element.Id);

                Increment(modelCounts, worksetId);
                result.ModelElementsCounted++;
            }

            foreach (var ws in worksets.OrderBy(w => w.Name))
            {
                int id = ws.Id.IntegerValue;

                if (!ws.IsOpen)
                {
                    // Counts are UNKNOWN, not zero. Reported as a closed workset
                    // with no categories and never offered as "empty".
                    result.ClosedWorksetNames.Add(ws.Name);
                    result.Worksets.Add(new WorksetNodeData(
                        ws.Name, id, ws.IsEditable, isOpen: false, ws.Owner ?? string.Empty,
                        modelElementCount: 0, viewSpecificElementCount: 0, otherElementCount: 0,
                        categories: new List<CategoryNodeData>()));
                    continue;
                }

                var categories = grouped.TryGetValue(id, out var byCategory)
                    ? byCategory
                        .OrderBy(c => c.Key)
                        .Select(c => new CategoryNodeData(
                            c.Key,
                            c.Value
                                .OrderBy(t => t.Key)
                                .Select(t => new TypeNodeData(t.Key, t.Value))
                                .ToList()))
                        .ToList()
                    : new List<CategoryNodeData>();

                result.Worksets.Add(new WorksetNodeData(
                    ws.Name,
                    id,
                    ws.IsEditable,
                    isOpen: true,
                    ws.Owner ?? string.Empty,
                    Read(modelCounts, id),
                    Read(viewSpecificCounts, id),
                    Read(otherCounts, id),
                    categories));
            }

            stopwatch.Stop();
            result.ElapsedMilliseconds = stopwatch.ElapsedMilliseconds;
            return result;
        }

        private static void Increment(Dictionary<int, int> counts, int key)
        {
            counts.TryGetValue(key, out int current);
            counts[key] = current + 1;
        }

        private static int Read(Dictionary<int, int> counts, int key)
            => counts.TryGetValue(key, out int value) ? value : 0;

        /// <summary>
        /// "Type" for grouping purposes: the element's own ElementType name
        /// where one exists (family+type name), otherwise the element's own
        /// Name. Resolved once per type id and cached — the uncached version
        /// was one document lookup per element instance.
        /// </summary>
        private static string ResolveTypeName(
            Document doc,
            Element element,
            Dictionary<ElementId, string> cache,
            WorksetTreeBuildResult result)
        {
            var typeId = element.GetTypeId();

            if (typeId == null || typeId == ElementId.InvalidElementId)
                return string.IsNullOrWhiteSpace(element.Name) ? "(unnamed)" : element.Name;

            if (cache.TryGetValue(typeId, out string cached))
            {
                result.TypeNameCacheHits++;
                return cached;
            }

            string resolved;
            if (doc.GetElement(typeId) is ElementType elementType)
            {
                string familyName = elementType.FamilyName;
                resolved = string.IsNullOrWhiteSpace(familyName)
                    ? elementType.Name
                    : $"{familyName} — {elementType.Name}";
            }
            else
            {
                resolved = string.IsNullOrWhiteSpace(element.Name) ? "(unnamed)" : element.Name;
            }

            cache[typeId] = resolved;
            result.TypeNamesResolved++;
            return resolved;
        }
    }
}
