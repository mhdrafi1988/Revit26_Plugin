using System.Collections.Generic;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.UI.ViewModels;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Services
{
    /// <summary>
    /// Turns a <see cref="WorksetTreeBuildResult"/> into the row ViewModels the
    /// TreeView binds to, and produces the header metric counts in the same
    /// pass. Extracted from WSEB004's HandleLoadTreeCompleted(), which mixed
    /// Revit-result unpacking, node construction, counting and summary-string
    /// formatting in one ~70-line method.
    ///
    /// Note: this mapper sits in Core/Services but intentionally returns UI row
    /// ViewModels — it is the single seam between the Revit-side data model and
    /// the tree UI, and keeping it here leaves the ViewModel free of mapping code.
    /// </summary>
    public class WorksetTreeMapper
    {
        public List<TreeNodeViewModel> Map(
            WorksetTreeBuildResult build,
            TreeChangeNotifier notifier,
            out TreeStatistics statistics)
        {
            var roots = new List<TreeNodeViewModel>();
            statistics = new TreeStatistics();

            if (build == null) return roots;

            foreach (var worksetData in build.Worksets)
            {
                statistics.WorksetCount++;

                switch (worksetData.EmptyKind)
                {
                    case WorksetEmptyKind.HasElements:      statistics.WorksetsWithElements++; break;
                    case WorksetEmptyKind.Empty:            statistics.WorksetsEmpty++; break;
                    case WorksetEmptyKind.ViewSpecificOnly: statistics.WorksetsViewSpecificOnly++; break;
                    case WorksetEmptyKind.Closed:           statistics.WorksetsClosed++; break;
                }

                var worksetNode = new TreeNodeViewModel(
                    notifier,
                    ElementTreeNodeKind.Workset,
                    worksetData.Name,
                    elementCount: worksetData.ModelElementCount,
                    owner: worksetData.Owner,
                    editableBadge: worksetData.IsEditable ? "editable" : "not editable",
                    emptyKind: worksetData.EmptyKind,
                    emptyBadge: BuildEmptyBadge(worksetData))
                {
                    IsExpanded = false
                };

                foreach (var categoryData in worksetData.Categories)
                {
                    statistics.CategoryCount++;

                    var categoryNode = new TreeNodeViewModel(
                        notifier,
                        ElementTreeNodeKind.Category,
                        categoryData.Name);

                    worksetNode.AddChild(categoryNode);

                    foreach (var typeData in categoryData.Types)
                    {
                        statistics.TypeCount++;
                        statistics.ElementCount += typeData.ElementIds.Count;

                        categoryNode.AddChild(new TreeNodeViewModel(
                            notifier,
                            ElementTreeNodeKind.Type,
                            typeData.Name,
                            elementCount: typeData.ElementIds.Count,
                            elementIds: typeData.ElementIds));
                    }
                }

                roots.Add(worksetNode);
            }

            return roots;
        }

        /// <summary>
        /// The row badge. "empty" is reserved for a workset with nothing at all
        /// on it — the only case that is safe to clean up. The other two kinds
        /// say plainly why they are not that.
        /// </summary>
        private static string BuildEmptyBadge(WorksetNodeData workset)
        {
            switch (workset.EmptyKind)
            {
                case WorksetEmptyKind.Empty:
                    return "empty";

                case WorksetEmptyKind.ViewSpecificOnly:
                    return workset.OtherElementCount == 0
                        ? $"no model elements · {workset.ViewSpecificElementCount:N0} view-specific"
                        : $"no model elements · {workset.NonModelElementCount:N0} non-model";

                case WorksetEmptyKind.Closed:
                    return "closed — not counted";

                default:
                    return string.Empty;
            }
        }
    }
}
