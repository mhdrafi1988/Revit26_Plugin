namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models
{
    /// <summary>
    /// Counts behind the header metric cards. Produced once per tree build by
    /// WorksetTreeMapper so the ViewModel never has to walk the tree to fill
    /// the cards (WSEB004 counted inline while mapping, mixing the two jobs).
    /// </summary>
    public class TreeStatistics
    {
        public int WorksetCount { get; set; }
        public int CategoryCount { get; set; }
        public int TypeCount { get; set; }
        public int ElementCount { get; set; }

        public int WorksetsWithElements { get; set; }
        public int WorksetsEmpty { get; set; }
        public int WorksetsViewSpecificOnly { get; set; }
        public int WorksetsClosed { get; set; }

        /// <summary>Worksets shown by the "Empty Only" filter: truly empty plus annotation-only.</summary>
        public int WorksetsWithoutModelElements => WorksetsEmpty + WorksetsViewSpecificOnly;
    }
}
