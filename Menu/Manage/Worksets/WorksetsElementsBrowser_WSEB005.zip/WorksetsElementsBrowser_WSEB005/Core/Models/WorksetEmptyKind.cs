namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models
{
    /// <summary>
    /// How "empty" a workset is. New in WSEB005 — WSEB004 only had a boolean
    /// "no children" test, which was wrong in two ways:
    ///   * a CLOSED workset has no loaded elements at all, so it looked empty
    ///     when it may hold thousands (deleting it would be destructive);
    ///   * a workset holding only annotations/dimensions/detail items was
    ///     reported empty, because the tree collector is view-independent only.
    /// Those two cases now get their own kinds so the UI can never call them
    /// plain "empty".
    /// </summary>
    public enum WorksetEmptyKind
    {
        /// <summary>At least one model (view-independent) element.</summary>
        HasElements,

        /// <summary>No elements of any kind — safe to consider for cleanup.</summary>
        Empty,

        /// <summary>No model elements, but view-specific/other elements exist (annotations, detail items, links).</summary>
        ViewSpecificOnly,

        /// <summary>Workset is closed in this document: elements are not loaded and cannot be counted.</summary>
        Closed
    }
}
