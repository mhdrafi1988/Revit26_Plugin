using System.Collections.Generic;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models
{
    /// <summary>
    /// Everything one tree build produced, including the numbers the activity
    /// log reports. WSEB004 returned a bare List and logged nothing, so a
    /// non-workshared document and a genuinely empty model looked identical.
    /// </summary>
    public class WorksetTreeBuildResult
    {
        /// <summary>False for a non-workshared document — there are no worksets to browse, and that is not an error.</summary>
        public bool IsWorkshared { get; set; }

        public List<WorksetNodeData> Worksets { get; set; } = new();

        /// <summary>Names of worksets closed in this document, for the Warning log line.</summary>
        public List<string> ClosedWorksetNames { get; set; } = new();

        public int ElementsScanned { get; set; }
        public int ModelElementsCounted { get; set; }
        public int ViewSpecificElementsCounted { get; set; }
        public int OtherElementsCounted { get; set; }
        public int TypeNamesResolved { get; set; }
        public int TypeNameCacheHits { get; set; }
        public long ElapsedMilliseconds { get; set; }
    }
}
