namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models
{
    /// <summary>
    /// Persisted per-tool settings, System.Text.Json POCO, stored at
    /// %AppData%\Revit26_Plugin\WorksetsElementsBrowser\settings.json.
    /// Every property has a safe default so a missing or partial file still
    /// deserialises into a usable object.
    /// </summary>
    public class WsebSettings
    {
        /// <summary>Bump when a property changes meaning; the service migrates or falls back to defaults.</summary>
        public const int CurrentSchemaVersion = 1;

        public int SchemaVersion { get; set; } = CurrentSchemaVersion;

        /// <summary>Stored as the enum NAME (not the numeric value) so reordering WorksetVisibilityMode can never silently change the saved filter.</summary>
        public string WorksetVisibility { get; set; } = nameof(WorksetVisibilityMode.WithElementsOnly);

        /// <summary>Log panel starts collapsed by design — it is opened on demand.</summary>
        public bool IsLogExpanded { get; set; }

        /// <summary>Chosen once per session, then reused for log .txt exports.</summary>
        public string LogExportFolder { get; set; } = string.Empty;

        /// <summary>Chosen once per session, then reused for the empty-workset .csv export.</summary>
        public string ListExportFolder { get; set; } = string.Empty;

        public double WindowWidth { get; set; } = 900;
        public double WindowHeight { get; set; } = 790;

        /// <summary>Name of the last 3D view used, pre-selected in the picker next time.</summary>
        public string LastTargetViewName { get; set; } = string.Empty;
    }
}
