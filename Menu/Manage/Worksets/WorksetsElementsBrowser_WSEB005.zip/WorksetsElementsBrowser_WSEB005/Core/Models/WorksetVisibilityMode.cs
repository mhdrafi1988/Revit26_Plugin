namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models
{
    /// <summary>
    /// Toolbar workset filter. Replaces WSEB004's single "Hide Empty Worksets"
    /// bool — the requested "show only empty worksets" case had no
    /// representation there.
    /// </summary>
    public enum WorksetVisibilityMode
    {
        /// <summary>Every user workset, whatever its contents or open state.</summary>
        All,

        /// <summary>Only worksets holding at least one model element.</summary>
        WithElementsOnly,

        /// <summary>Only worksets with no model elements (truly empty + annotation-only, badged apart).</summary>
        EmptyOnly,

        /// <summary>Only worksets closed in this document — their counts are unknown, not zero.</summary>
        ClosedOnly
    }
}
