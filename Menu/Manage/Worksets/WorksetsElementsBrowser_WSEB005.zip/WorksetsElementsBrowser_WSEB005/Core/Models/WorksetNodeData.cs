using System.Collections.Generic;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models
{
    /// <summary>
    /// Root of the tree: one user workset, holding its Categories.
    /// WSEB005 adds the open state and the two element counts the emptiness
    /// test needs — see <see cref="WorksetEmptyKind"/> for why a single
    /// "has children" flag was not safe.
    /// </summary>
    public class WorksetNodeData
    {
        public string Name { get; }
        public int WorksetId { get; }
        public bool IsEditable { get; }

        /// <summary>False when the workset is closed in this document — its elements are NOT loaded, so all counts below are unknown (reported as 0).</summary>
        public bool IsOpen { get; }

        public string Owner { get; }

        /// <summary>View-independent, categorised, non-link elements — the ones the tree shows.</summary>
        public int ModelElementCount { get; }

        /// <summary>Annotations, dimensions, detail items and other view-specific elements. Not shown in the tree, but they make a workset NOT safe to delete.</summary>
        public int ViewSpecificElementCount { get; }

        /// <summary>View-independent elements the tree deliberately skips (links, category-less elements). Still real content.</summary>
        public int OtherElementCount { get; }

        public List<CategoryNodeData> Categories { get; }

        public int NonModelElementCount => ViewSpecificElementCount + OtherElementCount;

        /// <summary>Single source of truth for how this workset is classified and filtered.</summary>
        public WorksetEmptyKind EmptyKind
        {
            get
            {
                if (!IsOpen) return WorksetEmptyKind.Closed;
                if (ModelElementCount > 0) return WorksetEmptyKind.HasElements;
                if (NonModelElementCount > 0) return WorksetEmptyKind.ViewSpecificOnly;
                return WorksetEmptyKind.Empty;
            }
        }

        /// <summary>True only when nothing at all lives on this workset — the one case that is safe to clean up.</summary>
        public bool IsEmpty => EmptyKind == WorksetEmptyKind.Empty;

        public WorksetNodeData(
            string name,
            int worksetId,
            bool isEditable,
            bool isOpen,
            string owner,
            int modelElementCount,
            int viewSpecificElementCount,
            int otherElementCount,
            List<CategoryNodeData> categories)
        {
            Name = name;
            WorksetId = worksetId;
            IsEditable = isEditable;
            IsOpen = isOpen;
            Owner = owner;
            ModelElementCount = modelElementCount;
            ViewSpecificElementCount = viewSpecificElementCount;
            OtherElementCount = otherElementCount;
            Categories = categories;
        }
    }
}
