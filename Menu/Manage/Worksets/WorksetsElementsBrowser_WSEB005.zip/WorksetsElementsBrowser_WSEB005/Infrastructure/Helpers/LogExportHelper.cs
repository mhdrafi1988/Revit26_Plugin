using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Infrastructure.Helpers
{
    /// <summary>
    /// Writes the activity log and the empty-workset list to disk, following
    /// the suite conventions: auto-save under
    /// My Documents\Revit26_Plugin\{ToolName}\Logs\ and the filename pattern
    /// {ToolName}_Logs_{yyyy-MM-dd}_{HH-mm}.txt. No folder dialog is opened
    /// here — the caller asks once per session and reuses the answer.
    /// </summary>
    public static class LogExportHelper
    {
        private const string ToolName = "WorksetsElementsBrowser";

        public static string DefaultAutoSaveFolder => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "Revit26_Plugin",
            ToolName,
            "Logs");

        public static string BuildLogFileName()
            => $"{ToolName}_Logs_{DateTime.Now:yyyy-MM-dd}_{DateTime.Now:HH-mm}.txt";

        public static string BuildEmptyWorksetListFileName()
            => $"{ToolName}_EmptyWorksets_{DateTime.Now:yyyy-MM-dd}_{DateTime.Now:HH-mm}.csv";

        public static string BuildLogText(IEnumerable<LogEntry> entries)
        {
            var builder = new StringBuilder();
            builder.AppendLine($"{ToolName} — activity log");
            builder.AppendLine($"Saved: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            builder.AppendLine(new string('-', 72));

            if (entries != null)
                foreach (var entry in entries)
                    builder.AppendLine(entry.ToString());

            return builder.ToString();
        }

        /// <summary>Best-effort write; returns false with a message instead of throwing.</summary>
        public static bool WriteTextFile(string folder, string fileName, string contents, out string fullPath, out string error)
        {
            fullPath = string.Empty;
            error = string.Empty;

            try
            {
                if (string.IsNullOrWhiteSpace(folder)) folder = DefaultAutoSaveFolder;
                Directory.CreateDirectory(folder);

                fullPath = Path.Combine(folder, fileName);
                File.WriteAllText(fullPath, contents, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        /// <summary>Quotes a CSV field and doubles any embedded quotes — workset names regularly contain commas.</summary>
        public static string EscapeCsv(string value)
        {
            value ??= string.Empty;
            return $"\"{value.Replace("\"", "\"\"")}\"";
        }
    }
}
