using System;
using System.IO;
using System.Text.Json;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Infrastructure.Helpers
{
    /// <summary>
    /// Load/save for this tool's settings.json, per the suite convention
    /// (%AppData%\Revit26_Plugin\{ToolName}\settings.json, System.Text.Json).
    /// WSEB004 had no persistence at all — the filter reset on every open.
    ///
    /// Every failure path returns defaults and a message instead of throwing:
    /// a corrupt or hand-edited settings file must never stop the window from
    /// opening. The caller logs the message as a Warning.
    /// </summary>
    public static class WsebSettingsService
    {
        private const string ToolName = "WorksetsElementsBrowser";

        private static readonly JsonSerializerOptions WriteOptions = new() { WriteIndented = true };

        public static string SettingsFolder => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "Revit26_Plugin",
            ToolName);

        public static string SettingsPath => Path.Combine(SettingsFolder, "settings.json");

        /// <summary>Returns stored settings, or defaults. <paramref name="warning"/> is empty on a clean load.</summary>
        public static WsebSettings Load(out string warning)
        {
            warning = string.Empty;

            try
            {
                if (!File.Exists(SettingsPath))
                    return new WsebSettings();

                string json = File.ReadAllText(SettingsPath);
                if (string.IsNullOrWhiteSpace(json))
                {
                    warning = $"Settings file was empty — defaults applied ({SettingsPath}).";
                    return new WsebSettings();
                }

                var loaded = JsonSerializer.Deserialize<WsebSettings>(json);
                if (loaded == null)
                {
                    warning = $"Settings file could not be read — defaults applied ({SettingsPath}).";
                    return new WsebSettings();
                }

                if (loaded.SchemaVersion != WsebSettings.CurrentSchemaVersion)
                {
                    warning = $"Settings schema v{loaded.SchemaVersion} differs from v{WsebSettings.CurrentSchemaVersion} — defaults applied.";
                    return new WsebSettings();
                }

                return loaded;
            }
            catch (Exception ex)
            {
                warning = $"Settings could not be loaded ({ex.Message}) — defaults applied.";
                return new WsebSettings();
            }
        }

        /// <summary>Best-effort save. Returns false with a message rather than throwing — losing a window-size preference must not break Close.</summary>
        public static bool Save(WsebSettings settings, out string error)
        {
            error = string.Empty;
            if (settings == null)
            {
                error = "No settings to save.";
                return false;
            }

            try
            {
                settings.SchemaVersion = WsebSettings.CurrentSchemaVersion;
                Directory.CreateDirectory(SettingsFolder);
                File.WriteAllText(SettingsPath, JsonSerializer.Serialize(settings, WriteOptions));
                return true;
            }
            catch (Exception ex)
            {
                error = $"Settings could not be saved: {ex.Message}";
                return false;
            }
        }
    }
}
