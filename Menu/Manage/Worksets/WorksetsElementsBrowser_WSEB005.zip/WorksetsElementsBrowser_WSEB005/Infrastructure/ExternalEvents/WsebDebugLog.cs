using System;
using System.IO;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Infrastructure.ExternalEvents
{
    /// <summary>
    /// Low-level file trace, written alongside the on-screen activity log.
    /// In WSEB004 this was a temporary diagnostic called ad-hoc from the
    /// ViewModel and the handler; in WSEB005 it is a sink the log service
    /// writes through, so a traced line and a logged line can never disagree.
    /// Every call is swallowed on failure — a locked trace file must never
    /// affect the tool.
    /// </summary>
    internal static class WsebDebugLog
    {
        private static readonly string LogPath = Path.Combine(Path.GetTempPath(), "WSEB_debug.log");
        private static readonly object Lock = new();

        public static void Write(LogLevel level, string message)
            => Write($"[{level}] {message}");

        public static void Write(string message)
        {
            try
            {
                lock (Lock)
                {
                    File.AppendAllText(
                        LogPath,
                        $"{DateTime.Now:HH:mm:ss.fff} [{Environment.CurrentManagedThreadId}] {message}{Environment.NewLine}");
                }
            }
            catch
            {
                // best-effort trace only
            }
        }
    }
}
