using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Models;
using Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Core.Services;

namespace Revit26_Plugin.WorksetsElementsBrowser.WSEB005.Infrastructure.ExternalEvents
{
    /// <summary>
    /// Requests this tool's orchestrator handler can execute, set by the
    /// ViewModel immediately before ExternalEvent.Raise() — per Revit API
    /// threading rules only one Execute() runs at a time, so there is no
    /// race between setting Request and it being read.
    /// </summary>
    public enum WorksetsElementsBrowserRequest
    {
        LoadTree,
        LoadViews,
        ApplyAction,

        /// <summary>Row context menu: select the row's elements, no view change.</summary>
        SelectElements,

        /// <summary>Row context menu: temporary-isolate the row's elements in the current view.</summary>
        IsolateInActiveView
    }

    /// <summary>
    /// Single shared orchestrator for all Revit-API-touching actions in this
    /// tool: building the Workset/Category/Type tree, listing 3D views,
    /// applying Isolate/Select/Isolate+Select in a chosen 3D view, and the two
    /// context-menu actions that act on the current view.
    ///
    /// WSEB005: every step appends to <see cref="HandlerLog"/>, which the
    /// ViewModel drains into the on-screen log once Execute() has returned.
    /// Logging from inside Execute() is the only way to record the Revit-side
    /// counts and ids the project's logging-depth rule asks for.
    /// </summary>
    public class WorksetsElementsBrowserHandler : IExternalEventHandler
    {
        /// <summary>Every transaction this tool opens starts with this, so the ViewModel's DocumentChanged watcher can tell our own edits from someone else's.</summary>
        public const string TransactionPrefix = "Worksets & Elements Browser";

        private readonly UIDocument _uiDoc;
        private readonly WorksetTreeBuilder _treeBuilder = new();

        public WorksetsElementsBrowserRequest Request { get; set; }

        // ---- Inputs (set by ViewModel before Raise()) ----
        public List<ElementId> ActionElementIds { get; set; } = new();
        public ElementId TargetViewId { get; set; }
        public ElementActionMode ActionMode { get; set; }

        // ---- Outputs (read by ViewModel after RequestCompleted fires) ----
        public WorksetTreeBuildResult LoadedTree { get; private set; } = new();
        public List<View3DOption> LoadedViews { get; private set; } = new();
        public string ErrorMessage { get; private set; } = string.Empty;
        public bool LastRunSucceeded { get; private set; }

        /// <summary>Log lines produced during the last Execute(); drained by the ViewModel.</summary>
        public List<LogEntry> HandlerLog { get; } = new();

        public event Action RequestCompleted;

        public WorksetsElementsBrowserHandler(UIDocument uiDoc)
        {
            _uiDoc = uiDoc;
        }

        public string GetName() => "WorksetsElementsBrowser Orchestrator";

        public void Execute(UIApplication app)
        {
            HandlerLog.Clear();
            ErrorMessage = string.Empty;
            Log(LogLevel.Info, $"Execute() entered — Request={Request}");

            try
            {
                switch (Request)
                {
                    case WorksetsElementsBrowserRequest.LoadTree:
                        ExecuteLoadTree();
                        break;
                    case WorksetsElementsBrowserRequest.LoadViews:
                        ExecuteLoadViews();
                        break;
                    case WorksetsElementsBrowserRequest.ApplyAction:
                        ExecuteApplyAction();
                        break;
                    case WorksetsElementsBrowserRequest.SelectElements:
                        ExecuteSelectElements();
                        break;
                    case WorksetsElementsBrowserRequest.IsolateInActiveView:
                        ExecuteIsolateInActiveView();
                        break;
                }

                LastRunSucceeded = true;
                Log(LogLevel.Info, $"Execute() finished — Request={Request}");
            }
            catch (Exception ex)
            {
                LastRunSucceeded = false;
                ErrorMessage = ex.Message;
                Log(LogLevel.Error, $"Execute() failed — Request={Request}: {ex.Message}");
            }
            finally
            {
                RequestCompleted?.Invoke();
            }
        }

        private void Log(LogLevel level, string message)
        {
            HandlerLog.Add(new LogEntry(level, message));
            WsebDebugLog.Write(level, message);
        }

        // ─────────────────────────────────────────────────────────────
        // LoadTree
        // ─────────────────────────────────────────────────────────────
        private void ExecuteLoadTree()
        {
            var doc = _uiDoc.Document;
            Log(LogLevel.Info, $"Building tree for '{doc.Title}' — IsWorkshared={doc.IsWorkshared}");

            LoadedTree = _treeBuilder.Build(doc);

            if (!LoadedTree.IsWorkshared)
            {
                Log(LogLevel.Warning, "Document is not workshared — there are no worksets to browse.");
                return;
            }

            Log(LogLevel.Info, $"Scanned {LoadedTree.ElementsScanned:N0} element(s): " +
                               $"{LoadedTree.ModelElementsCounted:N0} model, " +
                               $"{LoadedTree.ViewSpecificElementsCounted:N0} view-specific, " +
                               $"{LoadedTree.OtherElementsCounted:N0} other (links / no category)");

            Log(LogLevel.Info, $"Type-name cache: {LoadedTree.TypeNamesResolved:N0} resolved, " +
                               $"{LoadedTree.TypeNameCacheHits:N0} cache hit(s)");

            if (LoadedTree.ClosedWorksetNames.Count > 0)
            {
                Log(LogLevel.Warning,
                    $"{LoadedTree.ClosedWorksetNames.Count} workset(s) are CLOSED — elements not loaded, so their " +
                    $"counts are unknown and they are never reported as empty: " +
                    string.Join(", ", LoadedTree.ClosedWorksetNames));
            }

            Log(LogLevel.Info, $"Tree built in {LoadedTree.ElapsedMilliseconds:N0} ms — {LoadedTree.Worksets.Count} workset(s)");
        }

        // ─────────────────────────────────────────────────────────────
        // LoadViews
        // ─────────────────────────────────────────────────────────────
        private void ExecuteLoadViews()
        {
            LoadedViews = new FilteredElementCollector(_uiDoc.Document)
                .OfClass(typeof(View3D))
                .Cast<View3D>()
                .Where(v => !v.IsTemplate)
                .OrderBy(v => v.Name)
                .Select(v => new View3DOption(v.Id, v.Name))
                .ToList();

            Log(LogLevel.Info, $"Loaded {LoadedViews.Count} 3D view(s) for the picker");
        }

        // ─────────────────────────────────────────────────────────────
        // ApplyAction — isolate / select in a chosen 3D view
        // ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Activates the chosen 3D view, then isolates and/or selects the
        /// given elements in it, per ActionMode. Temporary isolation is set
        /// via View.IsolateElementsTemporary (reset by the user through
        /// Revit's own "Reset Temporary Hide/Isolate", same as any manual
        /// isolate) rather than permanent visibility overrides.
        /// </summary>
        private void ExecuteApplyAction()
        {
            var doc = _uiDoc.Document;

            if (doc.GetElement(TargetViewId) is not View3D view)
                throw new InvalidOperationException("The selected 3D view no longer exists.");

            var validIds = ResolveValidIds(doc, out int skipped);
            Log(LogLevel.Info, $"ApplyAction mode={ActionMode} view='{view.Name}' — {validIds.Count:N0} valid element(s)");

            _uiDoc.ActiveView = view;

            if (ActionMode == ElementActionMode.Isolate || ActionMode == ElementActionMode.IsolateAndSelect)
                IsolateTemporary(doc, view, validIds, "Isolate");

            if (ActionMode == ElementActionMode.Select || ActionMode == ElementActionMode.IsolateAndSelect)
            {
                _uiDoc.Selection.SetElementIds(validIds);
                Log(LogLevel.Info, $"Selection set — {validIds.Count:N0} element(s)");
            }

            Log(LogLevel.Success, $"{validIds.Count:N0} shown | {skipped:N0} skipped | 0 failed");
        }

        private void ExecuteSelectElements()
        {
            var validIds = ResolveValidIds(_uiDoc.Document, out int skipped);
            _uiDoc.Selection.SetElementIds(validIds);
            Log(LogLevel.Success, $"{validIds.Count:N0} selected | {skipped:N0} skipped | 0 failed");
        }

        private void ExecuteIsolateInActiveView()
        {
            var doc = _uiDoc.Document;
            var view = _uiDoc.ActiveView;

            if (view == null)
                throw new InvalidOperationException("There is no active view to isolate in.");

            if (view.IsTemplate || !view.CanUseTemporaryVisibilityModes())
                throw new InvalidOperationException($"View '{view.Name}' does not support temporary isolate.");

            var validIds = ResolveValidIds(doc, out int skipped);
            IsolateTemporary(doc, view, validIds, "Isolate in current view");
            Log(LogLevel.Success, $"{validIds.Count:N0} isolated in '{view.Name}' | {skipped:N0} skipped | 0 failed");
        }

        /// <summary>
        /// One Transaction per logical operation, rolled back on failure. The
        /// loop that drops the previous isolation is inside the single
        /// transaction — never a transaction per element.
        /// </summary>
        private void IsolateTemporary(Document doc, View view, List<ElementId> ids, string operationName)
        {
            using var tx = new Transaction(doc, $"{TransactionPrefix} - {operationName}");
            tx.Start();

            try
            {
                if (view.IsInTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate))
                    view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate);

                if (ids.Count > 0)
                    view.IsolateElementsTemporary(ids);

                var status = tx.Commit();
                if (status != TransactionStatus.Committed)
                {
                    Log(LogLevel.Error, $"Transaction '{operationName}' ended as {status} — rolling back");
                    if (tx.HasStarted()) tx.RollBack();
                    throw new InvalidOperationException($"Revit did not commit the {operationName} transaction ({status}).");
                }

                Log(LogLevel.Info, $"Transaction '{operationName}' committed in view '{view.Name}'");
            }
            catch
            {
                if (tx.HasStarted() && !tx.HasEnded()) tx.RollBack();
                throw;
            }
        }

        /// <summary>Drops ids deleted since the tree was built; the drop count is logged as a Warning, never shown as an error dialog.</summary>
        private List<ElementId> ResolveValidIds(Document doc, out int skipped)
        {
            var source = ActionElementIds ?? new List<ElementId>();
            var valid = source.Where(id => doc.GetElement(id) != null).ToList();

            skipped = source.Count - valid.Count;
            if (skipped > 0)
                Log(LogLevel.Warning, $"{skipped:N0} element(s) no longer exist in the model and were skipped");

            return valid;
        }
    }
}
