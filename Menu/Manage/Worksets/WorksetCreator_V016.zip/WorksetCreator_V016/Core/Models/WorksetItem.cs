// ==============================================
// File: WorksetItem.cs
// Layer: Core/Models  (no Revit API — CLAUDE.md)
// Workset Creator V016.
//
// Changes vs V015:
//   NEW  LinkTypeId — the row's identity is now the RevitLinkType, not its file
//        name. Two links with the same file name from different folders are two
//        rows (V015's Distinct(name) collapsed them into one).
//   NEW  LoadState + StatusText — Grid 3 no longer says "Unloaded / not placed"
//        for everything; it says which one it actually is.
//   CHG  GridCategory doc comments: NoInstances now means genuinely nothing
//        placed, because an unloaded-but-placed link is counted properly and
//        lands in NeedsWorkset.
// ==============================================

using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.WorksetCreator.V016.Core.Models
{
    public enum WorksetGridCategory
    {
        /// <summary>Grid 1 — proposed workset exists and every instance is already in it.</summary>
        AlreadyAssigned,

        /// <summary>
        /// Grid 2 — the link has instances in the model (loaded or unloaded) that
        /// are not all in the proposed workset.
        /// </summary>
        NeedsWorkset,

        /// <summary>
        /// Grid 3 — no RevitLinkInstance of this type exists in the model at all.
        /// The workset can be created, but there is nothing to assign to it until
        /// someone places the link.
        /// </summary>
        NoInstances
    }

    public partial class WorksetItem : ObservableObject
    {
        [ObservableProperty] private int    serialNumber;

        /// <summary>ElementId.IntegerValue of the RevitLinkType this row stands for.</summary>
        [ObservableProperty] private int    linkTypeId;

        [ObservableProperty] private string linkName;
        [ObservableProperty] private string currentWorksetName  = "None";
        [ObservableProperty] private bool   isMixedWorkset;
        [ObservableProperty] private string proposedWorksetName;
        [ObservableProperty] private string proposedWorksetTooltip;
        [ObservableProperty] private bool   isSelected;
        [ObservableProperty] private bool   hasInstances        = true;
        [ObservableProperty] private bool   isExactMatchAssigned;
        [ObservableProperty] private bool   isExistingWorkset;
        [ObservableProperty] private string existingWorksetName;
        [ObservableProperty] private int    instanceCount;
        [ObservableProperty] private WorksetGridCategory gridCategory;

        /// <summary>Loaded / Unloaded / NotFound — straight from the scan.</summary>
        [ObservableProperty] private LinkLoadState loadState = LinkLoadState.Loaded;

        partial void OnLoadStateChanged(LinkLoadState value)
        {
            OnPropertyChanged(nameof(StatusText));
            OnPropertyChanged(nameof(IsUnloaded));
            OnPropertyChanged(nameof(LoadStateText));
        }

        partial void OnInstanceCountChanged(int value) => OnPropertyChanged(nameof(StatusText));

        public bool IsUnloaded => LoadState == LinkLoadState.Unloaded;

        /// <summary>Short badge for Grid 2 — blank when the link is loaded and normal.</summary>
        public string LoadStateText => LoadState switch
        {
            LinkLoadState.Unloaded => "Unloaded",
            LinkLoadState.NotFound => "Not found",
            _                      => "Loaded"
        };

        /// <summary>
        /// Grid 3's Status column. V015 hard-coded "Unloaded / not placed" into the
        /// XAML because it could not tell the two apart; V016 can.
        /// </summary>
        public string StatusText => LoadState switch
        {
            LinkLoadState.NotFound => "Not found",
            LinkLoadState.Unloaded => "Unloaded · not placed",
            _                      => "Not placed"
        };
    }
}
