// ==============================================
// File: LinkRecord.cs
// Layer: Core/Models  (no Revit API — CLAUDE.md)
// NEW in Workset Creator V016.
//
// One scanned RevitLinkType, reduced to plain data. The service produces these
// in a single pass (WorksetService.ScanLinks) and the ViewModel builds its grid
// rows from them, so the model is read once per load instead of once per link
// per question — V015 ran a FilteredWorksetCollector inside a per-instance
// loop, which is O(links x instances x worksets) on a model like the one this
// version was written against (59 links).
//
// The link type's ElementId travels as a plain int (ElementId.IntegerValue) so
// this layer keeps its no-Revit-API rule; the service turns it back into an
// ElementId at the boundary.
// ==============================================

using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit26_Plugin.WorksetCreator.V016.Core.Models
{
    public sealed class LinkRecord
    {
        /// <summary>ElementId.IntegerValue of the RevitLinkType. The identity of a row.</summary>
        public int TypeId { get; set; }

        /// <summary>File name without its final extension — what the user sees.</summary>
        public string Name { get; set; } = string.Empty;

        public LinkLoadState LoadState { get; set; } = LinkLoadState.Loaded;

        /// <summary>RevitLinkInstance elements of this type found in the host, loaded or not.</summary>
        public int InstanceCount { get; set; }

        /// <summary>
        /// Distinct workset names across those instances. Empty when none of them
        /// has a readable workset parameter.
        /// </summary>
        public List<string> WorksetNames { get; } = new();

        /// <summary>Instances whose ELEM_PARTITION_PARAM was null or unset.</summary>
        public int UnassignedInstances { get; set; }

        public bool HasInstances => InstanceCount > 0;

        public bool IsUnloaded => LoadState == LinkLoadState.Unloaded;

        /// <summary>"None" / the single workset / "MIXED" — the Current workset column.</summary>
        public string CurrentWorksetName =>
            WorksetNames.Count == 0 ? "None" :
            WorksetNames.Count == 1 ? WorksetNames[0] : "MIXED";

        public bool IsMixedWorkset => WorksetNames.Count > 1;

        /// <summary>
        /// True when every instance of this link already sits in
        /// <paramref name="worksetName"/> — i.e. Grid 1, nothing to do.
        /// Pure: answered from the scan, with no further document reads.
        /// </summary>
        public bool IsFullyAssignedTo(string worksetName)
        {
            if (!HasInstances)              return false;
            if (UnassignedInstances > 0)    return false;
            if (WorksetNames.Count != 1)    return false;
            return WorksetNames[0].Equals(worksetName, StringComparison.OrdinalIgnoreCase);
        }
    }

    /// <summary>
    /// Result of one scan: the links this tool will act on, plus what it left
    /// out and why. The exclusion counts are shown in the window and written
    /// into the run report, so a link missing from the list is explained rather
    /// than simply absent.
    /// </summary>
    public sealed class LinkScan
    {
        public List<LinkRecord> Links { get; } = new();

        /// <summary>IFC links (Revit links the .ifc.rvt shadow file) — excluded by design.</summary>
        public int ExcludedIfc { get; set; }

        /// <summary>Nested links — their workset follows the parent link, so they are not ours to set.</summary>
        public int ExcludedNested { get; set; }

        public int ExcludedTotal => ExcludedIfc + ExcludedNested;

        /// <summary>"3 IFC, 1 nested link hidden" — or empty when nothing was excluded.</summary>
        public string ExclusionText()
        {
            if (ExcludedTotal == 0) return string.Empty;
            var parts = new List<string>();
            if (ExcludedIfc    > 0) parts.Add($"{ExcludedIfc} IFC");
            if (ExcludedNested > 0) parts.Add($"{ExcludedNested} nested");
            return $"{string.Join(", ", parts)} link(s) hidden";
        }

        public bool AnyLoadedFailure => Links.Any(l => l.LoadState == LinkLoadState.NotFound);
    }
}
