// ==============================================
// File: WorksetRequest.cs
// Layer: Core/Models  (no Revit API — CLAUDE.md)
// NEW in Workset Creator V016.
//
// One unit of work handed to WorksetService.CreateAndAssign. V015 passed a
// (ProposedName, LinkName, CreateNew) tuple, which could only find the link's
// instances by name — and name matching went through GetLinkDocument(), which
// is null for an unloaded link. The request now carries the link type id, so
// the service finds instances by type, and the unloaded flag, so a refusal can
// be reported with the reason instead of a bare "0 assigned".
// ==============================================

namespace Revit26_Plugin.WorksetCreator.V016.Core.Models
{
    public sealed class WorksetRequest
    {
        /// <summary>ElementId.IntegerValue of the RevitLinkType to act on.</summary>
        public int LinkTypeId { get; set; }

        /// <summary>Display name — for the log, the report and nothing else.</summary>
        public string LinkName { get; set; } = string.Empty;

        /// <summary>The workset to create or re-use.</summary>
        public string ProposedName { get; set; } = string.Empty;

        /// <summary>
        /// True for Create on a name that does not exist yet. The service still
        /// re-checks before creating — the pattern box can be edited after the
        /// scan, so this flag can be stale by the time the run starts.
        /// </summary>
        public bool CreateNew { get; set; }

        /// <summary>Used only to explain a refused assignment in the run report.</summary>
        public bool IsUnloaded { get; set; }
    }
}
