// ==============================================
// File: WorksetService.cs
// Layer: Core/Services  (no Revit document mutation outside a Transaction;
//         no UI / ViewModel dependency — CLAUDE.md)
// Workset Creator V016.
//
// Changes vs V015:
//   FIX  Instances are found by link TYPE id, not by RevitLinkInstance
//        .GetLinkDocument().Title. GetLinkDocument() returns null for an
//        unloaded link, so V015 reported every unloaded link as "0 instances",
//        dropped it into Grid 3 and created a workset that stayed empty while
//        the link's real instances sat in Workset1. Matching on
//        RevitLinkInstance.GetTypeId() works whatever the load state.
//   NEW  ScanLinks does the whole read in one pass and returns plain data
//        (LinkScan / LinkRecord). V015 asked the document one question per link
//        per property and ran a FilteredWorksetCollector inside a per-instance
//        loop — O(links x instances x worksets) on a 59-link model.
//   NEW  IFC links are excluded (confirmed with Rafi, 2026-10-17). Revit links
//        an IFC through a generated "<file>.ifc.rvt" shadow model, so it is a
//        perfectly ordinary RevitLinkType and V015 listed it like any other.
//   NEW  Nested links are excluded — a nested link's workset follows its parent,
//        so there is nothing here to assign and V015 only ever created an empty
//        workset for one.
//   NEW  A Create whose workset name already exists re-uses it instead of
//        throwing. V015 decided CreateNew at scan time and never re-checked, so
//        editing the pattern into an existing name produced a hard Error row.
//   NEW  A link that is unloaded and assigns nothing is reported with that as
//        the reason, rather than the generic read-only/pinned note.
// Everything else — name cleaning, duplicate resolution, one Transaction per
// link, roll-back-and-continue, the run-wide TransactionGroup — is V015.
// ==============================================

using Autodesk.Revit.DB;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.WorksetCreator.V016.Core.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Revit26_Plugin.WorksetCreator.V016.Core.Services
{
    public class WorksetService
    {
        private readonly Action<LogEntry> _log;

        public WorksetService(Action<LogEntry> logger) => _log = logger;

        // ─── Scan ─────────────────────────────────────────────────────────────

        /// <summary>
        /// Reads every RevitLinkType in <paramref name="doc"/> once and returns the
        /// links this tool will act on, plus the ones it deliberately left out.
        /// Pure read — no transaction, nothing mutated.
        /// </summary>
        public LinkScan ScanLinks(Document doc)
        {
            var scan = new LinkScan();
            if (doc == null) return scan;

            // One pass over the instances, bucketed by their type id. This is the
            // fix: no GetLinkDocument() anywhere, so load state is irrelevant.
            var instancesByType = new Dictionary<int, List<RevitLinkInstance>>();
            foreach (RevitLinkInstance instance in new FilteredElementCollector(doc)
                         .OfClass(typeof(RevitLinkInstance))
                         .Cast<RevitLinkInstance>())
            {
                int typeId = instance.GetTypeId()?.IntegerValue ?? ElementId.InvalidElementId.IntegerValue;
                if (!instancesByType.TryGetValue(typeId, out List<RevitLinkInstance> bucket))
                    instancesByType[typeId] = bucket = new List<RevitLinkInstance>();
                bucket.Add(instance);
            }

            // One pass over the worksets, so the per-instance lookup below is a
            // dictionary hit instead of a fresh collector.
            Dictionary<int, string> worksetNames = BuildWorksetNameMap(doc);

            foreach (RevitLinkType type in new FilteredElementCollector(doc)
                         .OfClass(typeof(RevitLinkType))
                         .Cast<RevitLinkType>())
            {
                if (IsNestedLink(type)) { scan.ExcludedNested++; continue; }
                if (IsIfcLink(type))    { scan.ExcludedIfc++;    continue; }

                var record = new LinkRecord
                {
                    TypeId    = type.Id.IntegerValue,
                    Name      = Path.GetFileNameWithoutExtension(type.Name ?? string.Empty),
                    LoadState = MapLoadState(type)
                };

                if (instancesByType.TryGetValue(record.TypeId, out List<RevitLinkInstance> instances))
                {
                    record.InstanceCount = instances.Count;

                    var distinct = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (RevitLinkInstance instance in instances)
                    {
                        Parameter param = instance.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM);
                        if (param == null || !param.HasValue)
                        {
                            record.UnassignedInstances++;
                            continue;
                        }

                        if (worksetNames.TryGetValue(param.AsInteger(), out string name))
                            distinct.Add(name);
                        else
                            record.UnassignedInstances++;
                    }

                    record.WorksetNames.AddRange(distinct.OrderBy(n => n, StringComparer.OrdinalIgnoreCase));
                }

                scan.Links.Add(record);
            }

            scan.Links.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
            return scan;
        }

        public string CheckExistingWorkset(Document doc, string worksetName)
        {
            Workset existing = new FilteredWorksetCollector(doc)
                .OfKind(WorksetKind.UserWorkset)
                .FirstOrDefault(ws =>
                    ws.Name.Equals(worksetName, StringComparison.OrdinalIgnoreCase));
            return existing?.Name;
        }

        // ─── Name helpers (V015, unchanged) ───────────────────────────────────

        public void ResolveDuplicates(IEnumerable<WorksetItem> items)
        {
            // Seed with Grid 1 names so they are never collided into
            var usedNames = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in items.Where(i => i.GridCategory == WorksetGridCategory.AlreadyAssigned))
                usedNames[item.ProposedWorksetName] = 1;

            foreach (var item in items.Where(i => i.GridCategory != WorksetGridCategory.AlreadyAssigned))
            {
                string baseName  = item.ProposedWorksetName;
                string finalName = baseName;
                int    count     = 1;

                while (usedNames.ContainsKey(finalName))
                {
                    count++;
                    finalName = $"{baseName}_{count}";
                }

                if (finalName != baseName)
                {
                    _log(new LogEntry(LogLevel.Warning,
                        $"Duplicate name '{baseName}' → renamed to '{finalName}'"));
                    item.ProposedWorksetName = finalName;
                }

                usedNames[finalName] = count;
            }
        }

        public string CleanName(string input)
        {
            if (string.IsNullOrEmpty(input)) return "Workset";

            string cleaned = input;

            char[] invalidChars = { ':', '{', '}', '[', ']', '|', ';', '<', '>', '?', '`', '~', '\t', '\n', '\r' };
            foreach (char c in invalidChars)
                cleaned = cleaned.Replace(c, '-');

            while (cleaned.Contains("--"))
                cleaned = cleaned.Replace("--", "-");

            cleaned = cleaned.Trim().Trim('-');

            if (string.IsNullOrEmpty(cleaned))
                cleaned = "Workset";

            if (cleaned.Length > 150)
            {
                string truncated = cleaned[..150];
                _log(new LogEntry(LogLevel.Warning,
                    $"Truncated '{cleaned}' to 150 chars: '{truncated}'"));
                cleaned = truncated;
            }

            return cleaned;
        }

        /// <summary>
        /// Variant used during live pattern editing — no log spam on every keystroke.
        /// </summary>
        public string CleanNameSilent(string input)
        {
            if (string.IsNullOrEmpty(input)) return "Workset";
            string cleaned = input;
            char[] invalidChars = { ':', '{', '}', '[', ']', '|', ';', '<', '>', '?', '`', '~', '\t', '\n', '\r' };
            foreach (char c in invalidChars)
                cleaned = cleaned.Replace(c, '-');
            while (cleaned.Contains("--"))
                cleaned = cleaned.Replace("--", "-");
            cleaned = cleaned.Trim().Trim('-');
            if (string.IsNullOrEmpty(cleaned)) cleaned = "Workset";
            if (cleaned.Length > 150) cleaned = cleaned[..150];
            return cleaned;
        }

        // ─── Write operations ─────────────────────────────────────────────────

        /// <summary>
        /// Creates (or re-uses) one workset per request and assigns that link's
        /// instances to it, one Transaction per link. Every request lands in
        /// <paramref name="summary"/> as a <see cref="LinkOutcome"/> — including
        /// failures, which are rolled back and do not stop the run.
        /// </summary>
        /// <param name="summary">
        /// Pre-filled with Mode / Label / link counts (and any outcome the caller
        /// already decided, e.g. a Resync skip). The same instance is returned.
        /// </param>
        /// <param name="onProgress">Called after each link with (processed, total).</param>
        public RunSummary CreateAndAssign(
            Document doc,
            IEnumerable<WorksetRequest> requests,
            RunSummary summary,
            Action<int, int> onProgress = null)
        {
            summary ??= new RunSummary();

            var queue = requests?.ToList() ?? new List<WorksetRequest>();
            int total = queue.Count;
            int processed = 0;
            int committed = 0;

            if (total == 0)
            {
                summary.FinishedAt = DateTime.Now;
                return summary;
            }

            // One undo step for the whole run (ARCHITECTURE.md §5): each link keeps its
            // own Transaction inside the group, so a failing link still rolls back on its
            // own, but the user undoes a 7-link run with one Ctrl+Z instead of seven.
            // Assimilate only when something committed — RollBack() on the group would
            // undo the links that already succeeded.
            using TransactionGroup group = new(doc, $"{summary.Mode}: {summary.Label}");
            group.Start();

            foreach (WorksetRequest request in queue)
            {
                processed++;

                var outcome = new LinkOutcome
                {
                    LinkName    = request.LinkName,
                    WorksetName = request.ProposedName,
                    WasUnloaded = request.IsUnloaded
                };

                using Transaction tx = new(doc,
                    request.CreateNew ? $"Create workset: {request.ProposedName}"
                                      : $"Resync workset: {request.ProposedName}");
                try
                {
                    tx.Start();

                    // Always re-read: the pattern box can be edited after the scan, so
                    // request.CreateNew may be stale. V015 trusted it and Workset.Create
                    // threw on an existing name, turning a re-usable workset into an Error.
                    Workset existing = new FilteredWorksetCollector(doc)
                        .OfKind(WorksetKind.UserWorkset)
                        .FirstOrDefault(ws =>
                            ws.Name.Equals(request.ProposedName, StringComparison.OrdinalIgnoreCase));

                    WorksetId targetId;
                    bool createdNew = false;

                    if (existing != null)
                    {
                        targetId = existing.Id;
                        if (request.CreateNew)
                            _log(new LogEntry(LogLevel.Info,
                                $"Workset '{request.ProposedName}' already exists — re-used instead of created."));
                    }
                    else if (request.CreateNew)
                    {
                        Workset workset = Workset.Create(doc, request.ProposedName);
                        targetId   = workset.Id;
                        createdNew = true;
                        _log(new LogEntry(LogLevel.Info, $"Created workset: '{request.ProposedName}'"));
                    }
                    else
                    {
                        // Resync against a workset that is not there.
                        _log(new LogEntry(LogLevel.Error,
                            $"Workset '{request.ProposedName}' not found — skipped."));
                        tx.RollBack();

                        outcome.Outcome = RunOutcome.Skipped;
                        outcome.Note    = "Workset does not exist — use Create";
                        summary.Outcomes.Add(outcome);
                        onProgress?.Invoke(processed, total);
                        continue;
                    }

                    AssignResult result = AssignLinkInstances(
                        doc, request.LinkTypeId, targetId, request.IsUnloaded);

                    outcome.InstancesAssigned = result.Assigned;
                    outcome.InstancesTotal    = result.Total;
                    outcome.Note              = result.Note;

                    if (result.Total == 0)
                    {
                        // Grid 3 — nothing placed in the model yet.
                        outcome.Outcome = createdNew ? RunOutcome.CreatedNoInstances : RunOutcome.Skipped;
                        outcome.Note    = "No instances placed — assignment happens when the link is placed";
                        _log(new LogEntry(LogLevel.Warning,
                            $"'{request.LinkName}' has no placed instances — workset '{request.ProposedName}' left empty."));
                    }
                    else if (result.Assigned == 0)
                    {
                        outcome.Outcome = RunOutcome.Missed;
                        _log(new LogEntry(LogLevel.Warning,
                            $"Missed '{request.LinkName}' — 0 of {result.Total} instance(s) could be assigned " +
                            $"to '{request.ProposedName}'. {result.Note}"));
                    }
                    else
                    {
                        outcome.Outcome = createdNew ? RunOutcome.Created : RunOutcome.Reused;
                        _log(new LogEntry(LogLevel.Info,
                            $"Assigned {result.Assigned} instance(s) of '{request.LinkName}' → '{request.ProposedName}'"));
                        if (!string.IsNullOrWhiteSpace(result.Note))
                            _log(new LogEntry(LogLevel.Warning, $"'{request.LinkName}': {result.Note}"));
                    }

                    tx.Commit();
                    committed++;

                    // Only after the commit: a workset created in a transaction that
                    // then threw does not exist, so it must not be counted.
                    outcome.WorksetWasCreated = createdNew;
                }
                catch (Exception ex)
                {
                    tx.RollBack();
                    _log(new LogEntry(LogLevel.Error, $"Failed on '{request.ProposedName}': {ex.Message}"));

                    outcome.Outcome = RunOutcome.Error;
                    outcome.Note    = ex.Message;
                }

                // The only path that adds its outcome early is the
                // "workset not found" skip above, which also `continue`s.
                summary.Outcomes.Add(outcome);

                onProgress?.Invoke(processed, total);
            }

            if (committed > 0) group.Assimilate();
            else               group.RollBack();

            summary.FinishedAt = DateTime.Now;
            return summary;
        }

        // ─── Private helpers ──────────────────────────────────────────────────

        /// <summary>Instances written, instances found, and a note about the rest.</summary>
        private readonly record struct AssignResult(int Assigned, int Total, string Note);

        private AssignResult AssignLinkInstances(Document doc, int linkTypeId, WorksetId worksetId, bool isUnloaded)
        {
            List<RevitLinkInstance> instances = GetLinkInstances(doc, linkTypeId);
            int assigned = 0;
            int blocked  = 0;

            foreach (RevitLinkInstance instance in instances)
            {
                Parameter param = instance.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM);
                if (param == null || param.IsReadOnly)
                {
                    blocked++;
                    continue;
                }

                try
                {
                    if (param.Set(worksetId.IntegerValue)) assigned++;
                    else blocked++;
                }
                catch (Exception)
                {
                    // Pinned / borrowed by another user / otherwise refused —
                    // counted, never fatal to the rest of the run.
                    blocked++;
                }
            }

            string note;
            if (blocked == 0)
            {
                note = string.Empty;
            }
            else if (isUnloaded && assigned == 0)
            {
                // The honest reading when nothing at all went through on an unloaded
                // link: Revit would not take the write. Load it and run again.
                note = $"{blocked} instance(s) not assigned — the link is unloaded and Revit refused " +
                       "the workset change; load the link and run again";
            }
            else
            {
                note = $"{blocked} instance(s) not assigned (workset parameter read-only, pinned, " +
                       "or owned by another user)";
            }

            return new AssignResult(assigned, instances.Count, note);
        }

        /// <summary>
        /// Instances of one link type. Matched on GetTypeId(), NOT on the linked
        /// document's title: GetLinkDocument() is null while a link is unloaded,
        /// which is exactly the case V015 got wrong.
        /// </summary>
        private List<RevitLinkInstance> GetLinkInstances(Document doc, int linkTypeId)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(RevitLinkInstance))
                .Cast<RevitLinkInstance>()
                .Where(i => (i.GetTypeId()?.IntegerValue ?? ElementId.InvalidElementId.IntegerValue) == linkTypeId)
                .ToList();
        }

        private static Dictionary<int, string> BuildWorksetNameMap(Document doc)
        {
            var map = new Dictionary<int, string>();
            foreach (Workset ws in new FilteredWorksetCollector(doc))
                map[ws.Id.IntegerValue] = ws.Name;
            return map;
        }

        /// <summary>
        /// A nested link (a link inside a linked model). Its workset in the host is
        /// governed by the parent link, so there is nothing here for this tool to
        /// set — V015 listed them and created worksets that could never fill.
        /// </summary>
        private static bool IsNestedLink(RevitLinkType type)
        {
            try { return type.IsNestedLink; }
            catch (Exception) { return false; }
        }

        /// <summary>
        /// An IFC link. Revit does not link an .ifc directly: it converts the file
        /// into a shadow Revit model next to it ("Z3_IFC_21-08-2026.ifc.rvt") and
        /// links that, so the result is an ordinary RevitLinkType whose name still
        /// carries the .ifc. Excluded by Rafi's decision (2026-10-17).
        /// </summary>
        private static bool IsIfcLink(RevitLinkType type)
        {
            string name = type.Name ?? string.Empty;

            // "Z3.ifc.rvt" → stem "Z3.ifc";  a bare "Z3.ifc" name is covered too.
            if (name.EndsWith(".ifc", StringComparison.OrdinalIgnoreCase)) return true;
            if (Path.GetFileNameWithoutExtension(name)
                    .EndsWith(".ifc", StringComparison.OrdinalIgnoreCase)) return true;

            // Belt and braces: ask the external reference for the path on disk.
            // Not every link type has one (and a broken one can throw), hence the guard.
            try
            {
                if (!type.IsExternalFileReference()) return false;

                ExternalFileReference reference = type.GetExternalFileReference();
                if (reference == null) return false;

                string path = ModelPathUtils.ConvertModelPathToUserVisiblePath(reference.GetAbsolutePath());
                if (string.IsNullOrWhiteSpace(path)) return false;

                if (path.EndsWith(".ifc", StringComparison.OrdinalIgnoreCase)) return true;
                if (Path.GetFileNameWithoutExtension(path)
                        .EndsWith(".ifc", StringComparison.OrdinalIgnoreCase)) return true;
            }
            catch (Exception)
            {
                // An unresolvable reference tells us nothing about the format —
                // fall through and treat it as an ordinary Revit link.
            }

            return false;
        }

        /// <summary>
        /// Maps Revit's LinkedFileStatus onto <see cref="LinkLoadState"/>.
        /// Compared by name rather than by enum member so this folder keeps
        /// compiling if the SDK's member set differs (LocallyUnloaded and friends).
        /// </summary>
        private static LinkLoadState MapLoadState(RevitLinkType type)
        {
            try
            {
                string status = type.GetLinkedFileStatus().ToString();

                if (status.Equals("Loaded", StringComparison.OrdinalIgnoreCase))
                    return LinkLoadState.Loaded;
                if (status.IndexOf("NotFound", StringComparison.OrdinalIgnoreCase) >= 0)
                    return LinkLoadState.NotFound;
                if (status.IndexOf("Unloaded", StringComparison.OrdinalIgnoreCase) >= 0)
                    return LinkLoadState.Unloaded;

                // "Invalid" and anything new: not loaded, but not provably missing.
                return LinkLoadState.Unloaded;
            }
            catch (Exception)
            {
                return LinkLoadState.Loaded;
            }
        }
    }
}
