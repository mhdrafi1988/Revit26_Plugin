namespace Revit26_Plugin.DwgToDetailLines.V006.Models
{
    public enum MissingFillPatternDecision
    {
        Create,
        Skip
    }
}
