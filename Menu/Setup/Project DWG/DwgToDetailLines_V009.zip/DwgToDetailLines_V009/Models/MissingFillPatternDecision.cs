namespace Revit26_Plugin.DwgToDetailLines.V009.Models
{
    public enum MissingFillPatternDecision
    {
        Create,
        Skip
    }
}
