namespace Revit26_Plugin.DwgToDetailLines.V009.Models
{
    public enum SplineHandlingMode
    {
        Preserve,
        Tessellate
    }
}
