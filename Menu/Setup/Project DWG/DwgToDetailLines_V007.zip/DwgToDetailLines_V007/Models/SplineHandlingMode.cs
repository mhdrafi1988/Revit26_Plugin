namespace Revit26_Plugin.DwgToDetailLines.V007.Models
{
    public enum SplineHandlingMode
    {
        Preserve,
        Tessellate
    }
}
