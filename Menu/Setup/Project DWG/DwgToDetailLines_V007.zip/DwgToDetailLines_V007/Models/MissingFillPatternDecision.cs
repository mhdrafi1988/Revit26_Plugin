namespace Revit26_Plugin.DwgToDetailLines.V007.Models
{
    public enum MissingFillPatternDecision
    {
        Create,
        Skip
    }
}
