using Autodesk.Revit.UI;
using System.Reflection;
using System.Windows.Media.Imaging;

namespace WorksetManager_01
{
    /// <summary>
    /// Call this from your existing Application.cs OnStartup to register the ribbon tab.
    /// </summary>
    public static class WorksetManagerRibbon
    {
        private const string TabName    = "Workset Tools";
        private const string PanelName  = "Workset Manager";

        public static void Register(UIControlledApplication app)
        {
            // Create the new tab
            app.CreateRibbonTab(TabName);

            // Add panel inside the tab
            RibbonPanel panel = app.CreateRibbonPanel(TabName, PanelName);

            string assemblyPath = Assembly.GetExecutingAssembly().Location;

            var btnData = new PushButtonData(
                "WorksetManagerCmd",
                "Workset\nManager",
                assemblyPath,
                "WorksetManager_01.Commands.WorksetManagerCommand")
            {
                ToolTip = "Analyse all worksets — element counts, type breakdown, export to Excel.",
                LongDescription = "Scans all user worksets in the active workshared document. " +
                                  "Shows element count and type breakdown per workset. " +
                                  "Supports filtering, clipboard copy, and Excel export."
            };

            // Optional: add a 32x32 icon if you have one in Resources
            // btnData.LargeImage = LoadIcon("WorksetManager_01.Resources.icon_32.png");

            panel.AddItem(btnData);
        }

        // Uncomment if you add an icon PNG as Embedded Resource:
        // private static BitmapImage LoadIcon(string resourcePath)
        // {
        //     var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourcePath);
        //     if (stream == null) return null;
        //     var img = new BitmapImage();
        //     img.BeginInit();
        //     img.StreamSource = stream;
        //     img.EndInit();
        //     return img;
        // }
    }
}
