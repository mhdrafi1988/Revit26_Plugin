# WorksetManager_01
Revit 2026 plugin — Workset Analysis & Export
Built for: Revit26_Plugin solution (net8.0-windows)

---

## Files

| File | Purpose |
|------|---------|
| Commands/WorksetManagerCommand.cs | IExternalCommand entry point |
| Models/WorksetSummaryItem.cs | Data model for one workset row |
| Helpers/WorksetScanner.cs | Single-pass element collector, groups by WorksetId |
| Helpers/ExcelExportHelper.cs | EPPlus export — Summary sheet + Type Detail sheet |
| ViewModels/WorksetManagerViewModel.cs | CommunityToolkit.Mvvm ViewModel |
| Views/WorksetManagerWindow.xaml | WPF window UI |
| Views/WorksetManagerWindow.xaml.cs | Code-behind |
| WorksetManagerRibbon.cs | Ribbon tab registration helper |
| WorksetManager_01.addin | Manifest (for reference) |

---

## Integration into Revit26_Plugin

### Step 1 — Copy files
Copy the entire `WorksetManager_01` folder into:
```
C:\Users\Rafi\source\repos\Revit26_Plugin\
```

### Step 2 — Add to your existing Application.cs
In your existing `OnStartup` method, add:
```csharp
WorksetManager_01.WorksetManagerRibbon.Register(application);
```

### Step 3 — NuGet packages required
These should already be in your solution. If not, add via NuGet:
```
EPPlus (version 5.x or 6.x, NonCommercial licence)
CommunityToolkit.Mvvm
```

### Step 4 — Build
Build the solution in Release mode. The new "Workset Tools" tab will appear
in Revit next to your existing Rf_2026_MAR_26_00 tab.

---

## Features in this version

- Scan all user worksets in a single collector pass (fast on large models)
- Toggle to include or exclude linked model elements
- Summary DataGrid: Workset Name, Total Elements, Status, Editable, Type Breakdown
- Empty worksets highlighted in red
- Filter/search bar across workset name and type breakdown
- Copy filtered results to clipboard (tab-separated, paste into Excel)
- Export to Excel (.xlsx) — two sheets:
  - Sheet 1: Workset Summary (one row per workset)
  - Sheet 2: Type Detail (one row per type per workset)

---

## Notes

- Only works on workshared (cloud or local) documents
- Assembly is compiled into the existing Revit26_Plugin.dll — no separate DLL needed
- WorksetManagerRibbon.Register() safely creates a new "Workset Tools" tab
