using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using Autodesk.Revit.DB;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.DwgStatistics.V002.Infrastructure.RevitApi
{
    /// <summary>
    /// Reads every CAD type, every CAD instance and — through a deep scan of every graphical view —
    /// which views actually draw each instance. Must run in a Revit API context (the command, or the
    /// tool's external event). Read-only: opens no transaction.
    /// </summary>
    public static class DwgStatsScanner
    {
        /// <summary>View types the deep scan checks. Schedules, browsers and the like cannot hold CAD.</summary>
        private static readonly HashSet<ViewType> GraphicalViewTypes = new HashSet<ViewType>
        {
            ViewType.FloorPlan, ViewType.CeilingPlan, ViewType.EngineeringPlan, ViewType.AreaPlan,
            ViewType.Section, ViewType.Elevation, ViewType.Detail, ViewType.ThreeD,
            ViewType.DraftingView, ViewType.Legend, ViewType.DrawingSheet
        };

        /// <summary>Scans <paramref name="doc"/>. Problems with single elements or views are logged, not thrown.</summary>
        public static DwgScanResult Scan(Document doc, Action<LogEntry> log)
        {
            var watch = Stopwatch.StartNew();
            var result = new DwgScanResult { ProjectTitle = doc?.Title ?? string.Empty };
            if (doc == null) return result;

            var instances = new FilteredElementCollector(doc)
                .OfClass(typeof(ImportInstance))
                .Cast<ImportInstance>()
                .ToList();

            ReadTypes(doc, instances, result, log);
            ReadInstances(doc, instances, result, log);

            var sheetsByView = ReadSheetPlacements(doc);

            // Owner views always get a ViewFact, even if the deep scan cannot read them.
            foreach (var inst in result.Instances.Where(i => i.IsViewSpecific && i.OwnerViewId != 0))
                EnsureViewFact(doc, inst.OwnerViewId, result, sheetsByView);

            if (instances.Count > 0)
                DeepScanViews(doc, result, sheetsByView, log);

            watch.Stop();
            result.Elapsed = watch.Elapsed;
            return result;
        }

        // ── Types ────────────────────────────────────────────────────────────

        private static void ReadTypes(Document doc, List<ImportInstance> instances, DwgScanResult result, Action<LogEntry> log)
        {
            // Every CAD type (also those with no instance), plus any other type an instance uses.
            var typeIds = new HashSet<ElementId>(new FilteredElementCollector(doc)
                .OfClass(typeof(CADLinkType))
                .ToElementIds());
            foreach (var inst in instances)
            {
                var id = inst.GetTypeId();
                if (id != null && id != ElementId.InvalidElementId) typeIds.Add(id);
            }

            int unreadable = 0;
            foreach (var typeId in typeIds)
            {
                try
                {
                    var fact = ReadType(doc, typeId);
                    if (fact != null) result.Types.Add(fact);
                    else unreadable++;
                }
                catch (Autodesk.Revit.Exceptions.ApplicationException)
                {
                    unreadable++;
                }
            }

            if (unreadable > 0)
                log?.Invoke(new LogEntry(LogLevel.Warning, $"{unreadable} CAD type(s) could not be read and were skipped."));
        }

        private static CadTypeFact ReadType(Document doc, ElementId typeId)
        {
            if (doc.GetElement(typeId) is not ElementType type) return null;

            string name = type.Name;
            string path = string.Empty;
            string status = "Imported";
            string pathType = string.Empty;
            bool isLinked = false;
            bool isLoaded = true;

            if (ExternalFileUtils.IsExternalFileReference(doc, typeId))
            {
                isLinked = true;
                try
                {
                    var reference = ExternalFileUtils.GetExternalFileReference(doc, typeId);
                    if (reference != null)
                    {
                        var linkStatus = reference.GetLinkedFileStatus();
                        isLoaded = linkStatus == LinkedFileStatus.Loaded;
                        status = Friendly(linkStatus.ToString());
                        pathType = reference.PathType.ToString();

                        var modelPath = reference.GetAbsolutePath();
                        if (modelPath != null)
                            path = ModelPathUtils.ConvertModelPathToUserVisiblePath(modelPath) ?? string.Empty;
                    }
                }
                catch (Autodesk.Revit.Exceptions.ApplicationException)
                {
                    status = "Unknown";
                    isLoaded = false;
                }
            }

            if (string.IsNullOrWhiteSpace(name) && path.Length > 0) name = global::System.IO.Path.GetFileName(path);
            if (string.IsNullOrWhiteSpace(name)) name = $"(CAD type #{typeId.Value})";

            long? size = null;
            DateTime? modified = null;
            if (path.Length > 0)
            {
                try
                {
                    var info = new FileInfo(path);
                    if (info.Exists)
                    {
                        size = info.Length;
                        modified = info.LastWriteTime;
                    }
                }
                catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException ||
                                           ex is ArgumentException || ex is NotSupportedException ||
                                           ex is global::System.Security.SecurityException)
                {
                    // Cloud/server path or no access: size and date stay empty.
                }
            }

            return new CadTypeFact
            {
                TypeId = typeId.Value,
                Name = name,
                IsLinked = isLinked,
                Path = path,
                Status = status,
                IsLoaded = isLoaded,
                PathType = pathType,
                FileSizeBytes = size,
                FileModified = modified
            };
        }

        // "NotFound" → "Not found", "LocallyUnloaded" → "Locally unloaded".
        private static string Friendly(string enumText)
        {
            if (string.IsNullOrEmpty(enumText)) return enumText;
            var sb = new StringBuilder();
            for (int i = 0; i < enumText.Length; i++)
            {
                char c = enumText[i];
                if (i > 0 && char.IsUpper(c)) sb.Append(' ').Append(char.ToLowerInvariant(c));
                else sb.Append(c);
            }
            return sb.ToString();
        }

        // ── Instances ────────────────────────────────────────────────────────

        private static void ReadInstances(Document doc, List<ImportInstance> instances, DwgScanResult result, Action<LogEntry> log)
        {
            var worksets = doc.IsWorkshared ? doc.GetWorksetTable() : null;
            var levelNames = new Dictionary<ElementId, string>();
            int skipped = 0;

            foreach (var inst in instances)
            {
                try
                {
                    var typeId = inst.GetTypeId();
                    if (typeId == null || typeId == ElementId.InvalidElementId)
                    {
                        skipped++;
                        continue;
                    }

                    var ownerId = inst.OwnerViewId ?? ElementId.InvalidElementId;
                    bool viewSpecific = inst.ViewSpecific && ownerId != ElementId.InvalidElementId;

                    result.Instances.Add(new CadInstanceFact
                    {
                        Id = inst.Id.Value,
                        TypeId = typeId.Value,
                        IsViewSpecific = viewSpecific,
                        OwnerViewId = viewSpecific ? ownerId.Value : 0,
                        Pinned = inst.Pinned,
                        Workset = WorksetName(worksets, inst),
                        Level = LevelName(doc, inst.LevelId, levelNames),
                        CreatedBy = Creator(doc, inst.Id),
                        LayerCount = LayerCount(inst)
                    });
                }
                catch (Autodesk.Revit.Exceptions.ApplicationException)
                {
                    skipped++;
                }
            }

            if (skipped > 0)
                log?.Invoke(new LogEntry(LogLevel.Warning, $"{skipped} CAD instance(s) skipped: their type could not be read."));
        }

        private static string WorksetName(WorksetTable table, Element element)
        {
            if (table == null) return string.Empty;
            try
            {
                return table.GetWorkset(element.WorksetId)?.Name ?? string.Empty;
            }
            catch (Autodesk.Revit.Exceptions.ApplicationException)
            {
                return string.Empty;
            }
        }

        private static string LevelName(Document doc, ElementId levelId, Dictionary<ElementId, string> cache)
        {
            if (levelId == null || levelId == ElementId.InvalidElementId) return string.Empty;
            if (cache.TryGetValue(levelId, out var name)) return name;
            name = (doc.GetElement(levelId) as Level)?.Name ?? string.Empty;
            cache[levelId] = name;
            return name;
        }

        private static string Creator(Document doc, ElementId id)
        {
            if (!doc.IsWorkshared) return string.Empty;
            try
            {
                return WorksharingUtils.GetWorksharingTooltipInfo(doc, id)?.Creator ?? string.Empty;
            }
            catch (Autodesk.Revit.Exceptions.ApplicationException)
            {
                return string.Empty;
            }
        }

        // Each CAD file gets its own import category; its sub-categories are the DWG layers.
        private static int LayerCount(ImportInstance inst)
        {
            try
            {
                return inst.Category?.SubCategories?.Size ?? 0;
            }
            catch (Autodesk.Revit.Exceptions.ApplicationException)
            {
                return 0;
            }
        }

        // ── Views and sheets ─────────────────────────────────────────────────

        // View → sheet numbers, from every viewport in the project.
        private static Dictionary<ElementId, List<string>> ReadSheetPlacements(Document doc)
        {
            var map = new Dictionary<ElementId, List<string>>();
            var sheetNumbers = new Dictionary<ElementId, string>();

            foreach (var vp in new FilteredElementCollector(doc).OfClass(typeof(Viewport)).Cast<Viewport>())
            {
                if (!sheetNumbers.TryGetValue(vp.SheetId, out var number))
                {
                    number = (doc.GetElement(vp.SheetId) as ViewSheet)?.SheetNumber ?? string.Empty;
                    sheetNumbers[vp.SheetId] = number;
                }
                if (number.Length == 0) continue;

                if (!map.TryGetValue(vp.ViewId, out var list))
                {
                    list = new List<string>();
                    map[vp.ViewId] = list;
                }
                if (!list.Contains(number)) list.Add(number);
            }

            return map;
        }

        private static void DeepScanViews(Document doc, DwgScanResult result,
            Dictionary<ElementId, List<string>> sheetsByView, Action<LogEntry> log)
        {
            var views = new FilteredElementCollector(doc)
                .OfClass(typeof(View))
                .Cast<View>()
                .Where(v => !v.IsTemplate && GraphicalViewTypes.Contains(v.ViewType))
                .ToList();

            foreach (var view in views)
            {
                ICollection<ElementId> ids;
                try
                {
                    ids = new FilteredElementCollector(doc, view.Id)
                        .OfClass(typeof(ImportInstance))
                        .ToElementIds();
                }
                catch (Autodesk.Revit.Exceptions.ArgumentException)
                {
                    result.ViewsSkipped++;
                    continue;
                }
                catch (Autodesk.Revit.Exceptions.InvalidOperationException)
                {
                    result.ViewsSkipped++;
                    continue;
                }

                result.ViewsScanned++;
                if (ids.Count == 0) continue;

                long viewId = view.Id.Value;
                foreach (var id in ids)
                {
                    if (!result.VisibleIn.TryGetValue(id.Value, out var set))
                    {
                        set = new HashSet<long>();
                        result.VisibleIn[id.Value] = set;
                    }
                    set.Add(viewId);
                }

                EnsureViewFact(view, result, sheetsByView);
            }

            log?.Invoke(new LogEntry(LogLevel.Info,
                $"Deep scan: {result.ViewsScanned} view(s) checked" +
                (result.ViewsSkipped > 0 ? $", {result.ViewsSkipped} skipped (cannot be read)" : string.Empty) + "."));
        }

        private static void EnsureViewFact(Document doc, long viewId, DwgScanResult result,
            Dictionary<ElementId, List<string>> sheetsByView)
        {
            if (result.Views.ContainsKey(viewId)) return;

            if (doc.GetElement(new ElementId(viewId)) is View view)
            {
                EnsureViewFact(view, result, sheetsByView);
            }
            else
            {
                result.Views[viewId] = new ViewFact { Id = viewId, Name = $"(view #{viewId})", TypeLabel = "Other Views" };
            }
        }

        private static void EnsureViewFact(View view, DwgScanResult result, Dictionary<ElementId, List<string>> sheetsByView)
        {
            long id = view.Id.Value;
            if (result.Views.ContainsKey(id)) return;

            var sheets = new List<string>();
            if (view is ViewSheet sheet)
                sheets.Add(sheet.SheetNumber);
            else if (sheetsByView.TryGetValue(view.Id, out var onSheets))
                sheets.AddRange(onSheets);

            string name = view is ViewSheet vs ? $"{vs.SheetNumber} - {vs.Name}" : view.Name;

            result.Views[id] = new ViewFact
            {
                Id = id,
                Name = name,
                TypeLabel = CategoryLabel(view.ViewType),
                SheetNumbers = sheets
            };
        }

        /// <summary>View type label — the same groups DWG Manager V003 uses.</summary>
        public static string CategoryLabel(ViewType viewType)
        {
            switch (viewType)
            {
                case ViewType.FloorPlan:
                case ViewType.EngineeringPlan:
                case ViewType.AreaPlan:
                    return "Floor Plans";
                case ViewType.CeilingPlan:
                    return "Ceiling Plans";
                case ViewType.Elevation:
                    return "Elevations";
                case ViewType.Section:
                    return "Sections";
                case ViewType.Detail:
                    return "Detail Views";
                case ViewType.ThreeD:
                    return "3D Views";
                case ViewType.DraftingView:
                    return "Drafting Views";
                case ViewType.Legend:
                    return "Legends";
                case ViewType.DrawingSheet:
                    return "Sheets";
                default:
                    return "Other Views";
            }
        }
    }
}
