using System;
using System.Collections.Generic;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.DwgStatistics.V002.Infrastructure.RevitApi
{
    /// <summary>
    /// Opens views and selects / zooms to CAD instances. Must run in a Revit API context (the tool's
    /// external event) — Revit refuses these calls from a modeless window directly. Same behaviour as
    /// DWG Manager V003's DwgViewService, plus opening a view that draws the instance before zooming.
    /// </summary>
    public static class DwgNavigationService
    {
        /// <summary>Makes <paramref name="viewId"/> the active view. Returns false if it cannot be opened.</summary>
        public static bool OpenView(UIDocument uidoc, long viewId, Action<LogEntry> log)
        {
            if (viewId == 0) return false;

            if (uidoc.Document.GetElement(new ElementId(viewId)) is not View view || !view.IsValidObject || view.IsTemplate)
            {
                log?.Invoke(new LogEntry(LogLevel.Warning, $"View #{viewId} no longer exists. Refresh the statistics."));
                return false;
            }

            if (uidoc.ActiveView != null && uidoc.ActiveView.Id == view.Id) return true;

            try
            {
                uidoc.ActiveView = view;
                log?.Invoke(new LogEntry(LogLevel.Info, $"Opened view: {view.Name}"));
                return true;
            }
            catch (Autodesk.Revit.Exceptions.ApplicationException ex)
            {
                log?.Invoke(new LogEntry(LogLevel.Warning, $"Could not open '{view.Name}': {ex.Message}"));
                return false;
            }
        }

        /// <summary>
        /// Opens every view in <paramref name="viewIds"/> in order (duplicates once); the last one opened
        /// ends up active. Returns how many views were opened.
        /// </summary>
        public static int OpenViews(UIDocument uidoc, IEnumerable<long> viewIds, Action<LogEntry> log)
        {
            int opened = 0;
            var seen = new HashSet<long>();
            foreach (long id in viewIds)
            {
                if (id == 0 || !seen.Add(id)) continue;
                if (OpenView(uidoc, id, log)) opened++;
            }
            return opened;
        }

        /// <summary>
        /// Selects instance <paramref name="instanceId"/> and zooms to it. If the active view does not
        /// draw it, <paramref name="fallbackViewId"/> (a view that does) is opened first.
        /// </summary>
        public static bool SelectAndZoom(UIDocument uidoc, long instanceId, long fallbackViewId, Action<LogEntry> log)
        {
            var doc = uidoc.Document;
            var id = new ElementId(instanceId);
            var element = doc.GetElement(id);
            if (element == null || !element.IsValidObject)
            {
                log?.Invoke(new LogEntry(LogLevel.Warning, $"#{instanceId} no longer exists. Refresh the statistics."));
                return false;
            }

            if (!IsDrawnIn(doc, uidoc.ActiveView, id))
            {
                if (fallbackViewId == 0 || !OpenView(uidoc, fallbackViewId, log))
                {
                    log?.Invoke(new LogEntry(LogLevel.Warning, $"#{instanceId} is not drawn in any view that can be opened."));
                    return false;
                }
            }

            uidoc.Selection.SetElementIds(new List<ElementId> { id });

            try
            {
                uidoc.ShowElements(id);
            }
            catch (Autodesk.Revit.Exceptions.ApplicationException ex)
            {
                log?.Invoke(new LogEntry(LogLevel.Warning, $"Selected #{instanceId} but could not zoom to it: {ex.Message}"));
                return true;
            }

            log?.Invoke(new LogEntry(LogLevel.Info, $"Selected and zoomed to #{instanceId}."));
            return true;
        }

        private static bool IsDrawnIn(Document doc, View view, ElementId id)
        {
            if (view == null || !view.IsValidObject) return false;
            try
            {
                foreach (var visible in new FilteredElementCollector(doc, view.Id).OfClass(typeof(ImportInstance)).ToElementIds())
                    if (visible == id) return true;
            }
            catch (Autodesk.Revit.Exceptions.ApplicationException)
            {
                // Schedules, browsers…: nothing is drawn there.
            }
            return false;
        }
    }
}
