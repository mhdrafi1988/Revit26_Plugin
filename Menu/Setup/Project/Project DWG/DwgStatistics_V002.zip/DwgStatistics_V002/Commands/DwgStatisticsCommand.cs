using System.Windows;
using System.Windows.Interop;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;
using Revit26_Plugin.DwgStatistics.V002.UI.ViewModels;
using Revit26_Plugin.DwgStatistics.V002.UI.Views;
using Revit26_Plugin.Shared.Services;

namespace Revit26_Plugin.DwgStatistics.V002.Commands
{
    // V002 (2026-10-13) — bumped from V001, per Anas's request:
    //   • Views tab of the selected DWG now has a tick column: tick the views you need, then
    //     "Open Ticked Views" opens them all (up to MaxOpenViews at once, same idea as DWG Manager V003).
    //     Tick All / Clear in the tab; the per-row Open button stays for a quick single view.
    //   • View ticks are kept across Refresh and cleanup actions (by DWG type + view).
    // V001 (2026-10-13) — new tool, per Anas's confirmed plan:
    //   • One row per DWG file (CAD link or import type): instances (view-specific / model), views it is
    //     placed in, views it is visible in, sheets, pinned, layers, link status and issue badges.
    //   • Always deep-scans every graphical view to count where each DWG is actually drawn.
    //   • Cleanup actions on ticked files: Pin All, Reload Links, Purge Unused (each one undo step).
    //   • Export to .xlsx (Summary / Views / Instances / Scan Info) with no extra NuGet dependency.
    //   • Reuses DWG Manager V003's patterns: single window per session, queued external event,
    //     ToolWindowShell, shared LogEntry log.
    /// <summary>
    /// Opens the DWG Statistics window (single instance per Revit session). Running it again brings the
    /// open window forward, or reopens it for the active document if the user switched documents.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class DwgStatisticsCommand : IExternalCommand
    {
        private static DwgStatisticsWindow _window;

        /// <inheritdoc/>
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
            => ToolGuard.RunCommand(GetType(), commandData, ref message, elements, ExecuteUnguarded);

        private Result ExecuteUnguarded(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            var uidoc = commandData.Application.ActiveUIDocument;
            if (uidoc?.Document == null)
            {
                TaskDialog.Show(DwgStatisticsTool.Title, "Open a project first.");
                return Result.Cancelled;
            }

            if (uidoc.Document.IsFamilyDocument)
            {
                TaskDialog.Show(DwgStatisticsTool.Title, "DWG Statistics works in a project, not in the Family Editor.");
                return Result.Cancelled;
            }

            if (_window != null)
            {
                if (_window.ViewModel.IsFor(uidoc.Document))
                {
                    if (_window.WindowState == WindowState.Minimized) _window.WindowState = WindowState.Normal;
                    _window.Activate();
                    return Result.Succeeded;
                }

                // Opened for another document: replace it with a window for the active one.
                _window.Close();
            }

            // The first scan is queued from the window's ContentRendered, so the window (with its
            // "Scanning…" status) is on screen before the deep scan starts.
            var viewModel = new DwgStatisticsViewModel(uidoc.Document);
            var window = new DwgStatisticsWindow(viewModel);
            new WindowInteropHelper(window).Owner = commandData.Application.MainWindowHandle;
            window.Closed += (_, _) =>
            {
                if (ReferenceEquals(_window, window)) _window = null;
            };

            _window = window;
            window.Show();
            return Result.Succeeded;
        }
    }
}
