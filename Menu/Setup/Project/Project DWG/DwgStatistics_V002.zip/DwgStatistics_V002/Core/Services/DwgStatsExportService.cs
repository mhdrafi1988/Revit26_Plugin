using System;
using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;

namespace Revit26_Plugin.DwgStatistics.V002.Core.Services
{
    /// <summary>
    /// Writes the statistics to an .xlsx workbook: Summary (one row per DWG file), Views (file × view),
    /// Instances (one row per instance) and Scan Info. Pure .NET; runs on the UI thread from the last
    /// scan, so it never needs Revit.
    /// </summary>
    public static class DwgStatsExportService
    {
        /// <summary>Saves the workbook to <paramref name="path"/>.</summary>
        public static void Export(string path, IReadOnlyList<DwgFileStats> files, DwgProjectTotals totals,
            string projectTitle, int viewsScanned, int viewsSkipped, TimeSpan elapsed, string toolLabel)
        {
            var xlsx = new SimpleXlsxWriter();

            xlsx.AddSheet("Summary",
                new[]
                {
                    "DWG File", "Kind", "Status", "Instances", "View-specific", "Model", "Pinned", "Unpinned",
                    "Placed in Views", "Views Total (placed + visible)", "Sheets", "Layers", "Issues",
                    "Path", "Path Type", "File Size (KB)", "File Modified", "Type Id"
                },
                files.Select(f => new object[]
                {
                    f.FileName, f.Kind, f.Status, f.InstanceCount, f.ViewSpecificCount, f.ModelCount,
                    f.PinnedCount, f.UnpinnedCount, f.PlacedViewCount, f.VisibleViewCount, f.SheetCount,
                    f.LayerCount, f.IssueText, f.Path, f.PathType,
                    f.FileSizeBytes.HasValue ? Math.Round(f.FileSizeBytes.Value / 1024.0, 1) : (object)null,
                    f.FileModified, f.TypeId
                }));

            xlsx.AddSheet("Views",
                new[] { "DWG File", "Kind", "View", "View Type", "Relation", "Placed Instances", "Visible Instances", "Sheets", "View Id" },
                files.SelectMany(f => f.Views.Select(v => new object[]
                {
                    f.FileName, f.Kind, v.ViewName, v.ViewType, v.Relation, v.PlacedInstances, v.VisibleInstances, v.Sheets, v.ViewId
                })));

            xlsx.AddSheet("Instances",
                new[] { "DWG File", "Kind", "Instance Id", "Placement", "Owner View", "Visible in Views", "Pinned", "Workset", "Level", "Created By" },
                files.SelectMany(f => f.Instances.Select(i => new object[]
                {
                    f.FileName, f.Kind, i.Id, i.Placement, i.OwnerViewName, i.VisibleViewCount, i.PinnedText, i.Workset, i.Level, i.CreatedBy
                })));

            xlsx.AddSheet("Scan Info",
                new[] { "Item", "Value" },
                new List<object[]>
                {
                    new object[] { "Project", projectTitle },
                    new object[] { "Exported", DateTime.Now },
                    new object[] { "Tool", toolLabel },
                    new object[] { "DWG files", totals.Files },
                    new object[] { "Links", totals.Links },
                    new object[] { "Imports", totals.Imports },
                    new object[] { "Instances", totals.Instances },
                    new object[] { "Views showing CAD", totals.Views },
                    new object[] { "Sheets showing CAD", totals.Sheets },
                    new object[] { "Links not loaded", totals.NotLoaded },
                    new object[] { "Unused types", totals.Unused },
                    new object[] { "Files with issues", totals.WithIssues },
                    new object[] { "Views scanned", viewsScanned },
                    new object[] { "Views skipped", viewsSkipped },
                    new object[] { "Scan time (s)", Math.Round(elapsed.TotalSeconds, 1) }
                });

            xlsx.Save(path);
        }

        /// <summary>"Project_DWG_Statistics_20261013_0945.xlsx" with characters Windows rejects removed.</summary>
        public static string DefaultFileName(string projectTitle)
        {
            string name = string.IsNullOrWhiteSpace(projectTitle) ? "Project" : projectTitle;
            // Windows-invalid characters listed explicitly too, so the name is safe whatever OS builds it.
            foreach (char c in global::System.IO.Path.GetInvalidFileNameChars().Concat("<>:\"/\\|?*"))
                name = name.Replace(c, '_');
            name = name.Trim().TrimEnd('.');
            return $"{name}_DWG_Statistics_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
        }
    }
}
