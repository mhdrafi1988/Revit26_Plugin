using System;
using System.Collections.Generic;
using System.Linq;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;

namespace Revit26_Plugin.DwgStatistics.V002.Core.Services
{
    /// <summary>
    /// Turns the raw facts of one scan into per-file statistics, issue badges and project totals.
    /// Pure .NET — no Revit API — so it can be reasoned about (and tested) on its own.
    /// </summary>
    public static class DwgStatsBuilder
    {
        /// <summary>Builds one <see cref="DwgFileStats"/> per CAD type, problems first, then by name.</summary>
        public static List<DwgFileStats> Build(DwgScanResult scan)
        {
            var result = new List<DwgFileStats>();
            if (scan == null) return result;

            var byType = scan.Instances
                .GroupBy(i => i.TypeId)
                .ToDictionary(g => g.Key, g => g.ToList());

            // Duplicate detection: the same path (links) or the same file name brought in more than once.
            var pathCounts = scan.Types
                .Where(t => !string.IsNullOrWhiteSpace(t.Path))
                .GroupBy(t => t.Path.Trim(), StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase);
            var nameCounts = scan.Types
                .GroupBy(t => t.Name.Trim(), StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase);

            foreach (var type in scan.Types)
            {
                byType.TryGetValue(type.TypeId, out var instances);
                instances ??= new List<CadInstanceFact>();

                var instanceStats = new List<DwgInstanceStats>();
                var placedViews = new Dictionary<long, int>();   // view → instances owned
                var visibleViews = new Dictionary<long, int>();  // view → instances drawn

                foreach (var inst in instances)
                {
                    if (inst.IsViewSpecific && inst.OwnerViewId != 0)
                        placedViews[inst.OwnerViewId] = placedViews.TryGetValue(inst.OwnerViewId, out int p) ? p + 1 : 1;

                    scan.VisibleIn.TryGetValue(inst.Id, out var seenIn);
                    seenIn ??= new HashSet<long>();
                    foreach (var viewId in seenIn)
                        visibleViews[viewId] = visibleViews.TryGetValue(viewId, out int v) ? v + 1 : 1;

                    long best = inst.IsViewSpecific && inst.OwnerViewId != 0
                        ? inst.OwnerViewId
                        : PickBestView(seenIn, scan.Views);

                    instanceStats.Add(new DwgInstanceStats
                    {
                        Id = inst.Id,
                        IsViewSpecific = inst.IsViewSpecific,
                        Placement = inst.IsViewSpecific ? "View-specific" : "Model",
                        OwnerViewId = inst.OwnerViewId,
                        OwnerViewName = inst.IsViewSpecific ? ViewName(scan, inst.OwnerViewId) : "(all views)",
                        VisibleViewCount = seenIn.Count,
                        BestViewId = best,
                        Pinned = inst.Pinned,
                        Workset = inst.Workset,
                        Level = inst.Level,
                        CreatedBy = inst.CreatedBy
                    });
                }

                // Views tab: every view that owns or draws the file.
                var allViewIds = new HashSet<long>(placedViews.Keys);
                allViewIds.UnionWith(visibleViews.Keys);

                var views = allViewIds
                    .Select(id =>
                    {
                        scan.Views.TryGetValue(id, out var vf);
                        placedViews.TryGetValue(id, out int placed);
                        visibleViews.TryGetValue(id, out int visible);
                        return new DwgViewUsage
                        {
                            ViewId = id,
                            ViewName = vf?.Name ?? $"(view #{id})",
                            ViewType = vf?.TypeLabel ?? "Other Views",
                            Sheets = vf == null ? string.Empty : string.Join(", ", vf.SheetNumbers),
                            IsPlaced = placed > 0,
                            PlacedInstances = placed,
                            VisibleInstances = visible
                        };
                    })
                    .OrderByDescending(v => v.IsPlaced)
                    .ThenBy(v => v.ViewType, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(v => v.ViewName, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                var sheets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var id in allViewIds)
                    if (scan.Views.TryGetValue(id, out var vf))
                        sheets.UnionWith(vf.SheetNumbers);

                var stats = new DwgFileStats
                {
                    TypeId = type.TypeId,
                    FileName = type.Name,
                    IsLinked = type.IsLinked,
                    Status = type.Status,
                    IsLoaded = type.IsLoaded,
                    Path = type.Path,
                    PathType = type.PathType,
                    FileSizeBytes = type.FileSizeBytes,
                    FileModified = type.FileModified,
                    InstanceCount = instances.Count,
                    ViewSpecificCount = instances.Count(i => i.IsViewSpecific),
                    ModelCount = instances.Count(i => !i.IsViewSpecific),
                    PinnedCount = instances.Count(i => i.Pinned),
                    PlacedViewCount = placedViews.Count,
                    VisibleViewCount = allViewIds.Count,
                    SheetCount = sheets.Count,
                    LayerCount = instances.Count == 0 ? 0 : instances.Max(i => i.LayerCount),
                    Instances = instanceStats.OrderBy(i => i.Placement).ThenBy(i => i.OwnerViewName).ThenBy(i => i.Id).ToList(),
                    Views = views
                };

                stats.Issues.AddRange(FindIssues(type, stats, pathCounts, nameCounts));
                result.Add(stats);
            }

            return result
                .OrderByDescending(s => s.Issues.Count == 0 ? -1 : (int)s.Issues.Max(i => i.Severity))
                .ThenByDescending(s => s.IsLinked)
                .ThenBy(s => s.FileName, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        /// <summary>Header totals over all files.</summary>
        public static DwgProjectTotals Totals(IReadOnlyCollection<DwgFileStats> files)
        {
            var views = new HashSet<long>();
            var sheets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var f in files)
            {
                foreach (var v in f.Views)
                {
                    views.Add(v.ViewId);
                    foreach (var s in v.Sheets.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries))
                        sheets.Add(s);
                }
            }

            return new DwgProjectTotals
            {
                Files = files.Count,
                Links = files.Count(f => f.IsLinked),
                Imports = files.Count(f => !f.IsLinked),
                Instances = files.Sum(f => f.InstanceCount),
                Views = views.Count,
                Sheets = sheets.Count,
                NotLoaded = files.Count(f => f.IsLinked && !f.IsLoaded),
                WithIssues = files.Count(f => f.HasProblem),
                Unused = files.Count(f => f.InstanceCount == 0)
            };
        }

        /// <summary>True when <paramref name="file"/> passes the quick filter.</summary>
        public static bool Passes(DwgFileStats file, DwgQuickFilter filter)
        {
            switch (filter)
            {
                case DwgQuickFilter.Links: return file.IsLinked;
                case DwgQuickFilter.Imports: return !file.IsLinked;
                case DwgQuickFilter.NotLoaded: return file.IsLinked && !file.IsLoaded;
                case DwgQuickFilter.Unused: return file.InstanceCount == 0;
                case DwgQuickFilter.Issues: return file.HasProblem;
                default: return true;
            }
        }

        private static IEnumerable<DwgIssue> FindIssues(CadTypeFact type, DwgFileStats s,
            IReadOnlyDictionary<string, int> pathCounts, IReadOnlyDictionary<string, int> nameCounts)
        {
            if (type.IsLinked && !type.IsLoaded)
                yield return new DwgIssue(type.Status, IssueSeverity.Danger,
                    $"The link is {type.Status}. Reload it, or fix the path in Manage Links.");

            if (!type.IsLinked)
                yield return new DwgIssue("Imported", IssueSeverity.Warning,
                    "Imported CAD is stored inside the model and does not update. Prefer Link CAD.");

            if (s.InstanceCount == 0)
                yield return new DwgIssue("Unused", IssueSeverity.Warning,
                    "No instance is placed. Purge Unused removes this type.");

            bool duplicatePath = !string.IsNullOrWhiteSpace(type.Path)
                                 && pathCounts.TryGetValue(type.Path.Trim(), out int pc) && pc > 1;
            bool duplicateName = nameCounts.TryGetValue(type.Name.Trim(), out int nc) && nc > 1;
            if (duplicatePath || duplicateName)
                yield return new DwgIssue("Duplicate", IssueSeverity.Warning,
                    duplicatePath
                        ? "The same file is linked/imported more than once."
                        : "Another CAD type has the same file name.");

            if (s.ModelCount > 0)
                yield return new DwgIssue("Model placed", IssueSeverity.Info,
                    $"{s.ModelCount} instance(s) are not 'Current view only', so they can show in every view (including 3D).");

            if (s.InstanceCount > 0 && s.UnpinnedCount > 0)
                yield return new DwgIssue("Unpinned", IssueSeverity.Info,
                    $"{s.UnpinnedCount} instance(s) are not pinned and can be moved by accident. Pin All fixes this.");

            if (s.InstanceCount > 0 && s.VisibleViewCount == 0)
                yield return new DwgIssue("Not visible", IssueSeverity.Info,
                    "Placed, but no view draws it (hidden by category, hidden in view, or only in views that cannot be read).");
        }

        // Prefer a plan, then other views, so Zoom opens a sensible view for a model instance.
        private static long PickBestView(HashSet<long> viewIds, IReadOnlyDictionary<long, ViewFact> views)
        {
            if (viewIds == null || viewIds.Count == 0) return 0;

            return viewIds
                .OrderBy(id => views.TryGetValue(id, out var v) ? Rank(v.TypeLabel) : 99)
                .ThenBy(id => views.TryGetValue(id, out var v) ? v.Name : string.Empty, StringComparer.OrdinalIgnoreCase)
                .First();
        }

        private static int Rank(string typeLabel)
        {
            switch (typeLabel)
            {
                case "Floor Plans": return 0;
                case "Ceiling Plans": return 1;
                case "Sections": return 2;
                case "Elevations": return 3;
                case "3D Views": return 4;
                default: return 5;
            }
        }

        private static string ViewName(DwgScanResult scan, long viewId)
            => scan.Views.TryGetValue(viewId, out var v) ? v.Name : $"(view #{viewId})";
    }
}
