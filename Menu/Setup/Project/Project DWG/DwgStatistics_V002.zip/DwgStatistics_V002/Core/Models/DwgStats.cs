using System;
using System.Collections.Generic;

namespace Revit26_Plugin.DwgStatistics.V002.Core.Models
{
    /// <summary>How serious an issue badge is; drives its colour.</summary>
    public enum IssueSeverity
    {
        /// <summary>Worth knowing (model placement, unpinned).</summary>
        Info,

        /// <summary>Should be cleaned up (imported, unused, duplicate).</summary>
        Warning,

        /// <summary>Broken (link not found / not loaded).</summary>
        Danger
    }

    /// <summary>One issue badge on a DWG file row.</summary>
    public sealed class DwgIssue
    {
        /// <summary>Creates an issue.</summary>
        public DwgIssue(string text, IssueSeverity severity, string detail)
        {
            Text = text;
            Severity = severity;
            Detail = detail;
        }

        /// <summary>Short badge text ("Not found").</summary>
        public string Text { get; }

        /// <summary>Badge colour.</summary>
        public IssueSeverity Severity { get; }

        /// <summary>Tooltip: what the issue means and what to do.</summary>
        public string Detail { get; }

        /// <summary>Severity as text, for XAML triggers.</summary>
        public string SeverityName => Severity.ToString();
    }

    /// <summary>The quick-filter chips above the file grid.</summary>
    public enum DwgQuickFilter
    {
        /// <summary>Every file.</summary>
        All,

        /// <summary>Linked files only.</summary>
        Links,

        /// <summary>Imported files only.</summary>
        Imports,

        /// <summary>Links that are not loaded (not found, unloaded…).</summary>
        NotLoaded,

        /// <summary>Types with no instance.</summary>
        Unused,

        /// <summary>Files with at least one warning or danger issue.</summary>
        Issues
    }

    /// <summary>One CAD instance with its resolved view names, for the Instances tab and the export.</summary>
    public sealed class DwgInstanceStats
    {
        /// <summary>Element ID.</summary>
        public long Id { get; init; }

        /// <summary>"View-specific" or "Model".</summary>
        public string Placement { get; init; } = string.Empty;

        /// <summary>True when placed "Current view only".</summary>
        public bool IsViewSpecific { get; init; }

        /// <summary>Owner view ID, or 0.</summary>
        public long OwnerViewId { get; init; }

        /// <summary>Owner view name, or "(all views)".</summary>
        public string OwnerViewName { get; init; } = string.Empty;

        /// <summary>Number of views that draw this instance.</summary>
        public int VisibleViewCount { get; init; }

        /// <summary>A view that draws this instance (owner view first), used to open and zoom; 0 if none.</summary>
        public long BestViewId { get; init; }

        /// <summary>True when pinned.</summary>
        public bool Pinned { get; init; }

        /// <summary>"Yes" / "No".</summary>
        public string PinnedText => Pinned ? "Yes" : "No";

        /// <summary>Workset name.</summary>
        public string Workset { get; init; } = string.Empty;

        /// <summary>Level name.</summary>
        public string Level { get; init; } = string.Empty;

        /// <summary>Creator (workshared models).</summary>
        public string CreatedBy { get; init; } = string.Empty;
    }

    /// <summary>One view that owns or draws a DWG file, for the Views tab and the export.</summary>
    public sealed class DwgViewUsage
    {
        /// <summary>Element ID of the view.</summary>
        public long ViewId { get; init; }

        /// <summary>View name.</summary>
        public string ViewName { get; init; } = string.Empty;

        /// <summary>View type label.</summary>
        public string ViewType { get; init; } = string.Empty;

        /// <summary>Sheet numbers, comma separated, or empty.</summary>
        public string Sheets { get; init; } = string.Empty;

        /// <summary>True when the view owns at least one view-specific instance of the file.</summary>
        public bool IsPlaced { get; init; }

        /// <summary>Instances of the file drawn in the view.</summary>
        public int VisibleInstances { get; init; }

        /// <summary>Instances of the file owned by the view.</summary>
        public int PlacedInstances { get; init; }

        /// <summary>"Placed here" or "Visible (model)".</summary>
        public string Relation => IsPlaced ? "Placed here" : "Visible (model)";
    }

    /// <summary>Statistics of one DWG file (one CAD type) — one row of the main grid.</summary>
    public sealed class DwgFileStats
    {
        /// <summary>Element ID of the CAD type.</summary>
        public long TypeId { get; init; }

        /// <summary>File name.</summary>
        public string FileName { get; init; } = string.Empty;

        /// <summary>True for a link, false for an import.</summary>
        public bool IsLinked { get; init; }

        /// <summary>"Link" / "Import".</summary>
        public string Kind => IsLinked ? "Link" : "Import";

        /// <summary>Revit link status, or "Imported".</summary>
        public string Status { get; init; } = string.Empty;

        /// <summary>True when loaded (always true for imports).</summary>
        public bool IsLoaded { get; init; }

        /// <summary>Full path, or empty.</summary>
        public string Path { get; init; } = string.Empty;

        /// <summary>Absolute / Relative…</summary>
        public string PathType { get; init; } = string.Empty;

        /// <summary>File size on disk.</summary>
        public long? FileSizeBytes { get; init; }

        /// <summary>File date on disk.</summary>
        public DateTime? FileModified { get; init; }

        /// <summary>Size as "1.2 MB", or "—".</summary>
        public string FileSizeText => FormatSize(FileSizeBytes);

        /// <summary>Total instances.</summary>
        public int InstanceCount { get; init; }

        /// <summary>Instances placed "Current view only".</summary>
        public int ViewSpecificCount { get; init; }

        /// <summary>Instances placed in the model (all views).</summary>
        public int ModelCount { get; init; }

        /// <summary>Pinned instances.</summary>
        public int PinnedCount { get; init; }

        /// <summary>Unpinned instances.</summary>
        public int UnpinnedCount => InstanceCount - PinnedCount;

        /// <summary>"3 / 5".</summary>
        public string PinnedText => InstanceCount == 0 ? "—" : $"{PinnedCount} / {InstanceCount}";

        /// <summary>Distinct views that own a view-specific instance.</summary>
        public int PlacedViewCount { get; init; }

        /// <summary>Distinct views that draw any instance (deep scan).</summary>
        public int VisibleViewCount { get; init; }

        /// <summary>Distinct sheets holding any of those views.</summary>
        public int SheetCount { get; init; }

        /// <summary>CAD layers (max over its instances), or 0 when unused.</summary>
        public int LayerCount { get; init; }

        /// <summary>Issue badges.</summary>
        public List<DwgIssue> Issues { get; init; } = new List<DwgIssue>();

        /// <summary>Issues joined for the export ("Imported; Unpinned").</summary>
        public string IssueText => string.Join("; ", Issues.ConvertAll(i => i.Text));

        /// <summary>True when any issue is a warning or worse.</summary>
        public bool HasProblem => Issues.Exists(i => i.Severity != IssueSeverity.Info);

        /// <summary>Instances of the file.</summary>
        public List<DwgInstanceStats> Instances { get; init; } = new List<DwgInstanceStats>();

        /// <summary>Views that own or draw the file.</summary>
        public List<DwgViewUsage> Views { get; init; } = new List<DwgViewUsage>();

        /// <summary>"1.2 MB" style size text.</summary>
        public static string FormatSize(long? bytes)
        {
            if (bytes == null) return "—";
            double b = bytes.Value;
            if (b < 1024) return $"{b:0} B";
            if (b < 1024 * 1024) return $"{b / 1024:0.0} KB";
            return $"{b / (1024 * 1024):0.0} MB";
        }
    }

    /// <summary>Project-wide totals for the header tiles.</summary>
    public sealed class DwgProjectTotals
    {
        /// <summary>CAD files (types).</summary>
        public int Files { get; init; }

        /// <summary>Linked files.</summary>
        public int Links { get; init; }

        /// <summary>Imported files.</summary>
        public int Imports { get; init; }

        /// <summary>CAD instances.</summary>
        public int Instances { get; init; }

        /// <summary>Distinct views that own or draw CAD.</summary>
        public int Views { get; init; }

        /// <summary>Distinct sheets showing CAD.</summary>
        public int Sheets { get; init; }

        /// <summary>Links not loaded.</summary>
        public int NotLoaded { get; init; }

        /// <summary>Files with a warning or danger issue.</summary>
        public int WithIssues { get; init; }

        /// <summary>Types with no instance.</summary>
        public int Unused { get; init; }
    }

    /// <summary>Counts from one cleanup action (pin, reload or purge).</summary>
    public sealed class DwgActionResult
    {
        /// <summary>Action name for the summary ("Pin").</summary>
        public string Action { get; init; } = string.Empty;

        /// <summary>Items changed.</summary>
        public int Done { get; set; }

        /// <summary>Items left alone (already done, owned by another user, not applicable).</summary>
        public int Skipped { get; set; }

        /// <summary>Items Revit refused.</summary>
        public int Failed { get; set; }

        /// <summary>True when Revit rolled the transaction back.</summary>
        public bool RolledBack { get; set; }

        /// <summary>"Pin: 4 done | 1 skipped | 0 failed".</summary>
        public string Summary => RolledBack
            ? $"{Action}: rolled back — nothing was changed."
            : $"{Action}: {Done} done | {Skipped} skipped | {Failed} failed";
    }
}
