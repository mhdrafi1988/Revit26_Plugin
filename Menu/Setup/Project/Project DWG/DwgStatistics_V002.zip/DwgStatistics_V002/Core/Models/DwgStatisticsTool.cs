namespace Revit26_Plugin.DwgStatistics.V002.Core.Models
{
    /// <summary>
    /// Title and version of the tool. Kept local instead of in Shared ToolCatalog so this tool builds on
    /// its own; move it into ToolCatalog (like ToolCatalog.DwgManager) if you prefer one catalog.
    /// </summary>
    public static class DwgStatisticsTool
    {
        /// <summary>Window / dialog title.</summary>
        public const string Title = "DWG Statistics";

        /// <summary>Version shown in the window header.</summary>
        public const string Version = "V002";

        /// <summary>
        /// V002: most views "Open Ticked Views" opens at once (each one is a full view open in Revit;
        /// DWG Manager V003 uses the same limit). Raise it here if you need more.
        /// </summary>
        public const int MaxOpenViews = 5;

        /// <summary>"DWG Statistics V002".</summary>
        public const string Label = Title + " " + Version;
    }
}
