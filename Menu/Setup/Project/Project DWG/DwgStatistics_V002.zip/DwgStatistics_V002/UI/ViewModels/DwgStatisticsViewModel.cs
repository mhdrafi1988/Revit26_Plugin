using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Threading;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;
using Revit26_Plugin.DwgStatistics.V002.Core.Services;
using Revit26_Plugin.DwgStatistics.V002.Infrastructure.ExternalEvents;
using Revit26_Plugin.DwgStatistics.V002.Infrastructure.RevitApi;
using Revit26_Plugin.Shared.Models;
using Revit26_Plugin.Shared.Services;
using Revit26_Plugin.Shared.ViewModels;

namespace Revit26_Plugin.DwgStatistics.V002.UI.ViewModels
{
    /// <summary>
    /// View model of the DWG Statistics window. Every Revit read or write goes through the tool's
    /// external event; the grid, filters and export work on the last scan in memory.
    /// </summary>
    public partial class DwgStatisticsViewModel : ToolViewModelBase
    {
        private readonly Document _doc;
        private readonly DwgStatisticsHandler _handler = new();
        private readonly ExternalEvent _externalEvent;
        private readonly Dispatcher _dispatcher;

        // Queued actions that have not finished; the window shows "running" while above zero.
        private int _busy;

        // True while this view model ticks rows itself, so the counts are recomputed once.
        private bool _suspend;

        // Last scan, kept for the export's Scan Info sheet.
        private DwgScanResult _lastScan;
        private DwgProjectTotals _totals = new DwgProjectTotals();

        // V002: the file row whose view ticks drive OpenTickedViewsCommand's CanExecute.
        private DwgFileRowViewModel _watchedFile;

        /// <summary>All file rows.</summary>
        public ObservableCollection<DwgFileRowViewModel> Files { get; } = new();

        /// <summary>File rows that pass the quick filter and the search box.</summary>
        public ICollectionView FilesView { get; }

        /// <summary>Active quick-filter chip.</summary>
        [ObservableProperty] private DwgQuickFilter activeQuickFilter = DwgQuickFilter.All;

        /// <summary>Shows only files whose name, status, kind, path or issues contain every word typed.</summary>
        [ObservableProperty] private string searchText = string.Empty;

        /// <summary>File shown in the detail tabs.</summary>
        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(HasSelectedFile))]
        private DwgFileRowViewModel selectedFile;

        /// <summary>True when a file is selected (detail tabs visible).</summary>
        public bool HasSelectedFile => SelectedFile != null;

        // ── Header tiles ─────────────────────────────────────────────────────

        /// <summary>DWG files.</summary>
        [ObservableProperty] private int totalFiles;

        /// <summary>Linked files.</summary>
        [ObservableProperty] private int linkCount;

        /// <summary>Imported files.</summary>
        [ObservableProperty] private int importCount;

        /// <summary>CAD instances.</summary>
        [ObservableProperty] private int totalInstances;

        /// <summary>Views that own or draw CAD.</summary>
        [ObservableProperty] private int viewsUsed;

        /// <summary>Sheets that show CAD.</summary>
        [ObservableProperty] private int sheetsUsed;

        /// <summary>Links not loaded.</summary>
        [ObservableProperty] private int notLoadedCount;

        /// <summary>Files with warning/danger issues.</summary>
        [ObservableProperty] private int issueFileCount;

        /// <summary>Unused types.</summary>
        [ObservableProperty] private int unusedCount;

        /// <summary>Hint under the toolbar (views scanned, time).</summary>
        [ObservableProperty] private string scanInfo = "Scanning…";

        // ── Chip labels ──────────────────────────────────────────────────────

        /// <summary>"All (12)".</summary>
        public string AllChipText => $"All ({TotalFiles})";

        /// <summary>"Links (8)".</summary>
        public string LinksChipText => $"Links ({LinkCount})";

        /// <summary>"Imports (4)".</summary>
        public string ImportsChipText => $"Imports ({ImportCount})";

        /// <summary>"Not loaded (1)".</summary>
        public string NotLoadedChipText => $"Not loaded ({NotLoadedCount})";

        /// <summary>"Unused (2)".</summary>
        public string UnusedChipText => $"Unused ({UnusedCount})";

        /// <summary>"Has issues (5)".</summary>
        public string IssuesChipText => $"Has issues ({IssueFileCount})";

        // ── Ticks and action labels ──────────────────────────────────────────

        /// <summary>Ticked rows.</summary>
        [ObservableProperty] private int tickedCount;

        /// <summary>Unpinned instances among the ticked files.</summary>
        [ObservableProperty] private int tickedUnpinned;

        /// <summary>Linked files among the ticked files.</summary>
        [ObservableProperty] private int tickedLinks;

        /// <summary>Unused types among the ticked files.</summary>
        [ObservableProperty] private int tickedUnused;

        /// <summary>"Pin All (3)".</summary>
        public string PinAllLabel => $"Pin All ({TickedUnpinned})";

        /// <summary>"Reload Links (2)".</summary>
        public string ReloadLabel => $"Reload Links ({TickedLinks})";

        /// <summary>"Purge Unused (1)".</summary>
        public string PurgeLabel => $"Purge Unused ({TickedUnused})";

        /// <summary>Footer hint.</summary>
        public string TickHint => TickedCount == 0
            ? "Tick files to pin, reload or purge them. Click a file to see its views and instances."
            : $"{TickedCount} file(s) ticked · each action is one undo step (Ctrl+Z in Revit).";

        /// <summary>
        /// Creates the view model for <paramref name="doc"/>. The first scan is started by the window
        /// (RefreshCommand on ContentRendered) so the window is visible while it runs.
        /// </summary>
        public DwgStatisticsViewModel(Document doc)
        {
            _doc = doc ?? throw new ArgumentNullException(nameof(doc));
            _dispatcher = Dispatcher.CurrentDispatcher;
            _externalEvent = ExternalEvent.Create(_handler);

            var view = CollectionViewSource.GetDefaultView(Files);
            view.Filter = obj => obj is DwgFileRowViewModel row && PassesFilters(row);
            FilesView = view;
        }

        /// <summary>True when this window was opened for <paramref name="doc"/>.</summary>
        public bool IsFor(Document doc) => doc != null && _doc.IsValidObject && doc.Equals(_doc);

        /// <summary>Releases the external event; called when the window closes.</summary>
        public void Shutdown()
        {
            try { _externalEvent.Dispose(); }
            catch (Autodesk.Revit.Exceptions.ApplicationException) { /* Revit already released it */ }
        }

        partial void OnSearchTextChanged(string value) => FilesView?.Refresh();

        // V002: follow the selected file's view ticks so Open Ticked Views enables/disables live.
        partial void OnSelectedFileChanged(DwgFileRowViewModel value)
        {
            if (_watchedFile != null) _watchedFile.PropertyChanged -= OnWatchedFileChanged;
            _watchedFile = value;
            if (_watchedFile != null) _watchedFile.PropertyChanged += OnWatchedFileChanged;
            NotifyViewCommands();
        }

        private void OnWatchedFileChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(DwgFileRowViewModel.TickedViewCount)) NotifyViewCommands();
        }

        private void NotifyViewCommands()
        {
            OpenTickedViewsCommand.NotifyCanExecuteChanged();
            TickAllViewsCommand.NotifyCanExecuteChanged();
            ClearViewTicksCommand.NotifyCanExecuteChanged();
        }

        partial void OnActiveQuickFilterChanged(DwgQuickFilter value) => FilesView?.Refresh();

        partial void OnTotalFilesChanged(int value) => OnPropertyChanged(nameof(AllChipText));
        partial void OnLinkCountChanged(int value) => OnPropertyChanged(nameof(LinksChipText));
        partial void OnImportCountChanged(int value) => OnPropertyChanged(nameof(ImportsChipText));
        partial void OnNotLoadedCountChanged(int value) => OnPropertyChanged(nameof(NotLoadedChipText));
        partial void OnUnusedCountChanged(int value) => OnPropertyChanged(nameof(UnusedChipText));
        partial void OnIssueFileCountChanged(int value) => OnPropertyChanged(nameof(IssuesChipText));

        // ── Filtering ────────────────────────────────────────────────────────

        /// <summary>Activates a quick-filter chip ("All", "Links", …).</summary>
        [RelayCommand]
        private void SetQuickFilter(string name)
        {
            if (Enum.TryParse(name, out DwgQuickFilter filter)) ActiveQuickFilter = filter;
        }

        private bool PassesFilters(DwgFileRowViewModel row)
        {
            if (!DwgStatsBuilder.Passes(row.Stats, ActiveQuickFilter)) return false;
            if (string.IsNullOrWhiteSpace(SearchText)) return true;

            string haystack = $"{row.FileName} {row.Kind} {row.Status} {row.Stats.Path} {row.Stats.IssueText}";
            return SearchText
                .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .All(word => haystack.IndexOf(word, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        // ── Scanning ─────────────────────────────────────────────────────────

        /// <summary>Scans the model again (always with the deep view scan). Ticks and selection are kept.</summary>
        [RelayCommand(CanExecute = nameof(CanRun))]
        private void Refresh()
        {
            ScanInfo = "Scanning every view for CAD — this can take a while on large models…";
            RunInRevit("Scanning CAD links, imports and every view…", app =>
            {
                if (!TryGetUiDocument(app, out var uidoc)) return;
                ScanInto(uidoc.Document);
            });
        }

        private bool CanRun() => !IsRunning;

        // Runs in a Revit API context: scans, then shows the rows on the UI thread.
        private void ScanInto(Document doc)
        {
            var scan = DwgStatsScanner.Scan(doc, LogFromRevit);
            var stats = DwgStatsBuilder.Build(scan);
            OnUi(() => ShowRows(scan, stats));
        }

        private void ShowRows(DwgScanResult scan, List<DwgFileStats> stats)
        {
            var ticked = new HashSet<long>(Files.Where(r => r.IsTicked).Select(r => r.TypeId));
            // V002: keep each file's ticked views across the rescan.
            var tickedViews = Files
                .Where(r => r.TickedViewCount > 0)
                .ToDictionary(r => r.TypeId, r => new HashSet<long>(r.TickedViewIds));
            long? selected = SelectedFile?.TypeId;

            _suspend = true;
            try
            {
                foreach (var row in Files) row.PropertyChanged -= OnRowPropertyChanged;
                Files.Clear();
                foreach (var s in stats)
                {
                    tickedViews.TryGetValue(s.TypeId, out var viewTicks);
                    var row = new DwgFileRowViewModel(s, viewTicks) { IsTicked = ticked.Contains(s.TypeId) };
                    row.PropertyChanged += OnRowPropertyChanged;
                    Files.Add(row);
                }
            }
            finally
            {
                _suspend = false;
            }

            _lastScan = scan;
            _totals = DwgStatsBuilder.Totals(stats);
            TotalFiles = _totals.Files;
            LinkCount = _totals.Links;
            ImportCount = _totals.Imports;
            TotalInstances = _totals.Instances;
            ViewsUsed = _totals.Views;
            SheetsUsed = _totals.Sheets;
            NotLoadedCount = _totals.NotLoaded;
            IssueFileCount = _totals.WithIssues;
            UnusedCount = _totals.Unused;

            SelectedFile = selected.HasValue ? Files.FirstOrDefault(r => r.TypeId == selected.Value) : null;
            Recount();

            ScanInfo = $"Deep scan: {scan.ViewsScanned} view(s) checked" +
                       (scan.ViewsSkipped > 0 ? $", {scan.ViewsSkipped} skipped" : string.Empty) +
                       $" in {scan.Elapsed.TotalSeconds:0.0} s · '{scan.ProjectTitle}'.";

            string summary = $"Scan complete — {_totals.Files} DWG file(s), {_totals.Instances} instance(s), " +
                             $"{_totals.Views} view(s), {_totals.Sheets} sheet(s), {_totals.WithIssues} file(s) with issues.";
            AddLog(_totals.WithIssues > 0 ? LogLevel.Warning : LogLevel.Success, summary);
            SummaryText = summary;
            ExportCommand.NotifyCanExecuteChanged();
        }

        // ── Ticks ────────────────────────────────────────────────────────────

        /// <summary>Ticks every row that passes the filters.</summary>
        [RelayCommand]
        private void TickAll() => SetTicks(true);

        /// <summary>Unticks every row that passes the filters.</summary>
        [RelayCommand]
        private void ClearTicks() => SetTicks(false);

        private void SetTicks(bool on)
        {
            _suspend = true;
            try
            {
                foreach (var row in FilesView.Cast<DwgFileRowViewModel>()) row.IsTicked = on;
            }
            finally
            {
                _suspend = false;
            }
            Recount();
        }

        private void OnRowPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (_suspend) return;
            if (e.PropertyName == nameof(DwgFileRowViewModel.IsTicked)) Recount();
        }

        private void Recount()
        {
            var ticked = Files.Where(r => r.IsTicked).ToList();
            TickedCount = ticked.Count;
            TickedUnpinned = ticked.Sum(r => r.UnpinnedCount);
            TickedLinks = ticked.Count(r => r.IsLinked);
            TickedUnused = ticked.Count(r => r.InstanceCount == 0);
            RefreshCommandState();
        }

        private void RefreshCommandState()
        {
            OnPropertyChanged(nameof(PinAllLabel));
            OnPropertyChanged(nameof(ReloadLabel));
            OnPropertyChanged(nameof(PurgeLabel));
            OnPropertyChanged(nameof(TickHint));
            RefreshCommand.NotifyCanExecuteChanged();
            PinAllCommand.NotifyCanExecuteChanged();
            ReloadLinksCommand.NotifyCanExecuteChanged();
            PurgeUnusedCommand.NotifyCanExecuteChanged();
            ExportCommand.NotifyCanExecuteChanged();
            NotifyViewCommands();
        }

        // ── Cleanup actions ──────────────────────────────────────────────────

        /// <summary>Pins every unpinned instance of the ticked files.</summary>
        [RelayCommand(CanExecute = nameof(CanPinAll))]
        private void PinAll()
        {
            var rows = Files.Where(r => r.IsTicked && r.UnpinnedCount > 0).ToList();
            if (!Confirm($"Pin {rows.Sum(r => r.UnpinnedCount)} unpinned instance(s) in {rows.Count} DWG file(s)?", rows))
                return;

            var ids = rows.Select(r => r.TypeId).ToList();
            RunAction("Pinning CAD instances…", doc => new DwgCleanupService(LogFromRevit).PinAll(doc, ids));
        }

        private bool CanPinAll() => !IsRunning && TickedUnpinned > 0;

        /// <summary>Reloads the ticked CAD links from their saved paths.</summary>
        [RelayCommand(CanExecute = nameof(CanReload))]
        private void ReloadLinks()
        {
            var rows = Files.Where(r => r.IsTicked && r.IsLinked).ToList();
            if (!Confirm($"Reload {rows.Count} CAD link(s) from their saved paths?", rows))
                return;

            var ids = rows.Select(r => r.TypeId).ToList();
            RunAction($"Reloading {ids.Count} link(s)…", doc => new DwgCleanupService(LogFromRevit).ReloadLinks(doc, ids));
        }

        private bool CanReload() => !IsRunning && TickedLinks > 0;

        /// <summary>Deletes the ticked CAD types that have no instance.</summary>
        [RelayCommand(CanExecute = nameof(CanPurge))]
        private void PurgeUnused()
        {
            var rows = Files.Where(r => r.IsTicked && r.InstanceCount == 0).ToList();
            if (!Confirm($"Purge {rows.Count} unused CAD type(s)? Linked ones are removed from Manage Links.", rows))
                return;

            var ids = rows.Select(r => r.TypeId).ToList();
            RunAction($"Purging {ids.Count} unused type(s)…", doc => new DwgCleanupService(LogFromRevit).PurgeUnused(doc, ids));
        }

        private bool CanPurge() => !IsRunning && TickedUnused > 0;

        private static bool Confirm(string question, IReadOnlyList<DwgFileRowViewModel> rows)
        {
            if (rows.Count == 0) return false;

            var sb = new StringBuilder();
            sb.AppendLine(question);
            sb.AppendLine();
            foreach (var row in rows.Take(12)) sb.AppendLine($"  • {row.FileName}  ({row.Kind}, {row.Status})");
            if (rows.Count > 12) sb.AppendLine($"  … and {rows.Count - 12} more");
            sb.AppendLine();
            sb.AppendLine("You can undo this with Ctrl+Z in Revit.");

            return MessageBox.Show(sb.ToString(), DwgStatisticsTool.Title,
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
        }

        // Runs one cleanup action in Revit, logs its summary, then rescans.
        private void RunAction(string busyText, Func<Document, DwgActionResult> action)
        {
            RunInRevit(busyText, app =>
            {
                if (!TryGetUiDocument(app, out var uidoc)) return;

                var result = action(uidoc.Document);
                OnUi(() =>
                {
                    var level = result.RolledBack || result.Failed > 0 ? LogLevel.Error
                        : result.Done == 0 ? LogLevel.Warning
                        : LogLevel.Success;
                    AddLog(level, result.Summary);
                });

                ScanInto(uidoc.Document);
                OnUi(() => SummaryText = result.Summary);
            });
        }

        // ── Navigation ───────────────────────────────────────────────────────

        /// <summary>
        /// V002: opens every view ticked in the selected file's Views tab (1 to MaxOpenViews). The last
        /// one opened ends up active; the others stay open as tabs in Revit.
        /// </summary>
        [RelayCommand(CanExecute = nameof(CanOpenTickedViews))]
        private void OpenTickedViews()
        {
            var file = SelectedFile;
            if (file == null) return;
            var viewIds = file.TickedViewIds;
            if (viewIds.Count == 0 || viewIds.Count > DwgStatisticsTool.MaxOpenViews) return;

            RunInRevit($"Opening {viewIds.Count} view(s) of {file.FileName}…", app =>
            {
                if (!TryGetUiDocument(app, out var uidoc)) return;
                int opened = DwgNavigationService.OpenViews(uidoc, viewIds, LogFromRevit);
                OnUi(() =>
                {
                    string summary = $"{opened} opened | {viewIds.Count - opened} failed";
                    AddLog(opened == viewIds.Count ? LogLevel.Success : LogLevel.Warning,
                        $"Open Ticked Views ({file.FileName}): {summary}");
                    SummaryText = summary;
                });
            });
        }

        private bool CanOpenTickedViews()
            => !IsRunning && SelectedFile != null
               && SelectedFile.TickedViewCount > 0
               && SelectedFile.TickedViewCount <= DwgStatisticsTool.MaxOpenViews;

        /// <summary>V002: ticks every view in the selected file's Views tab.</summary>
        [RelayCommand(CanExecute = nameof(HasViewRows))]
        private void TickAllViews() => SelectedFile?.SetAllViewTicks(true);

        /// <summary>V002: unticks every view in the selected file's Views tab.</summary>
        [RelayCommand(CanExecute = nameof(HasViewRows))]
        private void ClearViewTicks() => SelectedFile?.SetAllViewTicks(false);

        private bool HasViewRows() => SelectedFile != null && SelectedFile.ViewRows.Count > 0;

        /// <summary>V002: hint next to Open Ticked Views.</summary>
        public string ViewTickHint =>
            $"Tick the views you need, then Open Ticked Views (up to {DwgStatisticsTool.MaxOpenViews} at a time).";

        /// <summary>Opens a view from the Views tab.</summary>
        [RelayCommand]
        private void OpenView(DwgViewUsage usage)
        {
            if (usage == null) return;
            long viewId = usage.ViewId;
            RunInRevit($"Opening {usage.ViewName}…", app =>
            {
                if (!TryGetUiDocument(app, out var uidoc)) return;
                DwgNavigationService.OpenView(uidoc, viewId, LogFromRevit);
            });
        }

        /// <summary>Selects and zooms to an instance from the Instances tab (opens a view that draws it if needed).</summary>
        [RelayCommand]
        private void ZoomInstance(DwgInstanceStats instance)
        {
            if (instance == null) return;
            long id = instance.Id;
            long fallback = instance.BestViewId;
            RunInRevit($"Selecting #{id}…", app =>
            {
                if (!TryGetUiDocument(app, out var uidoc)) return;
                DwgNavigationService.SelectAndZoom(uidoc, id, fallback, LogFromRevit);
            });
        }

        // ── Export ───────────────────────────────────────────────────────────

        /// <summary>Saves the last scan as an .xlsx workbook (all files, not only the filtered ones).</summary>
        [RelayCommand(CanExecute = nameof(CanExport))]
        private void Export()
        {
            if (_lastScan == null) return;

            var dialog = new SaveFileDialog
            {
                Title = "Export DWG statistics",
                Filter = "Excel workbook (*.xlsx)|*.xlsx",
                FileName = DwgStatsExportService.DefaultFileName(_lastScan.ProjectTitle),
                AddExtension = true,
                OverwritePrompt = true
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                var files = Files.Select(r => r.Stats).ToList();
                DwgStatsExportService.Export(dialog.FileName, files, _totals, _lastScan.ProjectTitle,
                    _lastScan.ViewsScanned, _lastScan.ViewsSkipped, _lastScan.Elapsed, DwgStatisticsTool.Label);
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                AddLog(LogLevel.Error, $"Export failed: {ex.Message} (is the file open in Excel?)");
                SummaryText = "Export failed — see the log.";
                return;
            }

            AddLog(LogLevel.Success, $"Exported to {dialog.FileName}");
            SummaryText = $"Exported {Files.Count} DWG file(s) to {global::System.IO.Path.GetFileName(dialog.FileName)}.";

            if (MessageBox.Show("Export complete. Open the file now?", DwgStatisticsTool.Title,
                    MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
            {
                try
                {
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
                }
                catch (Exception ex) when (ex is global::System.ComponentModel.Win32Exception || ex is InvalidOperationException)
                {
                    AddLog(LogLevel.Warning, $"Could not open the file: {ex.Message}");
                }
            }
        }

        private bool CanExport() => !IsRunning && _lastScan != null;

        // ── Revit plumbing (same pattern as DWG Manager V003) ────────────────

        private sealed class Job
        {
            public bool Cancelled;
        }

        // Queues work for the Revit API context. A failure is logged and reported; the run counter always
        // goes back down so the window never stays stuck on "running".
        private void RunInRevit(string summary, Action<UIApplication> body)
        {
            var job = new Job();
            SetBusy(+1, summary);

            _handler.Queue(app =>
            {
                if (job.Cancelled) return;

                try
                {
                    body(app);
                }
                catch (Exception ex)
                {
                    OnUi(() => AddLog(LogLevel.Error, $"Stopped, changes were rolled back: {ex.Message}"));
                    ToolGuard.Report(GetType(), ex);
                }
                finally
                {
                    OnUi(() => SetBusy(-1, null));
                }
            });

            if (_externalEvent.Raise() == ExternalEventRequest.Denied)
            {
                job.Cancelled = true;
                SetBusy(-1, null);
                SummaryText = "Revit is busy. Close any open dialog and try again.";
                AddLog(LogLevel.Warning, SummaryText);
            }
        }

        private void SetBusy(int delta, string summary)
        {
            _busy = Math.Max(0, _busy + delta);
            IsRunning = _busy > 0;
            if (summary != null) SummaryText = summary;
            RefreshCommandState();
        }

        private bool TryGetUiDocument(UIApplication app, out UIDocument uidoc)
        {
            uidoc = app.ActiveUIDocument;
            if (uidoc != null && _doc.IsValidObject && uidoc.Document.Equals(_doc)) return true;

            OnUi(() => AddLog(LogLevel.Error,
                "The active document changed. Switch back to the document this window was opened for."));
            uidoc = null;
            return false;
        }

        private void LogFromRevit(LogEntry entry) => OnUi(() => AddLog(entry.Level, entry.Message));

        private void OnUi(Action action)
        {
            if (_dispatcher.CheckAccess()) action();
            else _dispatcher.Invoke(action);
        }
    }
}
