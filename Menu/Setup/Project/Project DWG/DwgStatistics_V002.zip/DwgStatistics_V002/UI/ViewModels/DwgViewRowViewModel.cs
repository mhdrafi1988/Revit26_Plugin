using System;
using CommunityToolkit.Mvvm.ComponentModel;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;

namespace Revit26_Plugin.DwgStatistics.V002.UI.ViewModels
{
    /// <summary>
    /// One row of the Views tab (V002): a view that owns or draws the selected DWG, plus the tick used by
    /// "Open Ticked Views".
    /// </summary>
    public partial class DwgViewRowViewModel : ObservableObject
    {
        /// <summary>Creates a row for <paramref name="usage"/>.</summary>
        public DwgViewRowViewModel(DwgViewUsage usage)
        {
            Usage = usage ?? throw new ArgumentNullException(nameof(usage));
        }

        /// <summary>The view usage behind the row (also the Open button's command parameter).</summary>
        public DwgViewUsage Usage { get; }

        /// <summary>Ticked for Open Ticked Views.</summary>
        [ObservableProperty] private bool isTicked;

        /// <summary>Element ID of the view.</summary>
        public long ViewId => Usage.ViewId;

        /// <summary>View name.</summary>
        public string ViewName => Usage.ViewName;

        /// <summary>View type label.</summary>
        public string ViewType => Usage.ViewType;

        /// <summary>"Placed here" / "Visible (model)".</summary>
        public string Relation => Usage.Relation;

        /// <summary>Instances owned by the view.</summary>
        public int PlacedInstances => Usage.PlacedInstances;

        /// <summary>Instances drawn in the view.</summary>
        public int VisibleInstances => Usage.VisibleInstances;

        /// <summary>Sheet numbers.</summary>
        public string Sheets => Usage.Sheets;
    }
}
