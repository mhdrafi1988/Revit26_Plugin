using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;
using Revit26_Plugin.DwgStatistics.V002.Core.Models;

namespace Revit26_Plugin.DwgStatistics.V002.UI.ViewModels
{
    /// <summary>
    /// One row of the file grid: the statistics of one DWG file, flattened for binding and sorting,
    /// plus the tick used by the cleanup actions.
    /// </summary>
    public partial class DwgFileRowViewModel : ObservableObject
    {
        /// <summary>Creates a row for <paramref name="stats"/>.</summary>
        public DwgFileRowViewModel(DwgFileStats stats, ISet<long> tickedViewIds = null)
        {
            Stats = stats ?? throw new ArgumentNullException(nameof(stats));

            // V002: Views tab rows with their own tick (restored from the previous scan when given).
            ViewRows = new ObservableCollection<DwgViewRowViewModel>(stats.Views.Select(v =>
                new DwgViewRowViewModel(v) { IsTicked = tickedViewIds != null && tickedViewIds.Contains(v.ViewId) }));
            foreach (var row in ViewRows) row.PropertyChanged += OnViewRowChanged;
            TickedViewCount = ViewRows.Count(r => r.IsTicked);
        }

        /// <summary>The statistics behind the row.</summary>
        public DwgFileStats Stats { get; }

        /// <summary>Ticked for Pin All / Reload / Purge.</summary>
        [ObservableProperty] private bool isTicked;

        /// <summary>V002: rows of the Views tab, each with a tick for Open Ticked Views.</summary>
        public ObservableCollection<DwgViewRowViewModel> ViewRows { get; }

        /// <summary>V002: views ticked in the Views tab.</summary>
        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(OpenTickedViewsLabel))]
        private int tickedViewCount;

        /// <summary>V002: "Open Ticked Views (2 / 5)".</summary>
        public string OpenTickedViewsLabel => $"Open Ticked Views ({TickedViewCount} / {DwgStatisticsTool.MaxOpenViews})";

        /// <summary>V002: IDs of the ticked views, in list order.</summary>
        public List<long> TickedViewIds => ViewRows.Where(r => r.IsTicked).Select(r => r.ViewId).ToList();

        /// <summary>V002: ticks or unticks every view in the Views tab.</summary>
        public void SetAllViewTicks(bool on)
        {
            foreach (var row in ViewRows) row.IsTicked = on;
        }

        private void OnViewRowChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(DwgViewRowViewModel.IsTicked))
                TickedViewCount = ViewRows.Count(r => r.IsTicked);
        }

        /// <summary>CAD type element ID.</summary>
        public long TypeId => Stats.TypeId;

        /// <summary>File name.</summary>
        public string FileName => Stats.FileName;

        /// <summary>Tooltip: full path and file details when known.</summary>
        public string FileToolTip
        {
            get
            {
                if (string.IsNullOrEmpty(Stats.Path)) return Stats.IsLinked ? $"{FileName}\n(path unavailable)" : $"{FileName}\n(imported — stored in the model)";
                string details = Stats.FileSizeBytes.HasValue
                    ? $"\n{Stats.FileSizeText} · modified {Stats.FileModified:yyyy-MM-dd HH:mm}"
                    : "\n(file not found on this computer)";
                string pathType = string.IsNullOrEmpty(Stats.PathType) ? string.Empty : $"\nPath type: {Stats.PathType}";
                return Stats.Path + pathType + details;
            }
        }

        /// <summary>"Link" / "Import".</summary>
        public string Kind => Stats.Kind;

        /// <summary>True for a link.</summary>
        public bool IsLinked => Stats.IsLinked;

        /// <summary>Link status, or "Imported".</summary>
        public string Status => Stats.Status;

        /// <summary>True when loaded.</summary>
        public bool IsLoaded => Stats.IsLoaded;

        /// <summary>Total instances.</summary>
        public int InstanceCount => Stats.InstanceCount;

        /// <summary>View-specific instances.</summary>
        public int ViewSpecificCount => Stats.ViewSpecificCount;

        /// <summary>Model instances.</summary>
        public int ModelCount => Stats.ModelCount;

        /// <summary>Views that own an instance.</summary>
        public int PlacedViewCount => Stats.PlacedViewCount;

        /// <summary>Views that own or draw an instance.</summary>
        public int VisibleViewCount => Stats.VisibleViewCount;

        /// <summary>Sheets showing the file.</summary>
        public int SheetCount => Stats.SheetCount;

        /// <summary>Pinned instances.</summary>
        public int PinnedCount => Stats.PinnedCount;

        /// <summary>Unpinned instances.</summary>
        public int UnpinnedCount => Stats.UnpinnedCount;

        /// <summary>"3 / 5".</summary>
        public string PinnedText => Stats.PinnedText;

        /// <summary>CAD layers.</summary>
        public int LayerCount => Stats.LayerCount;

        /// <summary>Issue badges.</summary>
        public IReadOnlyList<DwgIssue> Issues => Stats.Issues;

        /// <summary>Number of issues, for sorting the Issues column.</summary>
        public int IssueCount => Stats.Issues.Count;

        /// <summary>True when any issue is a warning or worse.</summary>
        public bool HasProblem => Stats.HasProblem;

        /// <summary>Views tab rows.</summary>
        public IReadOnlyList<DwgViewUsage> Views => Stats.Views;

        /// <summary>Instances tab rows.</summary>
        public IReadOnlyList<DwgInstanceStats> Instances => Stats.Instances;

        /// <summary>"Views (12)".</summary>
        public string ViewsTabHeader => $"Views ({Stats.Views.Count})";

        /// <summary>"Instances (4)".</summary>
        public string InstancesTabHeader => $"Instances ({Stats.Instances.Count})";

        /// <summary>One-line summary above the detail tabs.</summary>
        public string DetailSummary =>
            $"{Stats.Kind} · {Stats.Status} · {Stats.InstanceCount} instance(s) " +
            $"({Stats.ViewSpecificCount} view-specific, {Stats.ModelCount} model) · " +
            $"placed in {Stats.PlacedViewCount} view(s) · shown in {Stats.VisibleViewCount} view(s) · " +
            $"on {Stats.SheetCount} sheet(s) · {Stats.LayerCount} layer(s)";
    }
}
