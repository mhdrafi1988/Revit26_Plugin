# DWG Statistics V002 — integration

**V002 adds:** in the Views tab of the selected DWG, a tick column with Tick All / Clear and
**Open Ticked Views (n / 5)**, which opens every ticked view at once (the last one becomes active).
The per-row Open button stays. The limit is `DwgStatisticsTool.MaxOpenViews` (5, same as DWG Manager V003).
View ticks survive Refresh and the cleanup actions. Everything else is unchanged from V001.

## 1. Copy the files
- `DwgStatistics_V002/` → `Menu/Setup/Project/Project DWG/DwgStatistics_V002/`
  (keep `DwgStatistics_V001/` on disk next to it, as with other versioned tools)
- `Resources/Icons/SetupTools/DwgStatistics_16.png` and `_32.png` → same path in the repo (skip if already added for V001)

## 2. Revit26_Plugin.csproj (icons are not globbed)
```xml
<EmbeddedResource Include="Resources\Icons\SetupTools\DwgStatistics_16.png" />
<EmbeddedResource Include="Resources\Icons\SetupTools\DwgStatistics_32.png" />
<None Remove="Resources\Icons\SetupTools\DwgStatistics_16.png" />
<None Remove="Resources\Icons\SetupTools\DwgStatistics_32.png" />
```
No NuGet package is added — the Excel export is written with System.IO.Compression only.

## 3. Ribbon — its own button (now a pulldown: V002 first, V001 second)
Same convention as the other versioned Setup tools. In the Setup ribbon file, Project panel,
right after the DWG Manager entry:
```csharp
// DWG Statistics — own pulldown (per Anas, 2026-10-13): V002 current, V001 previous
var dwgStatisticsV002 = new PushButtonData(
    "Btn_DwgStatistics_V002", "DWG Statistics V002", assemblyPath,
    "Revit26_Plugin.DwgStatistics.V002.Commands.DwgStatisticsCommand")
{
    Image = ImageUtils.Load("Revit26_Plugin.Resources.Icons.SetupTools.DwgStatistics_16.png"),
    LargeImage = ImageUtils.Load("Revit26_Plugin.Resources.Icons.SetupTools.DwgStatistics_32.png"),
    ToolTip = RibbonLayoutHelper.VersionTip("DWG Statistics", "V002",
        "Instances, views placed in / visible in, sheets, pins, layers and link health of every CAD link and import. Tick views to open them together. Pin, reload, purge, export to Excel.")
};
var dwgStatisticsV001 = new PushButtonData(
    "Btn_DwgStatistics_V001", "DWG Statistics V001", assemblyPath,
    "Revit26_Plugin.DwgStatistics.V001.Commands.DwgStatisticsCommand")
{
    Image = ImageUtils.Load("Revit26_Plugin.Resources.Icons.SetupTools.DwgStatistics_16.png"),
    ToolTip = RibbonLayoutHelper.VersionTip("DWG Statistics", "V001",
        "Statistics per DWG file; one view opened per click.")
};

var dwgStatisticsPulldown = RibbonLayoutHelper.CreatePulldownButtonData(
    "Pulldown_DwgStatistics", "DWG Statistics", dwgStatisticsV002);
// ... add dwgStatisticsPulldown to the items list passed to AddStackedButtons, then:
RibbonLayoutHelper.WirePulldownButton(created, "Pulldown_DwgStatistics", dwgStatisticsV002, dwgStatisticsV001);
```
If you'd rather keep a single plain button, wire only `dwgStatisticsV002` the same way V001 was.

## 4. Shared code it relies on (same as DWG Manager V003)
`ToolViewModelBase` (IsRunning, Progress, SummaryText, LogEntries, AddLog, ClearLogCommand),
`ToolGuard`, `LogClipboardService`, `LogEntry`/`LogLevel`, `ToolWindowShell` + `ShellBehaviors`,
converters `BoolToVisibilityConverter`, `InverseBoolToVisibilityConverter`, `EnumToBoolConverter`,
`LogLevelToColorConverter`, and SharedStyles keys used by V003 plus `BrushSoftWarningBackground`.
The title lives in `Core/Models/DwgStatisticsTool.cs` (not ToolCatalog) so nothing in Shared changes.

## 5. Things to check on the first run in Revit
- **Reload Links**: the Revit API docs don't say whether `CADLinkType.Reload()` needs a transaction;
  the service tries inside one, then outside. Check the log after the first reload.
- **Deep scan time** on the biggest model (shown under the toolbar and in the log). It runs on every
  open and Refresh, as agreed; the window shows "Scanning…" but can't repaint until it finishes.
- **"Views" counts** come from Revit's per-view collector, so they follow visibility (hidden
  category / hidden in view = not counted). Crop region is not considered.

## Layout
```
DwgStatistics_V002/
  Commands/DwgStatisticsCommand.cs           single window per session (same as V003)
  Core/Models/                               Revit-free facts + statistics models
  Core/Services/DwgStatsBuilder.cs           aggregation + issue rules (pure .NET)
  Core/Services/SimpleXlsxWriter.cs          dependency-free .xlsx writer
  Core/Services/DwgStatsExportService.cs     Summary / Views / Instances / Scan Info sheets
  Infrastructure/ExternalEvents/             queued IExternalEventHandler
  Infrastructure/RevitApi/DwgStatsScanner.cs types, instances, sheets, deep view scan
  Infrastructure/RevitApi/DwgCleanupService.cs  Pin All / Reload Links / Purge Unused
  Infrastructure/RevitApi/DwgNavigationService.cs  open view, select + zoom
  UI/ViewModels/DwgViewRowViewModel.cs       V002: Views-tab row with tick
  UI/ViewModels, UI/Views                    ToolWindowShell window
```
