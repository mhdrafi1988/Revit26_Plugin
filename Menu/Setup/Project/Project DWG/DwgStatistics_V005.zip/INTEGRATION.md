# DWG Statistics V005 — integration

## What's new since V004
| Feature | How it works | Default (Rules & history row) |
|---|---|---|
| **Far from origin** | Farthest point of each DWG's geometry (bounding box) from Revit's internal origin. **Max km** column, distance per instance, warning badge. | 10 km |
| **Updated on disk** | Each link's file date is stored with the scan history; a newer file on disk → warning + "file updated on disk" in Changes. **Reload Links** clears it. | — |
| **Layers** | Scan records, per view showing the DWG, which layers are hidden or overridden. New **Layers** tab (hidden in / overridden in / which views), **Hid. Layers / Ovr. Layers** columns in the Views tab, **Many layers** badge. Tick layers + tick views → **Hide / Unhide** (Visibility/Graphics → Imported Categories; one undo step; views whose template controls V/G are reported). | 100 layers |
| **Workset rule** | Model-placed instances whose workset name doesn't contain the pattern → **Wrong workset**; **Workset ▾ + Move** on ticked files (model-placed only — "Current view only" ones live on their view's workset and are exempt). Shown only in workshared models. | "CAD;Link" |
| **Shared history** | History saved to **`_DwgStatistics\<Project>_<id>.dwgstats.json` next to the project / central file**, so the team shares "changes since last scan" (shows who scanned) plus a 50-line scan log (Excel **Scan History** sheet). Atomic writes; re-reads before writing so teammates' lines are kept. Falls back to `%AppData%` for cloud / Revit Server / unsaved models or an unwritable folder (logged). Reads a V004 snapshot once so the first V005 run still compares. | On |
| **Rules & history row** | Edit limits in the window; badges update at once from the last scan (no rescan). Remembered in `settings_v005.json`. | — |

Excel gains **Layers** and **Scan History** sheets; Summary adds Max Distance (km), Wrong Workset, Updated on Disk; Instances adds Distance (km), Workset OK; Views adds Hidden/Overridden Layers; Scan Info lists the rules and history location.

> **Also fixed in V001, V002 and V004** (separate hotfix zip): a compile error in the export summary line —
> `{global::System.IO.Path.GetFileName(...)}` inside an interpolated string must be `{(global::…)}`.
> V005 has the fix. Replace those three ViewModel files even if the versions are not on the ribbon (they still compile).

## Standards check (error handling, threading, memory)
| Standard | V004 |
|---|---|
| Status bar / progress | Shell status strip bound to `IsRunning` / `Progress` / `SummaryText`; real % + "n / N views" + Cancel Scan during the deep scan, animated bar during actions; every result line also goes to the log. |
| Command error handling | `Execute` wrapped by `ToolGuard.RunCommand` (as V003); external-event handler by `ToolGuard.RunHandler`. |
| UI-thread error handling | Every command button and dispatcher callback runs through `Guarded()` → logged, `ToolGuard.Report`, status strip message; never reaches Revit's dispatcher. |
| Revit-side errors | Each queued job in try/catch (log + report); per-element `Autodesk.Revit.Exceptions` caught and counted (done / skipped / failed); elements owned by other users skipped. |
| Transactions | All in `using`; one per action (one Ctrl+Z); rolled back when nothing changed; Revit warnings logged on delete; read-only documents refused. |
| Threading | No Revit API call from the window: everything goes through the queued `ExternalEvent`; UI updates via the dispatcher; Revit busy (`Raise` denied) handled. |
| Memory | No `Element` kept between events (IDs only); per-view collectors disposed; row/event subscriptions removed on refresh and close; `ExternalEvent` disposed on close; window closes with its document (`DocumentClosing`, unsubscribed after). |
| Files | Settings/snapshot/Excel I/O in try/catch with defaults; nothing throws into Revit. |
| Known limit | The log list grows for the life of the window (it lives in `ToolViewModelBase`); press Clear on very long sessions. |

## 1. Copy the files
- `DwgStatistics_V005/` → `Menu/Setup/Project/Project DWG/DwgStatistics_V005/` (keep older folders on disk)
- Icons: `Resources/Icons/SetupTools/DwgStatistics_16.png` / `_32.png` (skip if already added)

## 2. Revit26_Plugin.csproj
Only if the icons are not yet registered:
```xml
<EmbeddedResource Include="Resources\Icons\SetupTools\DwgStatistics_16.png" />
<EmbeddedResource Include="Resources\Icons\SetupTools\DwgStatistics_32.png" />
<None Remove="Resources\Icons\SetupTools\DwgStatistics_16.png" />
<None Remove="Resources\Icons\SetupTools\DwgStatistics_32.png" />
```
No NuGet package added (Excel via System.IO.Compression, JSON via System.Text.Json).

## 3. Ribbon — pulldown: V005 first, then V004
```csharp
// DWG Statistics — own pulldown (per Anas, 2026-10-13): V005 current, V004 previous
var dwgStatisticsV005 = new PushButtonData(
    "Btn_DwgStatistics_V005", "DWG Statistics V005", assemblyPath,
    "Revit26_Plugin.DwgStatistics.V005.Commands.DwgStatisticsCommand")
{
    Image = ImageUtils.Load("Revit26_Plugin.Resources.Icons.SetupTools.DwgStatistics_16.png"),
    LargeImage = ImageUtils.Load("Revit26_Plugin.Resources.Icons.SetupTools.DwgStatistics_32.png"),
    ToolTip = RibbonLayoutHelper.VersionTip("DWG Statistics", "V005",
        "CAD link/import statistics and health: far from origin, updated on disk, layers, workset rule, shared change history. Open / hide / delete in ticked views, pin, reload, purge, move to workset, export to Excel.")
};
var dwgStatisticsV004 = new PushButtonData(
    "Btn_DwgStatistics_V004", "DWG Statistics V004", assemblyPath,
    "Revit26_Plugin.DwgStatistics.V004.Commands.DwgStatisticsCommand")
{
    Image = ImageUtils.Load("Revit26_Plugin.Resources.Icons.SetupTools.DwgStatistics_16.png"),
    ToolTip = RibbonLayoutHelper.VersionTip("DWG Statistics", "V004", "Previous version.")
};

var dwgStatisticsPulldown = RibbonLayoutHelper.CreatePulldownButtonData(
    "Pulldown_DwgStatistics", "DWG Statistics", dwgStatisticsV005);
// ... add dwgStatisticsPulldown to the items list passed to AddStackedButtons, then:
RibbonLayoutHelper.WirePulldownButton(created, "Pulldown_DwgStatistics", dwgStatisticsV005, dwgStatisticsV004);
```

## 4. Shared code it relies on (unchanged from V002)
`ToolViewModelBase` (IsRunning, Progress, SummaryText, LogEntries, AddLog, ClearLogCommand), `ToolGuard`,
`LogClipboardService`, `LogEntry`/`LogLevel`, `ToolWindowShell` + `ShellBehaviors`, converters
`BoolToVisibilityConverter`, `InverseBoolToVisibilityConverter`, `EnumToBoolConverter`, `LogLevelToColorConverter`,
SharedStyles keys used by DWG Manager V003 plus `BrushSoftWarningBackground`.

## 5. Check on the first run in Revit
- **Shared history folder:** after the first scan, check `_DwgStatistics` appears next to the project (central) file and
  the Changes card says "history: shared (…)". If the folder is read-only for you, the log says so and it saves locally.
- **Layer states:** views controlled by a view template report the template's V/G; Hide/Unhide on those views is refused
  and logged ("its view template controls Visibility/Graphics") — change the template instead.
- **Far from origin:** uses the DWG's bounding box; a stray object far away in the DWG is exactly what it should catch.
- **Shell binding:** V004 binds `IsIndeterminate="{Binding IsProgressIndeterminate}"` (real % while scanning,
  animated bar for actions). If `ToolWindowShell.IsIndeterminate` is a plain CLR property rather than a
  dependency property, the window throws on open — then set it back to `IsIndeterminate="False"`.
- **Progress** is assigned an `int` (0–100), so it compiles whether `ToolViewModelBase.Progress` is int or double.
- **Reload Links:** tries `CADLinkType.Reload()` inside a transaction, then outside — check the log once.
- **Close other open views:** Revit may refuse to close some views (e.g. the last one); those are skipped silently.
- **Scan time:** the hidden-in-view check adds an `IsHidden` call per model-placed CAD instance per model view;
  watch the "Deep scan … in N s" log line on your biggest model.
- **Compare with last scan:** the first V004 run on a project has nothing to compare with; changes appear from the
  next session. Delete the snapshot file to reset the baseline.

## Layout
```
DwgStatistics_V005/
  Commands/DwgStatisticsCommand.cs                single window per session
  Core/Models/DwgScanFacts.cs, DwgStats.cs        facts + statistics (Revit-free)
  Core/Models/DwgSnapshot.cs                      snapshot, change line, remembered settings
  Core/Models/DwgStatisticsTool.cs                title, version, limits, data folder
  Core/Services/DwgStatsBuilder.cs                aggregation + issue rules (+ fixes)
  Core/Services/DwgSnapshotService.cs             compare (+ updated on disk), shared history store, settings store
  Core/Services/DwgStatsExportService.cs          6-sheet .xlsx
  Core/Services/SimpleXlsxWriter.cs               dependency-free .xlsx writer
  Infrastructure/ExternalEvents/                  queued IExternalEventHandler
  Infrastructure/RevitApi/DwgStatsScanner.cs      Begin + ScanBatch (cancellable), hidden-in-view
  Infrastructure/RevitApi/DwgCleanupService.cs    Pin All / Reload Links / Purge Unused
  Infrastructure/RevitApi/DwgViewActionService.cs Hide / Unhide / Delete in views, V005 Hide / Unhide layers
  Infrastructure/RevitApi/DwgNavigationService.cs open views (zoom, sheet, close others), select + zoom
  UI/ViewModels/DwgLayerRowViewModel.cs           V005 Layers-tab row
  UI/ViewModels, UI/Views                         ToolWindowShell window
```
