using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Revit26_Plugin.WorksetRenamer_01.ViewModels
{
    /// <summary>
    /// Converts a <see cref="RenameStatus"/> enum value to a
    /// <see cref="SolidColorBrush"/> using the SharedStyles color tokens.
    /// </summary>
    public class RenameStatusToBrushConverter : IValueConverter
    {
        // Matches the Apple-palette tokens in SharedStyles.xaml
        private static readonly SolidColorBrush Pending   = new SolidColorBrush(Color.FromRgb(0xAE, 0xAE, 0xB2)); // TextTertiary
        private static readonly SolidColorBrush Renamed   = new SolidColorBrush(Color.FromRgb(0x34, 0xC7, 0x59)); // ColorSuccess
        private static readonly SolidColorBrush Unchanged = new SolidColorBrush(Color.FromRgb(0x8E, 0x8E, 0x93)); // TextSecondary
        private static readonly SolidColorBrush Error     = new SolidColorBrush(Color.FromRgb(0xFF, 0x45, 0x3A)); // ColorDanger

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is RenameStatus status)
            {
                return status switch
                {
                    RenameStatus.Pending   => Pending,
                    RenameStatus.Renamed   => Renamed,
                    RenameStatus.Unchanged => Unchanged,
                    RenameStatus.Error     => Error,
                    _                      => Pending
                };
            }
            return Pending;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}
