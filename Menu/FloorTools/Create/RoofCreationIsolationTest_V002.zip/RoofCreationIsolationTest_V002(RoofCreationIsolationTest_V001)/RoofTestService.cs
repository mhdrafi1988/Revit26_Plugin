using Autodesk.Revit.DB;
using Revit26_Plugin.RoofCreationIsolationTest.V002.Core.Models;
using Revit26_Plugin.RoofCreationIsolationTest.V002.Infrastructure.Helpers;
using Revit26_Plugin.Shared.Models;
using System;
using System.Linq;

namespace Revit26_Plugin.RoofCreationIsolationTest.V002.Core.Services
{
    /// <summary>
    /// Core diagnostic logic for the roof creation isolation test.
    /// Locates the first available Level and RoofType, builds a fixed 4m x 4m
    /// footprint at the origin, and attempts a single, textbook NewFootPrintRoof()
    /// call — logging every step, parameter, and (on failure) the full exception
    /// chain. No fallback methods: this is intentionally a single-path diagnostic,
    /// since no second footprint-based creation API exists in Revit 2026.
    ///
    /// Logging goes through ThreadSafeLogSink (not a raw ObservableCollection) because
    /// this method runs on the Revit API thread via ExternalEvent — direct collection
    /// mutation from that thread does not reach the WPF-bound UI.
    /// </summary>
    public class RoofTestService
    {
        private const double FootprintSideMeters = 4.0;

        /// <summary>
        /// Runs the isolation test inside an already-open Transaction context.
        /// Must be called from a valid Revit API execution context (i.e. inside
        /// IExternalEventHandler.Execute()). All steps are logged to the supplied
        /// sink as they happen — this method never throws; all exceptions are
        /// caught, logged, and reflected in the returned RoofTestResult.
        /// </summary>
        public RoofTestResult RunTest(Document doc, ThreadSafeLogSink log)
        {
            var result = new RoofTestResult();

            log.Add(LogLevel.Info, "=== RoofTestService.RunTest() entered ===");

            try
            {
                // ── Step 1: Locate first Level, sorted by Elevation ascending ──
                log.Add(LogLevel.Info, "Collecting Levels via FilteredElementCollector...");
                var levels = new FilteredElementCollector(doc)
                    .OfClass(typeof(Level))
                    .Cast<Level>()
                    .OrderBy(l => l.Elevation)
                    .ToList();

                log.Add(LogLevel.Info,
                    $"Levels found: {levels.Count} -> [" +
                    string.Join(", ", levels.Select(l => $"{l.Name} (Elev {l.Elevation:F2} ft)")) +
                    "]");

                if (levels.Count == 0)
                {
                    log.Add(LogLevel.Error, "No Level elements exist in this document. Cannot proceed.");
                    result.Success = false;
                    result.ExceptionTypeName = "PreconditionFailure";
                    result.ExceptionMessage = "No Level elements found in document.";
                    return result;
                }

                var level = levels.First();
                result.LevelId = level.Id;
                result.LevelName = level.Name;
                result.LevelElevationFt = level.Elevation;

                log.Add(LogLevel.Success,
                    $"Selected Level: \"{level.Name}\" | Id={level.Id.Value} | Elevation={level.Elevation:F2} ft");

                // ── Step 2: Locate first RoofType with a valid compound structure ──
                log.Add(LogLevel.Info, "Collecting RoofTypes via FilteredElementCollector...");
                var allRoofTypes = new FilteredElementCollector(doc)
                    .OfClass(typeof(RoofType))
                    .Cast<RoofType>()
                    .ToList();

                log.Add(LogLevel.Info,
                    $"RoofTypes found: {allRoofTypes.Count} total, checking GetCompoundStructure() != null...");

                RoofType? roofType = null;
                foreach (var rt in allRoofTypes)
                {
                    bool hasStructure = rt.GetCompoundStructure() != null;
                    log.Add(LogLevel.Info,
                        $"  Candidate: \"{rt.Name}\" | Id={rt.Id.Value} | HasCompoundStructure={hasStructure}");

                    if (hasStructure && roofType == null)
                        roofType = rt;
                }

                if (roofType == null)
                {
                    log.Add(LogLevel.Error, "No RoofType with a valid CompoundStructure exists in this document. Cannot proceed.");
                    result.Success = false;
                    result.ExceptionTypeName = "PreconditionFailure";
                    result.ExceptionMessage = "No RoofType with GetCompoundStructure() != null found in document.";
                    return result;
                }

                result.RoofTypeId = roofType.Id;
                result.RoofTypeName = roofType.Name;

                log.Add(LogLevel.Success,
                    $"Selected RoofType: \"{roofType.Name}\" | Id={roofType.Id.Value} | HasCompoundStructure=True");

                // ── Step 3: Build the 4m x 4m footprint CurveArray at origin ──
                // Z-VALUE FIX: footprint points must sit at the selected Level's own
                // elevation (Z = level.Elevation), NOT at absolute Z = 0. NewFootPrintRoof()
                // expects the footprint curve loop to be sketched on the host level's plane;
                // if Z doesn't match the level's elevation, Revit throws ArgumentException
                // ("footprint curve loop is not valid") with no mention of Z in the message —
                // this looks identical to a genuinely malformed loop, so it's easy to miss.
                // This same class of bug (absolute-Z vs. level-relative-Z mismatch) is a
                // plausible root cause if FloorsAndRoofsFromLinkedRoomsViaPlanView derives
                // footprint points from a LINKED model whose Z datum/base point differs from
                // the host document's.
                log.Add(LogLevel.Info,
                    $"Building footprint CurveArray - {FootprintSideMeters}m x {FootprintSideMeters}m square @ origin (0,0), Z = level elevation");

                double sideFt = UnitUtils.ConvertToInternalUnits(FootprintSideMeters, UnitTypeId.Meters);
                double levelZFt = level.Elevation;

                log.Add(LogLevel.Info,
                    $"Using Z = {levelZFt:F3} ft (selected Level's Elevation) for all footprint points");

                XYZ p1 = new XYZ(0, 0, levelZFt);
                XYZ p2 = new XYZ(sideFt, 0, levelZFt);
                XYZ p3 = new XYZ(sideFt, sideFt, levelZFt);
                XYZ p4 = new XYZ(0, sideFt, levelZFt);

                result.FootprintPointsFt = new[] { p1, p2, p3, p4 };

                foreach (var (label, pt) in new[] { ("P1", p1), ("P2", p2), ("P3", p3), ("P4", p4) })
                {
                    double xM = UnitUtils.ConvertFromInternalUnits(pt.X, UnitTypeId.Meters);
                    double yM = UnitUtils.ConvertFromInternalUnits(pt.Y, UnitTypeId.Meters);
                    log.Add(LogLevel.Info,
                        $"  {label} = ({pt.X:F3}, {pt.Y:F3}, {pt.Z:F3}) ft  [ ({xM:F2}, {yM:F2}) m ]");
                }

                var footprint = new CurveArray();
                footprint.Append(Line.CreateBound(p1, p2));
                footprint.Append(Line.CreateBound(p2, p3));
                footprint.Append(Line.CreateBound(p3, p4));
                footprint.Append(Line.CreateBound(p4, p1));

                log.Add(LogLevel.Info, "Footprint CurveArray built: 4 bound lines forming closed loop.");

                // ── Step 3b: Validate all NewFootPrintRoof() inputs before calling it ──
                // Validation NEVER blocks execution — per project decision, this tool always
                // proceeds to the API call regardless of ValidationPassed, so a validation
                // false-negative/false-positive never hides the real Revit exception.
                ValidateInputs(footprint, level, roofType, result, log);

                // ── Step 4: Attempt NewFootPrintRoof() — the single method under test ──
                log.Add(LogLevel.Info,
                    "Calling doc.Create.NewFootPrintRoof(footprint, level, roofType, out mapping)...");

                try
                {
                    ModelCurveArray mapping = new ModelCurveArray();
                    FootPrintRoof roof = doc.Create.NewFootPrintRoof(footprint, level, roofType, out mapping);

                    result.Success = true;
                    result.CreatedRoofId = roof.Id;
                    result.CreatedRoofName = roof.Name;

                    log.Add(LogLevel.Success,
                        $"NewFootPrintRoof() SUCCEEDED | New Roof Id={roof.Id.Value} | Name=\"{roof.Name}\"");
                }
                catch (Exception apiEx)
                {
                    result.Success = false;
                    CaptureException(apiEx, result);
                    LogFullException(log, "NewFootPrintRoof()", apiEx);
                }
            }
            catch (Exception outerEx)
            {
                // Catches any failure outside the API call itself (e.g. collector or
                // geometry setup) so the isolation test never crashes silently.
                result.Success = false;
                CaptureException(outerEx, result);
                LogFullException(log, "RunTest() (outer)", outerEx);
            }

            log.Add(LogLevel.Info, "=== RoofTestService.RunTest() exited ===");
            return result;
        }

        /// <summary>
        /// Runs pre-call checks on the exact objects about to be passed to
        /// NewFootPrintRoof(): footprint (closed loop, planar, no degenerate/duplicate
        /// segments, no self-intersection), level (non-null), and roofType (non-null,
        /// has a CompoundStructure). Logs entry, each individual check result, and a
        /// final pass/fail summary. Never throws; never blocks the subsequent API call —
        /// writes only to ValidationPassed / ValidationIssues on the result.
        /// </summary>
        private void ValidateInputs(CurveArray footprint, Level level, RoofType roofType,
            RoofTestResult result, ThreadSafeLogSink log)
        {
            log.Add(LogLevel.Info,
                $"=== ValidateInputs() entered | footprint.Size={footprint.Size} | " +
                $"level={(level == null ? "null" : level.Name)} | " +
                $"roofType={(roofType == null ? "null" : roofType.Name)} ===");

            var issues = new System.Collections.Generic.List<string>();
            const double shortCurveTolFt = 1.0 / 256.0; // Revit's practical short-curve tolerance

            // ── Level check ──
            if (level == null)
            {
                issues.Add("Level is null.");
                log.Add(LogLevel.Error, "  [FAIL] Level is null.");
            }
            else
            {
                log.Add(LogLevel.Success, $"  [PASS] Level is non-null: \"{level.Name}\" (Id={level.Id.Value}).");
            }

            // ── RoofType check ──
            if (roofType == null)
            {
                issues.Add("RoofType is null.");
                log.Add(LogLevel.Error, "  [FAIL] RoofType is null.");
            }
            else if (roofType.GetCompoundStructure() == null)
            {
                issues.Add($"RoofType \"{roofType.Name}\" has no CompoundStructure.");
                log.Add(LogLevel.Error, $"  [FAIL] RoofType \"{roofType.Name}\" has no CompoundStructure.");
            }
            else
            {
                log.Add(LogLevel.Success,
                    $"  [PASS] RoofType \"{roofType.Name}\" is non-null and has a CompoundStructure.");
            }

            // ── Footprint: curve count ──
            int curveCount = footprint.Size;
            log.Add(LogLevel.Info, $"  Checking curve count: {curveCount} curve(s) in footprint.");
            if (curveCount < 3)
            {
                issues.Add($"Footprint has only {curveCount} curve(s); a closed loop needs at least 3.");
                log.Add(LogLevel.Error, $"  [FAIL] Curve count {curveCount} < 3.");
            }
            else
            {
                log.Add(LogLevel.Success, $"  [PASS] Curve count {curveCount} >= 3.");
            }

            // Pull curves into an ordered list for the remaining geometric checks.
            var curves = new System.Collections.Generic.List<Curve>();
            foreach (Curve c in footprint) curves.Add(c);

            // ── Footprint: degenerate (zero/near-zero length) curves ──
            log.Add(LogLevel.Info, "  Checking for degenerate (near-zero-length) curves...");
            bool anyDegenerate = false;
            for (int i = 0; i < curves.Count; i++)
            {
                double len = curves[i].Length;
                if (len < shortCurveTolFt)
                {
                    anyDegenerate = true;
                    issues.Add($"Curve[{i}] length {len:F5} ft is below short-curve tolerance ({shortCurveTolFt:F5} ft).");
                    log.Add(LogLevel.Error, $"  [FAIL] Curve[{i}] length {len:F5} ft is degenerate.");
                }
            }
            if (!anyDegenerate)
                log.Add(LogLevel.Success, "  [PASS] No degenerate curves found.");

            // ── Footprint: planarity (all points share the same Z within tolerance) ──
            log.Add(LogLevel.Info, "  Checking planarity (all endpoint Z values equal)...");
            var allZ = new System.Collections.Generic.List<double>();
            foreach (var c in curves)
            {
                allZ.Add(c.GetEndPoint(0).Z);
                allZ.Add(c.GetEndPoint(1).Z);
            }
            double zMin = allZ.Count > 0 ? allZ.Min() : 0;
            double zMax = allZ.Count > 0 ? allZ.Max() : 0;
            double zSpread = zMax - zMin;
            if (zSpread > shortCurveTolFt)
            {
                issues.Add($"Footprint is not planar: Z ranges from {zMin:F5} to {zMax:F5} ft (spread {zSpread:F5} ft).");
                log.Add(LogLevel.Error, $"  [FAIL] Non-planar: Z spread = {zSpread:F5} ft.");
            }
            else
            {
                log.Add(LogLevel.Success, $"  [PASS] Planar: Z spread = {zSpread:F5} ft (within tolerance).");
            }

            // ── Footprint: closed loop (end[i] == start[i+1], end[last] == start[0]) ──
            log.Add(LogLevel.Info, "  Checking loop closure (consecutive endpoint continuity)...");
            bool anyGap = false;
            for (int i = 0; i < curves.Count; i++)
            {
                XYZ end = curves[i].GetEndPoint(1);
                XYZ nextStart = curves[(i + 1) % curves.Count].GetEndPoint(0);
                double gap = end.DistanceTo(nextStart);
                if (gap > shortCurveTolFt)
                {
                    anyGap = true;
                    issues.Add($"Gap of {gap:F5} ft between Curve[{i}] end and Curve[{(i + 1) % curves.Count}] start.");
                    log.Add(LogLevel.Error,
                        $"  [FAIL] Gap {gap:F5} ft between Curve[{i}].End and Curve[{(i + 1) % curves.Count}].Start.");
                }
            }
            if (!anyGap)
                log.Add(LogLevel.Success, "  [PASS] Loop is closed — all consecutive endpoints match.");

            // ── Footprint: self-intersection (non-adjacent segments crossing) ──
            // Approximate check: only meaningful for straight Line segments, which is
            // all this tool's fixed test footprint ever produces. Non-adjacent pairs
            // are compared for a 2D intersection (Z ignored, since planarity is
            // checked separately above).
            log.Add(LogLevel.Info, "  Checking for self-intersection (non-adjacent segment crossings)...");
            bool anyIntersection = false;
            for (int i = 0; i < curves.Count; i++)
            {
                for (int j = i + 1; j < curves.Count; j++)
                {
                    bool adjacent = j == i + 1 || (i == 0 && j == curves.Count - 1);
                    if (adjacent) continue;

                    if (curves[i] is Line li && curves[j] is Line lj &&
                        SegmentsIntersect2D(li.GetEndPoint(0), li.GetEndPoint(1),
                                             lj.GetEndPoint(0), lj.GetEndPoint(1)))
                    {
                        anyIntersection = true;
                        issues.Add($"Curve[{i}] and Curve[{j}] intersect (self-intersecting loop).");
                        log.Add(LogLevel.Error, $"  [FAIL] Curve[{i}] intersects Curve[{j}].");
                    }
                }
            }
            if (!anyIntersection)
                log.Add(LogLevel.Success, "  [PASS] No self-intersection detected among non-adjacent segments.");

            // ── Summary ──
            result.ValidationIssues = issues;
            result.ValidationPassed = issues.Count == 0;

            if (result.ValidationPassed)
            {
                log.Add(LogLevel.Success, "=== ValidateInputs() exited | Result: PASS (0 issues) ===");
            }
            else
            {
                log.Add(LogLevel.Warning,
                    $"=== ValidateInputs() exited | Result: FAIL ({issues.Count} issue(s)) | " +
                    "Proceeding to NewFootPrintRoof() anyway per tool design ===");
            }
        }

        /// <summary>2D (XY-plane) segment intersection test, ignoring Z. Used only for the
        /// self-intersection check above, where planarity is already validated separately.</summary>
        private static bool SegmentsIntersect2D(XYZ p1, XYZ p2, XYZ p3, XYZ p4)
        {
            double d1 = Cross(p3, p4, p1);
            double d2 = Cross(p3, p4, p2);
            double d3 = Cross(p1, p2, p3);
            double d4 = Cross(p1, p2, p4);

            return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
                   ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0));
        }

        private static double Cross(XYZ a, XYZ b, XYZ p) =>
            (b.X - a.X) * (p.Y - a.Y) - (b.Y - a.Y) * (p.X - a.X);

        /// <summary>Captures full exception detail (type, message, stack, source, inner chain) onto the result.</summary>
        private static void CaptureException(Exception ex, RoofTestResult result)
        {
            result.ExceptionTypeName = ex.GetType().FullName;
            result.ExceptionMessage = ex.Message;
            result.ExceptionStackTrace = ex.StackTrace;
            result.ExceptionSource = ex.Source;

            var inner = ex.InnerException;
            while (inner != null)
            {
                result.InnerExceptionChain.Add(
                    $"Type: {inner.GetType().FullName}\n" +
                    $"Message: {inner.Message}\n" +
                    $"Source: {inner.Source}\n" +
                    $"StackTrace:\n{inner.StackTrace}");
                inner = inner.InnerException;
            }
        }

        /// <summary>Writes the full exception text (message + stack trace + inner chain) to the log as one entry.</summary>
        private static void LogFullException(ThreadSafeLogSink log, string context, Exception ex)
        {
            string text =
                $"EXCEPTION in {context}:\n" +
                $"  Type: {ex.GetType().FullName}\n" +
                $"  Message: {ex.Message}\n" +
                $"  Source: {ex.Source}\n" +
                $"  StackTrace:\n{ex.StackTrace}";

            var inner = ex.InnerException;
            int depth = 1;
            while (inner != null)
            {
                text += $"\n  --- Inner Exception #{depth} ---\n" +
                        $"  Type: {inner.GetType().FullName}\n" +
                        $"  Message: {inner.Message}\n" +
                        $"  Source: {inner.Source}\n" +
                        $"  StackTrace:\n{inner.StackTrace}";
                inner = inner.InnerException;
                depth++;
            }

            log.Add(LogLevel.Error, text);
        }
    }
}