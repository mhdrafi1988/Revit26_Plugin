using System.Windows.Interop;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace Revit26_Plugin.FloorsAndRoofFromLinkedRooms.V006
{
    /// <summary>
    /// V005 changes (confirmed spec, carried forward):
    /// - First link + first instance auto-selected on load; rooms load immediately.
    /// - Settings JSON persistence (last link / floor type / roof type) restored on open.
    /// - Regenerate() calls removed from the run loop (Revit regenerates on commit).
    /// - Progress-count and roof inner-loop-count bugs fixed.
    /// - New Level column upgraded to a live substring-filter dropdown.
    /// Roof creation logic itself is untouched from V004 per confirmed spec.
    ///
    /// V006 changes:
    /// - LoadRoofTypes() now logs a Warning when the host model has zero RoofType
    ///   elements, matching the existing pattern for LoadHostLevels()/LoadLinkedDocuments().
    ///   Diagnoses an empty Roof type dropdown instead of leaving it unexplained.
    /// </summary>
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class Command : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            var uidoc = commandData.Application.ActiveUIDocument;
            var doc = uidoc.Document;

            var handler = new RunCreateElementsExternalEventHandler();
            var externalEvent = ExternalEvent.Create(handler);

            var viewModel = new MainViewModel(doc, handler, externalEvent);
            handler.ViewModel = viewModel;

            var window = new FloorsFromLinkedRoomsWindow { DataContext = viewModel };
            new WindowInteropHelper(window).Owner = commandData.Application.MainWindowHandle;
            window.Show();

            return Result.Succeeded;
        }
    }
}
