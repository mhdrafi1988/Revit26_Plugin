﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.FloorsAndRoofFromLinkedRooms.V006
{
    /// <summary>
    /// V006 – Switched to the modern FootPrintRoof.Create static API,
    /// which accepts IList&lt;CurveLoop&gt; and is consistent with Floor.Create.
    /// This eliminates the cryptic "Value cannot be null" errors from the legacy NewFootPrintRoof.
    /// </summary>
    public static class RoofCreationService
    {
        public static FootPrintRoof Create(Document doc, CurveLoop outerLoop, ElementId roofTypeId, Level level)
        {
            // Validate all inputs (same as before)
            if (outerLoop == null)
                throw new ArgumentNullException(nameof(outerLoop), "Outer boundary loop is null.");
            if (!outerLoop.Any())
                throw new ArgumentException("Outer boundary loop is empty.", nameof(outerLoop));

            if (level == null)
                throw new ArgumentNullException(nameof(level), "Target level is null.");
            if (doc.GetElement(level.Id) == null)
                throw new ArgumentException($"Level ID {level.Id.Value} not found in document.", nameof(level));

            if (roofTypeId == null || roofTypeId == ElementId.InvalidElementId)
                throw new ArgumentException($"Invalid roofTypeId: {roofTypeId?.Value}", nameof(roofTypeId));
            var roofType = doc.GetElement(roofTypeId) as RoofType;
            if (roofType == null)
                throw new ArgumentException($"RoofType with ID {roofTypeId.Value} not found or not a RoofType.", nameof(roofTypeId));

            // Prepare the loops list – only the outer loop is used for footprint roofs
            var loops = new List<CurveLoop> { outerLoop };

            // Use the correct NewFootPrintRoof overload with out parameter
            try
            {
                // Convert CurveLoop to CurveArray as required by the API
                var curveArray = new CurveArray();
                foreach (var curve in outerLoop)
                {
                    curveArray.Append(curve);
                }

                ModelCurveArray modelCurves;
                var roof = doc.Create.NewFootPrintRoof(curveArray, level, roofType, out modelCurves);
                if (roof == null)
                    throw new InvalidOperationException(
                        $"FootPrintRoof.Create returned null for level '{level.Name}' – geometry likely invalid.");
                return roof;
            }
            catch (Exception ex)
            {
                // Provide context if it still fails
                throw new InvalidOperationException(
                    $"Roof creation failed for level '{level.Name}' with roof type '{roofType.Name}'. " +
                    $"Curve count: {outerLoop.Count()}. Inner: {ex.Message}",
                    ex);
            }
        }
    }
}