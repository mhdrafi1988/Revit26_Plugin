// ═══════════════════════════════════════════════════════════════════════
// ADD THESE TO: Revit26_Plugin.Shared/Converters.cs
// (append inside the same namespace as your existing converters —
//  BoolToVisibilityConverter, LogLevelToColorConverter, etc.)
// ═══════════════════════════════════════════════════════════════════════

using Revit26_Plugin.ViewAutoRenamer.V002.Models;
using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Revit26_Plugin.Shared.Models
{
    /// <summary>
    /// Maps a ViewTypeGroup to a themed pill background/foreground brush.
    /// ConverterParameter: "Background" or "Foreground".
    /// Colors chosen to be distinct at a glance in a dense mixed-type grid
    /// while staying within a muted, non-clashing palette consistent with
    /// the navy (#1E3A5F) SharedStyles theme.
    /// </summary>
    public class ViewTypeGroupToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is not ViewTypeGroup group) return Brushes.Transparent;
            bool wantForeground = (parameter as string) == "Foreground";

            var (bg, fg) = group switch
            {
                ViewTypeGroup.SectionOrCallout => ("#EAF3DE", "#27500A"),
                ViewTypeGroup.FloorPlan         => ("#E6F1FB", "#0C447C"),
                ViewTypeGroup.CeilingPlan       => ("#E6F1FB", "#0C447C"),
                ViewTypeGroup.StructuralPlan    => ("#E6F1FB", "#0C447C"),
                ViewTypeGroup.AreaPlan          => ("#E6F1FB", "#0C447C"),
                ViewTypeGroup.Elevation         => ("#F3E9FB", "#5A2A82"),
                ViewTypeGroup.Drafting          => ("#FCEEDC", "#7A4A0B"),
                ViewTypeGroup.Legend            => ("#FDEAF0", "#8A1D4E"),
                ViewTypeGroup.Schedule          => ("#E9EDF1", "#3A4652"),
                _                                => ("#E9EDF1", "#3A4652"),
            };

            var hex = wantForeground ? fg : bg;
            return new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();
    }

    /// <summary>
    /// Generic enum-to-bool converter for RadioButton/ToggleButton IsChecked
    /// bindings against an enum property. ConverterParameter is the enum
    /// member name to compare against (as a string).
    /// </summary>
    public class EnumToBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null) return false;
            return value.ToString() == parameter.ToString();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool b && b && parameter != null)
                return Enum.Parse(targetType, parameter.ToString()!);
            return Binding.DoNothing;
        }
    }
}
