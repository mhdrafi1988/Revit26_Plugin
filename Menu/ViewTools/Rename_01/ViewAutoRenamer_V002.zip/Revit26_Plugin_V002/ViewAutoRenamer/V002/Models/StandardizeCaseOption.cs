namespace Revit26_Plugin.ViewAutoRenamer.V002.Models
{
    /// <summary>
    /// Case rule applied by the Standardize row. None keeps original casing.
    /// </summary>
    public enum StandardizeCaseOption
    {
        None,
        UpperCase,
        TitleCase,
        SentenceCase
    }
}
