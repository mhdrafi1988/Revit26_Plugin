namespace Revit26_Plugin.ViewAutoRenamer.V002.Models
{
    public enum DuplicateFixStrategy
    {
        NumberedBrackets,
        AlphabetSuffix,
        DupSuffix
    }
}
