namespace Revit26_Plugin.SectionRenamer.V011.ViewModels
{
    public enum DuplicateFixStrategy
    {
        NumberedBrackets,
        AlphabetSuffix,
        DupSuffix
    }
}
