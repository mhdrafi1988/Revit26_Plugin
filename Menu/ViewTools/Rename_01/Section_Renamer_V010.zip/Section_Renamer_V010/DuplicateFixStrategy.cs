namespace Revit26_Plugin.SectionAutoRenamer.V10.ViewModels
{
    public enum DuplicateFixStrategy
    {
        NumberedBrackets,
        AlphabetSuffix,
        DupSuffix
    }
}
