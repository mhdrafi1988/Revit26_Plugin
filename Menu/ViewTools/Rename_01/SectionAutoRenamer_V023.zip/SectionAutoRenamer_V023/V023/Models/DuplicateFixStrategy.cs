namespace Revit26_Plugin.SectionAutoRenamer.V023.Models
{
    public enum DuplicateFixStrategy
    {
        NumberedBrackets,
        AlphabetSuffix,
        DupSuffix,
        SerialNumber
    }
}
