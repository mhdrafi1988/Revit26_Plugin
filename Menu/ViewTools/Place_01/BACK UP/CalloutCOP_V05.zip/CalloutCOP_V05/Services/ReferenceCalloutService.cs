using Autodesk.Revit.DB;
using System;

namespace Revit26_Plugin.CalloutCOP_V05.Services
{
    public static class ReferenceCalloutService
    {
        /// <summary>
        /// Places reference callout using CropBox + Transform logic
        /// (proven working approach from legacy CalloutViewUpdater).
        /// Size input is in MILLIMETERS.
        /// </summary>
        public static void CreateReferenceCallout(
            Document doc,
            View parentView,
            View viewToReference,
            double sizeMm)
        {
            var sectionView = parentView as ViewSection;
            if (sectionView == null)
                throw new InvalidOperationException("Target view is not a section.");

            if (!sectionView.CropBoxActive || !sectionView.CropBoxVisible)
                throw new InvalidOperationException(
                    $"Crop box not active/visible in view: {sectionView.Name}");

            BoundingBoxXYZ cropBox = sectionView.CropBox;
            Transform tf = cropBox.Transform;

            // --- CENTER (same as your working file) ---
            XYZ min = cropBox.Min;
            XYZ max = cropBox.Max;
            XYZ centerLocal = (min + max) * 0.5;
            XYZ centerWorld = tf.OfPoint(centerLocal);

            // --- AXES (critical difference) ---
            XYZ right = tf.BasisX.Normalize();
            XYZ up = tf.BasisY.Normalize();

            // --- SIZE: mm ? feet ---
            double sizeFt = sizeMm / 304.8;
            double half = sizeFt / 2.0;

            // --- RECTANGLE POINTS ---
            XYZ p1 = centerWorld - right * half - up * half;
            XYZ p2 = centerWorld + right * half + up * half;

            // --- PLACE REFERENCE CALLOUT ---
            ViewSection.CreateReferenceCallout(
                doc,
                sectionView.Id,
                viewToReference.Id,
                p1,
                p2);
        }
    }
}
