using Autodesk.Revit.DB;
using System.Collections.ObjectModel;
using System.Linq;
using Revit26_Plugin.CalloutCOP_V05.ViewModels;

namespace Revit26_Plugin.CalloutCOP_V05.Services
{
    public static class ViewCollectionService
    {
        public static ObservableCollection<ViewItemViewModel> CollectViews(Document doc)
        {
            return new ObservableCollection<ViewItemViewModel>(
                new FilteredElementCollector(doc)
                    .OfClass(typeof(View))
                    .Cast<View>()
                    .Where(v =>
                        !v.IsTemplate &&
                        (v.ViewType == ViewType.Section || v.ViewType == ViewType.Elevation))
                    .Select(v => new ViewItemViewModel(doc, v)));
        }

        public static ObservableCollection<ViewDrafting> CollectDraftingViews(Document doc)
        {
            return new ObservableCollection<ViewDrafting>(
                new FilteredElementCollector(doc)
                    .OfClass(typeof(ViewDrafting))
                    .Cast<ViewDrafting>()
                    .OrderBy(v => v.Name));
        }

        public static ObservableCollection<string> CollectSheetNumbers(Document doc)
        {
            var list = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSheet))
                .Cast<ViewSheet>()
                .Select(s => s.SheetNumber)
                .Distinct()
                .OrderBy(s => s)
                .ToList();

            return new ObservableCollection<string>(list);
        }
    }
}
