﻿using Autodesk.Revit.UI;
using System.Windows;
using Revit26_Plugin.CalloutCOP_V05.ViewModels;

namespace Revit26_Plugin.CalloutCOP_V05.Views
{
    public partial class CalloutCOPWindow : Window
    {
        public CalloutCOPWindow(ExternalCommandData data)
        {
            InitializeComponent();
            DataContext = new CalloutCOPViewModel(data);
        }
    }
}
