using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using Revit26_Plugin.CalloutCOP_V05.Helpers;
using Revit26_Plugin.CalloutCOP_V05.Services;
using Revit26_Plugin.CalloutCOP_V05.ViewModels;

namespace Revit26_Plugin.CalloutCOP_V05.ExternalEvents
{
    public class CalloutPlacementExternalEvent : IExternalEventHandler
    {
        private readonly Document _doc;
        private readonly ObservableCollection<ViewItemViewModel> _views;
        private readonly ObservableCollection<string> _logs;
        private readonly Func<ViewDrafting> _draftingViewProvider;
        private readonly Func<double> _sizeProvider; // mm

        public CalloutPlacementExternalEvent(
            Document doc,
            ObservableCollection<ViewItemViewModel> views,
            ObservableCollection<string> logs,
            Func<ViewDrafting> draftingViewProvider,
            Func<double> sizeProvider)
        {
            _doc = doc;
            _views = views;
            _logs = logs;
            _draftingViewProvider = draftingViewProvider;
            _sizeProvider = sizeProvider;
        }

        public void Execute(UIApplication app)
        {
            var draftingView = _draftingViewProvider();
            if (draftingView == null)
            {
                _logs.Add("? No Drafting View selected.");
                return;
            }

            var targets = _views.Where(v => v.IsSelected).ToList();
            if (targets.Count == 0)
            {
                _logs.Add("? No target views selected.");
                return;
            }

            using var tx = new Transaction(
                _doc,
                "Callout COP V05 � Reference Callouts");

            tx.Start();

            int ok = 0, fail = 0;

            foreach (var vm in targets)
            {
                if (!RevitViewValidator.IsValid(vm.View))
                {
                    _logs.Add($"? Skipped invalid view: {vm.Name}");
                    fail++;
                    continue;
                }

                try
                {
                    ReferenceCalloutService.CreateReferenceCallout(
                        _doc,
                        vm.View,
                        draftingView,
                        _sizeProvider()); // mm

                    _logs.Add(
                        $"? Reference callout placed at center of {vm.Name}");
                    ok++;
                }
                catch (Exception ex)
                {
                    _logs.Add(
                        $"? Failed in {vm.Name}: {ex.Message}");
                    fail++;
                }
            }

            tx.Commit();

            _logs.Add(
                $"? Finished. Success: {ok}, Failed: {fail}");
        }

        public string GetName() =>
            "CalloutCOP V05 External Event";
    }
}
