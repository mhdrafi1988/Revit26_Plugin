using Autodesk.Revit.DB;

namespace Revit26_Plugin.CalloutCOP_V05.Helpers
{
    public static class RevitViewValidator
    {
        public static bool IsValid(View view)
        {
            return !view.IsTemplate && view.CanBePrinted;
        }
    }
}
