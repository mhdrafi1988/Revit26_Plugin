using Autodesk.Revit.DB;
using System.Linq;
using Revit26_Plugin.CalloutCOP_V05.Helpers;

namespace Revit26_Plugin.CalloutCOP_V05.ViewModels
{
    public class ViewItemViewModel
    {
        public View View { get; }

        public string Name { get; }
        public ViewType ViewType { get; }

        public bool IsPlaced { get; }
        public string SheetNumbers { get; }   // can be multiple sheets: "A101, A102"

        public bool IsSelected { get; set; }

        public ViewItemViewModel(Document doc, View view)
        {
            View = view;
            Name = view.Name;
            ViewType = view.ViewType;

            var sheets = SheetLookupHelper.GetSheetNumbers(doc, view);
            IsPlaced = sheets.Any();
            SheetNumbers = sheets.Any() ? string.Join(", ", sheets) : string.Empty;
        }
    }
}
