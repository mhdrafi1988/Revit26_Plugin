using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;
using System.Windows.Input;
using Revit26_Plugin.CalloutCOP_V05.ExternalEvents;
using Revit26_Plugin.CalloutCOP_V05.Services;

namespace Revit26_Plugin.CalloutCOP_V05.ViewModels
{
    public class CalloutCOPViewModel : INotifyPropertyChanged
    {
        private readonly ExternalEvent _externalEvent;
        private readonly CalloutPlacementExternalEvent _handler;

        public ObservableCollection<ViewItemViewModel> Views { get; }
        public ICollectionView ViewsCollection { get; }

        public ObservableCollection<string> SheetFilterItems { get; }
        public ObservableCollection<ViewDrafting> DraftingViews { get; }

        public ObservableCollection<string> Logs { get; } = new();

        private string _sheetFilterText = "ALL";
        public string SheetFilterText
        {
            get => _sheetFilterText;
            set
            {
                _sheetFilterText = value ?? string.Empty;
                RaisePropertyChanged(nameof(SheetFilterText));
                ViewsCollection.Refresh();
            }
        }

        private ViewDrafting _selectedDraftingView;
        public ViewDrafting SelectedDraftingView
        {
            get => _selectedDraftingView;
            set
            {
                _selectedDraftingView = value;
                RaisePropertyChanged(nameof(SelectedDraftingView));
            }
        }

        private double _calloutSize = 500;
        public double CalloutSize
        {
            get => _calloutSize;
            set
            {
                _calloutSize = value;
                RaisePropertyChanged(nameof(CalloutSize));
            }
        }

        // optional toggles
        private bool _showPlaced = true;
        public bool ShowPlaced
        {
            get => _showPlaced;
            set { _showPlaced = value; RaisePropertyChanged(nameof(ShowPlaced)); ViewsCollection.Refresh(); }
        }

        private bool _showUnplaced = true;
        public bool ShowUnplaced
        {
            get => _showUnplaced;
            set { _showUnplaced = value; RaisePropertyChanged(nameof(ShowUnplaced)); ViewsCollection.Refresh(); }
        }

        private bool _showSections = true;
        public bool ShowSections
        {
            get => _showSections;
            set { _showSections = value; RaisePropertyChanged(nameof(ShowSections)); ViewsCollection.Refresh(); }
        }

        private bool _showElevations = true;
        public bool ShowElevations
        {
            get => _showElevations;
            set { _showElevations = value; RaisePropertyChanged(nameof(ShowElevations)); ViewsCollection.Refresh(); }
        }

        public ICommand PlaceCalloutsCommand { get; }

        public CalloutCOPViewModel(ExternalCommandData data)
        {
            var doc = data.Application.ActiveUIDocument.Document;

            // Load all section/elevation views with their sheet placement info
            Views = ViewCollectionService.CollectViews(doc);

            // Sheet numbers list (for ComboBox)
            SheetFilterItems = ViewCollectionService.CollectSheetNumbers(doc);
            if (!SheetFilterItems.Contains("ALL"))
                SheetFilterItems.Insert(0, "ALL");

            // Drafting views list (for ComboBox)
            DraftingViews = ViewCollectionService.CollectDraftingViews(doc);

            // WPF view + filter
            ViewsCollection = CollectionViewSource.GetDefaultView(Views);
            ViewsCollection.Filter = FilterViews;

            // External event handler uses current selections
            _handler = new CalloutPlacementExternalEvent(
                doc,
                Views,
                Logs,
                () => SelectedDraftingView,
                () => CalloutSize);

            _externalEvent = ExternalEvent.Create(_handler);

            PlaceCalloutsCommand = new RelayCommand(_ =>
            {
                Logs.Add("? Place Callouts clicked");
                ViewsCollection.Refresh();

                if (SelectedDraftingView == null)
                {
                    Logs.Add("? Select a Drafting View first.");
                    return;
                }

                var selectedCount = Views.Count(v => v.IsSelected);
                if (selectedCount == 0)
                {
                    Logs.Add("? No target views selected (tick views in the grid).");
                    return;
                }

                _externalEvent.Raise();
            });
        }

        private bool FilterViews(object obj)
        {
            if (obj is not ViewItemViewModel vm)
                return false;

            // Sheet filter: when user types/chooses sheet number, grid updates
            var sheetFilter = (SheetFilterText ?? string.Empty).Trim();

            if (!string.IsNullOrWhiteSpace(sheetFilter) &&
                !sheetFilter.Equals("ALL", System.StringComparison.OrdinalIgnoreCase))
            {
                // show only views placed on that sheet number
                if (!vm.SheetNumbers.Contains(sheetFilter, System.StringComparison.OrdinalIgnoreCase))
                    return false;
            }

            // placed/unplaced
            if (!ShowPlaced && vm.IsPlaced)
                return false;

            if (!ShowUnplaced && !vm.IsPlaced)
                return false;

            // section/elevation
            if (vm.ViewType == ViewType.Section && !ShowSections)
                return false;

            if (vm.ViewType == ViewType.Elevation && !ShowElevations)
                return false;

            return true;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void RaisePropertyChanged(string propertyName)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
