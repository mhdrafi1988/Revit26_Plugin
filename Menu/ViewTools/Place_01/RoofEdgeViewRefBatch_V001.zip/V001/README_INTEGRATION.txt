RoofEdgeViewRefBatch V001 - Integration Notes
================================================
Default callout box size: 500mm (user-editable in Placement Options).

WHAT THIS TOOL DOES
--------------------
Batch-processes selected section views. For each, detects roof edges within
the section's crop box extruded by far clip depth (bbox-level filter, no
solid/face intersection), dedups edges by endpoint match within a tolerance,
and places a Reference Callout (ViewSection.CreateReferenceCallout) centered
on each edge's midpoint, all pointing to one shared Drafting View picked once.
Sections with zero detected edges get one fallback callout at the section's
crop center instead, so the batch never silently skips a selected section.

FILES
-----
RoofEdgeViewRefBatchCommand.cs      - IExternalCommand entry point, ribbon-callable
Models/LogEntry.cs                  - LogEntry/LogLevel (matches suite convention)
Models/SectionViewRow.cs            - DataGrid row VM
Models/ToolSettings.cs              - JSON settings shape
Services/DetectedEdge.cs            - detected edge data (model-space points)
Services/RoofEdgeDetectionService.cs - crop+far-clip volume build, bbox filter, dedup
Services/ReferenceCalloutPlacementService.cs - CreateReferenceCallout wrapper
Services/RoofEdgeViewRefEventHandler.cs - orchestrator IExternalEventHandler (Scan/Run)
Services/RequestType.cs             - enum routing Scan vs Run
Services/SettingsService.cs         - load/save %AppData%\Revit26_Plugin\RoofEdgeViewRefBatch\settings.json
ViewModels/MainViewModel.cs          - MVVM glue, ExternalEvent wiring
Views/MainWindow.xaml(.cs)           - main window
Views/DraftingViewPickerWindow.xaml(.cs) - simple modal picker for target drafting view
Views/NewConvertersToMergeIntoShared.cs - NEW converters, see below

INTEGRATION STEPS (before this compiles in your solution)
-----------------------------------------------------------
1. Move the two converter classes from
   Views/NewConvertersToMergeIntoShared.cs
   into your existing Revit26_Plugin.Shared/Converters.cs, per your
   "converters in one shared file" convention. Delete the temp file after.
   - LogLevelToBrushConverter (new - not used by prior tools per memory)
   - InverseBoolConverter (check first - you may already have an equivalent
     from a prior tool's Run-button-disable pattern; if so, reuse that one
     and update the x:Key references in MainWindow.xaml instead)

2. STYLE NAMES ASSUMED TO EXIST IN SharedStyles.xaml - I do not have your
   actual SharedStyles.xaml content in this session, so I used names
   consistent with your navy theme conventions from memory. Verify these
   resource keys exist (or rename to match yours) before building:
     CardBorderStyle, CardTitleStyle, FieldLabelStyle, NoteTextStyle,
     SecondaryButtonStyle, PrimaryButtonStyle, DataGridStyle,
     NumericCellStyle, FooterBorderStyle
   If any are named differently in your actual file, it's a find/replace
   in MainWindow.xaml only - no logic changes needed.

3. RoofEdgeViewRefBatchCommand.cs uses Autodesk.Windows.ComponentManager
   for the Revit window handle (AdWindows.dll / RevitAPIUI reference),
   consistent with WindowInteropHelper ownership convention. Confirm this
   assembly reference already exists in your solution (it should, from
   other tools using the same pattern).

4. Namespace: Revit26_Plugin.RoofEdgeViewRefBatch.V001 (as confirmed).

5. Add ribbon button registration in your existing ribbon panel setup
   (not included here - point me to your ribbon registration file/pattern
   from a prior tool and I'll match it, or I can draft a stub).

KNOWN LIMITATIONS / DESIGN NOTES
----------------------------------
- Roof edge extraction uses top-facing planar faces' edge loops as a proxy
  for "roof boundary/eave/ridge edges." This will also pick up any internal
  planar face boundaries on a top face (e.g. shape-edited sub-regions) - if
  your roofs have SlabShapeEditor points creating extra internal facets,
  you may see more edges than expected. Flagging this now since it wasn't
  part of the earlier Q&A - let me know if it needs filtering to only outer
  perimeter loops (EdgeLoops order in Revit generally puts the outer loop
  first, so this can be tightened to loop index 0 only if needed).
- Dedup is O(n^2) per section (each new edge compared against all kept
  edges). Fine for typical roof edge counts per section; flag if a section
  has hundreds of edges and this needs a spatial index instead.
- CropBox.Transform.Inverse is used to project model points into view-local
  space for building the callout's two corner points. This assumes the
  section's crop box transform is orthogonal (standard Revit section
  behavior) - not tested against sections with unusual crop region edits.
- Scan must run before Run for accurate counts; Run will auto-scan any
  selected section that wasn't scanned yet (logged as a Warning) so it
  never silently produces zero placements from a missed Scan step.

NOT YET DONE (pending your confirmation before I add them)
--------------------------------------------------------------
- Ribbon button/icon registration
- Inno Setup installer entry for this new tool
- Logging retroactive review pass (per your logging convention, this tool's
  logs already capture parameter values, collection counts, and step
  entry/exit at each stage - let me know if you want a dedicated review
  pass against the full suite logging convention checklist)
