namespace Revit26_Plugin.RoofEdgeViewRefBatch.V001.Models
{
    public class ToolSettings
    {
        public string LastDraftingViewUniqueId { get; set; } = string.Empty;
        public double DedupToleranceMm { get; set; } = 10.0;
        public double CalloutBoxSizeMm { get; set; } = 500.0;
        public string LastLogExportFolder { get; set; } = string.Empty;
    }
}
