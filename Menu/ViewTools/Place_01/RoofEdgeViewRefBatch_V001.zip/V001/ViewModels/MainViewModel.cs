using System;
using System.Collections.ObjectModel;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Revit26_Plugin.RoofEdgeViewRefBatch.V001.Models;
using Revit26_Plugin.RoofEdgeViewRefBatch.V001.Services;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V001.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private readonly Document _doc;
        private readonly ExternalEvent _externalEvent;
        private readonly RoofEdgeViewRefEventHandler _handler;
        private readonly ToolSettings _settings;

        public ObservableCollection<SectionViewRow> SectionRows { get; } = new ObservableCollection<SectionViewRow>();
        public ObservableCollection<LogEntry> LogEntries { get; } = new ObservableCollection<LogEntry>();

        [ObservableProperty]
        private string _targetDraftingViewName = "(none selected)";

        private ElementId _targetDraftingViewId = ElementId.InvalidElementId;

        [ObservableProperty]
        private string _dedupToleranceMmText = "10";

        [ObservableProperty]
        private string _calloutBoxSizeMmText = "500";

        [ObservableProperty]
        private string _sectionFilterText = string.Empty;

        [ObservableProperty]
        private bool _isBusy;

        [ObservableProperty]
        private string _footerSummary = "0 sections | 0 est. edges";

        public MainViewModel(Document doc)
        {
            _doc = doc;
            _settings = SettingsService.Load();
            DedupToleranceMmText = _settings.DedupToleranceMm.ToString("0.##");
            CalloutBoxSizeMmText = _settings.CalloutBoxSizeMm.ToString("0.##");

            _handler = new RoofEdgeViewRefEventHandler
            {
                LogCallback = AddLog,
                ScanCompletedCallback = OnScanCompleted,
                RunCompletedCallback = OnRunCompleted
            };
            _externalEvent = ExternalEvent.Create(_handler);

            LoadSectionViews();
            RestoreLastDraftingView();
        }

        private void LoadSectionViews()
        {
            var sections = new FilteredElementCollector(_doc)
                .OfClass(typeof(ViewSection))
                .Cast<ViewSection>()
                .Where(v => !v.IsTemplate && v.ViewType == ViewType.Section)
                .OrderBy(v => v.Name)
                .ToList();

            AddLog(LogLevel.Info, $"Loaded {sections.Count} section view(s) from model.");

            foreach (var s in sections)
            {
                string sheetNumber = "(none)";
                var vp = s.GetPlacementOnSheetStatus(); // ViewPlacementOnSheetStatus - existence only
                var sheetId = s.LookupParameter("Sheet Number");
                // Sheet lookup via Viewport is more reliable than a parameter that may not exist;
                // fallback to (none) if the section isn't placed on any sheet.
                var placedSheetNumber = GetSheetNumberForView(s.Id);
                if (!string.IsNullOrEmpty(placedSheetNumber))
                    sheetNumber = placedSheetNumber;

                SectionRows.Add(new SectionViewRow
                {
                    ViewId = s.Id,
                    SectionView = s,
                    ViewName = s.Name,
                    SheetNumber = sheetNumber,
                    IsSelected = true
                });
            }

            UpdateFooterSummary();
        }

        private string GetSheetNumberForView(ElementId viewId)
        {
            var viewports = new FilteredElementCollector(_doc)
                .OfClass(typeof(Viewport))
                .Cast<Viewport>()
                .FirstOrDefault(vp => vp.ViewId == viewId);

            if (viewports == null) return null;

            var sheet = _doc.GetElement(viewports.SheetId) as ViewSheet;
            return sheet?.SheetNumber;
        }

        private void RestoreLastDraftingView()
        {
            if (string.IsNullOrEmpty(_settings.LastDraftingViewUniqueId)) return;

            try
            {
                Element el = _doc.GetElement(_settings.LastDraftingViewUniqueId);
                if (el is ViewDrafting dv)
                {
                    _targetDraftingViewId = dv.Id;
                    TargetDraftingViewName = dv.Name;
                }
            }
            catch
            {
                // Stored view no longer exists; leave unset.
            }
        }

        public void SetTargetDraftingView(ViewDrafting view)
        {
            _targetDraftingViewId = view.Id;
            TargetDraftingViewName = view.Name;
            _settings.LastDraftingViewUniqueId = view.UniqueId;
            SettingsService.Save(_settings);
        }

        [RelayCommand]
        private void SelectAll()
        {
            foreach (var row in FilteredRows()) row.IsSelected = true;
            UpdateFooterSummary();
        }

        [RelayCommand]
        private void ClearSelection()
        {
            foreach (var row in FilteredRows()) row.IsSelected = false;
            UpdateFooterSummary();
        }

        [RelayCommand]
        private void Refresh()
        {
            SectionRows.Clear();
            LoadSectionViews();
        }

        private System.Collections.Generic.IEnumerable<SectionViewRow> FilteredRows()
        {
            if (string.IsNullOrWhiteSpace(SectionFilterText)) return SectionRows;
            return SectionRows.Where(r => r.ViewName.IndexOf(SectionFilterText, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        [RelayCommand]
        private void Scan()
        {
            var selected = SectionRows.Where(r => r.IsSelected).ToList();
            if (selected.Count == 0)
            {
                AddLog(LogLevel.Warning, "No sections selected. Scan aborted.");
                return;
            }

            if (!TryParseDouble(DedupToleranceMmText, out double tolMm))
            {
                AddLog(LogLevel.Error, "Invalid dedup tolerance value. Scan aborted.");
                return;
            }

            IsBusy = true;
            _handler.PendingRequest = RequestType.Scan;
            _handler.SectionsToProcess = selected;
            _handler.DedupToleranceFeet = UnitUtils.ConvertToInternalUnits(tolMm, UnitTypeId.Millimeters);
            _externalEvent.Raise();
        }

        [RelayCommand]
        private void Run()
        {
            var selected = SectionRows.Where(r => r.IsSelected).ToList();
            if (selected.Count == 0)
            {
                AddLog(LogLevel.Warning, "No sections selected. Run aborted.");
                return;
            }

            if (_targetDraftingViewId == ElementId.InvalidElementId)
            {
                AddLog(LogLevel.Error, "No target Drafting View selected. Run aborted.");
                return;
            }

            if (!TryParseDouble(DedupToleranceMmText, out double tolMm) ||
                !TryParseDouble(CalloutBoxSizeMmText, out double boxMm))
            {
                AddLog(LogLevel.Error, "Invalid tolerance or box size value. Run aborted.");
                return;
            }

            IsBusy = true;
            _handler.PendingRequest = RequestType.Run;
            _handler.SectionsToProcess = selected;
            _handler.TargetDraftingViewId = _targetDraftingViewId;
            _handler.DedupToleranceFeet = UnitUtils.ConvertToInternalUnits(tolMm, UnitTypeId.Millimeters);
            _handler.CalloutBoxSizeFeet = UnitUtils.ConvertToInternalUnits(boxMm, UnitTypeId.Millimeters);

            _settings.DedupToleranceMm = tolMm;
            _settings.CalloutBoxSizeMm = boxMm;
            SettingsService.Save(_settings);

            _externalEvent.Raise();
        }

        private void OnScanCompleted()
        {
            IsBusy = false;
            UpdateFooterSummary();
        }

        private void OnRunCompleted(int placed, int fallbackPlaced, int skipped)
        {
            IsBusy = false;
            FooterSummary = $"{placed} placed | {fallbackPlaced} fallback | {skipped} skipped";
        }

        private void UpdateFooterSummary()
        {
            int selectedCount = SectionRows.Count(r => r.IsSelected);
            int totalEdges = SectionRows.Where(r => r.IsSelected && r.EstimatedEdges > 0).Sum(r => r.EstimatedEdges);
            FooterSummary = $"{selectedCount} sections | {totalEdges} est. edges (post-dedup)";
        }

        private bool TryParseDouble(string text, out double value)
        {
            return double.TryParse(text, out value) && value > 0;
        }

        /// <summary>
        /// Called by the log callback from the handler; must marshal to UI thread since
        /// ExternalEvent callbacks run on Revit's API thread, which is also the UI thread
        /// in this context (WPF window owned by Revit) - added defensively via Dispatcher.
        /// </summary>
        private void AddLog(LogLevel level, string message)
        {
            var entry = new LogEntry(level, message);
            System.Windows.Application.Current?.Dispatcher.Invoke(() =>
            {
                LogEntries.Add(entry);
            });
        }
    }
}
