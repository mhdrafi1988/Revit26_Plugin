using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V001.Services
{
    /// <summary>
    /// Detects roof edges that fall within a section view's crop box extruded by its
    /// far clip depth (cut + beyond, projection-visible), then dedups edges whose
    /// endpoints match within tolerance (shared/touching edges across multiple roofs
    /// collapse to a single detected edge).
    /// </summary>
    public class RoofEdgeDetectionService
    {
        private readonly Document _doc;
        private readonly Action<Models.LogLevel, string> _log;

        public RoofEdgeDetectionService(Document doc, Action<Models.LogLevel, string> logCallback)
        {
            _doc = doc;
            _log = logCallback;
        }

        /// <summary>
        /// Builds the world-space solid volume (crop box extruded by far clip depth) for a section.
        /// </summary>
        public Solid GetSectionScanVolume(ViewSection section)
        {
            BoundingBoxXYZ crop = section.CropBox;
            if (crop == null)
            {
                _log(Models.LogLevel.Warning, $"Section '{section.Name}': no crop box available, skipping volume build.");
                return null;
            }

            // Crop box is defined in the view's own transform space.
            Transform t = crop.Transform;
            double minX = crop.Min.X, minY = crop.Min.Y;
            double maxX = crop.Max.X, maxY = crop.Max.Y;

            // Far clip depth: if far clipping is off, fall back to crop box Z depth only.
            double farClipDepth = crop.Max.Z - crop.Min.Z;
            Parameter farClipActive = section.get_Parameter(BuiltInParameter.VIEWER_BOUND_ACTIVE_FAR);
            Parameter farClipOffset = section.get_Parameter(BuiltInParameter.VIEWER_BOUND_OFFSET_FAR);
            if (farClipActive != null && farClipActive.AsInteger() == 1 && farClipOffset != null)
            {
                farClipDepth = farClipOffset.AsDouble();
            }

            // Build a box profile in view space: X = width, Y = height, Z = 0..farClipDepth (view depth).
            List<XYZ> profile = new List<XYZ>
            {
                new XYZ(minX, minY, 0),
                new XYZ(maxX, minY, 0),
                new XYZ(maxX, maxY, 0),
                new XYZ(minX, maxY, 0)
            };

            List<Curve> profileCurves = new List<Curve>();
            for (int i = 0; i < profile.Count; i++)
            {
                XYZ p1 = profile[i];
                XYZ p2 = profile[(i + 1) % profile.Count];
                profileCurves.Add(Line.CreateBound(t.OfPoint(p1), t.OfPoint(p2)));
            }

            CurveLoop loop = CurveLoop.Create(profileCurves);
            XYZ extrudeDir = t.OfVector(new XYZ(0, 0, 1)).Normalize();

            try
            {
                Solid volume = GeometryCreationUtilities.CreateExtrusionGeometry(
                    new List<CurveLoop> { loop }, extrudeDir, farClipDepth);
                return volume;
            }
            catch (Exception ex)
            {
                _log(Models.LogLevel.Warning, $"Section '{section.Name}': failed to build scan volume ({ex.Message}).");
                return null;
            }
        }

        /// <summary>
        /// Finds roofs whose bounding box intersects the section's scan volume bounding box
        /// (coarse pass), then does an edge-level pass on the survivors.
        /// </summary>
        public List<DetectedEdge> DetectEdges(ViewSection section, IList<RoofBase> allRoofs)
        {
            var results = new List<DetectedEdge>();

            Solid scanVolume = GetSectionScanVolume(section);
            if (scanVolume == null)
            {
                _log(Models.LogLevel.Warning, $"Section '{section.Name}': no scan volume, 0 roofs checked.");
                return results;
            }

            BoundingBoxXYZ scanBox = GetSolidBoundingBox(scanVolume);
            _log(Models.LogLevel.Info, $"Section '{section.Name}': scan volume built, checking {allRoofs.Count} roofs.");

            int roofsInCrop = 0;

            foreach (RoofBase roof in allRoofs)
            {
                BoundingBoxXYZ roofBox = roof.get_BoundingBox(null);
                if (roofBox == null) continue;

                if (!BoundingBoxesOverlap(scanBox, roofBox))
                    continue;

                roofsInCrop++;
                List<Curve> edges = GetRoofBoundaryEdges(roof);
                _log(Models.LogLevel.Info, $"Section '{section.Name}': roof {roof.Id.Value} in crop, {edges.Count} boundary edges collected.");

                foreach (Curve c in edges)
                {
                    // Keep edge if either endpoint (or midpoint, for curved/safety) falls inside the scan volume's bbox.
                    // Bbox-level filter only, per confirmed "simpler" approach — no solid/face intersection.
                    if (PointRoughlyInBox(c.GetEndPoint(0), scanBox) ||
                        PointRoughlyInBox(c.GetEndPoint(1), scanBox) ||
                        PointRoughlyInBox(c.Evaluate(0.5, true), scanBox))
                    {
                        results.Add(new DetectedEdge
                        {
                            RoofId = roof.Id,
                            StartPoint = c.GetEndPoint(0),
                            EndPoint = c.GetEndPoint(1)
                        });
                    }
                }
            }

            _log(Models.LogLevel.Info, $"Section '{section.Name}': {roofsInCrop} roofs in crop, {results.Count} raw edges before dedup.");
            return results;
        }

        /// <summary>
        /// Dedups edges whose start/end points both match within tolerance (in either order,
        /// since a shared edge from two roofs may be authored in opposite directions).
        /// </summary>
        public List<DetectedEdge> DedupEdges(List<DetectedEdge> edges, double toleranceFeet)
        {
            var result = new List<DetectedEdge>();

            foreach (var edge in edges)
            {
                bool isDuplicate = result.Any(existing =>
                    (PointsMatch(existing.StartPoint, edge.StartPoint, toleranceFeet) &&
                     PointsMatch(existing.EndPoint, edge.EndPoint, toleranceFeet)) ||
                    (PointsMatch(existing.StartPoint, edge.EndPoint, toleranceFeet) &&
                     PointsMatch(existing.EndPoint, edge.StartPoint, toleranceFeet)));

                if (!isDuplicate)
                    result.Add(edge);
            }

            int removed = edges.Count - result.Count;
            if (removed > 0)
                _log(Models.LogLevel.Warning, $"Dedup removed {removed} overlapping edge(s) (endpoint tolerance applied).");

            return result;
        }

        private bool PointsMatch(XYZ a, XYZ b, double toleranceFeet)
        {
            return a.DistanceTo(b) <= toleranceFeet;
        }

        private List<Curve> GetRoofBoundaryEdges(RoofBase roof)
        {
            var edges = new List<Curve>();
            Options opts = new Options { ComputeReferences = false, DetailLevel = ViewDetailLevel.Fine };
            GeometryElement geomElem = roof.get_Geometry(opts);
            if (geomElem == null) return edges;

            foreach (GeometryObject obj in geomElem)
            {
                if (obj is Solid solid && solid.Volume > 0)
                {
                    foreach (Face face in solid.Faces)
                    {
                        // Top faces only, to approximate the roof's boundary/eave/ridge edges
                        // rather than every vertical side face edge.
                        if (!(face is PlanarFace pf) || pf.FaceNormal.Z <= 0.1) continue;

                        foreach (EdgeArray loop in face.EdgeLoops)
                        {
                            foreach (Edge e in loop)
                            {
                                edges.Add(e.AsCurve());
                            }
                        }
                    }
                }
            }
            return edges;
        }

        private BoundingBoxXYZ GetSolidBoundingBox(Solid solid)
        {
            XYZ min = null, max = null;
            foreach (Edge e in solid.Edges)
            {
                Curve c = e.AsCurve();
                foreach (XYZ pt in new[] { c.GetEndPoint(0), c.GetEndPoint(1) })
                {
                    if (min == null)
                    {
                        min = pt; max = pt;
                    }
                    else
                    {
                        min = new XYZ(Math.Min(min.X, pt.X), Math.Min(min.Y, pt.Y), Math.Min(min.Z, pt.Z));
                        max = new XYZ(Math.Max(max.X, pt.X), Math.Max(max.Y, pt.Y), Math.Max(max.Z, pt.Z));
                    }
                }
            }
            return new BoundingBoxXYZ { Min = min, Max = max };
        }

        private bool BoundingBoxesOverlap(BoundingBoxXYZ a, BoundingBoxXYZ b)
        {
            return a.Min.X <= b.Max.X && a.Max.X >= b.Min.X &&
                   a.Min.Y <= b.Max.Y && a.Max.Y >= b.Min.Y &&
                   a.Min.Z <= b.Max.Z && a.Max.Z >= b.Min.Z;
        }

        private bool PointRoughlyInBox(XYZ pt, BoundingBoxXYZ box)
        {
            const double pad = 0.01; // small feet padding for boundary tolerance
            return pt.X >= box.Min.X - pad && pt.X <= box.Max.X + pad &&
                   pt.Y >= box.Min.Y - pad && pt.Y <= box.Max.Y + pad &&
                   pt.Z >= box.Min.Z - pad && pt.Z <= box.Max.Z + pad;
        }
    }
}
