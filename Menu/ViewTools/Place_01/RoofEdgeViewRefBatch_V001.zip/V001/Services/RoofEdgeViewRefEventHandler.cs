using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.RoofEdgeViewRefBatch.V001.Models;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V001.Services
{
    /// <summary>
    /// Single orchestrator handler for this tool's two distinct Revit-side actions
    /// (Scan and Run), routed via the PendingRequest property. Per suite convention,
    /// this is only justified because both actions operate on the same section/roof
    /// selection state and sharing one handler avoids duplicated setup code.
    /// </summary>
    public class RoofEdgeViewRefEventHandler : IExternalEventHandler
    {
        public RequestType PendingRequest { get; set; } = RequestType.None;

        public List<SectionViewRow> SectionsToProcess { get; set; }
        public ElementId TargetDraftingViewId { get; set; }
        public double DedupToleranceFeet { get; set; }
        public double CalloutBoxSizeFeet { get; set; }

        public Action<LogLevel, string> LogCallback { get; set; }
        public Action ScanCompletedCallback { get; set; }
        public Action<int, int, int> RunCompletedCallback { get; set; } // placed, fallbackPlaced, skipped

        public void Execute(UIApplication app)
        {
            Document doc = app.ActiveUIDocument.Document;

            try
            {
                switch (PendingRequest)
                {
                    case RequestType.Scan:
                        ExecuteScan(doc);
                        break;
                    case RequestType.Run:
                        ExecuteRun(doc);
                        break;
                }
            }
            catch (Exception ex)
            {
                LogCallback?.Invoke(LogLevel.Error, $"Unexpected error: {ex.Message}");
            }
            finally
            {
                PendingRequest = RequestType.None;
            }
        }

        private void ExecuteScan(Document doc)
        {
            LogCallback?.Invoke(LogLevel.Info, "Scan started.");

            var detectionService = new RoofEdgeDetectionService(doc, (lvl, msg) => LogCallback?.Invoke(lvl, msg));

            IList<RoofBase> allRoofs = new FilteredElementCollector(doc)
                .OfClass(typeof(RoofBase))
                .Cast<RoofBase>()
                .ToList();

            LogCallback?.Invoke(LogLevel.Info, $"Collected {allRoofs.Count} roof element(s) in model for scanning.");

            foreach (var row in SectionsToProcess)
            {
                var rawEdges = detectionService.DetectEdges(row.SectionView, allRoofs);
                var dedupedEdges = detectionService.DedupEdges(rawEdges, DedupToleranceFeet);

                row.DetectedEdges = dedupedEdges;
                row.RoofsInCrop = rawEdges.Select(e => e.RoofId).Distinct().Count();
                row.EstimatedEdges = dedupedEdges.Count;
                row.ScanStatus = dedupedEdges.Count > 0 ? "Scanned" : "Scanned (0 edges - fallback will apply)";
            }

            LogCallback?.Invoke(LogLevel.Info, "Scan completed.");
            ScanCompletedCallback?.Invoke();
        }

        private void ExecuteRun(Document doc)
        {
            LogCallback?.Invoke(LogLevel.Info, "Run started.");

            if (TargetDraftingViewId == null || TargetDraftingViewId == ElementId.InvalidElementId)
            {
                LogCallback?.Invoke(LogLevel.Error, "No target Drafting View selected. Run aborted.");
                RunCompletedCallback?.Invoke(0, 0, 0);
                return;
            }

            var placementService = new ReferenceCalloutPlacementService(doc, (lvl, msg) => LogCallback?.Invoke(lvl, msg));

            int placed = 0, fallbackPlaced = 0, skipped = 0;

            using (TransactionGroup tg = new TransactionGroup(doc, "Place Roof Edge View References"))
            {
                tg.Start();

                foreach (var row in SectionsToProcess)
                {
                    // Sections not scanned yet (edge case) are scanned inline so Run
                    // never silently no-ops on an unscanned section.
                    if (row.EstimatedEdges < 0)
                    {
                        LogCallback?.Invoke(LogLevel.Warning, $"Section '{row.ViewName}': not scanned prior to Run - scanning now.");
                        var detectionService = new RoofEdgeDetectionService(doc, (lvl, msg) => LogCallback?.Invoke(lvl, msg));
                        IList<RoofBase> allRoofs = new FilteredElementCollector(doc)
                            .OfClass(typeof(RoofBase)).Cast<RoofBase>().ToList();
                        var rawEdges = detectionService.DetectEdges(row.SectionView, allRoofs);
                        row.DetectedEdges = detectionService.DedupEdges(rawEdges, DedupToleranceFeet);
                        row.EstimatedEdges = row.DetectedEdges.Count;
                    }

                    using (Transaction t = new Transaction(doc, $"Place References - {row.ViewName}"))
                    {
                        t.Start();
                        try
                        {
                            if (row.DetectedEdges.Count == 0)
                            {
                                // Zero-edge fallback: place a single callout at the section's crop center.
                                XYZ center = placementService.GetSectionCropCenter(row.SectionView);
                                bool ok = placementService.TryPlaceCallout(
                                    row.SectionView, TargetDraftingViewId, center, CalloutBoxSizeFeet, out _);

                                if (ok)
                                {
                                    fallbackPlaced++;
                                    LogCallback?.Invoke(LogLevel.Warning,
                                        $"Section '{row.ViewName}': 0 edges detected - placed fallback reference at section center.");
                                }
                                else
                                {
                                    skipped++;
                                }
                            }
                            else
                            {
                                foreach (var edge in row.DetectedEdges)
                                {
                                    bool ok = placementService.TryPlaceCallout(
                                        row.SectionView, TargetDraftingViewId, edge.PlacementPoint, CalloutBoxSizeFeet, out _);

                                    if (ok) placed++;
                                    else skipped++;
                                }
                            }

                            t.Commit();
                        }
                        catch (Exception ex)
                        {
                            t.RollBack();
                            LogCallback?.Invoke(LogLevel.Error, $"Section '{row.ViewName}': transaction rolled back - {ex.Message}");
                        }
                    }
                }

                tg.Assimilate();
            }

            LogCallback?.Invoke(LogLevel.Info,
                $"Run completed. {placed} placed | {fallbackPlaced} fallback placed | {skipped} skipped.");
            RunCompletedCallback?.Invoke(placed, fallbackPlaced, skipped);
        }

        public string GetName() => "Roof Edge View Reference Batch Handler";
    }
}
