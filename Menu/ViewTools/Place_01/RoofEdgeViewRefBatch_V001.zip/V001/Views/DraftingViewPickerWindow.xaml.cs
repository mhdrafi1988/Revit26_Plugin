using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V001.Views
{
    public partial class DraftingViewPickerWindow : Window
    {
        private readonly List<ViewDrafting> _allViews;
        public ViewDrafting SelectedView { get; private set; }

        public DraftingViewPickerWindow(List<ViewDrafting> draftingViews)
        {
            InitializeComponent();
            _allViews = draftingViews;
            ViewsListBox.ItemsSource = _allViews;
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string filter = FilterBox.Text;
            ViewsListBox.ItemsSource = string.IsNullOrWhiteSpace(filter)
                ? _allViews
                : _allViews.Where(v => v.Name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
        }

        private void Select_Click(object sender, RoutedEventArgs e)
        {
            ConfirmSelection();
        }

        private void ViewsListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ConfirmSelection();
        }

        private void ConfirmSelection()
        {
            if (ViewsListBox.SelectedItem is ViewDrafting vd)
            {
                SelectedView = vd;
                DialogResult = true;
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
