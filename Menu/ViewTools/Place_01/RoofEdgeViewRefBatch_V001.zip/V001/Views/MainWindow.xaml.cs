using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Autodesk.Revit.DB;
using Microsoft.Win32;
using Revit26_Plugin.RoofEdgeViewRefBatch.V001.Models;
using Revit26_Plugin.RoofEdgeViewRefBatch.V001.ViewModels;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V001.Views
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _viewModel;
        private readonly Document _doc;
        private string _lastLogExportFolder;

        public MainWindow(Document doc, IntPtr revitWindowHandle)
        {
            InitializeComponent();

            _doc = doc;
            _viewModel = new MainViewModel(doc);
            DataContext = _viewModel;

            // Per suite convention: WindowInteropHelper for Revit window ownership.
            new System.Windows.Interop.WindowInteropHelper(this).Owner = revitWindowHandle;
        }

        private void PickDraftingView_Click(object sender, RoutedEventArgs e)
        {
            var draftingViews = new FilteredElementCollector(_doc)
                .OfClass(typeof(ViewDrafting))
                .Cast<ViewDrafting>()
                .Where(v => !v.IsTemplate)
                .OrderBy(v => v.Name)
                .ToList();

            if (draftingViews.Count == 0)
            {
                MessageBox.Show(this, "No Drafting Views found in this model.", "Roof Edge View Reference Batch",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var picker = new DraftingViewPickerWindow(draftingViews) { Owner = this };
            if (picker.ShowDialog() == true && picker.SelectedView != null)
            {
                _viewModel.SetTargetDraftingView(picker.SelectedView);
            }
        }

        private void RowCheckbox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Prevents the checkbox click from also triggering DataGrid row selection,
            // per Advanced DataGrid spec (checkbox column click isolation).
            e.Handled = false; // allow the checkbox's own click to proceed
        }

        private void CopyAllLogs_Click(object sender, RoutedEventArgs e)
        {
            string text = string.Join(Environment.NewLine, _viewModel.LogEntries.Select(l => l.ToString()));
            TryCopyToClipboard(text);
        }

        private void CopySelectedLogs_Click(object sender, RoutedEventArgs e)
        {
            if (LogListBox.SelectedItems.Count == 0)
            {
                TryCopyToClipboard(string.Empty);
                return;
            }

            var selected = LogListBox.SelectedItems.Cast<LogEntry>().Select(l => l.ToString());
            TryCopyToClipboard(string.Join(Environment.NewLine, selected));
        }

        private void TryCopyToClipboard(string text)
        {
            try
            {
                if (!string.IsNullOrEmpty(text))
                    Clipboard.SetText(text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Could not copy to clipboard: {ex.Message}", "Roof Edge View Reference Batch",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void ExportLogs_Click(object sender, RoutedEventArgs e)
        {
            string fileName = $"RoofEdgeViewRefBatch_Logs_{DateTime.Now:yyyy-MM-dd_HH-mm}.txt";

            string folder = _lastLogExportFolder;
            string fullPath;

            if (string.IsNullOrEmpty(folder))
            {
                var dlg = new SaveFileDialog
                {
                    FileName = fileName,
                    Filter = "Text files (*.txt)|*.txt",
                    Title = "Export Logs"
                };

                if (dlg.ShowDialog(this) != true) return;

                fullPath = dlg.FileName;
                _lastLogExportFolder = Path.GetDirectoryName(fullPath);
            }
            else
            {
                fullPath = Path.Combine(folder, fileName);
            }

            try
            {
                string content = string.Join(Environment.NewLine, _viewModel.LogEntries.Select(l => l.ToString()));
                File.WriteAllText(fullPath, content, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Failed to export logs: {ex.Message}", "Roof Edge View Reference Batch",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
