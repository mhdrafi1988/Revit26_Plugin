using System;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.RoofEdgeViewRefBatch.V002.Views;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V002
{
    [Transaction(TransactionMode.Manual)]
    [Regeneration(RegenerationOption.Manual)]
    public class RoofEdgeViewRefBatchCommand : IExternalCommand
    {
        // Kept alive for the app session so the window isn't garbage collected
        // while open (modeless window, per suite convention of staying open
        // after operation completes).
        private static MainWindow _window;

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                UIApplication uiApp = commandData.Application;
                UIDocument uiDoc = uiApp.ActiveUIDocument;
                Document doc = uiDoc.Document;

                if (_window != null && _window.IsLoaded)
                {
                    _window.Activate();
                    return Result.Succeeded;
                }

                IntPtr revitHandle = Autodesk.Windows.ComponentManager.ApplicationWindow;
                _window = new MainWindow(doc, revitHandle);
                _window.Closed += (s, e) => _window = null;
                _window.Show();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }
    }
}
