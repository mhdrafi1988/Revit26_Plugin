// NOTE: Per suite convention, converter classes live in one shared file:
// Revit26_Plugin.Shared/Converters.cs. These two are new (not yet in that file
// based on prior tools' known converters) and should be appended there, then
// instantiated locally in this tool's Window.Resources like every other tool.
//
// If LogLevelToBrushConverter or BoolToBusyTextConverter already exist in your
// shared Converters.cs from a previous tool, skip adding duplicates - just
// reference the existing ones in this Window's local resources.

using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using Revit26_Plugin.RoofEdgeViewRefBatch.V002.Models;

namespace Revit26_Plugin.Shared
{
    /// <summary>
    /// Converts a LogLevel to a display brush (Info = navy, Warning = amber, Error = red),
    /// matching the log-box color convention used across the suite.
    /// </summary>
    public class LogLevelToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is LogLevel level)
            {
                switch (level)
                {
                    case LogLevel.Warning: return new SolidColorBrush(Color.FromRgb(0xA6, 0x7C, 0x00));
                    case LogLevel.Error: return new SolidColorBrush(Color.FromRgb(0xB3, 0x26, 0x1E));
                    default: return new SolidColorBrush(Color.FromRgb(0x1E, 0x3A, 0x5F));
                }
            }
            return new SolidColorBrush(Colors.Black);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }

    /// <summary>
    /// Inverts a bool - used to disable Scan/Run buttons while IsBusy is true and
    /// re-enable on completion, per your Run/action button convention.
    /// Add only if an equivalent (e.g. "InverseBooleanConverter") doesn't already
    /// exist in your shared Converters.cs from a prior tool.
    /// </summary>
    public class InverseBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : true;

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => value is bool b ? !b : true;
    }
}
