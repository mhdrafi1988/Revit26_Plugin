using System;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V002.Services
{
    /// <summary>
    /// Places Reference Callouts (ViewSection.CreateReferenceCallout) in a section view,
    /// each centered on a detected edge's placement point and pointing to a single
    /// shared target Drafting View.
    /// </summary>
    public class ReferenceCalloutPlacementService
    {
        private readonly Document _doc;
        private readonly Action<Models.LogLevel, string> _log;

        public ReferenceCalloutPlacementService(Document doc, Action<Models.LogLevel, string> logCallback)
        {
            _doc = doc;
            _log = logCallback;
        }

        /// <summary>
        /// Places one reference callout centered on the given model-space point, projected
        /// into the section view's own 2D space using the section's transform.
        /// boxSizeFeet is the full side length of the square callout box (model units, feet).
        /// Returns true if placement succeeded; false if it was skipped (logged as Warning).
        /// </summary>
        public bool TryPlaceCallout(
            ViewSection parentView,
            ElementId draftingViewId,
            XYZ modelPoint,
            double boxSizeFeet,
            out ElementId createdCalloutId)
        {
            createdCalloutId = ElementId.InvalidElementId;

            try
            {
                // Project model point into the section's view-space (X = right, Y = up)
                // so the callout box corners can be built in the coordinate system
                // CreateReferenceCallout expects (parent view space).
                Transform t = parentView.CropBox.Transform;
                Transform inverse = t.Inverse;
                XYZ localPt = inverse.OfPoint(modelPoint);

                double half = boxSizeFeet / 2.0;
                XYZ localP1 = new XYZ(localPt.X - half, localPt.Y - half, 0);
                XYZ localP2 = new XYZ(localPt.X + half, localPt.Y + half, 0);

                XYZ worldP1 = t.OfPoint(localP1);
                XYZ worldP2 = t.OfPoint(localP2);

                ViewSection calloutRef = ViewSection.CreateReferenceCallout(
                    _doc,
                    parentView.Id,
                    draftingViewId,
                    worldP1,
                    worldP2);

                createdCalloutId = calloutRef.Id;
                return true;
            }
            catch (Exception ex)
            {
                _log(Models.LogLevel.Warning,
                    $"Section '{parentView.Name}': failed to place reference callout at point ({modelPoint.X:F2}, {modelPoint.Y:F2}, {modelPoint.Z:F2}) - {ex.Message}. Skipped.");
                return false;
            }
        }

        /// <summary>
        /// Returns the world-space center point of a section's crop box, for the
        /// zero-edges fallback placement case.
        /// </summary>
        public XYZ GetSectionCropCenter(ViewSection section)
        {
            BoundingBoxXYZ crop = section.CropBox;
            XYZ localCenter = (crop.Min + crop.Max) * 0.5;
            return crop.Transform.OfPoint(localCenter);
        }
    }
}
