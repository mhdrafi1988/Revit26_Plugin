using Autodesk.Revit.DB;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V002.Services
{
    /// <summary>
    /// A single roof edge detected within a section's crop box + far clip depth volume,
    /// projected into that section's view space. Endpoints are in model (feet) coordinates.
    /// </summary>
    public class DetectedEdge
    {
        public ElementId RoofId { get; set; }
        public XYZ StartPoint { get; set; }
        public XYZ EndPoint { get; set; }

        public XYZ Midpoint => (StartPoint + EndPoint) * 0.5;

        /// <summary>
        /// The point used for placement (currently Midpoint, per confirmed convention).
        /// </summary>
        public XYZ PlacementPoint => Midpoint;

        /// <summary>
        /// True if this edge is a synthetic fallback point (zero real edges detected in section),
        /// placed at the section view's crop box center instead of a real roof edge.
        /// </summary>
        public bool IsFallback { get; set; } = false;
    }
}
