namespace Revit26_Plugin.RoofEdgeViewRefBatch.V002.Services
{
    /// <summary>
    /// This tool has two distinct Revit-side actions (Scan = read-only detection,
    /// Run = actual placement), so a small orchestrator with a Request enum is used
    /// instead of two separate IExternalEventHandler/ExternalEvent pairs.
    /// </summary>
    public enum RequestType
    {
        None,
        Scan,
        Run
    }
}
