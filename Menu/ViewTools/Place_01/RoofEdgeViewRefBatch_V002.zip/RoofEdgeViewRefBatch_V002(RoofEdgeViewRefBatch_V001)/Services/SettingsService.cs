using System;
using System.IO;
using System.Text.Json;
using Revit26_Plugin.RoofEdgeViewRefBatch.V002.Models;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V002.Services
{
    public static class SettingsService
    {
        private const string ToolName = "RoofEdgeViewRefBatch";

        private static string SettingsFolder =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "Revit26_Plugin", ToolName);

        private static string SettingsFilePath => Path.Combine(SettingsFolder, "settings.json");

        public static ToolSettings Load()
        {
            try
            {
                if (!File.Exists(SettingsFilePath))
                    return new ToolSettings();

                string json = File.ReadAllText(SettingsFilePath);
                return JsonSerializer.Deserialize<ToolSettings>(json) ?? new ToolSettings();
            }
            catch
            {
                // Corrupt or unreadable settings should never block tool startup.
                return new ToolSettings();
            }
        }

        public static void Save(ToolSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFilePath, json);
            }
            catch
            {
                // Best-effort persistence; failure to save should not interrupt the user.
            }
        }
    }
}
