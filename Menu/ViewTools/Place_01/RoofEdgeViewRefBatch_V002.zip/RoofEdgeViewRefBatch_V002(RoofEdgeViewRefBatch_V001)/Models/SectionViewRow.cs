using Autodesk.Revit.DB;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.RoofEdgeViewRefBatch.V002.Models
{
    /// <summary>
    /// Represents a single section view row in the selection DataGrid.
    /// Est. Roofs In Crop / Est. Edges are populated by the Scan step, not on load.
    /// </summary>
    public partial class SectionViewRow : ObservableObject
    {
        public ElementId ViewId { get; set; }
        public ViewSection SectionView { get; set; }

        [ObservableProperty]
        private bool _isSelected;

        public string ViewName { get; set; }
        public string SheetNumber { get; set; } = "(none)";

        [ObservableProperty]
        private int _roofsInCrop = -1; // -1 = not yet scanned

        [ObservableProperty]
        private int _estimatedEdges = -1; // -1 = not yet scanned

        [ObservableProperty]
        private string _scanStatus = "Not scanned";

        /// <summary>
        /// Detected + deduped edge midpoints (or start points) in this section, populated by Scan.
        /// Consumed directly by Run so Scan results don't need to be recomputed.
        /// </summary>
        public System.Collections.Generic.List<Services.DetectedEdge> DetectedEdges { get; set; }
            = new System.Collections.Generic.List<Services.DetectedEdge>();
    }
}
