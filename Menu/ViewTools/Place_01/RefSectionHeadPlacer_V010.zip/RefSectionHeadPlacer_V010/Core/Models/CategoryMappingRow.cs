using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.RefSectionHeadPlacer.V010.Core.Models
{
    /// <summary>Display wrapper for a drafting view in the mapping ComboBox (Grid 3).
    /// V004: equality is by underlying view ElementId, NOT reference — LoadDraftingViews()
    /// constructs fresh instances on every call, and WPF's ComboBox SelectedItem matching
    /// plus dictionary lookups must treat two wrappers of the same ViewDrafting as equal,
    /// otherwise a rescan orphans every existing selection (Selector pushes null back
    /// through the two-way binding when SelectedItem isn't found in ItemsSource).</summary>
    public class DraftingViewOption
    {
        public string Name { get; }
        public ViewDrafting RevitView { get; }

        public DraftingViewOption(ViewDrafting revitView)
        {
            RevitView = revitView;
            Name = revitView.Name;
        }

        public override string ToString() => Name;

        public override bool Equals(object obj)
            => obj is DraftingViewOption other &&
               other.RevitView?.Id.Value == RevitView?.Id.Value;

        public override int GetHashCode()
            => RevitView?.Id.Value.GetHashCode() ?? 0;
    }

    /// <summary>
    /// Bindable row for Grid 3 — identity is (SourceLabel, Bic, TypeName), matching
    /// ElementTypeRow exactly. Bic is the stable routing key; Category is display
    /// only. Rows are generated from the user's Grid 2 selections (one per selected
    /// row, per link); the user then assigns each a target drafting view.
    ///
    /// V006 (confirmed, Rafi): auto-match removed. Every row starts blank and is
    /// mapped ONLY by explicit user pick — no name-based guessing.
    ///
    /// V010 (confirmed, Rafi): the V008 popover (button + Popup) is REMOVED. The
    /// picker is now an editable, searchable ComboBox living directly in the grid
    /// cell (see RefSectionHeadPlacerWindow.xaml, Grid 3 CellTemplate). Typed text
    /// filters FilteredDraftingViews by substring match (not just prefix, unlike
    /// WPF's native ComboBox text-search) — SearchText/FilteredDraftingViews are
    /// KEPT from V008 and simply re-purposed: they used to feed a Popup's ListBox,
    /// now they feed the ComboBox's own drop-down ItemsSource directly.
    ///
    /// IsPopoverOpen and SelectDraftingView(...)'s popover-closing responsibility
    /// are gone — an editable ComboBox opens/closes its own drop-down natively, and
    /// commits a pick via its own SelectionChanged, so no code-behind popover-find
    /// workaround is needed anymore either (see window code-behind diff).
    ///
    /// Un-mapping a row is NOT supported via the ComboBox (confirmed, Rafi) — to
    /// exclude a row from Run, untick its IsSelected checkbox instead; the mapped
    /// value is left as-is and simply ignored by the engine for unselected rows.
    /// </summary>
    public partial class CategoryMappingRow : ObservableObject
    {
        [ObservableProperty]
        private bool isSelected = true;

        public string SourceLabel { get; }
        public string Category { get; }
        public BuiltInCategory Bic { get; }
        public string TypeName { get; }

        /// <summary>Combined label shown in the grid, e.g.
        /// "ARCH-Link.rvt · Plumbing Fixtures · Floor Drain 100mm".</summary>
        public string DisplayLabel => $"{SourceLabel} · {Category} · {TypeName}";

        [ObservableProperty]
        [NotifyPropertyChangedFor(nameof(MappedDraftingViewDisplay))]
        private DraftingViewOption mappedDraftingView;

        /// <summary>Fallback placeholder text shown when nothing is mapped yet
        /// (used by the ComboBox's Text binding when MappedDraftingView is null).</summary>
        public string MappedDraftingViewDisplay => MappedDraftingView?.Name ?? "— pick —";

        // ── V010: per-row live-search state for the ComboBox drop-down ──────
        [ObservableProperty]
        private string searchText = string.Empty;

        partial void OnSearchTextChanged(string value) => ApplyFilter();

        /// <summary>Full drafting-view list — set once by the ViewModel, shared
        /// (same instance) across every row; this row only reads it to filter.</summary>
        private IReadOnlyList<DraftingViewOption> _allDraftingViews = Array.Empty<DraftingViewOption>();

        /// <summary>This row's own live-narrowed list, bound to the ComboBox's
        /// ItemsSource — narrows by substring as SearchText changes.</summary>
        public ObservableCollection<DraftingViewOption> FilteredDraftingViews { get; } = new();

        /// <summary>Called once by the ViewModel after construction (and again if the
        /// drafting-view list is refreshed) to give this row something to filter.</summary>
        public void SetAvailableDraftingViews(IReadOnlyList<DraftingViewOption> allViews)
        {
            _allDraftingViews = allViews ?? Array.Empty<DraftingViewOption>();
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            FilteredDraftingViews.Clear();

            // V010: SearchText is pre-filled with the current pick's name so the
            // box displays it (see SelectDraftingView/ctor). Treat that unchanged
            // "just showing the pick" state the same as an empty filter — dropping
            // down should show the FULL list to pick a different view, not just the
            // one item that happens to match what's already shown. Only once the
            // user actually types something DIFFERENT from the current pick does
            // real filtering kick in.
            var search = SearchText?.Trim() ?? string.Empty;
            var isShowingCurrentPickUnedited =
                MappedDraftingView != null &&
                string.Equals(search, MappedDraftingView.Name, StringComparison.OrdinalIgnoreCase);

            foreach (var v in _allDraftingViews)
            {
                if (search.Length == 0 || isShowingCurrentPickUnedited ||
                    v.Name.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0)
                    FilteredDraftingViews.Add(v);
            }
        }

        /// <summary>Bound to the ComboBox's SelectionChanged (code-behind) — commits
        /// the pick. Unlike V008 there is no popover to close; the ComboBox closes
        /// its own drop-down natively on selection.
        ///
        /// FIX (V010): SearchText is set to the PICKED NAME here, not cleared to
        /// empty. The ComboBox's Text is bound to SearchText (so typing filters
        /// live), which means an empty SearchText would show a blank box even for
        /// an already-mapped row. Setting it to the pick's name keeps the box
        /// showing what's mapped once the pick is made, matching the old popover
        /// button's display behavior.</summary>
        public void SelectDraftingView(DraftingViewOption view)
        {
            MappedDraftingView = view;
            SearchText = view?.Name ?? string.Empty;
        }

        public CategoryMappingRow(
            string sourceLabel, string category, string typeName,
            BuiltInCategory bic, DraftingViewOption mappedDraftingView = null)
        {
            SourceLabel = sourceLabel;
            Category = category;
            TypeName = typeName;
            Bic = bic;
            this.mappedDraftingView = mappedDraftingView;

            // V010: if a pick is restored from session memory (RebuildMappings),
            // show its name in the box immediately rather than starting blank —
            // otherwise a restored mapping would look unmapped until the user
            // interacts with the row.
            searchText = mappedDraftingView?.Name ?? string.Empty;
        }
    }
}
