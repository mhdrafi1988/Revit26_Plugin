using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit26_Plugin.RefSectionHeadPlacer.V010.Core.Models;
using Revit26_Plugin.RefSectionHeadPlacer.V010.UI.ViewModels;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.RefSectionHeadPlacer.V010.UI.Views
{
    public partial class RefSectionHeadPlacerWindow : Window
    {
        private readonly RefSectionHeadPlacerViewModel _viewModel;

        public RefSectionHeadPlacerWindow(UIApplication uiApp, Document doc)
        {
            InitializeComponent();

            _viewModel = new RefSectionHeadPlacerViewModel(doc);
            DataContext = _viewModel;

            // Window ownership via WindowInteropHelper — never Application.Current
            // .MainWindow in a Revit add-in.
            new WindowInteropHelper(this).Owner = uiApp.MainWindowHandle;

            // ViewModel raises CloseRequested (it has no window reference itself).
            _viewModel.CloseRequested += Close;

            // MEMORY: dispose the ViewModel when the window closes so it unsubscribes
            // from the long-lived ExternalEvent handler and disposes the event.
            Closed += (s, e) =>
            {
                _viewModel.CloseRequested -= Close;
                _viewModel.Dispose();
            };
        }

        /// <summary>
        /// Copy Selected — code-behind per convention: reads the log grid's
        /// SelectedItems directly rather than routing through the ViewModel.
        /// </summary>
        private void OnCopySelectedLogsClick(object sender, RoutedEventArgs e)
        {
            var text = string.Join(System.Environment.NewLine,
                GridLog.SelectedItems.Cast<LogEntry>().Select(entry => entry.ToString()));
            if (!string.IsNullOrEmpty(text))
                Clipboard.SetText(text);
        }

        /// <summary>
        /// V010: fires when the user picks a drafting view from a Grid 3 row's
        /// ComboBox drop-down. Unlike the V008 popover, the ComboBox sits directly
        /// in the DataGrid cell's visual/logical tree — its DataContext is simply
        /// the CategoryMappingRow for that row, so no Popup/logical-tree lookup is
        /// needed here (that workaround existed only because a Popup's content
        /// renders in a separate visual root; a ComboBox's drop-down does not have
        /// that problem for DataContext inheritance purposes).
        ///
        /// GUARD (V010 review): FilteredDraftingViews (the ComboBox's ItemsSource)
        /// is cleared and rebuilt on every keystroke (CategoryMappingRow.ApplyFilter).
        /// Some WPF versions raise a spurious SelectionChanged with SelectedItem
        /// momentarily null during that Clear()/re-Add() sequence, not just from an
        /// actual user click. The pattern match below already no-ops on a null/
        /// non-DraftingViewOption SelectedItem, so a mapping is only ever committed
        /// on a genuine item pick — never on a filter-driven collection reset.
        /// </summary>
        private void MappingCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender is not ComboBox { SelectedItem: DraftingViewOption option, DataContext: CategoryMappingRow row })
                return; // null/none selected (e.g. filter reset mid-type) — ignore, no mapping change

            row.SelectDraftingView(option);
        }
    }
}
