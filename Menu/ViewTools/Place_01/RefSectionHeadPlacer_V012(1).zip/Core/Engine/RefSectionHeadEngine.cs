using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Revit26_Plugin.RefSectionHeadPlacer.V012.Core.Models;
using Revit26_Plugin.Shared.Models;

namespace Revit26_Plugin.RefSectionHeadPlacer.V012.Core.Engine
{
    public class RunSummary
    {
        public int PlacedCount { get; set; }
        public int SkippedCount { get; set; }
        public int FailedCount { get; set; }
    }

    /// <summary>
    /// Orchestrates a run in TWO phases:
    ///   1. Non-wall categories (Doors, Plumbing Fixtures/Equipment, Roofs) —
    ///      unchanged, one origin per selected instance via SectionOriginService.
    ///   2. Walls (V012 REWRITE, confirmed Rafi) — no longer one mark per wall.
    ///      Selected walls are grouped under their nearest qualifying roof
    ///      (RoofWallGroupingService), and for each roof-group the engine tries
    ///      candidate walls closest-to-roof-center first, scanning each wall
    ///      (WallClearPointService) for a point clear of BOTH hosted openings
    ///      and already-placed marks. First clear wall/point wins — ONE mark for
    ///      that roof. If every candidate wall is fully blocked, the closest
    ///      wall's midpoint is used anyway (forced placement, no checks).
    ///
    /// TRANSACTION MODEL (corrected): a SubTransaction REQUIRES an open host
    /// Transaction — a TransactionGroup is not a Transaction. So we open ONE
    /// Transaction for the whole run and isolate each item in its own
    /// SubTransaction. One item's failure rolls back only that SubTransaction;
    /// the run continues. The whole run is a single undo step.
    /// </summary>
    public class RefSectionHeadEngine
    {
        private readonly Document _hostDoc;
        private readonly Services.SectionOriginService _originService;
        private readonly Services.ClashAvoidanceService _clashService;
        private readonly Services.SectionPlacementService _placementService;
        private readonly Services.WallClearPointService _wallClearPointService;
        private readonly Services.RoofWallGroupingService _roofWallGroupingService;

        public event Action<LogEntry> LogEmitted;
        public event Action<int, int> ProgressChanged;

        public RefSectionHeadEngine(
            Document hostDoc,
            Services.SectionOriginService originService,
            Services.ClashAvoidanceService clashService,
            Services.SectionPlacementService placementService,
            Services.WallClearPointService wallClearPointService,
            Services.RoofWallGroupingService roofWallGroupingService)
        {
            _hostDoc = hostDoc;
            _originService = originService;
            _clashService = clashService;
            _placementService = placementService;
            _wallClearPointService = wallClearPointService;
            _roofWallGroupingService = roofWallGroupingService;
        }

        public RunSummary Run(
            IReadOnlyList<ElementTypeRow> selectedTypes,
            IReadOnlyList<CategoryMappingRow> mappings,
            ElementId activeViewId,
            ElementId sectionTypeId,
            double tailLengthFeet,
            Func<bool> cancellationRequested)
        {
            var summary = new RunSummary();

            // ── PHASE 1: non-wall categories — unchanged per-element pipeline ──
            var nonWallWork = selectedTypes
                .Where(t => t.IsSelected && t.Bic != BuiltInCategory.OST_Walls)
                .SelectMany(t => t.ElementIds.Select(id => (Row: t, ElementId: id)))
                .ToList();

            // ── PHASE 2 setup: roofs available as grouping anchors (host-owned,
            // per the confirmed split) — NOT filtered by IsSelected on purpose,
            // any roof in scope is a valid grouping anchor for nearby walls. ──
            var hostRoofs = selectedTypes
                .Where(t => t.Bic == BuiltInCategory.OST_Roofs)
                .SelectMany(t => t.ElementIds.Select(id => t.SourceDocument.GetElement(id)))
                .Where(e => e != null)
                .ToList();

            var wallRows = selectedTypes.Where(t => t.IsSelected && t.Bic == BuiltInCategory.OST_Walls).ToList();
            var wallCandidates = wallRows
                .SelectMany(row => row.ElementIds.Select(id => (Row: row, ElementId: id)))
                .Select(w => (Wall: (Element)w.Row.SourceDocument.GetElement(w.ElementId), Row: w.Row, ElementId: w.ElementId))
                .Where(w => w.Wall != null)
                .ToList();

            var groups = _roofWallGroupingService.BuildGroups(
                hostRoofs,
                wallCandidates.Select(w => (w.Wall, w.Row.LinkTransform)).ToList());

            int total = nonWallWork.Count + groups.Count(g => g.OrderedWalls.Count > 0), current = 0;
            Log(LogLevel.Info, $"Starting run · {nonWallWork.Count} non-wall item(s) + {groups.Count(g => g.OrderedWalls.Count > 0)} roof(s) with candidate walls.");

            using (var tx = new Transaction(_hostDoc, "Place Reference Section Heads"))
            {
                tx.Start();

                // ── PHASE 1 ──
                foreach (var (row, elementId) in nonWallWork)
                {
                    current++;
                    ProgressChanged?.Invoke(current, total);

                    if (cancellationRequested?.Invoke() == true)
                    {
                        Log(LogLevel.Warning, $"Run cancelled at item {current} of {total}.");
                        tx.Commit();
                        Log(LogLevel.Info, $"Run complete — {summary.PlacedCount} placed | {summary.SkippedCount} skipped | {summary.FailedCount} failed.");
                        return summary;
                    }

                    var element = row.SourceDocument.GetElement(elementId);
                    if (element == null)
                    {
                        summary.SkippedCount++;
                        Log(LogLevel.Warning, $"Skip · {row.Category} · id {elementId.Value} · element not found.");
                        continue;
                    }

                    var mapping = mappings.FirstOrDefault(m =>
                        m.IsSelected && m.SourceLabel == row.SourceLabel &&
                        m.Bic == row.Bic && m.TypeName == row.TypeName);
                    if (mapping?.MappedDraftingView == null)
                    {
                        summary.SkippedCount++;
                        Log(LogLevel.Warning, $"Skip · {row.SourceLabel} · {row.Category} · {row.TypeName} · no drafting-view mapping.");
                        continue;
                    }

                    var origin = _originService.GetOrigin(element, row.Bic, row.LinkTransform, tailLengthFeet);
                    if (!origin.IsValid)
                    {
                        summary.SkippedCount++;
                        Log(LogLevel.Warning, $"Skip · {row.Category} · id {elementId.Value} · {origin.SkipReason}");
                        continue;
                    }

                    PlaceOne(row, elementId.Value, origin.Origin, origin.ViewDirection, mapping,
                        activeViewId, sectionTypeId, tailLengthFeet, summary);
                }

                // ── PHASE 2: walls, one mark per roof-group (V012) ──
                foreach (var group in groups)
                {
                    if (group.OrderedWalls.Count == 0)
                        continue; // no candidate walls near this roof — no mark, as agreed

                    current++;
                    ProgressChanged?.Invoke(current, total);

                    if (cancellationRequested?.Invoke() == true)
                    {
                        Log(LogLevel.Warning, $"Run cancelled at roof {current} of {total}.");
                        break;
                    }

                    PlaceWallMarkForRoof(group, wallRows, mappings, activeViewId, sectionTypeId, tailLengthFeet, summary);
                }

                tx.Commit();
            }

            Log(LogLevel.Info, $"Run complete — {summary.PlacedCount} placed | {summary.SkippedCount} skipped | {summary.FailedCount} failed.");
            return summary;
        }

        /// <summary>
        /// V012: one roof-group -> one wall mark. Tries candidate walls
        /// closest-to-roof-center first (group.OrderedWalls is pre-sorted);
        /// each wall is scanned end-to-end (WallClearPointService) for a point
        /// clear of hosted openings AND already-placed marks. First clear point
        /// on the first workable wall wins. If EVERY candidate wall is fully
        /// blocked, forces a placement at the closest wall's midpoint —
        /// ignoring both opening and clash checks (confirmed, Rafi: "if all
        /// blocked, place at middle").
        /// </summary>
        private void PlaceWallMarkForRoof(
            Services.RoofWallGroup group,
            IReadOnlyList<ElementTypeRow> wallRows,
            IReadOnlyList<CategoryMappingRow> mappings,
            ElementId activeViewId, ElementId sectionTypeId, double tailLengthFeet,
            RunSummary summary)
        {
            string roofLabel = $"Roof id {group.Roof.Id.Value}";

            foreach (var (wall, toHost) in group.OrderedWalls)
            {
                var row = FindRow(wallRows, wall, toHost);
                var mapping = FindMapping(mappings, row);
                if (mapping?.MappedDraftingView == null)
                {
                    Log(LogLevel.Warning, $"Skip · Walls · id {wall.Id.Value} · no drafting-view mapping for this wall type.");
                    continue; // try the next candidate wall — a different wall type might be mapped
                }

                var clear = _wallClearPointService.FindClearPoint((Wall)wall, toHost, _clashService);
                if (clear.Found)
                {
                    var origin = Services.SectionOriginService.WallOriginAtParameter(wall, toHost, tailLengthFeet, clear.Parameter);
                    if (origin.IsValid)
                    {
                        PlaceOne(row, wall.Id.Value, origin.Origin, origin.ViewDirection, mapping,
                            activeViewId, sectionTypeId, tailLengthFeet, summary, registerClash: true);
                        return; // one mark for this roof — done
                    }
                }
            }

            // All candidate walls fully blocked -> force placement at the
            // CLOSEST wall's (first in OrderedWalls) midpoint, no checks.
            var (closestWall, closestToHost) = group.OrderedWalls[0];
            var forcedRow = FindRow(wallRows, closestWall, closestToHost);
            var forcedMapping = FindMapping(mappings, forcedRow);
            if (forcedMapping?.MappedDraftingView == null)
            {
                summary.SkippedCount++;
                Log(LogLevel.Warning, $"Skip · {roofLabel} · all candidate walls blocked, and closest wall's type has no drafting-view mapping.");
                return;
            }

            var forcedOrigin = Services.SectionOriginService.WallOriginAtParameter(closestWall, closestToHost, tailLengthFeet, 0.5);
            Log(LogLevel.Warning, $"{roofLabel} · every candidate wall fully blocked (openings/marks) — forced placement at closest wall's midpoint, ignoring blocks.");
            PlaceOne(forcedRow, closestWall.Id.Value, forcedOrigin.Origin, forcedOrigin.ViewDirection, forcedMapping,
                activeViewId, sectionTypeId, tailLengthFeet, summary, registerClash: true);
        }

        /// <summary>Finds the ElementTypeRow a candidate wall came from. Matches
        /// on SourceDocument (the wall's own doc) rather than LinkTransform —
        /// Transform is a Revit API type without value equality, so comparing
        /// two separately-obtained Transform instances for "same link" is
        /// unreliable even when numerically identical.</summary>
        private static ElementTypeRow FindRow(IReadOnlyList<ElementTypeRow> wallRows, Element wall, Transform toHost)
            => wallRows.FirstOrDefault(r => r.SourceDocument.Equals(wall.Document) && r.ElementIds.Any(id => id == wall.Id));

        private static CategoryMappingRow FindMapping(IReadOnlyList<CategoryMappingRow> mappings, ElementTypeRow row)
            => row == null ? null : mappings.FirstOrDefault(m =>
                m.IsSelected && m.SourceLabel == row.SourceLabel &&
                m.Bic == row.Bic && m.TypeName == row.TypeName);

        /// <summary>Shared single-item placement — SubTransaction isolation,
        /// success/failure logging, and (for walls) clash registration so later
        /// roof-groups in the same run see this mark too.</summary>
        private void PlaceOne(
            ElementTypeRow row, long elementId, XYZ origin, XYZ direction, CategoryMappingRow mapping,
            ElementId activeViewId, ElementId sectionTypeId, double tailLengthFeet,
            RunSummary summary, bool registerClash = false)
        {
            using (var sub = new SubTransaction(_hostDoc))
            {
                sub.Start();
                var result = _placementService.PlaceReferenceSection(
                    activeViewId, origin, direction,
                    mapping.MappedDraftingView.RevitView.Id, sectionTypeId, tailLengthFeet);

                if (result.Success && sub.Commit() == TransactionStatus.Committed)
                {
                    summary.PlacedCount++;
                    if (registerClash) _clashService.RegisterPlacement(origin);
                    Log(LogLevel.Success, $"Placed · {row.Category} · {row.TypeName} → {mapping.MappedDraftingView.Name}");
                }
                else
                {
                    if (sub.GetStatus() == TransactionStatus.Started) sub.RollBack();
                    summary.FailedCount++;
                    Log(LogLevel.Error, $"Failed · {row.Category} · id {elementId} · {result.Message ?? "sub-transaction not committed"}");
                }
            }
        }

        private void Log(LogLevel level, string message) => LogEmitted?.Invoke(new LogEntry(level, message));
    }
}
