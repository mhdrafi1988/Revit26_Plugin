using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.RefSectionHeadPlacer.V012.Core.Services
{
    public class WallClearPointResult
    {
        public bool Found { get; set; }

        /// <summary>Normalized curve parameter (0..1) of the clear point, SOURCE
        /// (wall document) space — used by SectionOriginService to build the
        /// centered origin + perpendicular direction at that exact spot.</summary>
        public double Parameter { get; set; }
    }

    /// <summary>
    /// V012 (confirmed, Rafi): scans a wall's own location line for a point clear
    /// of BOTH hosted openings (any family instance hosted on the wall — doors,
    /// windows, or otherwise, per Rafi: "any familiy is on hosted considered as a
    /// block") AND other reference-section marks already placed this run.
    ///
    /// Scope note: hosted inserts are queried directly from the WALL'S OWN
    /// document (wall.FindInserts), independent of the tool's Grid 2 selection —
    /// a door outside the roof-buffer bounding box would never be a loaded
    /// ElementTypeRow, but it still physically blocks the wall and must count.
    ///
    /// Everything here is 2D (XY only, Z ignored) — "when 2D considered" per
    /// Rafi — matching ClashAvoidanceService's existing plan-only clearance rule.
    /// </summary>
    public class WallClearPointService
    {
        private const double StepFeet = 0.492; // 150 mm scan step (confirmed, Rafi)
        private const double OpeningMarginFeet = 0.492; // 150 mm margin around each opening (confirmed, Rafi)

        /// <summary>
        /// Scans wall.LocationCurve from one end to the other in fixed 150mm
        /// steps (source/wall-document space). At each step, the point (pushed
        /// to HOST space for the clash check) must be clear of:
        ///   - every hosted opening's footprint ± OpeningMarginFeet, and
        ///   - every already-placed mark this run (clashService, 1 ft, XY).
        /// Returns the FIRST clear parameter found, preferring the wall's own
        /// midpoint region first is NOT done here — this is a straight end-to-end
        /// scan; candidate ordering (mid-first) was the old fixed-3-point
        /// approach and is superseded by this continuous scan per Rafi's
        /// "find a point where there is no opening... place it there" direction.
        /// </summary>
        public WallClearPointResult FindClearPoint(
            Wall wall, Transform toHost, ClashAvoidanceService clashService)
        {
            if (!(wall.Location is LocationCurve lc) || lc.Curve == null)
                return new WallClearPointResult { Found = false };

            Curve curve = lc.Curve;
            double length = curve.Length;
            if (length <= 0)
                return new WallClearPointResult { Found = false };

            var openingRanges = GetHostedOpeningRanges(wall, curve);

            int steps = Math.Max(1, (int)Math.Ceiling(length / StepFeet));
            for (int i = 0; i <= steps; i++)
            {
                double distAlong = Math.Min(i * StepFeet, length);
                double param = distAlong / length; // normalize 0..1

                if (IsInsideAnyRange(distAlong, openingRanges))
                    continue;

                XYZ hostPoint = toHost.OfPoint(curve.Evaluate(param, normalized: true));
                if (!clashService.IsClear(hostPoint))
                    continue;

                return new WallClearPointResult { Found = true, Parameter = param };
            }

            return new WallClearPointResult { Found = false };
        }

        /// <summary>
        /// Every family instance hosted on this wall (wall.FindInserts covers
        /// doors/windows/openings; a direct Host-id filter catches any other
        /// hosted family type too, per Rafi's "any family... considered a
        /// block"), projected onto the wall's own curve as a [start, end] range
        /// in DISTANCE-ALONG-WALL terms (source space), each expanded by
        /// OpeningMarginFeet on both sides.
        /// </summary>
        private static List<(double Start, double End)> GetHostedOpeningRanges(Wall wall, Curve curve)
        {
            var doc = wall.Document;
            double length = curve.Length;

            var hostedIds = new HashSet<ElementId>(
                wall.FindInserts(true, true, true, true));

            // FindInserts covers standard hosted categories reliably; a direct
            // Host-id sweep is added as a belt-and-braces catch-all so a hosted
            // family FindInserts might miss still counts as a block.
            var extra = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Cast<FamilyInstance>()
                .Where(fi => fi.Host?.Id == wall.Id)
                .Select(fi => fi.Id);
            foreach (var id in extra) hostedIds.Add(id);

            var ranges = new List<(double, double)>();

            foreach (var id in hostedIds)
            {
                var elem = doc.GetElement(id);
                var bbox = elem?.get_BoundingBox(null);
                if (bbox == null) continue;

                // Project the 8 bbox corners onto the wall's curve parameter
                // space by finding each corner's closest distance-along-wall;
                // the min/max of those gives the footprint's span on the wall.
                double? min = null, max = null;
                foreach (var corner in BoxCorners(bbox))
                {
                    IntersectionResult proj;
                    try { proj = curve.Project(corner); }
                    catch (Autodesk.Revit.Exceptions.ArgumentException) { continue; } // degenerate/zero-length curve guard

                    if (proj == null) continue;

                    double d = DistanceAlong(curve, proj.Parameter);
                    min = min == null ? d : Math.Min(min.Value, d);
                    max = max == null ? d : Math.Max(max.Value, d);
                }

                if (min == null) continue;

                ranges.Add((
                    Math.Max(0, min.Value - OpeningMarginFeet),
                    Math.Min(length, max.Value + OpeningMarginFeet)));
            }

            return ranges;
        }

        /// <summary>Converts a raw (non-normalized) curve parameter — as returned
        /// by Curve.Project — into true arc-length distance from the curve's
        /// start. Clamped to the curve's own [start,end] parameter bound first,
        /// since Project can return a parameter for the closest point on the
        /// UNBOUND extension of the curve, which MakeBound would reject.</summary>
        private static double DistanceAlong(Curve curve, double rawParameter)
        {
            double startParam = curve.GetEndParameter(0);
            double endParam = curve.GetEndParameter(1);
            double clamped = Math.Max(startParam, Math.Min(endParam, rawParameter));

            if (clamped <= startParam) return 0;

            try
            {
                Curve trimmed = curve.Clone();
                trimmed.MakeBound(startParam, clamped);
                return trimmed.Length;
            }
            catch
            {
                return 0;
            }
        }

        private static IEnumerable<XYZ> BoxCorners(BoundingBoxXYZ b)
        {
            yield return new XYZ(b.Min.X, b.Min.Y, b.Min.Z);
            yield return new XYZ(b.Min.X, b.Max.Y, b.Min.Z);
            yield return new XYZ(b.Max.X, b.Min.Y, b.Min.Z);
            yield return new XYZ(b.Max.X, b.Max.Y, b.Min.Z);
            yield return new XYZ(b.Min.X, b.Min.Y, b.Max.Z);
            yield return new XYZ(b.Min.X, b.Max.Y, b.Max.Z);
            yield return new XYZ(b.Max.X, b.Min.Y, b.Max.Z);
            yield return new XYZ(b.Max.X, b.Max.Y, b.Max.Z);
        }

        private static bool IsInsideAnyRange(double distAlong, List<(double Start, double End)> ranges)
        {
            foreach (var (start, end) in ranges)
                if (distAlong >= start && distAlong <= end)
                    return true;
            return false;
        }
    }
}
