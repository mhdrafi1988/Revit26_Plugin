using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;

namespace Revit26_Plugin.RefSectionHeadPlacer.V012.Core.Services
{
    /// <summary>One roof's placement group: the roof itself and its candidate
    /// walls (HOST space), ordered CLOSEST-TO-ROOF-CENTER FIRST (confirmed,
    /// Rafi) — the engine tries walls in this order until one yields a clear
    /// point, or forces a placement on the first (closest) wall if all are
    /// blocked.</summary>
    public class RoofWallGroup
    {
        public Element Roof { get; set; }
        public List<(Element Wall, Transform ToHost)> OrderedWalls { get; set; } = new();
    }

    /// <summary>
    /// V012 (confirmed, Rafi): groups selected walls under their nearest
    /// qualifying roof so the engine can place ONE reference-section mark per
    /// roof, not one per wall. A wall qualifies for a roof if the wall's HOST-
    /// space bounding box intersects/touches that roof's bounding box (Q1,
    /// confirmed) — the same style of proximity test the old (deleted)
    /// wall–roof-corner heuristic used, just for grouping instead of for a
    /// corner point. A wall touching multiple roof bboxes is assigned to the
    /// CLOSEST one only (by center-to-center distance) so it is never placed
    /// twice.
    /// </summary>
    public class RoofWallGroupingService
    {
        public List<RoofWallGroup> BuildGroups(
            IReadOnlyList<Element> hostRoofs,
            IReadOnlyList<(Element Wall, Transform ToHost)> candidateWalls)
        {
            var groups = hostRoofs
                .Select(r => new RoofWallGroup { Roof = r })
                .ToList();

            var roofBoxes = groups
                .Select(g => (Group: g, Box: g.Roof.get_BoundingBox(null)))
                .Where(t => t.Box != null)
                .ToList();

            foreach (var (wall, toHost) in candidateWalls)
            {
                var wallBox = GetHostSpaceBoundingBox(wall, toHost);
                if (wallBox == null) continue;

                RoofWallGroup best = null;
                double bestDist = double.MaxValue;

                foreach (var (group, roofBox) in roofBoxes)
                {
                    if (!Intersects(wallBox.Value, roofBox)) continue;

                    double dist = CenterOf(wallBox.Value).DistanceTo(CenterOf(roofBox));
                    if (dist < bestDist) { bestDist = dist; best = group; }
                }

                best?.OrderedWalls.Add((wall, toHost));
            }

            // Order each roof's walls closest-to-roof-center first.
            foreach (var (group, roofBox) in roofBoxes)
            {
                XYZ roofCenter = CenterOf(roofBox);
                group.OrderedWalls = group.OrderedWalls
                    .OrderBy(w => CenterOf(GetHostSpaceBoundingBox(w.Wall, w.ToHost) ?? roofBox).DistanceTo(roofCenter))
                    .ToList();
            }

            return groups;
        }

        private static (XYZ Min, XYZ Max)? GetHostSpaceBoundingBox(Element elem, Transform toHost)
        {
            var b = elem.get_BoundingBox(null);
            if (b == null) return null;

            // Transform all 8 corners — toHost may include rotation, so Min/Max
            // alone (transformed) would be wrong for a rotated link.
            var corners = new[]
            {
                new XYZ(b.Min.X, b.Min.Y, b.Min.Z), new XYZ(b.Min.X, b.Max.Y, b.Min.Z),
                new XYZ(b.Max.X, b.Min.Y, b.Min.Z), new XYZ(b.Max.X, b.Max.Y, b.Min.Z),
                new XYZ(b.Min.X, b.Min.Y, b.Max.Z), new XYZ(b.Min.X, b.Max.Y, b.Max.Z),
                new XYZ(b.Max.X, b.Min.Y, b.Max.Z), new XYZ(b.Max.X, b.Max.Y, b.Max.Z),
            }.Select(toHost.OfPoint).ToList();

            var min = new XYZ(corners.Min(c => c.X), corners.Min(c => c.Y), corners.Min(c => c.Z));
            var max = new XYZ(corners.Max(c => c.X), corners.Max(c => c.Y), corners.Max(c => c.Z));
            return (min, max);
        }

        private static bool Intersects((XYZ Min, XYZ Max) a, BoundingBoxXYZ b)
            => a.Min.X <= b.Max.X && a.Max.X >= b.Min.X &&
               a.Min.Y <= b.Max.Y && a.Max.Y >= b.Min.Y;

        private static XYZ CenterOf(BoundingBoxXYZ b) => (b.Min + b.Max) * 0.5;
        private static XYZ CenterOf((XYZ Min, XYZ Max) b) => (b.Min + b.Max) * 0.5;
    }
}
