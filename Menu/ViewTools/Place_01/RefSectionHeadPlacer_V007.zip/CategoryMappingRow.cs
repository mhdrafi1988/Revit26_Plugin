using Autodesk.Revit.DB;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.RefSectionHeadPlacer.V007.Core.Models
{
    /// <summary>Display wrapper for a drafting view in the mapping ComboBox (Grid 3).
    /// V004: equality is by underlying view ElementId, NOT reference — LoadDraftingViews()
    /// constructs fresh instances on every call, and WPF's ComboBox SelectedItem matching
    /// plus dictionary lookups must treat two wrappers of the same ViewDrafting as equal,
    /// otherwise a rescan orphans every existing selection (Selector pushes null back
    /// through the two-way binding when SelectedItem isn't found in ItemsSource).</summary>
    public class DraftingViewOption
    {
        public string Name { get; }
        public ViewDrafting RevitView { get; }

        public DraftingViewOption(ViewDrafting revitView)
        {
            RevitView = revitView;
            Name = revitView.Name;
        }

        public override string ToString() => Name;

        public override bool Equals(object obj)
            => obj is DraftingViewOption other &&
               other.RevitView?.Id.Value == RevitView?.Id.Value;

        public override int GetHashCode()
            => RevitView?.Id.Value.GetHashCode() ?? 0;
    }

    /// <summary>
    /// Bindable row for Grid 3 — identity is (SourceLabel, Bic, TypeName), matching
    /// ElementTypeRow exactly. Bic is the stable routing key; Category is display
    /// only. Rows are generated from the user's Grid 2 selections (one per selected
    /// row, per link); the user then assigns each a target drafting view.
    ///
    /// V006 (confirmed, Rafi): auto-match removed. Every row starts blank and is
    /// mapped ONLY by explicit user pick in the Grid 3 ComboBox — no name-based
    /// guessing. IsAutoAssigned is gone with it; there is no longer a distinction
    /// between an auto-guessed pick and a manual one, because every pick is manual.
    /// </summary>
    public partial class CategoryMappingRow : ObservableObject
    {
        [ObservableProperty]
        private bool isSelected = true;

        public string SourceLabel { get; }
        public string Category { get; }
        public BuiltInCategory Bic { get; }
        public string TypeName { get; }

        /// <summary>Combined label shown in the grid, e.g.
        /// "ARCH-Link.rvt · Plumbing Fixtures · Floor Drain 100mm".</summary>
        public string DisplayLabel => $"{SourceLabel} · {Category} · {TypeName}";

        [ObservableProperty]
        private DraftingViewOption mappedDraftingView;

        public CategoryMappingRow(
            string sourceLabel, string category, string typeName,
            BuiltInCategory bic, DraftingViewOption mappedDraftingView = null)
        {
            SourceLabel = sourceLabel;
            Category = category;
            TypeName = typeName;
            Bic = bic;
            this.mappedDraftingView = mappedDraftingView;
        }
    }
}
