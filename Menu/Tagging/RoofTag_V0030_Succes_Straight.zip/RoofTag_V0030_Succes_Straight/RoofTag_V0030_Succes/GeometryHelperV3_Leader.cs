﻿﻿using Autodesk.Revit.DB;
using System;
namespace Revit26_Plugin.RoofTag_V03.Helpers
{
    internal static partial class GeometryHelperV3
    {
        internal enum PlacementMode
        {
            Inward,
            Outward
        }

        /// <summary>
        /// Converts model millimeters to feet.
        /// </summary>
        private static double MmToFeet(double modelMm)
        {
            return modelMm / 304.8;
        }

        /// <summary>
        /// Gets the visible bounding box of an element in view coordinates
        /// </summary>
        private static BoundingBoxXYZ GetElementViewBoundingBox(Element element, View view)
        {
            Options options = new Options
            {
                View = view,
                ComputeReferences = true
            };

            GeometryElement geometry = element.get_Geometry(options);
            if (geometry == null) return null;

            BoundingBoxXYZ bbox = geometry.GetBoundingBox();
            if (bbox == null) return null;

            // Transform to view coordinates
            Transform transform = view.CropBox.Transform;
            XYZ min = transform.Inverse.OfPoint(bbox.Min);
            XYZ max = transform.Inverse.OfPoint(bbox.Max);

            return new BoundingBoxXYZ
            {
                Min = min,
                Max = max
            };
        }

        /// <summary>
        /// Determines the quadrant of a point relative to bounding box center in view space
        /// </summary>
        private static (bool isTop, bool isRight) GetViewQuadrant(
            XYZ anchorPoint,
            XYZ center,
            XYZ rightDirection,
            XYZ upDirection)
        {
            XYZ delta = anchorPoint - center;
            double x = delta.DotProduct(rightDirection); // left/right
            double y = delta.DotProduct(upDirection);    // top/bottom

            return (y >= 0, x >= 0); // isTop, isRight
        }

        /// <summary>
        /// Computes orthogonal leader bend and end points in VIEW SPACE.
        /// First move: vertical (Up/Down) -> BEND
        /// Second move: horizontal (Left/Right) -> END
        /// Uses model units (converts internally from feet).
        /// </summary>
        public static (XYZ Bend, XYZ End) ComputeLeaderBendAndEnd(
            View view,
            Element element,
            XYZ anchorPoint,
            double bendOffsetFt,    // Already in feet
            double endOffsetFt,     // Already in feet
            PlacementMode placementMode)
        {
            // Get view basis vectors
            XYZ right = view.RightDirection.Normalize();
            XYZ up = view.UpDirection.Normalize();

            // Get element's bounding box in view coordinates
            BoundingBoxXYZ bbox = GetElementViewBoundingBox(element, view);
            if (bbox == null)
            {
                // Fallback: use anchor point as both bend and end
                return (anchorPoint, anchorPoint);
            }

            XYZ center = (bbox.Min + bbox.Max) * 0.5;

            // Transform anchor point to view coordinates
            Transform viewTransform = view.CropBox.Transform.Inverse;
            XYZ anchorView = viewTransform.OfPoint(anchorPoint);

            // Determine quadrant
            var (isTop, isRight) = GetViewQuadrant(anchorView, center, right, up);

            // Determine movement directions based on mode and quadrant
            XYZ verticalDir;
            XYZ horizontalDir;

            if (placementMode == PlacementMode.Outward)
            {
                // OUTWARD: Leader end outside bounding box
                verticalDir = isTop ? up : -up;           // Top: Up, Bottom: Down
                horizontalDir = isRight ? right : -right; // Right: Right, Left: Left
            }
            else // Inward
            {
                // INWARD: Leader end inside bounding box
                // Reverse both directions from outward
                verticalDir = isTop ? -up : up;           // Top: Down, Bottom: Up
                horizontalDir = isRight ? -right : right; // Right: Left, Left: Right
            }

            // Transform directions back to model coordinates
            verticalDir = viewTransform.Inverse.OfVector(verticalDir).Normalize();
            horizontalDir = viewTransform.Inverse.OfVector(horizontalDir).Normalize();

            // Apply two-step movement (using feet values directly)
            XYZ bendPoint = anchorPoint + verticalDir * bendOffsetFt;
            XYZ endPoint = bendPoint + horizontalDir * endOffsetFt;

            return (bendPoint, endPoint);
        }

        /// <summary>
        /// Legacy method for backward compatibility - uses centroid instead of bounding box
        /// </summary>
        public static XYZ ComputeBendPoint(
            XYZ anchorPoint,
            XYZ centroid,
            double bendOffsetFt,  // Already in feet
            bool bendInward)
        {
            if (centroid == null) return anchorPoint;

            // This is a simplified version for backward compatibility
            // Uses direct vector instead of view-based calculation
            XYZ direction = bendInward ?
                (centroid - anchorPoint).Normalize() :
                (anchorPoint - centroid).Normalize();

            if (direction == null) return anchorPoint;

            return anchorPoint + direction * bendOffsetFt;
        }

        /// <summary>
        /// Legacy method for backward compatibility - uses angle-based calculation
        /// </summary>
        public static XYZ ComputeEndPointWithAngle(
            XYZ anchorPoint,
            XYZ bendPoint,
            double angleDegrees,
            double endOffsetFt,  // Already in feet
            XYZ outwardDirection,
            bool bendInward)
        {
            if (outwardDirection == null) return bendPoint;

            // This maintains existing behavior for backward compatibility
            // Not using view-based calculations
            double angleRad = angleDegrees * Math.PI / 180.0;
            XYZ direction = outwardDirection.Normalize();

            if (direction == null) return bendPoint;

            // Rotate direction by specified angle
            XYZ rotatedDir = new XYZ(
                direction.X * Math.Cos(angleRad) - direction.Y * Math.Sin(angleRad),
                direction.X * Math.Sin(angleRad) + direction.Y * Math.Cos(angleRad),
                0);

            if (bendInward)
                rotatedDir = -rotatedDir;

            return bendPoint + rotatedDir * endOffsetFt;
        }

        /// <summary>
        /// Simple helper to convert UI mm to feet for direct use
        /// </summary>
        public static double ConvertMmToFeet(double millimeters)
        {
            return millimeters / 304.8;
        }
    }
}