using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.DB;
using Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Models;
using Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Services;

namespace Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Engine
{
    /// <summary>
    /// Orchestrates the full Profile-group (Floor/Roof) pipeline for one enabled
    /// ElementMapping, per spec Section 16/17/24:
    ///
    ///   Find Matching Linked Elements
    ///     -> Spatial Candidate Filter (Stage 1)
    ///     -> Extract Geometry (outer + inner boundary loops, exact curve types)
    ///     -> Transform Link -> Host
    ///     -> Project to Plan (flatten to view's Z)
    ///     -> Clip to View Boundary (Stage 2: trim / close-loop / cap per ProcessingScope)
    ///     -> Create Detail Curves
    ///     -> Apply Detail Line Style
    ///     -> Apply Color Override
    ///     -> Store Metadata
    ///
    /// Must be called from within an active host-document Transaction (this class
    /// does not open/commit its own transaction -- see spec Section 25 and the
    /// ExternalEventHandler that wraps it).
    /// </summary>
    public class ProfileProcessingEngine
    {
        private readonly SpatialFilterService _spatialFilter = new();
        private readonly GeometryExtractionService _extraction = new();
        private readonly GeometryTransformService _transform = new();
        private readonly GeometryProjectionService _projection = new();
        private readonly GeometryClippingService _clipping = new();
        private readonly DetailLineCreationService _lineCreation = new();
        private readonly GraphicsOverrideService _graphicsOverride = new();
        private readonly MetadataService _metadata = new();
        private readonly DetailLineStyleService _lineStyleService = new();

        public MappingProcessingResult ProcessMapping(
            Document hostDoc,
            View activeView,
            RevitLinkInstance linkInstance,
            ElementMapping mapping,
            List<XYZ> processingBoundary,
            ProcessingScope scope,
            ComplexCurveSettings complexCurveSettings,
            Action<string, LogSeverity>? onLog = null)
        {
            var result = new MappingProcessingResult { MappingId = mapping.MappingId };

            void Log(string msg, LogSeverity sev = LogSeverity.Info) => onLog?.Invoke(msg, sev);

            Document? linkedDoc = linkInstance.GetLinkDocument();
            if (linkedDoc == null)
            {
                Log($"Mapping '{mapping.CategoryName}/{mapping.TypeName}': link document not loaded, skipped.", LogSeverity.Warning);
                return result;
            }

            Transform linkToHost = linkInstance.GetTotalTransform();

            // ── Find matching linked elements (Category + Type filter) ──
            List<Element> matchingElements;
            try
            {
                BuiltInCategory bic = mapping.CategoryName == "Roof" ? BuiltInCategory.OST_Roofs : BuiltInCategory.OST_Floors;
                matchingElements = new FilteredElementCollector(linkedDoc)
                    .OfCategory(bic)
                    .WhereElementIsNotElementType()
                    .Where(e => e.GetTypeId().Value == mapping.TypeId)
                    .ToList();
            }
            catch (Exception ex)
            {
                Log($"Mapping '{mapping.TypeName}': failed to query linked elements: {ex.Message}", LogSeverity.Error);
                return result;
            }

            result.ElementsFound = matchingElements.Count;
            Log($"{mapping.CategoryName} / {mapping.TypeName}: {matchingElements.Count} candidate(s) found in '{mapping.LinkDisplayName}'.");

            // ── Stage 1: spatial candidate filter ──
            List<Element> spatialCandidates = _spatialFilter.FilterCandidates(
                matchingElements, linkToHost, processingBoundary, linkedDoc);

            Log($"{mapping.TypeName}: {spatialCandidates.Count} candidate(s) survived spatial pre-filter.");

            GraphicsStyle? lineStyle = _lineStyleService.FindByName(hostDoc, mapping.DetailLineStyleName);
            if (lineStyle == null && !string.IsNullOrWhiteSpace(mapping.DetailLineStyleName))
                Log($"Detail Line Style '{mapping.DetailLineStyleName}' not found in host project — lines created with default style.", LogSeverity.Warning);

            double planZ = activeView.GenLevel?.Elevation ?? activeView.Origin.Z;

            foreach (var elem in spatialCandidates)
            {
                try
                {
                    ProcessSingleElement(
                        hostDoc, activeView, linkInstance, linkedDoc, elem, mapping,
                        linkToHost, processingBoundary, scope, complexCurveSettings,
                        lineStyle, planZ, result, Log);
                }
                catch (Exception ex)
                {
                    result.ElementsSkipped++;
                    result.Errors.Add(new ProcessingError
                    {
                        ElementId = elem.Id.Value,
                        CategoryName = mapping.CategoryName,
                        Reason = ex.Message
                    });
                    Log($"Element {elem.Id.Value} ({mapping.TypeName}): unhandled error — {ex.Message}", LogSeverity.Error);
                }
            }

            return result;
        }

        private void ProcessSingleElement(
            Document hostDoc, View activeView, RevitLinkInstance linkInstance, Document linkedDoc,
            Element elem, ElementMapping mapping, Transform linkToHost, List<XYZ> processingBoundary,
            ProcessingScope scope, ComplexCurveSettings complexCurveSettings, GraphicsStyle? lineStyle,
            double planZ, MappingProcessingResult result, Action<string, LogSeverity> log)
        {
            var profile = _extraction.ExtractProfile(elem, complexCurveSettings,
                (msg, id) =>
                {
                    result.ElementsSkipped++;
                    result.Errors.Add(new ProcessingError { ElementId = elem.Id.Value, CategoryName = mapping.CategoryName, Reason = msg });
                    log($"Element {elem.Id.Value}: {msg}", LogSeverity.Warning);
                });

            if (profile == null) return;

            var allLoops = new List<List<Curve>>();
            allLoops.AddRange(profile.OuterLoops);
            allLoops.AddRange(profile.InnerLoops);

            int loopsCreated = 0;

            foreach (var loop in allLoops)
            {
                List<Curve> hostCurves = _transform.TransformCurves(loop, linkToHost);
                List<Curve> planCurves = _projection.ProjectToPlan(hostCurves, planZ);

                ClipResult clip = _clipping.ClipLoop(planCurves, processingBoundary, scope,
                    w => log($"Element {elem.Id.Value}: {w}", LogSeverity.Warning));

                foreach (var w in clip.Warnings)
                    log($"Element {elem.Id.Value}: {w}", LogSeverity.Warning);

                if (clip.FullyOutside)
                    continue; // not an error -- simply outside processing scope

                foreach (var chain in clip.Chains)
                {
                    List<DetailCurve> createdCurves = _lineCreation.CreateDetailCurves(
                        hostDoc, activeView, chain,
                        w => log($"Element {elem.Id.Value}: {w}", LogSeverity.Warning));

                    if (createdCurves.Count == 0) continue;

                    _lineCreation.ApplyLineStyle(createdCurves, lineStyle,
                        w => log($"Element {elem.Id.Value}: {w}", LogSeverity.Warning));

                    foreach (var dc in createdCurves)
                    {
                        _graphicsOverride.ApplyColorOverride(hostDoc, activeView, dc.Id, mapping.ColorName,
                            w => log($"Element {elem.Id.Value}: {w}", LogSeverity.Warning));

                        _metadata.WriteMetadata(
                            dc,
                            mapping.LinkInstanceId,
                            mapping.LinkDisplayName,
                            mapping.CategoryName,
                            mapping.FamilyName,
                            mapping.TypeName,
                            elem.Id.Value,
                            mapping.Representation.ToString(),
                            mapping.MappingId);
                    }

                    result.DetailLinesCreated += createdCurves.Count;
                }

                loopsCreated++;
            }

            if (loopsCreated > 0)
                result.ElementsProcessed++;
            else
                result.ElementsSkipped++;
        }
    }

    public enum LogSeverity { Info, Warning, Error, Success }

    public class MappingProcessingResult
    {
        public Guid MappingId { get; set; }
        public int ElementsFound { get; set; }
        public int ElementsProcessed { get; set; }
        public int ElementsSkipped { get; set; }
        public int DetailLinesCreated { get; set; }
        public List<ProcessingError> Errors { get; set; } = new();
    }
}
