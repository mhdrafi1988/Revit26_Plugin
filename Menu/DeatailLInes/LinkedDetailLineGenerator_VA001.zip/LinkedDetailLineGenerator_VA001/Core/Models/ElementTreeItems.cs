using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Models
{
    /// <summary>
    /// Root node grouping Category items under a single linked model instance.
    /// Only appears when 2+ links are checked in Section 1 (merged-tree display);
    /// with a single link checked, the UI may choose to hide this header row.
    /// </summary>
    public partial class LinkTreeNode : ObservableObject
    {
        public long LinkInstanceId { get; set; }
        public string LinkDisplayName { get; set; } = string.Empty;

        [ObservableProperty]
        private bool _isExpanded = true;

        public ObservableCollection<CategoryTreeItem> Categories { get; set; } = new();
    }

    /// <summary>
    /// Category-level node (e.g. "Floors", "Walls", "Structural Columns").
    /// IsChecked is tri-state driven by child Family/Type checked states
    /// (implemented in MainViewModel's checkbox-cascade logic, Phase 1 UI-only).
    /// </summary>
    public partial class CategoryTreeItem : ObservableObject
    {
        public string CategoryName { get; set; } = string.Empty;

        /// <summary>Which RepresentationGroup tab (Profile/Linear/Point) this category belongs under.</summary>
        public RepresentationGroup Group { get; set; }

        [ObservableProperty]
        private bool _isExpanded = true;

        [ObservableProperty]
        private bool? _isChecked = false;

        public ObservableCollection<FamilyTreeItem> Families { get; set; } = new();
    }

    /// <summary>Family-level node (e.g. "Generic Floor", "Basic Wall").</summary>
    public partial class FamilyTreeItem : ObservableObject
    {
        public string FamilyName { get; set; } = string.Empty;

        [ObservableProperty]
        private bool _isExpanded = true;

        [ObservableProperty]
        private bool? _isChecked = false;

        public ObservableCollection<TypeTreeItem> Types { get; set; } = new();
    }

    /// <summary>
    /// Leaf Type node (e.g. "150mm Floor"). Checking this is what actually
    /// creates/removes a row in the Mapping Grid (Section 3).
    /// </summary>
    public partial class TypeTreeItem : ObservableObject
    {
        public long TypeId { get; set; }
        public string TypeName { get; set; } = string.Empty;

        [ObservableProperty]
        private bool _isChecked;
    }
}
