using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Models
{
    /// <summary>
    /// Section 5 settings: controls how far processing extends and how clipped
    /// Profile-group boundaries are finished off. Persisted to settings.json.
    ///
    /// CapOpenEnds and CloseOpenLoops are mutually exclusive in practice (only one
    /// finishing behavior applies when TrimToBoundary is on and a loop was cut open);
    /// MainViewModel enforces the exclusivity in the UI (Phase 1) — see remarks there.
    /// </summary>
    public partial class ProcessingScope : ObservableObject
    {
        [ObservableProperty]
        private bool _limitToActiveView = true;

        [ObservableProperty]
        private bool _trimToBoundary = true;

        /// <summary>When true, open chains produced by clipping a closed Profile boundary
        /// are stitched back into a closed loop by walking along the clip boundary
        /// between the two open ends (shorter-path direction). See engine notes.</summary>
        [ObservableProperty]
        private bool _closeOpenLoops = false;

        /// <summary>When true (and CloseOpenLoops is false), a single straight segment
        /// caps each open end pair instead of leaving the boundary open. User-controlled
        /// per Rafi's explicit instruction — no silent default behavior.</summary>
        [ObservableProperty]
        private bool _capOpenEnds = false;
    }
}
