using CommunityToolkit.Mvvm.ComponentModel;

namespace Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Models
{
    /// <summary>
    /// Circle marker sizing (Section 4a). Value represents diameter in mm.
    /// Persisted to settings.json.
    /// </summary>
    public partial class CircleMarkerSettings : ObservableObject
    {
        [ObservableProperty]
        private double _diameterMm = 300;

        [ObservableProperty]
        private bool _useUniversalSize = true;
    }

    /// <summary>
    /// Rectangle marker sizing (Section 4b). Width/Height in mm, independent axes.
    /// Persisted to settings.json.
    /// </summary>
    public partial class RectangleMarkerSettings : ObservableObject
    {
        [ObservableProperty]
        private double _widthMm = 300;

        [ObservableProperty]
        private double _heightMm = 300;

        [ObservableProperty]
        private bool _useUniversalSize = true;
    }
}
