namespace Revit26_Plugin.LinkedDetailLineGenerator.VA001.Core.Models
{
    /// <summary>
    /// Broad classification of how a selected linked-model Type will be represented
    /// as 2D Detail Line geometry. Drives which extraction pipeline (Profile / Linear /
    /// Point) is used for a given ElementMapping.
    /// </summary>
    public enum RepresentationGroup
    {
        Profile,
        Linear,
        Point
    }

    /// <summary>
    /// Specific representation mode within a RepresentationGroup.
    /// Profile → Boundary. Linear → Centerline. Point → Circle / Rectangle.
    /// </summary>
    public enum RepresentationMode
    {
        Boundary,
        Centerline,
        Circle,
        Rectangle
    }

    /// <summary>
    /// Point marker shape used for Point-group representations.
    /// Circle and Rectangle each have independent size settings (PointMarkerSettings).
    /// </summary>
    public enum PointMarkerShape
    {
        Circle,
        Rectangle
    }

    /// <summary>
    /// Fallback shape used to replace non-analytic (spline/NURBS) curves when
    /// "Replace complex curves with simplified shape" is enabled in Complex Curve Handling.
    /// StraightChord: single Line from curve start to end.
    /// BestFitArc: single Arc fit through start/mid/end; falls back to StraightChord
    /// automatically if curvature sign is inconsistent (see GeometryExtractionService).
    /// </summary>
    public enum SplineFallbackShape
    {
        StraightChord,
        BestFitArc
    }

    /// <summary>
    /// Overall tool run state. Drives the "gray out / inactive" UI behavior:
    /// form is interactive only while Idle or Configuring; becomes read-only
    /// once Complete, until the user explicitly resets to a new session.
    /// </summary>
    public enum ToolRunState
    {
        Idle,
        Configuring,
        Running,
        Complete
    }
}
